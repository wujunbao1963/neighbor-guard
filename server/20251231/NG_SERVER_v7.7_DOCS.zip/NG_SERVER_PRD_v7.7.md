# NG_SERVER_PRD_v7.7.md
# NeighborGuard Server v7.7 产品需求文档

## 1. 文档目的
本文档定义 NeighborGuard Server 在 **v7.7 协议下**的完整行为语义，覆盖：
- Edge → Server 事件与证据上报
- App → Server 事件与证据读取
- 幂等、乱序、重放处理规则
- 证据访问授权、安全与限流
- 审计与生命周期管理

> 本 PRD 以“当前实现即规范”为原则，所有行为均已通过 e2e 验证。

## 2. 系统角色
### 2.1 Edge（边缘设备）
- 负责事件检测、状态机推进
- 上报事件摘要（Event Summary）
- 上报证据索引（Incident Manifest）

### 2.2 Server（中心服务）
- 接收并收敛 Edge 上报
- 提供事件与证据读取接口
- 统一授权、审计、限流

### 2.3 App（用户侧）
- 查看事件与证据
- 通过 ticket 拉取证据内容

## 3. Edge → Server：事件上报
### 3.1 Event Summary Upsert
POST /api/circles/:circleId/edge/events/summary-upsert

**收敛规则**
- sequence < last → stale_sequence
- sequence == last & payloadHash 相同 → duplicate_payload
- sequence == last & updatedAt <= last → stale_timestamp
- sequence > last → applied

返回：
{
  ok, applied, reason, serverReceivedAt
}

### 3.2 Incident Manifest Upsert
POST /api/circles/:circleId/edge/events/:eventId/incident/manifest-upsert

描述事件下的证据索引（不传输内容）。

## 4. App → Server：读取与授权
### 4.1 获取 Incident Manifest
GET /api/circles/:circleId/events/:eventId/incident/manifest

### 4.2 创建 Evidence Ticket
POST /api/circles/:circleId/events/:eventId/evidence/tickets

ticket 绑定 user，仅授权单 evidenceKey。

### 4.3 Resolve Ticket
GET /api/evidence/tickets/:ticketId/resolve

## 5. Evidence 下载（Server Proxy）
GET /api/evidence/tickets/:ticketId/download
- 支持 Range
- Server 代理 edgeUrl

GET /api/evidence/tickets/:ticketId/meta

## 6. 并发控制与限流
- DB lease：UNIQUE(ticket_id, lease_type)
- 同 ticket 同时仅 1 个 download
- 第二个并发 → 429

## 7. 审计
- ng_edge_ingest_audit
- ng_evidence_download_audit

## 8. 生命周期管理
POST /api/admin/maintenance/purge-expired
- 清理过期 tickets / leases

## 9. 安全原则
- ticket 绑定 user
- evidenceKey 必须存在于 manifest
- server 作为唯一下载出口（MVP）
