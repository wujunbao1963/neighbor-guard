# NG_SERVER_ARCH_v7.7.md
# NeighborGuard Server v7.7 架构设计文档

## 1. 架构目标
- 保证 Edge 上报乱序/重放安全
- 保证证据访问的安全、可审计、可限流
- 支持 Server Proxy 与未来直连/云存储演进
- 实现即规范，代码与文档一一对应

## 2. 总体架构
Edge → Server → App
Server 作为唯一仲裁与访问中介：
- 一致性收敛
- 权限校验
- 下载代理
- 审计与限流

## 3. 数据模型

### 3.1 事件相关
- ng_edge_events（事件快照）
- ng_edge_event_summaries_raw（原始上报）

### 3.2 证据索引
- ng_incident_manifests（manifest 快照）
- ng_incident_manifests_raw

### 3.3 授权与访问
- ng_evidence_access_tickets
- ng_evidence_download_leases
- ng_evidence_download_audit

### 3.4 审计
- ng_edge_ingest_audit

## 4. 核心流程

### 4.1 Event Summary Ingest
Edge → summary-upsert  
→ 校验 contract  
→ raw landing  
→ snapshot 收敛  
→ ingest_audit

### 4.2 Manifest Ingest
Edge → manifest-upsert  
→ raw landing  
→ snapshot 收敛  
→ ingest_audit

### 4.3 Evidence 下载（Server Proxy）
App → /download  
→ 校验 ticket/user  
→ acquire lease  
→ fetch(edgeUrl)  
→ stream response  
→ await finished  
→ release lease  
→ write audit

## 5. 幂等与乱序处理
- sequence 主导
- payloadHash 判重
- updatedAt 辅助判断

## 6. 并发控制
- DB Lease（UNIQUE(ticket_id, lease_type)）
- 防止并发下载/风暴

## 7. 安全设计
- ticket 绑定 user
- evidenceKey 必须存在于 manifest
- server proxy 防止 App 直连内网 Edge

## 8. 迁移与演进
- Edge signed URL
- S3/CDN
- 一次性 ticket
- 下载限速与配额

## 9. 已验证状态
- 全链路 e2e 全绿
- 支持 Range/206
- 支持 purge-expired

