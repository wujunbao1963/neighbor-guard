import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { NgIncidentManifest } from '../edge-events/ng-incident-manifest.entity';
import { NgEvidenceAccessTicket } from './ng-evidence-access-ticket.entity';

@Injectable()
export class EvidenceTicketsService {
  constructor(
    @InjectRepository(NgEvidenceAccessTicket)
    private readonly repo: Repository<NgEvidenceAccessTicket>,
    @InjectRepository(NgIncidentManifest)
    private readonly manifests: Repository<NgIncidentManifest>,
  ) {}

  async createTicket(args: {
    circleId: string;
    eventId: string;
    requesterUserId: string;
    evidenceKey: string;
    ttlSec: number;
  }): Promise<NgEvidenceAccessTicket> {
    const ttl = Math.max(30, Math.min(args.ttlSec, 3600));
    const expiresAt = new Date(Date.now() + ttl * 1000);

    const row = this.repo.create({
      circleId: args.circleId,
      eventId: args.eventId,
      requesterUserId: args.requesterUserId,
      evidenceKey: args.evidenceKey,
      expiresAt,
    });

    return this.repo.save(row);
  }

  async resolveTicket(args: {
    ticketId: string;
  }): Promise<{
    ticket: NgEvidenceAccessTicket | null;
    manifest: NgIncidentManifest | null;
  }> {
    const ticket = await this.repo.findOne({ where: { ticketId: args.ticketId } });
    if (!ticket) return { ticket: null, manifest: null };
    const manifest = await this.manifests.findOne({ where: { circleId: ticket.circleId, eventId: ticket.eventId } });
    return { ticket, manifest };
  }
}
