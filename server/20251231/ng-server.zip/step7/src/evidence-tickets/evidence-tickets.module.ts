import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ContractsModule } from '../common/contracts/contracts.module';
import { CirclesModule } from '../circles/circles.module';
import { NgIncidentManifest } from '../edge-events/ng-incident-manifest.entity';
import { NgEvidenceAccessTicket } from './ng-evidence-access-ticket.entity';
import { EvidenceTicketsController } from './evidence-tickets.controller';
import { EvidenceTicketResolveController } from './evidence-ticket-resolve.controller';
import { EvidenceTicketDownloadController } from './evidence-ticket-download.controller';
import { EvidenceTicketsService } from './evidence-tickets.service';

@Module({
  imports: [TypeOrmModule.forFeature([NgEvidenceAccessTicket, NgIncidentManifest]), CirclesModule, ContractsModule],
  controllers: [EvidenceTicketsController, EvidenceTicketResolveController, EvidenceTicketDownloadController],
  providers: [EvidenceTicketsService],
})
export class EvidenceTicketsModule {}
