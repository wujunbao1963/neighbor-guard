import {
  BadGatewayException,
  Controller,
  ForbiddenException,
  Get,
  NotFoundException,
  Param,
  ParseUUIDPipe,
  Req,
  Res,
  UseGuards,
} from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';
import { Response } from 'express';
import { Readable } from 'stream';
import { CirclesService } from '../circles/circles.service';
import { JwtUser } from '../auth/auth.types';
import { EvidenceTicketsService } from './evidence-tickets.service';

@Controller('/api/evidence/tickets')
export class EvidenceTicketDownloadController {
  constructor(
    private readonly svc: EvidenceTicketsService,
    private readonly circles: CirclesService,
  ) {}

  @Get(':ticketId/download')
  @UseGuards(AuthGuard('jwt'))
  async download(
    @Req() req: { user: JwtUser },
    @Param('ticketId', new ParseUUIDPipe({ version: '4' })) ticketId: string,
    @Res() res: Response,
  ) {
    const { ticket, manifest } = await this.svc.resolveTicket({ ticketId });
    if (!ticket) throw new NotFoundException();

    await this.circles.mustBeMember(req.user.userId, ticket.circleId);

    const now = Date.now();
    if (ticket.expiresAt.getTime() <= now) {
      throw new ForbiddenException('ticket expired');
    }

    if (!manifest) {
      throw new NotFoundException('incident manifest not found');
    }

    const payload: any = manifest.manifestJson as any;
    const items: any[] = Array.isArray(payload?.manifest?.items) ? payload.manifest.items : [];
    const found = items.find((x) => x && x.evidenceKey === ticket.evidenceKey);
    const edgeUrl = found && typeof found.edgeUrl === 'string' ? found.edgeUrl : null;
    if (!edgeUrl) {
      throw new NotFoundException('evidence not available');
    }

    // Proxy download from edgeUrl.
    const ac = new AbortController();
    const timeout = setTimeout(() => ac.abort(), 15000);
    let upstream: globalThis.Response;
    try {
      upstream = await fetch(edgeUrl, { signal: ac.signal });
    } catch (e) {
      throw new BadGatewayException('failed to fetch evidence');
    } finally {
      clearTimeout(timeout);
    }

    if (!upstream.ok || !upstream.body) {
      throw new BadGatewayException(`upstream responded ${upstream.status}`);
    }

    const contentType = upstream.headers.get('content-type') || 'application/octet-stream';
    res.setHeader('Content-Type', contentType);
    const len = upstream.headers.get('content-length');
    if (len) res.setHeader('Content-Length', len);

    // Pipe web stream to Node response.
    const nodeReadable = Readable.fromWeb(upstream.body as any);
    nodeReadable.pipe(res);
  }
}
