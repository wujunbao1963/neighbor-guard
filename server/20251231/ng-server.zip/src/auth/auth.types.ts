export type JwtUser = {
  userId: string;
  email: string;
};
