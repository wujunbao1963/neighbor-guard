# NG-EDGE 架构审计报告

## 目标架构 (你提出的三层模型)

```
┌─────────────────────────────────────────────────────────────────┐
│                     1. SIGNAL LAYER                              │
│  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐  │
│  │ Camera PRE      │  │ Sensor          │  │ Health          │  │
│  │ Pipeline        │  │ Pipeline        │  │ Monitor         │  │
│  │                 │  │                 │  │                 │  │
│  │ → PreSignal     │  │ → HardSignal    │  │ → HealthSignal  │  │
│  │   (L1/L2/L3)    │  │   (doorOpen,    │  │   (tamper,      │  │
│  │                 │  │    glassBreak)  │  │    offline)     │  │
│  └────────┬────────┘  └────────┬────────┘  └────────┬────────┘  │
│           │                    │                    │           │
│           └───────────────┬────┴────────────────────┘           │
│                           ↓                                      │
└───────────────────────────┼─────────────────────────────────────┘
                            │
┌───────────────────────────┼─────────────────────────────────────┐
│                     2. CORRELATION LAYER                         │
│                           ↓                                      │
│  ┌─────────────────────────────────────────────────────────────┐│
│  │               Signal Correlator                              ││
│  │  - 时间窗匹配 (T±30s)                                        ││
│  │  - 区域/拓扑匹配 (zone/entrypoint)                           ││
│  │  - 去重与合并                                                ││
│  │  - 冲突隔离                                                  ││
│  └──────────────────────────┬──────────────────────────────────┘│
│                             ↓                                    │
│              IncidentCandidate{signals[], scores,                │
│                   recommended_actions, evidence_hints}           │
└─────────────────────────────┼───────────────────────────────────┘
                              │
┌─────────────────────────────┼───────────────────────────────────┐
│                     3. INCIDENT STATE MACHINE                    │
│                             ↓                                    │
│  ┌────────────────────────────────────────────────────────────┐ │
│  │  维度1: Threat Level                                        │ │
│  │  NONE → PRE_L1 → PRE_L2 → PRE_L3 → PENDING → TRIGGERED     │ │
│  │                                                             │ │
│  │  维度2: Workflow                                            │ │
│  │  IDLE → NOTIFIED → VERIFYING → ESCALATED → RESOLVED        │ │
│  └────────────────────────────────────────────────────────────┘ │
│                             │                                    │
│  ┌──────────────────────────┼─────────────────────────────────┐ │
│  │              Action Gate (按状态授权)                       │ │
│  │  PRE_L1: 静默记录                                          │ │
│  │  PRE_L2: 推关注通知 + live view                            │ │
│  │  PRE_L3: 强预警 + 自动拉证据                               │ │
│  │  PENDING: 需要确认                                         │ │
│  │  TRIGGERED: 警号/协作/报警                                 │ │
│  └────────────────────────────────────────────────────────────┘ │
│                             ↓                                    │
│              Output Channels (Keypad, Camera, Cloud...)          │
└──────────────────────────────────────────────────────────────────┘
```

---

## 当前架构分析

### 现有组件映射

| 目标层 | 当前组件 | 状态 | 问题 |
|--------|----------|------|------|
| **Signal Layer** | | | |
| - Camera PRE Pipeline | `camera_signal_source.py` | 存在但未集成 | 输出 Signal，但不是 PreSignal |
| - Sensor Pipeline | `zigbee_signal_router.py` | ✅ 工作中 | 直接发送到状态机，没有关联层 |
| - Health Monitor | 不存在 | ❌ | 无 tamper/offline 检测 |
| **Correlation Layer** | | | |
| - Signal Correlator | 不存在 | ❌ | 信号直接到状态机，无关联 |
| **Incident SM** | | | |
| - State Machine | `state_machine_v5.py` | ✅ 工作中 | 但直接处理原始信号 |
| - Action Gate | `manager.py._trigger_camera_deterrent()` | 部分 | 在回调中散落 |
| - Output Channels | `output_channels.py`, `camera_output_channel.py` | 部分 | 未统一 |

### 关键架构问题

#### 问题 1: 信号直通状态机，没有 Correlation Layer

```
当前:
  Zigbee Sensor → ZigbeeSignalRouter → SecurityCoordinator.process()
                                              ↓
                                       直接触发状态转换

缺失:
  - 时间窗匹配
  - 跨源关联 (PRE + door_open)
  - 去重合并
```

#### 问题 2: PRE 和 PENDING/TRIGGERED 混在同一状态维度

```
当前状态机 (state_machine_v5.py):
  AlarmState: QUIET → ATTENTION → PRE → PENDING → TRIGGERED

问题:
  - PRE 是摄像头驱动的"软"状态
  - PENDING/TRIGGERED 是传感器驱动的"硬"状态
  - 它们不应该在同一条线上
  - PRE 不应该阻塞 PENDING 的进入
```

#### 问题 3: Action Gate 分散在多处

```
当前:
  manager.py:421  → _trigger_camera_deterrent()
  manager.py:400  → _sync_keypad_state()
  
问题:
  - 动作触发逻辑分散
  - 无统一的权限控制
  - 难以测试
```

#### 问题 4: 没有 Lock/Lease 机制

```
当前:
  - 每个信号独立处理
  - 可能导致重复事件
  - 无事件窗口管理
```

---

## 重构方案

### Phase 1: 信号类型分离 (立即可做)

```python
# 新文件: ng_edge/domain/signals.py

class BaseSignal(BaseModel):
    """基础信号"""
    signal_id: str
    timestamp: datetime
    source_type: Literal["camera", "sensor", "health"]
    entry_point_id: Optional[str] = None
    zone_id: Optional[str] = None

class PreSignal(BaseSignal):
    """摄像头 PRE 信号 (软信号)"""
    source_type: Literal["camera"] = "camera"
    level: Literal["L0", "L1", "L2", "L3"]
    confidence: float
    target_class: str  # person, vehicle
    trajectory: Optional[dict] = None
    direction: Optional[str] = None
    
class HardSignal(BaseSignal):
    """传感器硬信号 (可触发 PENDING/TRIGGERED)"""
    source_type: Literal["sensor"] = "sensor"
    signal_type: Literal["door_open", "door_close", "glass_break", "motion"]
    device_id: str
    
class HealthSignal(BaseSignal):
    """系统健康信号"""
    source_type: Literal["health"] = "health"
    signal_type: Literal["tamper_s", "tamper_c", "offline", "battery_low"]
    device_id: str
```

### Phase 2: Correlation Layer (核心重构)

```python
# 新文件: ng_edge/services/signal_correlator.py

class IncidentCandidate:
    """事件候选"""
    candidate_id: str
    signals: List[BaseSignal]
    zone_id: str
    entry_point_id: Optional[str]
    start_time: datetime
    last_update: datetime
    
    # 评分
    threat_score: float
    confidence: float
    
    # 建议
    recommended_threat_level: ThreatLevel
    recommended_actions: List[str]
    evidence_hints: List[str]

class SignalCorrelator:
    """信号关联器"""
    
    def __init__(self, correlation_window_sec: int = 30):
        self.window_sec = correlation_window_sec
        self.active_candidates: Dict[str, IncidentCandidate] = {}
    
    def process(self, signal: BaseSignal) -> Optional[IncidentCandidate]:
        """
        处理信号，返回更新后的 IncidentCandidate
        
        规则:
        1. 在时间窗内，同一 zone/entry_point 的信号归并
        2. PreSignal 只能提升到 PRE_Lx
        3. HardSignal 可以提升到 PENDING/TRIGGERED
        4. 多信号关联提升置信度
        """
        pass
```

### Phase 3: 双维度状态机 (核心重构)

```python
# 修改: ng_edge/services/incident_state_machine.py

class ThreatLevel(str, Enum):
    """威胁等级 (由信号驱动)"""
    NONE = "none"
    PRE_L1 = "pre_l1"  # 低置信检测
    PRE_L2 = "pre_l2"  # 持续关注
    PRE_L3 = "pre_l3"  # 强预警
    PENDING = "pending"  # 入口延迟
    TRIGGERED = "triggered"  # 报警

class WorkflowState(str, Enum):
    """工作流状态 (由处置进度驱动)"""
    IDLE = "idle"
    NOTIFIED = "notified"
    VERIFYING = "verifying"
    ESCALATED = "escalated"
    RESOLVED = "resolved"
    CLOSED = "closed"

class IncidentState:
    """事件状态 (双维度)"""
    threat_level: ThreatLevel
    workflow_state: WorkflowState
    
class IncidentStateMachine:
    """事件状态机"""
    
    def process_candidate(self, candidate: IncidentCandidate) -> ActionSet:
        """
        处理 IncidentCandidate，返回授权的动作集
        
        规则:
        1. PRE_Lx 只能执行 PRE 动作集 (灯光、通知)
        2. PENDING/TRIGGERED 才能执行硬动作 (警号、报警)
        3. 两个维度互不干扰
        """
        pass
```

### Phase 4: Action Gate (统一动作控制)

```python
# 新文件: ng_edge/services/action_gate.py

class ActionGate:
    """动作闸门 - 按威胁等级授权动作"""
    
    ALLOWED_ACTIONS = {
        ThreatLevel.NONE: [],
        ThreatLevel.PRE_L1: ["log", "cache_evidence"],
        ThreatLevel.PRE_L2: ["log", "cache_evidence", "notify_light", "live_view_ready"],
        ThreatLevel.PRE_L3: ["log", "cache_evidence", "notify_strong", "live_view_ready", "pull_clip"],
        ThreatLevel.PENDING: ["log", "cache_evidence", "notify_urgent", "keypad_countdown", "prepare_siren"],
        ThreatLevel.TRIGGERED: ["log", "full_evidence", "notify_alarm", "siren", "collaboration", "dispatch"],
    }
    
    def authorize(self, threat_level: ThreatLevel, requested_action: str) -> bool:
        """检查动作是否被授权"""
        return requested_action in self.ALLOWED_ACTIONS.get(threat_level, [])
```

---

## 重构优先级

| 优先级 | 任务 | 影响 | 工作量 |
|--------|------|------|--------|
| P0 | 修复当前 port 参数问题 | 阻塞测试 | 小 ✅ 已完成 |
| P0 | 修复 PENDING 威慑逻辑 | 功能错误 | 小 ✅ 已完成 |
| P1 | 信号类型分离 (PreSignal/HardSignal) | 架构基础 | 中 |
| P1 | Correlation Layer 基础版 | 核心能力 | 中 |
| P2 | 双维度状态机 | 解耦 PRE 和 PENDING | 大 |
| P2 | Action Gate 统一 | 可测试性 | 中 |
| P3 | Lock/Lease 机制 | 去重防抖 | 中 |
| P3 | Evidence Policy 分离 | 存储优化 | 中 |

---

## 当前可以继续的路径

### 选项 A: 先让当前系统工作 (战术修复)

1. 修复 port 参数问题 ✅
2. 修复 PENDING 威慑逻辑 ✅  
3. 测试端到端流程 (Zigbee → 状态机 → 摄像头威慑)
4. 逐步引入 Correlation Layer

**优点**: 快速验证，保持系统可用
**缺点**: 技术债务累积

### 选项 B: 重构后再测试 (战略重构)

1. 先实现 PreSignal/HardSignal 分离
2. 实现基础 Correlation Layer
3. 修改状态机接受 IncidentCandidate
4. 统一 Action Gate
5. 再做端到端测试

**优点**: 架构干净，易于扩展
**缺点**: 时间长，风险高

### 建议: 混合路径

1. **先让当前系统跑起来** (验证硬件集成)
2. **在工作系统基础上重构** (有回归测试保护)
3. **逐步替换组件** (不破坏现有功能)

---

## 结论

当前架构与目标三层模型有以下差距:

1. **缺少 Correlation Layer** - 信号直通状态机
2. **PRE 和 PENDING/TRIGGERED 未分离** - 混在同一状态线
3. **Action Gate 分散** - 难以统一控制
4. **无 Lock/Lease** - 可能重复触发

但当前系统的核心组件 (状态机、Zigbee 路由、摄像头控制) 都存在，可以在此基础上重构。

**建议先完成当前修复的测试，确认硬件集成工作，然后逐步引入三层架构。**
