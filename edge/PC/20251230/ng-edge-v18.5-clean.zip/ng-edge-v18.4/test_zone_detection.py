#!/usr/bin/env python3
"""
YOLO 分区检测测试脚本

用法：
    # 测试单张图片
    python3 test_zone_detection.py --image test.jpg
    
    # 测试视频（按 q 退出）
    python3 test_zone_detection.py --video test.mp4
    
    # 测试 RTSP 流（按 q 退出）
    python3 test_zone_detection.py --rtsp rtsp://admin:password@10.0.0.155:554/h264Preview_01_sub
    
    # 自定义阈值
    python3 test_zone_detection.py --image test.jpg --door-threshold 0.55 --yard-threshold 0.20
"""

import argparse
import cv2
import numpy as np
from ultralytics import YOLO


def get_zone(bbox_xyxy, frame_height, door_y_px=None, yard_y_px=None, 
              door_threshold=None, yard_threshold=None):
    """
    根据 bbox (x1, y1, x2, y2) 判断分区
    
    可以用像素值或百分比指定分界线：
    - door_y_px=400 表示 y >= 400 是 door 区
    - 或 door_threshold=0.69 表示 y >= height * 0.69 是 door 区
    """
    x1, y1, x2, y2 = bbox_xyxy
    y_bottom = y2  # 脚的位置
    
    # 优先使用像素值
    if door_y_px is not None:
        door_y = door_y_px
    elif door_threshold is not None:
        door_y = int(frame_height * door_threshold)
    else:
        door_y = int(frame_height * 0.69)  # 默认 400/576
    
    if yard_y_px is not None:
        yard_y = yard_y_px
    elif yard_threshold is not None:
        yard_y = int(frame_height * yard_threshold)
    else:
        yard_y = 0  # 默认没有 street 区
    
    if y_bottom >= door_y:
        return "door", 2, door_y, yard_y
    elif y_bottom >= yard_y:
        return "yard", 1, door_y, yard_y
    else:
        return "street", 0, door_y, yard_y


def draw_zones(frame, door_y, yard_y):
    """绘制分区线"""
    h, w = frame.shape[:2]
    
    # door 分界线（红色）
    cv2.line(frame, (0, door_y), (w, door_y), (0, 0, 255), 2)
    cv2.putText(frame, f"door_y={door_y}", (10, door_y - 10), 
                cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 0, 255), 2)
    
    # yard 分界线（黄色）
    cv2.line(frame, (0, yard_y), (w, yard_y), (0, 255, 255), 2)
    cv2.putText(frame, f"yard_y={yard_y}", (10, yard_y - 10), 
                cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 255), 2)
    
    # 区域标签
    cv2.putText(frame, "STREET (L0)", (w - 150, yard_y - 30), 
                cv2.FONT_HERSHEY_SIMPLEX, 0.6, (128, 128, 128), 2)
    cv2.putText(frame, "YARD (L1)", (w - 150, (yard_y + door_y) // 2), 
                cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 255), 2)
    cv2.putText(frame, "DOOR (L2)", (w - 150, door_y + 30), 
                cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 0, 255), 2)


def process_frame(model, frame, door_y_px=None, yard_y_px=None, conf_threshold=0.3):
    """处理单帧"""
    h, w = frame.shape[:2]
    
    # YOLO 检测
    results = model(frame, verbose=False, conf=conf_threshold)
    
    detections = []
    for r in results:
        for box in r.boxes:
            cls_id = int(box.cls[0])
            if model.names[cls_id] == "person":
                conf = float(box.conf[0])
                bbox = [int(v) for v in box.xyxy[0].tolist()]
                zone, level, door_y, yard_y = get_zone(bbox, h, door_y_px=door_y_px, yard_y_px=yard_y_px)
                detections.append({
                    "bbox": bbox,
                    "conf": conf,
                    "zone": zone,
                    "level": level,
                    "door_y": door_y,
                    "yard_y": yard_y,
                })
    
    # 绘制结果
    vis_frame = frame.copy()
    
    if detections:
        # 使用第一个检测的分区线
        draw_zones(vis_frame, detections[0]["door_y"], detections[0]["yard_y"])
        
        for det in detections:
            x1, y1, x2, y2 = det["bbox"]
            zone = det["zone"]
            level = det["level"]
            conf = det["conf"]
            
            # 颜色：door=红, yard=黄, street=灰
            colors = {"door": (0, 0, 255), "yard": (0, 255, 255), "street": (128, 128, 128)}
            color = colors.get(zone, (0, 255, 0))
            
            # 绘制边界框
            cv2.rectangle(vis_frame, (x1, y1), (x2, y2), color, 3)
            
            # 绘制标签
            label = f"PERSON {conf:.2f} | {zone} L{level} | y2={y2}"
            cv2.putText(vis_frame, label, (x1, y1 - 10), 
                        cv2.FONT_HERSHEY_SIMPLEX, 0.6, color, 2)
            
            # 打印详细信息
            print(f"[DETECT] bbox=({x1},{y1},{x2},{y2}) conf={conf:.2f} "
                  f"y_bottom={y2} door_y={det['door_y']} → {zone} L{level}")
    else:
        # 没有检测到人，也绘制分区线
        door_y = door_y_px if door_y_px else 400
        yard_y = yard_y_px if yard_y_px else 0
        draw_zones(vis_frame, door_y, yard_y)
    
    # 显示帧信息
    door_y_show = door_y_px if door_y_px else 400
    yard_y_show = yard_y_px if yard_y_px else 0
    info = f"Frame: {w}x{h} | door_y={door_y_show} | yard_y={yard_y_show}"
    cv2.putText(vis_frame, info, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
    
    return vis_frame, detections


def test_image(model, image_path, door_y_px, yard_y_px, output_path=None):
    """测试单张图片"""
    print(f"\n[TEST] 加载图片: {image_path}")
    frame = cv2.imread(image_path)
    if frame is None:
        print(f"[ERROR] 无法加载图片: {image_path}")
        return
    
    h, w = frame.shape[:2]
    print(f"[INFO] 图片尺寸: {w}x{h}")
    print(f"[INFO] door_y={door_y_px}px (y >= {door_y_px} → door L2)")
    print(f"[INFO] yard_y={yard_y_px}px (y >= {yard_y_px} → yard L1)")
    print()
    
    vis_frame, detections = process_frame(model, frame, door_y_px, yard_y_px)
    
    if not detections:
        print("[INFO] 未检测到人")
    
    # 保存结果
    if output_path is None:
        output_path = image_path.rsplit('.', 1)[0] + '_zones.jpg'
    cv2.imwrite(output_path, vis_frame)
    print(f"\n[OUTPUT] 已保存: {output_path}")
    
    # 显示
    cv2.imshow("Zone Detection Test", vis_frame)
    print("[INFO] 按任意键关闭窗口")
    cv2.waitKey(0)
    cv2.destroyAllWindows()


def test_video(model, source, door_y_px, yard_y_px, is_rtsp=False):
    """测试视频或 RTSP"""
    print(f"\n[TEST] 打开视频源: {source}")
    
    cap = cv2.VideoCapture(source)
    if not cap.isOpened():
        print(f"[ERROR] 无法打开视频源: {source}")
        return
    
    w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    fps = cap.get(cv2.CAP_PROP_FPS) or 30
    
    # 如果没有指定，使用默认值
    if door_y_px is None:
        door_y_px = 400 if h == 576 else int(h * 0.69)
    if yard_y_px is None:
        yard_y_px = 0
    
    print(f"[INFO] 视频尺寸: {w}x{h} @ {fps:.1f}fps")
    print(f"[INFO] door_y={door_y_px}px (y >= {door_y_px} → door L2)")
    print(f"[INFO] yard_y={yard_y_px}px (y >= {yard_y_px} → yard L1)")
    print("[INFO] 按 'q' 退出, 's' 保存当前帧")
    print()
    
    frame_count = 0
    while True:
        ret, frame = cap.read()
        if not ret:
            if is_rtsp:
                continue
            else:
                break
        
        frame_count += 1
        
        # 每 N 帧处理一次
        if frame_count % 3 != 0:
            continue
        
        vis_frame, detections = process_frame(model, frame, door_y_px, yard_y_px)
        
        cv2.imshow("Zone Detection Test (q=quit, s=save)", vis_frame)
        
        key = cv2.waitKey(1) & 0xFF
        if key == ord('q'):
            break
        elif key == ord('s'):
            save_path = f"frame_{frame_count:06d}_zones.jpg"
            cv2.imwrite(save_path, vis_frame)
            print(f"[SAVED] {save_path}")
    
    cap.release()
    cv2.destroyAllWindows()
    print(f"\n[INFO] 共处理 {frame_count} 帧")


def main():
    parser = argparse.ArgumentParser(description="YOLO 分区检测测试")
    
    # 输入源
    parser.add_argument("--image", help="测试图片路径")
    parser.add_argument("--video", help="测试视频路径")
    parser.add_argument("--rtsp", help="RTSP URL")
    
    # 分区阈值（直接用像素值，更直观）
    parser.add_argument("--door-y", type=int, default=400,
                        help="door 区分界线 y 坐标 (默认 400，即 y >= 400 是 door L2)")
    parser.add_argument("--yard-y", type=int, default=0,
                        help="yard 区分界线 y 坐标 (默认 0，即没有 street 区)")
    
    # 其他
    parser.add_argument("--model", default="yolo11s.pt", help="YOLO 模型")
    parser.add_argument("--output", help="输出图片路径")
    
    args = parser.parse_args()
    
    # 加载模型
    print(f"[YOLO] 加载模型: {args.model}")
    model = YOLO(args.model)
    print("[YOLO] 模型已加载")
    
    if args.image:
        test_image(model, args.image, args.door_y, args.yard_y, args.output)
    elif args.video:
        test_video(model, args.video, args.door_y, args.yard_y)
    elif args.rtsp:
        test_video(model, args.rtsp, args.door_y, args.yard_y, is_rtsp=True)
    else:
        parser.print_help()
        print("\n示例 (1920x576 RTSP 流, door_y=400):")
        print("  python3 test_zone_detection.py --image test.jpg --door-y 400")
        print("  python3 test_zone_detection.py --video test.mp4 --door-y 400")
        print("  python3 test_zone_detection.py --rtsp 'rtsp://admin:pass@10.0.0.155:554/h264Preview_01_sub' --door-y 400")


if __name__ == "__main__":
    main()
