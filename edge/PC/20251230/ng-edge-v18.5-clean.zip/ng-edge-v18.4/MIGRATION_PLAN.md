# NG-EDGE 组件剥离与测试计划

> 目标：将已验证工作的硬件基础和基础逻辑按新架构要求剥离，逐个测试合格后再推进

---

## 1. 当前组件清单

### 1.1 已验证工作的组件 ✅

| 组件 | 文件 | 测试状态 | 说明 |
|------|------|----------|------|
| **CameraOutputChannel** | `hardware/camera_output_channel.py` | ✅ 15/15 测试通过 | 摄像头威慑输出 |
| **ReolinkCameraControl** | `hardware/reolink_control.py` | ✅ 实机验证 | reolink_aio 底层控制 |
| **SecurityCoordinator** | `services/state_machine_v5.py` | ✅ 功能验证 | 核心状态机 |
| **ZigbeeSignalRouter** | `api/zigbee_signal_router.py` | ✅ 实机验证 | Zigbee 信号路由 |

### 1.2 存在但未充分测试的组件 ⚠️

| 组件 | 文件 | 状态 | 问题 |
|------|------|------|------|
| **CameraManager** | `hardware/camera_manager.py` | ⚠️ 部分工作 | 与 OutputChannel 有重复 |
| **RingKeypadMQTT** | `hardware/ring_keypad_mqtt.py` | ⚠️ 代码存在 | 需要实机测试 |
| **ZigbeeDiscovery** | `hardware/zigbee_discovery.py` | ⚠️ 代码存在 | 自动发现逻辑 |
| **DevicePool** | `hardware/device_pool.py` | ⚠️ 代码存在 | 设备管理 |

### 1.3 需要新建的组件 (v2.2 架构)

| 组件 | 目标文件 | 依赖 | 优先级 |
|------|----------|------|--------|
| **SignalEnvelope** | `core/signal.py` | 无 | P0 |
| **ContextGateManager** | `core/context_gate.py` | SignalEnvelope | P1 |
| **LeaseManager** | `correlation/lease_manager.py` | SignalEnvelope | P1 |
| **Correlator** | `correlation/correlator.py` | LeaseManager | P1 |
| **IncidentStateMachine** | `state/incident_sm.py` | Correlator | P2 |
| **ActionGate** | `action/action_gate.py` | IncidentStateMachine | P2 |
| **ReplayEngine** | `replay/engine.py` | 全部 | P0 (测试基础) |

---

## 2. 剥离策略

### 2.1 原则

1. **先稳固，后演化**：确保现有组件测试通过后再改造
2. **小步快走**：每次只改一个组件，测试通过后再继续
3. **接口先行**：先定义接口/数据结构，再实现逻辑
4. **Replay 驱动**：用 Replay Engine 验证每个改造步骤

### 2.2 剥离顺序

```
Phase 0: 基础设施 (本次)
├── 0.1 创建 pytest 配置
├── 0.2 创建核心数据结构 (SignalEnvelope)
├── 0.3 创建 Replay Contract 框架
└── 0.4 为现有组件补充单元测试

Phase 1: Signal Layer 适配
├── 1.1 ZigbeeSignalRouter → 输出 SignalEnvelope
├── 1.2 CameraSignalSource → 输出 SignalEnvelope
└── 1.3 添加 camera_role, context_gate 字段

Phase 2: State Machine 重构
├── 2.1 提取 TransitionRule 到 RuleRegistry
├── 2.2 添加 JudgeAvailabilityState
├── 2.3 拆分 ThreatState / WorkflowState
└── 2.4 添加 Sub-Phase 支持

Phase 3: Correlation Layer 新建
├── 3.1 LeaseManager
├── 3.2 IncidentCandidate 结构
├── 3.3 Correlator 逻辑
└── 3.4 Context Gate TTL 管理

Phase 4: Action Layer 统一
├── 4.1 ActionGate 权限矩阵
├── 4.2 ActionExecutor 统一执行
├── 4.3 SirenPolicy 评估
└── 4.4 Evidence Policy (CANDIDATE)
```

---

## 3. Phase 0 详细计划

### 3.1 创建 pytest 配置

```ini
# pytest.ini
[pytest]
testpaths = src/ng_edge/tests tests
python_files = test_*.py
python_classes = Test*
python_functions = test_*
asyncio_mode = auto
addopts = -v --tb=short
```

### 3.2 核心数据结构

```python
# src/ng_edge/core/signal.py

@dataclass
class SignalEnvelope:
    """统一信号包络 (v2.2 Spec §1.1)"""
    signal_id: str
    source_type: Literal["camera", "sensor", "health", "context"]
    device_id: str
    
    zone_id: str
    entrypoint_id: Optional[str]
    
    signal_kind: str
    hardness: Literal["soft", "hard"]
    level: Optional[Literal["PRE_L1", "PRE_L2", "PRE_L3"]]
    confidence: float
    
    timestamp: datetime
    ingest_ts: datetime
    
    camera_role: Optional[Literal["judge", "witness"]]
    
    attributes: Dict[str, Any]
    evidence_hints: Dict[str, Any]
```

### 3.3 Replay Contract 框架

```python
# src/ng_edge/replay/contract.py

@dataclass
class ReplayInput:
    """Replay 输入 (v2.2 Spec §11.2)"""
    replay_id: str
    signals: List[SignalEnvelope]
    initial_state: InitialState
    config: Config
    time_mode: Literal["instant", "accelerated", "realtime"]

@dataclass
class ReplayOutput:
    """Replay 输出 (v2.2 Spec §11.3)"""
    replay_id: str
    incidents: List[Incident]
    transitions: List[TransitionRecord]
    actions_authorized: List[Action]
```

### 3.4 现有组件测试清单

| 组件 | 测试文件 | 需要测试的场景 |
|------|----------|----------------|
| state_machine_v5 | `test_state_machine_v5.py` | AWAY mode door open → PENDING |
| state_machine_v5 | `test_state_machine_v5.py` | PENDING timeout → TRIGGERED |
| state_machine_v5 | `test_state_machine_v5.py` | HOME mode door open → PRE |
| state_machine_v5 | `test_state_machine_v5.py` | Glass break → TRIGGERED |
| zigbee_signal_router | `test_zigbee_signal_router.py` | 信号解析和路由 |
| camera_output_channel | ✅ 已有 | 15 tests passing |
| reolink_control | `test_reolink_control.py` | Mock 测试 |

---

## 4. 验收标准

### Phase 0 完成标准

- [x] pytest.ini 配置完成
- [x] `SignalEnvelope` dataclass 定义完成 (10 tests)
- [x] `ReplayInput/Output` dataclass 定义完成
- [x] state_machine_v5 单元测试 32 个场景 (全部通过)
- [x] camera_output_channel 测试 15 个场景 (全部通过)
- [x] 核心测试通过 `pytest tests/unit/ -v` (57 passed)

### Phase 1 完成标准

- [ ] ZigbeeSignalRouter 输出 SignalEnvelope
- [ ] 原有功能测试仍然通过
- [ ] 新增 camera_role 字段测试

### 总体完成标准

- [ ] Replay Engine 可以重放生产场景
- [ ] 规则变更可以通过 Replay Diff 验证
- [ ] 所有组件测试覆盖率 > 80%

---

## 5. 执行步骤 (Phase 0)

### Step 0.1: 创建目录结构

```bash
mkdir -p src/ng_edge/core
mkdir -p src/ng_edge/correlation
mkdir -p src/ng_edge/state
mkdir -p src/ng_edge/action
mkdir -p src/ng_edge/replay
mkdir -p tests/unit
mkdir -p tests/integration
```

### Step 0.2: 创建 pytest.ini

### Step 0.3: 创建 SignalEnvelope

### Step 0.4: 创建 state_machine_v5 单元测试

### Step 0.5: 运行并验证所有测试

---

*准备好后，执行 Step 0.1*
