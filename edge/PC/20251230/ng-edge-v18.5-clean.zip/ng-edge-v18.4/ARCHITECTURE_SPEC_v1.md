# NG-EDGE 三层架构规范 v1.0

> 基于审核反馈的完整架构定义
> Status: **Draft for Review**

---

## 0. 核心原则（不可违背）

| 原则 | 规则 | 违反后果 |
|------|------|----------|
| **Signal Layer 无副作用** | 只产出信号，不改状态，不发动作 | PRE/Sensor 互相覆盖 |
| **Correlation Layer 纯逻辑** | 只做聚合/去重/归因，禁止触发任何外部动作 | 双事件世界 |
| **State Machine 唯一裁判** | 所有外部可见动作只能由 SM 触发 | 动作冲突 |
| **单一 Incident 原则** | 同一 leaseKey + 时间窗内只有一个活跃 Incident | 通知风暴 |

---

## 1. Signal Layer 规范

### 1.1 信号类型定义

```python
class SignalSource(str, Enum):
    CAMERA = "camera"      # 摄像头检测
    SENSOR = "sensor"      # 传感器触发
    HEALTH = "health"      # 系统健康

class SignalHardness(str, Enum):
    SOFT = "soft"          # 可丢弃，不能直接触发 PENDING/TRIGGERED
    HARD = "hard"          # 必须处理，可触发 PENDING/TRIGGERED

# 信号硬度映射（固定规则）
SIGNAL_HARDNESS = {
    # Camera 信号 - 全部是 SOFT
    "person_detected": SignalHardness.SOFT,
    "vehicle_detected": SignalHardness.SOFT,
    "motion_detected": SignalHardness.SOFT,
    "loitering": SignalHardness.SOFT,
    
    # Sensor 信号 - 全部是 HARD
    "door_open": SignalHardness.HARD,
    "door_close": SignalHardness.HARD,
    "glass_break": SignalHardness.HARD,
    "motion_active": SignalHardness.HARD,  # PIR motion
    
    # Health 信号 - 混合
    "tamper_s": SignalHardness.SOFT,       # 疑似篡改
    "tamper_c": SignalHardness.HARD,       # 确认篡改
    "offline": SignalHardness.SOFT,
    "battery_low": SignalHardness.SOFT,
}
```

### 1.2 信号数据结构

```python
@dataclass
class BaseSignal:
    signal_id: str                    # 唯一标识
    timestamp: datetime               # 产生时间
    source: SignalSource              # 来源类型
    hardness: SignalHardness          # 硬度（由类型决定）
    
    # 空间归属
    zone_id: str                      # 区域 ID
    entry_point_id: Optional[str]     # 入口点 ID（可选）
    
    # 置信度
    confidence: float = 1.0           # 0.0 - 1.0

@dataclass
class CameraSignal(BaseSignal):
    """摄像头产生的 SOFT 信号"""
    source: SignalSource = SignalSource.CAMERA
    hardness: SignalHardness = SignalHardness.SOFT
    
    # 检测信息
    signal_type: str                  # person_detected, vehicle_detected, etc.
    target_class: str                 # person, car, etc.
    bbox: Optional[Tuple[int,int,int,int]] = None
    trajectory: Optional[dict] = None
    direction: Optional[str] = None   # approaching, leaving, passing
    dwell_sec: float = 0.0            # 停留时间

@dataclass  
class SensorSignal(BaseSignal):
    """传感器产生的 HARD 信号"""
    source: SignalSource = SignalSource.SENSOR
    hardness: SignalHardness = SignalHardness.HARD
    
    signal_type: str                  # door_open, glass_break, etc.
    device_id: str                    # Zigbee device ID
    raw_payload: Optional[dict] = None

@dataclass
class HealthSignal(BaseSignal):
    """系统健康信号"""
    source: SignalSource = SignalSource.HEALTH
    
    signal_type: str                  # tamper_s, tamper_c, offline, etc.
    device_id: str
    details: Optional[dict] = None
```

### 1.3 Signal Layer 禁止事项

```python
# ❌ Signal Layer 禁止做的事情
class SignalLayerViolations:
    # 1. 不能改变任何状态
    incident.state = ...              # ❌
    state_machine.transition(...)     # ❌
    
    # 2. 不能发送任何通知
    push_notification(...)            # ❌
    send_alert(...)                   # ❌
    
    # 3. 不能控制任何输出设备
    camera.siren_on()                 # ❌
    camera.spotlight_on()             # ❌
    keypad.set_mode(...)              # ❌
    
    # 4. 不能拉取证据
    capture_video_clip(...)           # ❌
    save_snapshot(...)                # ❌

# ✅ Signal Layer 只能做的事情
class SignalLayerAllowed:
    # 1. 产出信号对象
    return CameraSignal(...)          # ✅
    return SensorSignal(...)          # ✅
    
    # 2. 发送到 Correlation Layer
    correlation.on_signal(signal)     # ✅
    event_bus.post(SignalEvent(...))  # ✅
```

---

## 2. Correlation Layer 规范

### 2.1 职责边界（硬性约束）

| 允许 | 禁止 |
|------|------|
| merge (信号合并) | 改变 Incident 状态 |
| dedupe (去重) | 发送通知 |
| attribution (归因) | 控制输出设备 |
| score-hint (评分建议) | 拉取证据 |
| 创建/更新 IncidentCandidate | 直接触发动作 |

### 2.2 IncidentCandidate 数据结构

```python
@dataclass
class IncidentCandidate:
    """事件候选 - Correlation 的唯一输出"""
    
    # 标识
    candidate_id: str
    lease_key: str                    # (home_id, zone_id, entry_point_id)
    
    # 时间窗
    window_start: datetime
    window_end: datetime              # 动态更新
    last_signal_at: datetime
    
    # 信号集合
    signals: List[BaseSignal]         # 所有关联信号
    soft_signals: List[CameraSignal]  # 仅 SOFT 信号
    hard_signals: List[SensorSignal]  # 仅 HARD 信号
    
    # 评分建议（不是决策）
    threat_hint: ThreatLevel          # 建议的威胁等级
    confidence: float                 # 综合置信度
    
    # 证据提示（不是拉取）
    evidence_hints: List[str]         # 建议收集的证据类型
    
    # 空间归属
    zone_id: str
    entry_point_id: Optional[str]

@dataclass
class IncidentPatch:
    """增量更新 - 用于追加信号"""
    candidate_id: str
    new_signals: List[BaseSignal]
    updated_threat_hint: Optional[ThreatLevel]
    updated_confidence: Optional[float]
```

### 2.3 Correlation 规则

```python
class CorrelationRules:
    """关联规则（必须是可回放的纯逻辑）"""
    
    # 时间窗配置
    PRE_AGGREGATION_WINDOW_SEC = 60      # PRE 信号聚合窗口
    HARD_CORRELATION_WINDOW_SEC = 30     # 硬信号关联窗口
    INCIDENT_ACTIVE_WINDOW_SEC = 300     # 事件活跃窗口 (5min)
    
    # 空间匹配规则
    def should_correlate(self, sig1: BaseSignal, sig2: BaseSignal) -> bool:
        """判断两个信号是否应该关联"""
        
        # 规则1: 时间窗内
        time_diff = abs((sig1.timestamp - sig2.timestamp).total_seconds())
        if sig1.hardness == SignalHardness.HARD or sig2.hardness == SignalHardness.HARD:
            if time_diff > self.HARD_CORRELATION_WINDOW_SEC:
                return False
        else:
            if time_diff > self.PRE_AGGREGATION_WINDOW_SEC:
                return False
        
        # 规则2: 空间匹配（同一 zone 或 entry_point）
        if sig1.entry_point_id and sig2.entry_point_id:
            return sig1.entry_point_id == sig2.entry_point_id
        return sig1.zone_id == sig2.zone_id
    
    # 威胁等级建议计算
    def compute_threat_hint(self, candidate: IncidentCandidate) -> ThreatLevel:
        """
        计算建议的威胁等级（纯计算，不触发动作）
        
        规则:
        1. 有 HARD 信号 → 至少 PENDING
        2. 仅 SOFT 信号 → 最高 PRE_L3
        3. HARD + SOFT 关联 → 置信度加成
        """
        has_hard = len(candidate.hard_signals) > 0
        soft_count = len(candidate.soft_signals)
        
        if has_hard:
            # 有硬信号，检查类型
            for sig in candidate.hard_signals:
                if sig.signal_type == "glass_break":
                    return ThreatLevel.TRIGGERED
                if sig.signal_type == "door_open":
                    return ThreatLevel.PENDING
            return ThreatLevel.PENDING
        
        # 仅软信号，根据数量和置信度
        if soft_count == 0:
            return ThreatLevel.NONE
        
        max_confidence = max(s.confidence for s in candidate.soft_signals)
        max_dwell = max((s.dwell_sec for s in candidate.soft_signals), default=0)
        
        if max_dwell >= 30 or max_confidence >= 0.9:
            return ThreatLevel.PRE_L3
        elif max_dwell >= 10 or max_confidence >= 0.7:
            return ThreatLevel.PRE_L2
        else:
            return ThreatLevel.PRE_L1
```

### 2.4 Lease 管理

```python
class LeaseManager:
    """事件租约管理 - 确保同一空间+时间只有一个活跃事件"""
    
    def __init__(self):
        # lease_key → IncidentCandidate
        self.active_leases: Dict[str, IncidentCandidate] = {}
    
    def get_lease_key(self, signal: BaseSignal) -> str:
        """生成租约键"""
        # 格式: home_id:zone_id:entry_point_id
        ep = signal.entry_point_id or "_"
        return f"{signal.zone_id}:{ep}"
    
    def acquire_or_append(self, signal: BaseSignal) -> Tuple[IncidentCandidate, bool]:
        """
        获取或追加到现有事件
        
        Returns:
            (candidate, is_new): 事件候选和是否新建
        """
        key = self.get_lease_key(signal)
        
        if key in self.active_leases:
            candidate = self.active_leases[key]
            
            # 检查是否在活跃窗口内
            elapsed = (signal.timestamp - candidate.last_signal_at).total_seconds()
            if elapsed <= CorrelationRules.INCIDENT_ACTIVE_WINDOW_SEC:
                # 追加到现有事件
                candidate.signals.append(signal)
                candidate.last_signal_at = signal.timestamp
                if signal.hardness == SignalHardness.HARD:
                    candidate.hard_signals.append(signal)
                else:
                    candidate.soft_signals.append(signal)
                return (candidate, False)
            else:
                # 窗口过期，关闭旧事件，创建新事件
                self._close_lease(key)
        
        # 创建新事件
        candidate = IncidentCandidate(
            candidate_id=f"inc_{uuid.uuid4().hex[:12]}",
            lease_key=key,
            window_start=signal.timestamp,
            window_end=signal.timestamp,
            last_signal_at=signal.timestamp,
            signals=[signal],
            soft_signals=[signal] if signal.hardness == SignalHardness.SOFT else [],
            hard_signals=[signal] if signal.hardness == SignalHardness.HARD else [],
            threat_hint=ThreatLevel.NONE,
            confidence=signal.confidence,
            evidence_hints=[],
            zone_id=signal.zone_id,
            entry_point_id=signal.entry_point_id,
        )
        self.active_leases[key] = candidate
        return (candidate, True)
    
    def _close_lease(self, key: str):
        """关闭租约"""
        if key in self.active_leases:
            # 发送关闭事件到状态机
            candidate = self.active_leases.pop(key)
            # event_bus.post(LeaseExpired(candidate))
```

---

## 3. Incident State Machine 规范

### 3.1 双维度状态定义

```python
class ThreatLevel(str, Enum):
    """威胁等级 - 由信号驱动"""
    NONE = "none"
    PRE_L1 = "pre_l1"       # 低置信检测
    PRE_L2 = "pre_l2"       # 持续关注
    PRE_L3 = "pre_l3"       # 强预警
    PENDING = "pending"     # 入口延迟
    TRIGGERED = "triggered" # 报警

class WorkflowState(str, Enum):
    """工作流状态 - 由处置进度驱动"""
    IDLE = "idle"           # 初始
    NOTIFIED = "notified"   # 已通知
    VERIFYING = "verifying" # 验证中
    ESCALATED = "escalated" # 已升级
    RESOLVED = "resolved"   # 已解决
    CLOSED = "closed"       # 已关闭

@dataclass
class IncidentState:
    """事件状态（双维度）"""
    incident_id: str
    threat: ThreatLevel
    workflow: WorkflowState
    
    # 状态时间戳
    threat_changed_at: datetime
    workflow_changed_at: datetime
    
    # 关联的 Candidate
    candidate: IncidentCandidate
```

### 3.2 有效状态组合矩阵

```python
# 不是所有组合都有效
VALID_STATE_COMBINATIONS = {
    # ThreatLevel: [允许的 WorkflowState]
    ThreatLevel.NONE: [
        WorkflowState.IDLE, 
        WorkflowState.CLOSED
    ],
    ThreatLevel.PRE_L1: [
        WorkflowState.IDLE
    ],
    ThreatLevel.PRE_L2: [
        WorkflowState.IDLE, 
        WorkflowState.NOTIFIED
    ],
    ThreatLevel.PRE_L3: [
        WorkflowState.IDLE, 
        WorkflowState.NOTIFIED, 
        WorkflowState.VERIFYING
    ],
    ThreatLevel.PENDING: [
        WorkflowState.NOTIFIED, 
        WorkflowState.VERIFYING
    ],
    ThreatLevel.TRIGGERED: [
        WorkflowState.NOTIFIED, 
        WorkflowState.VERIFYING, 
        WorkflowState.ESCALATED,
        WorkflowState.RESOLVED
    ],
}

def is_valid_combination(threat: ThreatLevel, workflow: WorkflowState) -> bool:
    return workflow in VALID_STATE_COMBINATIONS.get(threat, [])
```

### 3.3 状态转换规则

```python
class IncidentStateMachine:
    """事件状态机 - 唯一裁判"""
    
    def __init__(self, action_gate: 'ActionGate'):
        self.action_gate = action_gate
        self.incidents: Dict[str, IncidentState] = {}
    
    def on_candidate(self, candidate: IncidentCandidate) -> List[Action]:
        """
        处理 IncidentCandidate
        
        规则:
        1. SOFT 信号只能提升到 PRE_L1/L2/L3
        2. HARD 信号可以提升到 PENDING/TRIGGERED
        3. 威胁等级只升不降（除非显式降级）
        4. 每次转换记录完整审计
        """
        incident = self.get_or_create_incident(candidate)
        old_threat = incident.threat
        
        # 计算新威胁等级
        new_threat = self._compute_new_threat(incident, candidate)
        
        # 威胁只升不降
        if self._threat_level_value(new_threat) <= self._threat_level_value(old_threat):
            new_threat = old_threat
        
        # 更新状态
        if new_threat != old_threat:
            incident.threat = new_threat
            incident.threat_changed_at = datetime.now(timezone.utc)
            
            # 记录转换
            self._record_transition(
                incident_id=incident.incident_id,
                dimension="threat",
                from_state=old_threat,
                to_state=new_threat,
                reason_code=self._get_reason_code(candidate),
                trigger_signals=[s.signal_id for s in candidate.signals[-5:]],
            )
        
        # 通过 ActionGate 获取授权动作
        return self.action_gate.get_authorized_actions(incident)
    
    def _compute_new_threat(
        self, 
        incident: IncidentState, 
        candidate: IncidentCandidate
    ) -> ThreatLevel:
        """计算新威胁等级"""
        
        # 硬信号直接升级
        for sig in candidate.hard_signals:
            if sig.signal_type == "glass_break":
                return ThreatLevel.TRIGGERED
            if sig.signal_type == "door_open":
                # 检查 zone 类型
                if self._is_entry_exit_zone(sig.entry_point_id):
                    return ThreatLevel.PENDING
                else:
                    return ThreatLevel.TRIGGERED
        
        # 软信号最高到 PRE_L3
        return min(candidate.threat_hint, ThreatLevel.PRE_L3)
    
    def on_user_action(self, incident_id: str, action: str) -> List[Action]:
        """处理用户动作（影响 Workflow 维度）"""
        incident = self.incidents.get(incident_id)
        if not incident:
            return []
        
        old_workflow = incident.workflow
        new_workflow = old_workflow
        
        if action == "acknowledge":
            new_workflow = WorkflowState.NOTIFIED
        elif action == "verify":
            new_workflow = WorkflowState.VERIFYING
        elif action == "escalate":
            new_workflow = WorkflowState.ESCALATED
        elif action == "resolve":
            new_workflow = WorkflowState.RESOLVED
        elif action == "close":
            new_workflow = WorkflowState.CLOSED
        elif action == "disarm":
            # 撤防：威胁降级 + 工作流关闭
            incident.threat = ThreatLevel.NONE
            new_workflow = WorkflowState.CLOSED
        
        # 验证组合有效性
        if not is_valid_combination(incident.threat, new_workflow):
            raise InvalidStateTransition(
                f"Invalid: ({incident.threat}, {new_workflow})"
            )
        
        if new_workflow != old_workflow:
            incident.workflow = new_workflow
            incident.workflow_changed_at = datetime.now(timezone.utc)
            
            self._record_transition(
                incident_id=incident_id,
                dimension="workflow",
                from_state=old_workflow,
                to_state=new_workflow,
                reason_code=f"USER_{action.upper()}",
                trigger_signals=[],
            )
        
        return self.action_gate.get_authorized_actions(incident)
    
    def on_timeout(self, incident_id: str, timeout_type: str):
        """处理超时（PENDING → TRIGGERED）"""
        incident = self.incidents.get(incident_id)
        if not incident:
            return
        
        if timeout_type == "entry_delay" and incident.threat == ThreatLevel.PENDING:
            incident.threat = ThreatLevel.TRIGGERED
            incident.threat_changed_at = datetime.now(timezone.utc)
            
            self._record_transition(
                incident_id=incident_id,
                dimension="threat",
                from_state=ThreatLevel.PENDING,
                to_state=ThreatLevel.TRIGGERED,
                reason_code="ENTRY_DELAY_EXPIRED",
                trigger_signals=[],
            )
            
            return self.action_gate.get_authorized_actions(incident)
```

### 3.4 Camera-Alone Trigger 策略

```python
class CameraAloneTriggerPolicy:
    """
    摄像头单独触发策略
    
    默认保守：camera_alone_can_trigger = False
    仅在极强组合条件下允许例外
    """
    
    # 默认禁用
    ENABLED = False
    
    # 允许触发的组合条件
    ALLOWED_COMBOS = [
        # 条件1: 篡改 + 人员靠近 + 夜间 + 敏感区域
        {
            "signals": ["tamper_c", "person_detected"],
            "time": "night",
            "zone": ["entry_exit", "perimeter"],
            "min_confidence": 0.9,
        },
        # 条件2: 篡改 + 断电/断网
        {
            "signals": ["tamper_c", "offline"],
            "additional": ["power_loss"],
        },
    ]
    
    def can_trigger(self, candidate: IncidentCandidate) -> bool:
        """判断是否允许摄像头单独触发"""
        if not self.ENABLED:
            return False
        
        # 检查是否匹配任一组合条件
        for combo in self.ALLOWED_COMBOS:
            if self._matches_combo(candidate, combo):
                return True
        
        return False
    
    def get_reason_code(self) -> str:
        return "CAMERA_STRONG_COMBO_TRIGGER"
```

---

## 4. Action Gate 规范

### 4.1 动作权限表（硬性规则）

```python
class ActionGate:
    """动作闸门 - 按威胁等级授权"""
    
    # 动作权限矩阵
    ACTION_PERMISSIONS = {
        ThreatLevel.NONE: [],
        
        ThreatLevel.PRE_L1: [
            "log",                    # 记录日志
            "cache_evidence_pointer", # 缓存证据指针（不拉取）
        ],
        
        ThreatLevel.PRE_L2: [
            "log",
            "cache_evidence_pointer",
            "notify_light",           # 轻通知（可选）
            "live_view_ready",        # 准备 Live View
            "spotlight_on",           # 开灯威慑
        ],
        
        ThreatLevel.PRE_L3: [
            "log",
            "cache_evidence_pointer",
            "notify_strong",          # 强通知
            "live_view_ready",
            "spotlight_on",
            "pull_minimal_clip",      # 拉取最小证据包（短 clip）
            "beep_warning",           # 警告音（1Hz beep，非警号）
        ],
        
        ThreatLevel.PENDING: [
            "log",
            "cache_evidence_pointer",
            "notify_urgent",          # 紧急通知
            "live_view_ready",
            "spotlight_on",
            "pull_minimal_clip",
            "keypad_countdown",       # 键盘倒计时
            "prepare_siren",          # 准备警号（不触发）
        ],
        
        ThreatLevel.TRIGGERED: [
            "log",
            "pull_full_evidence",     # 拉取完整证据包
            "notify_alarm",           # 报警通知
            "live_view_ready",
            "spotlight_on",
            "siren_on",               # 警号
            "collaboration_alert",    # 协作通知
            "dispatch_ready",         # 准备报警
        ],
    }
    
    def is_authorized(self, threat: ThreatLevel, action: str) -> bool:
        """检查动作是否被授权"""
        return action in self.ACTION_PERMISSIONS.get(threat, [])
    
    def get_authorized_actions(self, incident: IncidentState) -> List[str]:
        """获取当前状态下所有授权动作"""
        return self.ACTION_PERMISSIONS.get(incident.threat, [])
```

### 4.2 PRE 通知降级规则

```python
class NotificationPolicy:
    """
    通知策略
    
    关键规则：进入 PENDING/TRIGGERED 后，PRE 通知降级为附加信息
    """
    
    def should_notify(self, incident: IncidentState, action: str) -> bool:
        """判断是否应该发送通知"""
        
        # PENDING/TRIGGERED 期间，PRE 通知变为附加信息
        if incident.threat in [ThreatLevel.PENDING, ThreatLevel.TRIGGERED]:
            if action in ["notify_light", "notify_strong"]:
                # 不独立发送，附加到主通知
                return False
        
        return True
    
    def get_notification_type(self, incident: IncidentState) -> str:
        """获取通知类型"""
        if incident.threat == ThreatLevel.TRIGGERED:
            return "ALARM"
        elif incident.threat == ThreatLevel.PENDING:
            return "ENTRY_DELAY"
        elif incident.threat == ThreatLevel.PRE_L3:
            return "STRONG_ALERT"
        elif incident.threat == ThreatLevel.PRE_L2:
            return "ATTENTION"
        else:
            return "SILENT"
```

---

## 5. Noise Policy 规范

### 5.1 去重与抑制

```python
class NoisePolicy:
    """噪声控制策略"""
    
    # PRE 通知冷却（秒）
    PRE_NOTIFICATION_COOLDOWN = {
        ThreatLevel.PRE_L1: 600,    # 10分钟
        ThreatLevel.PRE_L2: 300,    # 5分钟
        ThreatLevel.PRE_L3: 60,     # 1分钟
    }
    
    # 传感器抖动合并窗口（秒）
    SENSOR_DEBOUNCE_WINDOW = {
        "door_open": 5,             # 门磁抖动 5秒合并
        "door_close": 5,
        "motion_active": 15,        # Motion 15秒合并
        "glass_break": 0,           # 玻璃破碎不合并
    }
    
    # 事件内重复信号处理
    INCIDENT_SIGNAL_POLICY = {
        "duplicate_action": "count_only",  # 重复信号只计数，不重复动作
        "upgrade_action": "execute",       # 升级信号执行动作
    }
    
    def should_notify(
        self, 
        incident: IncidentState, 
        last_notify_time: Optional[datetime]
    ) -> bool:
        """判断是否应该发送通知（冷却检查）"""
        if incident.threat not in self.PRE_NOTIFICATION_COOLDOWN:
            return True
        
        if last_notify_time is None:
            return True
        
        cooldown = self.PRE_NOTIFICATION_COOLDOWN[incident.threat]
        elapsed = (datetime.now(timezone.utc) - last_notify_time).total_seconds()
        
        return elapsed >= cooldown
    
    def should_process_signal(
        self,
        signal: BaseSignal,
        recent_signals: List[BaseSignal]
    ) -> bool:
        """判断信号是否应该处理（抖动过滤）"""
        debounce = self.SENSOR_DEBOUNCE_WINDOW.get(signal.signal_type, 0)
        if debounce == 0:
            return True
        
        for recent in recent_signals:
            if recent.signal_type == signal.signal_type:
                if recent.entry_point_id == signal.entry_point_id:
                    elapsed = (signal.timestamp - recent.timestamp).total_seconds()
                    if elapsed < debounce:
                        return False
        
        return True
```

---

## 6. Close Policy 规范

### 6.1 关闭规则

```python
class ClosePolicy:
    """事件关闭策略"""
    
    # PRE 静默窗口（秒）- 无新信号后自动降级
    PRE_SILENCE_WINDOW = {
        ThreatLevel.PRE_L1: 60,     # 1分钟
        ThreatLevel.PRE_L2: 120,    # 2分钟
        ThreatLevel.PRE_L3: 300,    # 5分钟
    }
    
    # PENDING 超时
    PENDING_TIMEOUT_SEC = 30
    
    # TRIGGERED 最大持续时间
    TRIGGERED_MAX_DURATION_SEC = 180  # 3分钟（警号自动停止）
    
    # 关闭原因码
    class CloseReason(str, Enum):
        USER_DISARM = "user_disarm"
        USER_RESOLVE = "user_resolve"
        VERIFIED_FALSE_ALARM = "verified_false_alarm"
        SILENCE_TIMEOUT = "silence_timeout"
        ENTRY_DELAY_DISARM = "entry_delay_disarm"
        SYSTEM_RECOVERY = "system_recovery"
        MANUAL_CLOSE = "manual_close"
    
    def check_auto_close(self, incident: IncidentState) -> Optional[CloseReason]:
        """检查是否应该自动关闭"""
        
        # PRE 静默降级
        if incident.threat in self.PRE_SILENCE_WINDOW:
            silence_window = self.PRE_SILENCE_WINDOW[incident.threat]
            elapsed = (datetime.now(timezone.utc) - incident.candidate.last_signal_at).total_seconds()
            if elapsed >= silence_window:
                return CloseReason.SILENCE_TIMEOUT
        
        return None
    
    def close_incident(
        self, 
        incident: IncidentState, 
        reason: CloseReason
    ):
        """关闭事件"""
        incident.threat = ThreatLevel.NONE
        incident.workflow = WorkflowState.CLOSED
        
        # 记录关闭
        self._record_close(
            incident_id=incident.incident_id,
            close_reason=reason.value,
            final_threat=incident.threat,
            final_workflow=incident.workflow,
            duration_sec=(datetime.now(timezone.utc) - incident.candidate.window_start).total_seconds(),
        )
```

---

## 7. Evidence Policy 规范

### 7.1 分级证据策略

```python
class EvidencePolicy:
    """证据收集策略 - 分级处理"""
    
    # PRE 阶段：轻量级
    PRE_EVIDENCE = {
        "mode": "ring_buffer",
        "buffer_duration_sec": 30,
        "keyframe_interval_sec": 5,
        "resolution": "low",          # 低分辨率
        "storage": "local_only",      # 仅本地
    }
    
    # PENDING 阶段：准备升级
    PENDING_EVIDENCE = {
        "mode": "prepare_packet",
        "pre_buffer_sec": 30,         # 保留前30秒
        "resolution": "medium",
        "storage": "local_cache",
    }
    
    # TRIGGERED 阶段：完整证据包
    TRIGGERED_EVIDENCE = {
        "mode": "full_packet",
        "pre_buffer_sec": 60,         # 前60秒
        "post_buffer_sec": 120,       # 后120秒
        "resolution": "high",
        "multi_camera": True,         # 多摄像头
        "include_sensors": True,      # 包含传感器序列
        "include_health": True,       # 包含设备心跳
        "storage": "local_and_cloud", # 本地+云端
    }
    
    def get_policy(self, threat: ThreatLevel) -> dict:
        if threat == ThreatLevel.TRIGGERED:
            return self.TRIGGERED_EVIDENCE
        elif threat == ThreatLevel.PENDING:
            return self.PENDING_EVIDENCE
        else:
            return self.PRE_EVIDENCE
    
    def on_threat_upgrade(self, old: ThreatLevel, new: ThreatLevel):
        """威胁升级时的证据处理"""
        if new == ThreatLevel.PENDING and old in [ThreatLevel.PRE_L1, ThreatLevel.PRE_L2, ThreatLevel.PRE_L3]:
            # 保留 PRE 阶段的环形缓存
            return "preserve_ring_buffer"
        
        if new == ThreatLevel.TRIGGERED:
            # 开始完整证据收集
            return "start_full_capture"
```

---

## 8. 审计日志规范

### 8.1 转换记录

```python
@dataclass
class TransitionRecord:
    """状态转换记录（不可变）"""
    record_id: str
    timestamp: datetime
    
    # 事件标识
    incident_id: str
    
    # 转换信息
    dimension: str                    # "threat" 或 "workflow"
    from_state: str
    to_state: str
    
    # 原因
    reason_code: str
    rule_id: Optional[str]
    
    # 触发信号
    trigger_signal_ids: List[str]
    trigger_signal_summary: dict      # 关键字段摘要
    
    # 上下文
    house_mode: str
    user_mode: str
    zone_id: str
    entry_point_id: Optional[str]
```

---

## 9. 实施检查清单

| 检查项 | 状态 | 说明 |
|--------|------|------|
| Signal Layer 无副作用 | ⬜ | Code review gate |
| Correlation 纯逻辑 | ⬜ | 可回放测试 |
| State Machine 唯一裁判 | ⬜ | 动作只从 SM 触发 |
| Lease 管理 | ⬜ | zone 级别隔离 |
| 有效状态组合 | ⬜ | 矩阵验证 |
| Action Gate | ⬜ | 权限表硬编码 |
| PRE 通知降级 | ⬜ | PENDING/TRIGGERED 时 PRE 附加 |
| Camera-Alone 策略 | ⬜ | 默认禁用 |
| Noise Policy | ⬜ | 冷却+去重 |
| Close Policy | ⬜ | 所有关闭有 reason code |
| Evidence Policy | ⬜ | 分级策略 |
| 审计日志 | ⬜ | 每次转换记录 |

---

## 10. 与当前代码的映射

| 新架构组件 | 当前代码 | 改造方式 |
|------------|----------|----------|
| SignalLayer.CameraSignal | `camera_signal_source.py` | 改输出类型 |
| SignalLayer.SensorSignal | `zigbee_signal_router.py` | 改输出类型 |
| SignalLayer.HealthSignal | 不存在 | 新建 |
| CorrelationLayer | 不存在 | 新建 `signal_correlator.py` |
| LeaseManager | 不存在 | 新建 |
| IncidentStateMachine | `state_machine_v5.py` | 重构为双维度 |
| ActionGate | `manager.py` 散落 | 抽取统一 |
| NoisePolicy | 不存在 | 新建 |
| ClosePolicy | 部分在 `state_machine_v5.py` | 抽取统一 |
| EvidencePolicy | 不存在 | 新建 |

---

*End of Architecture Specification v1.0*
