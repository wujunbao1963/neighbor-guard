#!/usr/bin/env python3
"""
NG Edge - Event Verification Test

Sends an event and verifies it appears on the server.

Usage:
    python test_event_verify.py \
        --server http://10.0.0.136:3000 \
        --circle <circle_id> \
        --device-key <device_key>
"""

import asyncio
import argparse
import sys
import uuid
from pathlib import Path
from datetime import datetime, timezone

try:
    import aiohttp
except ImportError:
    print("ERROR: aiohttp required. Install with: pip install aiohttp")
    sys.exit(1)

sys.path.insert(0, str(Path(__file__).parent))


async def get_user_token(server_url: str) -> str:
    """Get a user token via dev login."""
    async with aiohttp.ClientSession() as session:
        async with session.post(
            f"{server_url}/api/auth/dev/login",
            json={"email": "verify@test.com", "displayName": "Verify Test"},
        ) as resp:
            if resp.status == 201:
                data = await resp.json()
                return data["accessToken"]
            else:
                text = await resp.text()
                raise Exception(f"Failed to get token: {resp.status} {text}")


async def send_event(
    server_url: str,
    circle_id: str,
    device_key: str,
    event: dict,
) -> tuple[bool, dict]:
    """Send event to server using device key."""
    async with aiohttp.ClientSession() as session:
        async with session.post(
            f"{server_url}/api/circles/{circle_id}/events/ingest",
            json={
                "idempotencyKey": str(uuid.uuid4()),
                "event": event,
            },
            headers={
                "Authorization": f"Device {device_key}",
                "Content-Type": "application/json",
            },
        ) as resp:
            data = await resp.json()
            return resp.status in (200, 201), data


async def get_event(
    server_url: str,
    circle_id: str,
    event_id: str,
    user_token: str,
) -> tuple[bool, dict]:
    """Get event from server using user token."""
    async with aiohttp.ClientSession() as session:
        async with session.get(
            f"{server_url}/api/circles/{circle_id}/events/{event_id}",
            headers={"Authorization": f"Bearer {user_token}"},
        ) as resp:
            if resp.status == 200:
                data = await resp.json()
                return True, data
            elif resp.status == 404:
                return False, {"error": "Event not found"}
            else:
                data = await resp.json()
                return False, data


async def list_events(
    server_url: str,
    circle_id: str,
    user_token: str,
    limit: int = 5,
) -> list:
    """List recent events from server."""
    async with aiohttp.ClientSession() as session:
        async with session.get(
            f"{server_url}/api/circles/{circle_id}/events?limit={limit}",
            headers={"Authorization": f"Bearer {user_token}"},
        ) as resp:
            if resp.status == 200:
                data = await resp.json()
                return data.get("events", [])
            else:
                return []


async def main():
    parser = argparse.ArgumentParser(description="NG Edge Event Verification Test")
    parser.add_argument("--server", "-s", required=True, help="Server URL")
    parser.add_argument("--circle", "-c", required=True, help="Circle ID")
    parser.add_argument("--device-key", "-k", required=True, help="Device key for auth")
    
    args = parser.parse_args()
    
    print("=" * 60)
    print("NG Edge - Event Verification Test")
    print("=" * 60)
    print(f"Server: {args.server}")
    print(f"Circle: {args.circle}")
    print()
    
    # Step 1: Get user token for verification
    print("Step 1: Getting user token...")
    try:
        user_token = await get_user_token(args.server)
        print(f"  ✓ Got token: {user_token[:30]}...")
    except Exception as e:
        print(f"  ✗ Failed: {e}")
        return 1
    
    # Step 2: Create unique test event
    event_id = str(uuid.uuid4())
    timestamp = datetime.now(timezone.utc).isoformat()
    unique_marker = f"VERIFY-{uuid.uuid4().hex[:8]}"
    
    event = {
        "eventId": event_id,
        "occurredAt": timestamp,
        "eventType": "motion_detected",
        "severity": "LOW",
        "notificationLevel": "NORMAL",
        "status": "OPEN",
        "title": f"Verification Test Event {unique_marker}",
        "description": f"Test event to verify server receipt. Marker: {unique_marker}",
        "explainSummary": {
            "ruleId": "VERIFY_TEST",
            "keySignals": [{"code": "test.verify", "source": "manual"}],
            "mode": "HOME",
        },
    }
    
    print(f"\nStep 2: Sending test event...")
    print(f"  Event ID: {event_id}")
    print(f"  Marker: {unique_marker}")
    
    success, send_result = await send_event(
        args.server, args.circle, args.device_key, event
    )
    
    if success:
        print(f"  ✓ Event sent!")
        print(f"    accepted: {send_result.get('accepted')}")
        print(f"    serverReceivedAt: {send_result.get('serverReceivedAt')}")
        print(f"    deduped: {send_result.get('deduped', False)}")
    else:
        print(f"  ✗ Send failed!")
        print(f"    Response: {send_result}")
        return 1
    
    # Step 3: Wait a moment for server processing
    print(f"\nStep 3: Waiting 1 second for server processing...")
    await asyncio.sleep(1)
    
    # Step 4: Verify event exists on server
    print(f"\nStep 4: Verifying event on server...")
    
    found, get_result = await get_event(
        args.server, args.circle, event_id, user_token
    )
    
    if found:
        print(f"  ✓ Event found on server!")
        print(f"    eventId: {get_result.get('eventId')}")
        print(f"    title: {get_result.get('title')}")
        print(f"    status: {get_result.get('status')}")
        print(f"    occurredAt: {get_result.get('occurredAt')}")
    else:
        print(f"  ✗ Event NOT found on server!")
        print(f"    Response: {get_result}")
        return 1
    
    # Step 5: List recent events to show context
    print(f"\nStep 5: Recent events in circle:")
    events = await list_events(args.server, args.circle, user_token, limit=5)
    
    for i, evt in enumerate(events, 1):
        marker = "→" if evt.get("eventId") == event_id else " "
        print(f"  {marker} {i}. {evt.get('title', 'No title')[:50]}")
        print(f"       ID: {evt.get('eventId')}")
        print(f"       At: {evt.get('occurredAt')}")
    
    # Summary
    print("\n" + "=" * 60)
    print("✓ VERIFICATION SUCCESSFUL")
    print("=" * 60)
    print(f"Event {event_id} was:")
    print(f"  1. Sent from edge with Device key auth")
    print(f"  2. Accepted by server at {send_result.get('serverReceivedAt')}")
    print(f"  3. Retrieved via GET with user Bearer auth")
    print(f"  4. Appears in circle event list")
    
    return 0


if __name__ == "__main__":
    exit_code = asyncio.run(main())
    sys.exit(exit_code)
