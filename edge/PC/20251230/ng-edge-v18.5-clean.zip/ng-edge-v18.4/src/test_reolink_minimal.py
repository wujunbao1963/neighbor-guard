#!/usr/bin/env python3
"""
最小测试脚本：验证 reolink_aio 能控制摄像头

用法:
    python test_reolink_minimal.py <ip> <user> <password> <command>

命令:
    test      - 测试连接
    light_on  - 开灯
    light_off - 关灯
    siren_on  - 开警报 (会响!)
    siren_off - 关警报
    deterrent - 声光齐发 3 秒后停止
"""

import asyncio
import sys


async def main():
    if len(sys.argv) < 5:
        print(__doc__)
        return
    
    ip, user, password, command = sys.argv[1:5]
    
    print(f"[TEST] 连接 {ip}...")
    
    try:
        from reolink_aio.api import Host
    except ImportError:
        print("[ERROR] reolink_aio 未安装!")
        print("运行: pip install reolink-aio")
        return
    
    host = Host(ip, user, password)
    
    try:
        await host.get_host_data()
        model = host.camera_model(0)
        print(f"[TEST] ✅ 已连接: {model}")
        
        if command == "test":
            print("[TEST] 连接测试完成")
        
        elif command == "light_on":
            print("[TEST] 开灯...")
            await host.set_whiteled(0, state=True)
            print("[TEST] ✅ 灯已开")
        
        elif command == "light_off":
            print("[TEST] 关灯...")
            await host.set_whiteled(0, state=False)
            print("[TEST] ✅ 灯已关")
        
        elif command == "siren_on":
            print("[TEST] ⚠️ 开警报 (会响!)...")
            await host.set_siren(0, True)
            print("[TEST] ✅ 警报已开")
        
        elif command == "siren_off":
            print("[TEST] 关警报...")
            await host.set_siren(0, False)
            print("[TEST] ✅ 警报已关")
        
        elif command == "deterrent":
            print("[TEST] 🚨 声光齐发...")
            await host.set_whiteled(0, state=True)
            await host.set_siren(0, True)
            print("[TEST] 等待 3 秒...")
            await asyncio.sleep(3)
            print("[TEST] 停止...")
            await host.set_whiteled(0, state=False)
            await host.set_siren(0, False)
            print("[TEST] ✅ 完成")
        
        else:
            print(f"[ERROR] 未知命令: {command}")
    
    except Exception as e:
        print(f"[ERROR] 失败: {e}")
    
    finally:
        try:
            await host.logout()
        except:
            pass


if __name__ == "__main__":
    asyncio.run(main())
