"""
EdgeRuntime - v2.2 集成层

将所有组件整合到一个运行时：
- Zigbee 传感器监听 (MQTT)
- Camera YOLO 检测 (RTSP)
- SignalEnvelope 统一信号
- SecurityCoordinatorV2 状态机
- ActionGate 动作权限
- EvidencePolicy 证据收集

使用方式：
    runtime = EdgeRuntime(config)
    await runtime.start()
"""

import asyncio
import json
import time
import cv2
from datetime import datetime, timezone
from typing import Dict, List, Optional, Callable, Any, Tuple
from dataclasses import dataclass, field
from enum import Enum
import logging

# v2.2 核心模块
from ng_edge.core.signal import SignalEnvelope, CameraRole, Hardness
from ng_edge.state.coordinator_v2 import SecurityCoordinatorV2, ProcessResult
from ng_edge.state.states import ThreatState, WorkflowState
from ng_edge.action.gate import ActionGate, ActionType, GateDecision
from ng_edge.action.evidence import EvidencePolicy, EvidenceType
from ng_edge.runtime.deterrent_system import DeterrentSystem

# 硬件模块
from ng_edge.hardware.reolink_ultrawide import (
    ReolinkUltrawideClient,
    CameraConfig,
    StreamType,
)
from ng_edge.hardware.yolo_detector import YOLODetector

# 状态机
from ng_edge.services.state_machine_v5 import HouseMode, UserMode

# LOGISTICS 状态机
from ng_edge.logistics.logistics_sm import LogisticsSM, LogisticsConfig, LogisticsEvent

# 设置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(name)s] %(levelname)s: %(message)s',
    datefmt='%H:%M:%S'
)
logger = logging.getLogger("EdgeRuntime")


# =============================================================================
# 配置
# =============================================================================

@dataclass
class ZigbeeDeviceConfig:
    """Zigbee 设备配置"""
    friendly_name: str
    device_type: str  # contact, motion, glass_break
    entrypoint_id: str
    zone_id: str = "entry_exit"


@dataclass
class CameraDeviceConfig:
    """摄像头配置"""
    camera_id: str
    name: str
    ip: str
    username: str
    password: str
    entrypoint_id: str
    role: CameraRole = CameraRole.JUDGE
    zone_id: str = "exterior"
    stream_type: str = "sub"
    # 输出控制
    has_siren: bool = True  # 是否有警报
    has_light: bool = True  # 是否有灯光
    
    # 分区配置 (用于判断 PRE 级别)
    zone_mode: str = "horizontal"  # horizontal (俯视) 或 vertical (水平视角)
    direction: str = "bottom_to_top"  # 进入方向
    # 分区阈值 (相对于帧高度/宽度的比例)
    door_threshold: float = 0.55  # 超过此阈值 = door 区域 (PRE-L2)
    yard_threshold: float = 0.20  # 超过此阈值 = yard 区域 (PRE-L1)
    # 低于 yard_threshold = street 区域 (PRE-L0, 不触发威慑)


@dataclass
class EdgeRuntimeConfig:
    """EdgeRuntime 配置"""
    # 模式
    house_mode: HouseMode = HouseMode.AWAY
    user_mode: UserMode = UserMode.QUIET
    entry_delay_sec: int = 30
    
    # MQTT
    mqtt_host: str = "localhost"
    mqtt_port: int = 1883
    zigbee_topic: str = "zigbee2mqtt/#"
    
    # HMI (MQTT 状态总线)
    hmi_status_topic: str = "ng/status"
    hmi_command_topic: str = "ng/command"
    
    # Zigbee 设备
    zigbee_devices: Dict[str, ZigbeeDeviceConfig] = field(default_factory=dict)
    
    # 摄像头
    cameras: Dict[str, CameraDeviceConfig] = field(default_factory=dict)
    
    # YOLO
    yolo_model: str = "yolo11m.pt"  # 更大模型，侧身/背影检测更好
    yolo_conf: float = 0.7  # 高置信度
    yolo_fps: float = 5.0
    yolo_confirm_frames: int = 1  # 单帧即触发（取消连续帧确认）
    
    # 信号冷却
    signal_cooldown_sec: float = 5.0
    
    # Ring Keypad
    keypad_enabled: bool = True
    keypad_node_id: int = 3  # Ring Keypad Node ID (从 Z-Wave JS UI 查看)
    keypad_use_mqtt: bool = True  # 使用 MQTT 而非 WebSocket
    keypad_ws_url: str = "ws://localhost:3000"  # Z-Wave JS WebSocket (如果不用 MQTT)
    
    # Keypad 按键映射 (从 test_zwave_websocket.py 学习得到)
    # 格式: {"disarm": "zwave/nodeID_3/111/0/xxx/0", ...}
    keypad_key_mapping: Dict[str, str] = field(default_factory=dict)
    
    # PIN 验证
    valid_pins: List[str] = field(default_factory=lambda: ["1234"])
    
    # 快递判断参数
    delivery_max_duration_sec: float = 15.0  # 最大停留时间（超过则不视为快递）
    delivery_min_duration_sec: float = 2.0   # 最小停留时间（太短可能是误检）
    
    # 摄像头清除超时
    camera_clear_timeout_sec: float = 4.0    # 人员离开判断时间


# =============================================================================
# 默认配置
# =============================================================================

def _load_cameras_from_file() -> Dict[str, 'CameraDeviceConfig']:
    """从 cameras.json 加载摄像头配置"""
    import json
    import os
    
    cameras = {}
    config_path = os.path.join(os.path.dirname(__file__), "../../data/cameras.json")
    
    try:
        if os.path.exists(config_path):
            with open(config_path, 'r') as f:
                data = json.load(f)
            
            for cam_id, cam_data in data.get("cameras", {}).items():
                # 转换 role 字符串为枚举
                role_str = cam_data.get("role", "judge").upper()
                role = CameraRole.JUDGE if role_str == "JUDGE" else CameraRole.VERIFY
                
                cameras[cam_id] = CameraDeviceConfig(
                    camera_id=cam_data.get("camera_id", cam_id),
                    name=cam_data.get("name", cam_id),
                    ip=cam_data.get("ip", ""),
                    username=cam_data.get("username", "admin"),
                    password=cam_data.get("password", ""),
                    entrypoint_id=cam_data.get("entrypoint_id", ""),
                    role=role,
                    zone_id=cam_data.get("zone_id", "exterior"),
                    stream_type=cam_data.get("stream_type", "sub"),
                    has_siren=cam_data.get("has_siren", False),
                    has_light=cam_data.get("has_light", False),
                    zone_mode=cam_data.get("zone_mode", "horizontal"),
                    direction=cam_data.get("direction", "bottom_to_top"),
                    door_threshold=float(cam_data.get("door_threshold", 0.55)),
                    yard_threshold=float(cam_data.get("yard_threshold", 0.20)),
                )
            logger.info(f"[CONFIG] 已从 {config_path} 加载 {len(cameras)} 个摄像头")
        else:
            logger.warning(f"[CONFIG] 摄像头配置文件不存在: {config_path}")
    except Exception as e:
        logger.error(f"[CONFIG] 加载摄像头配置失败: {e}")
    
    return cameras


def _load_zigbee_from_file() -> Dict[str, 'ZigbeeDeviceConfig']:
    """从 zigbee_devices.json 加载 Zigbee 设备配置（简化版，仅加载绑定信息）"""
    import json
    import os
    
    # 默认 Zigbee 设备（硬编码，因为需要 entrypoint 映射）
    devices = {
        "Back Door Contact": ZigbeeDeviceConfig(
            friendly_name="Back Door Contact",
            device_type="contact",
            entrypoint_id="ep_back",
            zone_id="entry_exit",
        ),
        "Front Door Contact": ZigbeeDeviceConfig(
            friendly_name="Front Door Contact",
            device_type="contact",
            entrypoint_id="ep_front",
            zone_id="entry_exit",
        ),
    }
    return devices


def get_default_config() -> EdgeRuntimeConfig:
    """获取默认配置（从配置文件加载）"""
    
    # 从文件加载摄像头配置
    cameras = _load_cameras_from_file()
    
    # 如果加载失败，使用空配置（后续可手动添加）
    if not cameras:
        logger.warning("[CONFIG] 未加载到摄像头配置，使用空配置")
    
    # 加载 Zigbee 设备
    zigbee_devices = _load_zigbee_from_file()
    
    return EdgeRuntimeConfig(
        house_mode=HouseMode.AWAY,
        user_mode=UserMode.QUIET,
        entry_delay_sec=30,
        
        zigbee_devices=zigbee_devices,
        cameras=cameras,
        
        # Ring Keypad (通过 Z-Wave JS UI MQTT 网关)
        keypad_enabled=True,
        keypad_use_mqtt=True,  # 使用 MQTT 而非 WebSocket
        keypad_node_id=3,
        keypad_ws_url="ws://localhost:3000",  # 备用
        keypad_key_mapping={
            "disarm": "zwave/nodeID_3/111/0/3/0",
            "home": "zwave/nodeID_3/111/0/6/0",
            "away": "zwave/nodeID_3/111/0/5/0",
            "cancel": "zwave/nodeID_3/111/0/25/0",
            "ok": "zwave/nodeID_3/111/0/2/0",
        },
        valid_pins=["8662", "1113"],  # 有效 PIN 码
    )


# =============================================================================
# EdgeRuntime
# =============================================================================

class EdgeRuntime:
    """
    NG-Edge v2.2 运行时
    
    整合 Zigbee + Camera + 状态机 + 动作控制
    """
    
    def __init__(self, config: EdgeRuntimeConfig = None):
        self.config = config or get_default_config()
        
        # 核心组件
        self.coordinator = SecurityCoordinatorV2(
            house_mode=self.config.house_mode,
            user_mode=self.config.user_mode,
            entry_delay_sec=self.config.entry_delay_sec,
        )
        self.action_gate = ActionGate()
        self.evidence_policy = EvidencePolicy()
        
        # 注册入口点
        entry_points = set()
        for dev in self.config.zigbee_devices.values():
            entry_points.add((dev.entrypoint_id, dev.entrypoint_id.replace("ep_", "").title()))
        for cam in self.config.cameras.values():
            entry_points.add((cam.entrypoint_id, cam.entrypoint_id.replace("ep_", "").title()))
        
        for ep_id, ep_name in entry_points:
            self.coordinator.register_entry_point(ep_id, ep_name)
        
        # 注册 Judge 摄像头
        for cam_id, cam_cfg in self.config.cameras.items():
            if cam_cfg.role == CameraRole.JUDGE:
                self.coordinator.register_judge(cam_id, cam_cfg.entrypoint_id)
        
        # 设置回调
        self.coordinator.on_transition = self._on_state_transition
        
        # Entry Delay 定时器
        self._entry_delay_tasks: Dict[str, asyncio.Task] = {}  # entry_point_id → Task
        self._entry_delay_remaining: Dict[str, float] = {}  # entry_point_id → seconds
        
        # 摄像头客户端
        self.cameras: Dict[str, ReolinkUltrawideClient] = {}
        self.detector: Optional[YOLODetector] = None
        
        # Reolink API 客户端 (用于声光控制)
        self.reolink_hosts: Dict[str, Any] = {}  # cam_id -> Host
        
        # MQTT 客户端
        self.mqtt_client = None
        
        # Ring Keypad
        self.keypad = None
        
        # =========================================================================
        # 威慑系统 - 每个 Entry Point 独立实例 (方案 A)
        # =========================================================================
        
        # 建立映射表
        self._sensor_to_ep: Dict[str, str] = {}  # sensor_id -> entry_point_id
        self._ep_to_cameras: Dict[str, List[str]] = {}  # entry_point_id -> [cam_id, ...]
        
        # 从摄像头配置建立映射
        for cam_id, cam_cfg in self.config.cameras.items():
            ep_id = cam_cfg.entrypoint_id
            self._sensor_to_ep[cam_id] = ep_id
            if ep_id not in self._ep_to_cameras:
                self._ep_to_cameras[ep_id] = []
            self._ep_to_cameras[ep_id].append(cam_id)
        
        # 从 Zigbee 设备配置建立映射
        for dev_name, dev_cfg in self.config.zigbee_devices.items():
            self._sensor_to_ep[dev_name] = dev_cfg.entrypoint_id
        
        logger.info(f"[DETERRENT] 传感器映射: {self._sensor_to_ep}")
        logger.info(f"[DETERRENT] EP→摄像头: {self._ep_to_cameras}")
        
        # 为每个 Entry Point 创建独立的 DeterrentSystem
        self.deterrent_systems: Dict[str, DeterrentSystem] = {}
        for ep_id in self._ep_to_cameras.keys():
            # 使用闭包捕获 ep_id
            def make_spotlight_callback(ep):
                return lambda on: self._deterrent_spotlight_ep(on, ep)
            def make_siren_callback(ep):
                return lambda duration: self._deterrent_siren_ep(duration, ep)
            
            self.deterrent_systems[ep_id] = DeterrentSystem(
                on_spotlight=make_spotlight_callback(ep_id),
                on_siren=make_siren_callback(ep_id),
                entry_point_id=ep_id,
            )
            logger.info(f"[DETERRENT] 创建 {ep_id} 威慑系统")
        
        # 兼容性：保留 self.deterrent_system 引用（用于 TRIGGERED 状态等全局操作）
        # 默认指向第一个，如果需要全局操作则遍历所有
        if self.deterrent_systems:
            self.deterrent_system = list(self.deterrent_systems.values())[0]
        else:
            # fallback: 如果没有摄像头配置，创建一个默认的
            self.deterrent_system = DeterrentSystem(
                on_spotlight=self._deterrent_spotlight,
                on_siren=self._deterrent_siren,
                entry_point_id="default",
            )
        
        # 状态
        self.running = False
        self.last_signal_time: Dict[str, float] = {}  # device_id -> timestamp
        
        # HMI: 传感器状态和事件历史
        self._sensor_status: Dict[str, Dict] = {}  # device_id -> {last_signal, last_value, ...}
        self._event_history: List[Dict] = []  # 最近事件记录
        self._max_events = 50  # 保留最近 50 条
        
        # 统计
        self.stats = {
            "zigbee_signals": 0,
            "camera_detections": 0,
            "state_changes": 0,
            "actions_allowed": 0,
            "actions_denied": 0,
            "entry_delays_started": 0,
            "entry_delays_expired": 0,
            "entry_delays_cancelled": 0,
            "triggered_count": 0,
            "keypad_disarms": 0,
            "keypad_invalid_pins": 0,
            "siren_activations": 0,
            "light_activations": 0,
        }
        
        # =========================================================================
        # LOGISTICS 状态机 (PRD §13.x)
        # =========================================================================
        self._logistics_sm = LogisticsSM(LogisticsConfig(
            delivery_max_duration_sec=self.config.delivery_max_duration_sec,
            delivery_min_duration_sec=self.config.delivery_min_duration_sec,
        ))
        self._logistics_sm.on_delivery_detected = self._on_delivery_detected
        logger.info("[LOGISTICS] 状态机已初始化")
        
        # 回调
        self.on_signal: Optional[Callable[[SignalEnvelope], None]] = None
        self.on_state_change: Optional[Callable[[ProcessResult], None]] = None
        self.on_action: Optional[Callable[[ActionType, GateDecision], None]] = None
        self.on_entry_delay_tick: Optional[Callable[[str, int], None]] = None  # (entry_point_id, seconds_remaining)
        self.on_triggered: Optional[Callable[[str, str], None]] = None  # (entry_point_id, incident_id)
        self.on_keypad_disarm: Optional[Callable[[], None]] = None  # Keypad 撤防成功
        self.on_delivery_detected: Optional[Callable[[LogisticsEvent], None]] = None  # LOGISTICS 快递检测
        self.on_tamper_detected: Optional[Callable[[str, str, str], None]] = None  # tamper 事件通知 (device_id, entry_point_id, tamper_type) - 仅记录，不触发威慑
        
        # 加载运行时配置（覆盖默认值）
        self._load_runtime_config()
        
        logger.info(f"EdgeRuntime 初始化完成")
        logger.info(f"  模式: {self.config.house_mode.value}")
        logger.info(f"  Zigbee 设备: {len(self.config.zigbee_devices)}")
        logger.info(f"  摄像头: {len(self.config.cameras)}")
    
    def _report_sensor_to_ep(self, sensor_id: str, level: int):
        """
        报告传感器级别到对应的 Entry Point 威慑系统
        
        Args:
            sensor_id: 传感器 ID (cam_id 或 zigbee device name)
            level: 威慑级别 (0-3)
        """
        ep_id = self._sensor_to_ep.get(sensor_id)
        if not ep_id:
            logger.debug(f"[DETERRENT] 未知传感器: {sensor_id}")
            return
        
        ds = self.deterrent_systems.get(ep_id)
        if ds:
            ds.report_sensor(sensor_id, level)
        else:
            logger.debug(f"[DETERRENT] 未找到 {ep_id} 的威慑系统")
    
    async def start(self):
        """启动运行时"""
        logger.info("=" * 60)
        logger.info("EdgeRuntime 启动")
        logger.info("=" * 60)
        
        self.running = True
        
        # 初始化 YOLO
        if self.config.cameras:
            logger.info("[YOLO] 加载模型...")
            self.detector = YOLODetector(
                model_name=self.config.yolo_model,
                conf_threshold=self.config.yolo_conf,
                target_classes=["person"],
                device="cpu",
            )
            logger.info("[YOLO] 模型加载完成")
            
            # 初始化 Reolink API (声光控制)
            await self._init_reolink_hosts()
        
        # 启动威慑系统（每个 Entry Point）
        for ep_id, ds in self.deterrent_systems.items():
            await ds.start()
            logger.info(f"[DETERRENT] {ep_id} 已启动")
        
        # 启动任务
        tasks = []
        
        # Zigbee 监听
        if self.config.zigbee_devices:
            tasks.append(asyncio.create_task(self._zigbee_listener()))
        
        # 摄像头处理
        for cam_id, cam_cfg in self.config.cameras.items():
            tasks.append(asyncio.create_task(self._camera_processor(cam_id, cam_cfg)))
        
        # Ring Keypad
        if self.config.keypad_enabled:
            tasks.append(asyncio.create_task(self._keypad_listener()))
        
        # 等待所有任务
        try:
            await asyncio.gather(*tasks)
        except asyncio.CancelledError:
            logger.info("任务被取消")
        finally:
            await self.stop()
    
    async def stop(self):
        """停止运行时"""
        logger.info("EdgeRuntime 停止...")
        self.running = False
        
        # 停止威慑系统（每个 Entry Point）
        for ep_id, ds in self.deterrent_systems.items():
            await ds.stop()
        
        # 关闭声光
        await self._deactivate_alarm()
        
        # 断开 Reolink API
        for cam_id, host in self.reolink_hosts.items():
            try:
                await host.logout()
                logger.info(f"[Reolink] {cam_id} API 已断开")
            except:
                pass
        
        # 断开摄像头
        for cam_id, camera in self.cameras.items():
            camera.disconnect()
            logger.info(f"[{cam_id}] 已断开")
        
        # 打印统计
        logger.info("-" * 60)
        logger.info("统计:")
        logger.info(f"  Zigbee 信号: {self.stats['zigbee_signals']}")
        logger.info(f"  Camera 检测: {self.stats['camera_detections']}")
        logger.info(f"  状态变化: {self.stats['state_changes']}")
        logger.info(f"  Entry Delay 启动: {self.stats['entry_delays_started']}")
        logger.info(f"  Entry Delay 超时: {self.stats['entry_delays_expired']}")
        logger.info(f"  Entry Delay 取消: {self.stats['entry_delays_cancelled']}")
        logger.info(f"  TRIGGERED 次数: {self.stats['triggered_count']}")
        logger.info(f"  Keypad 撤防: {self.stats['keypad_disarms']}")
        logger.info(f"  Keypad 无效 PIN: {self.stats['keypad_invalid_pins']}")
        logger.info(f"  警报激活: {self.stats['siren_activations']}")
        logger.info(f"  灯光激活: {self.stats['light_activations']}")
        logger.info("-" * 60)
    
    # =========================================================================
    # Zigbee 处理
    # =========================================================================
    
    async def _zigbee_listener(self):
        """Zigbee MQTT 监听"""
        try:
            import aiomqtt
        except ImportError:
            logger.error("aiomqtt 未安装: pip install aiomqtt")
            return
        
        logger.info(f"[Zigbee] 连接 MQTT {self.config.mqtt_host}:{self.config.mqtt_port}")
        
        try:
            async with aiomqtt.Client(self.config.mqtt_host, self.config.mqtt_port) as client:
                self.mqtt_client = client
                await client.subscribe(self.config.zigbee_topic)
                logger.info(f"[Zigbee] 已订阅 {self.config.zigbee_topic}")
                
                # HMI 命令订阅
                await client.subscribe(self.config.hmi_command_topic)
                logger.info(f"[HMI] 已订阅 {self.config.hmi_command_topic}")
                
                async for message in client.messages:
                    if not self.running:
                        break
                    topic = str(message.topic)
                    if topic == self.config.hmi_command_topic:
                        await self._handle_hmi_command(message)
                    else:
                        await self._handle_zigbee_message(message)
        except Exception as e:
            logger.error(f"[Zigbee] MQTT 错误: {e}")
    
    async def _handle_zigbee_message(self, message):
        """处理 Zigbee MQTT 消息"""
        topic = str(message.topic)
        
        # 跳过 bridge 消息
        if "bridge" in topic:
            return
        
        # 解析设备名
        parts = topic.split("/")
        if len(parts) < 2:
            return
        device_name = parts[1]
        
        # 查找设备配置
        dev_cfg = self.config.zigbee_devices.get(device_name)
        if not dev_cfg:
            # 调试：显示未配置的设备消息
            logger.debug(f"[Zigbee] 收到未配置设备消息: {device_name}")
            return
        
        # 解析 payload
        try:
            payload = json.loads(message.payload.decode())
        except:
            return
        
        logger.info(f"[Zigbee] 📨 {device_name}: {payload}")
        
        # 检测信号类型
        signal_kind = self._detect_zigbee_signal_kind(payload, dev_cfg.device_type)
        if not signal_kind:
            return
        
        # 冷却检查
        now = time.time()
        last_time = self.last_signal_time.get(device_name, 0)
        if now - last_time < self.config.signal_cooldown_sec:
            return
        self.last_signal_time[device_name] = now
        
        # 创建 SignalEnvelope
        envelope = SignalEnvelope.from_zigbee(
            device_id=device_name,
            friendly_name=device_name,
            signal_kind=signal_kind,
            zone_id=dev_cfg.zone_id,
            entrypoint_id=dev_cfg.entrypoint_id,
            battery=payload.get("battery"),
            linkquality=payload.get("linkquality"),
            raw_payload=payload,
        )
        
        self.stats["zigbee_signals"] += 1
        logger.info(f"[Zigbee] {device_name}: {signal_kind} → {dev_cfg.entrypoint_id}")
        
        # HMI: 更新传感器状态和记录事件
        self._update_sensor_status(device_name, signal_kind, payload)
        event_level = "warning" if signal_kind == "tamper_s" else "info"
        self._record_event("zigbee", f"{device_name}: {signal_kind}", event_level, device_name)
        
        # TAMPER-S 事件记录 (不触发威慑)
        # 注意：当前实现只是简单事件，不是 PRD §8.1 定义的完整 Tamper-C 确认流程
        # 完整 Tamper-C 需要：双摄独立域、与 door/glass 的时间窗口相关、Tier gating 等
        # 暂时只记录事件，不触发任何安全动作
        if signal_kind == "tamper_s":
            logger.info(f"[Zigbee] tamper_s 事件: {device_name} (仅记录，不触发威慑)")
            # 回调用于通知用户（可选）
            if self.on_tamper_detected:
                self.on_tamper_detected(device_name, dev_cfg.entrypoint_id, "zigbee_physical")
            return
        
        # LOGISTICS: 通知门磁状态变化 (PRD §13.x)
        if signal_kind == "door_open":
            self._logistics_sm.on_door_state_change(device_name, True, now)
        elif signal_kind == "door_close":
            self._logistics_sm.on_door_state_change(device_name, False, now)
        
        # 处理信号
        await self._process_signal(envelope)
    
    def _detect_zigbee_signal_kind(self, payload: dict, device_type: str) -> Optional[str]:
        """检测 Zigbee 信号类型"""
        # Tamper 检测优先 (PRD §8.1 Tamper-S)
        # Zigbee 传感器被撬开时 tamper=True
        if payload.get("tamper") == True:
            logger.warning(f"[Zigbee] ⚠️ TAMPER 检测: {payload}")
            return "tamper_s"
        
        if "contact" in payload:
            return "door_open" if payload["contact"] == False else "door_close"
        
        if "occupancy" in payload:
            if payload["occupancy"]:
                return "motion_pir"
            return None
        
        if "motion" in payload:
            if payload["motion"]:
                return "motion_pir"
            return None
        
        return None
    
    # =========================================================================
    # HMI MQTT 状态总线
    # =========================================================================
    
    async def _handle_hmi_command(self, message):
        """处理 HMI 命令"""
        try:
            import json
            payload = json.loads(message.payload.decode())
            cmd = payload.get("command")
            
            logger.info(f"[HMI] 收到命令: {cmd}")
            
            if cmd == "set_mode":
                mode = payload.get("mode", "").upper()
                if mode == "DISARMED":
                    # 调用完整的撤防流程（取消 entry delay、撤防协调器、停止威慑）
                    self.disarm()
                    self._record_event("mode_change", f"HMI 撤防", "info")
                elif mode == "HOME":
                    self.set_mode(HouseMode.HOME)
                    self._record_event("mode_change", f"HMI 模式切换: HOME", "info")
                elif mode == "AWAY":
                    self.set_mode(HouseMode.AWAY)
                    self._record_event("mode_change", f"HMI 模式切换: AWAY", "info")
                else:
                    logger.warning(f"[HMI] 无效模式: {mode}")
                    return
                logger.info(f"[HMI] 模式已设置: {self.config.house_mode.value}")
                await self._publish_hmi_status()
            
            elif cmd == "get_status":
                await self._publish_hmi_status()
            
            elif cmd == "get_config":
                await self._publish_hmi_config()
            
            elif cmd == "set_config":
                params = payload.get("params", {})
                self._apply_config(params)
                self._save_runtime_config()
                self._record_event("config_change", f"参数更新: {list(params.keys())}", "info")
                await self._publish_hmi_config()
            
            elif cmd == "get_cameras":
                await self._publish_hmi_cameras()
            
            elif cmd == "set_camera":
                cam_id = payload.get("camera_id")
                params = payload.get("params", {})
                if cam_id and cam_id in self.config.cameras:
                    self._apply_camera_config(cam_id, params)
                    self._save_cameras_config()
                    self._record_event("camera_config", f"摄像头 {cam_id} 参数更新", "info")
                    await self._publish_hmi_cameras()
                else:
                    logger.warning(f"[HMI] 未知摄像头: {cam_id}")
                
        except Exception as e:
            logger.error(f"[HMI] 命令处理错误: {e}")
    
    def _apply_config(self, params: dict):
        """应用配置参数"""
        if "entry_delay_sec" in params:
            self.config.entry_delay_sec = int(params["entry_delay_sec"])
            logger.info(f"[CONFIG] entry_delay_sec = {self.config.entry_delay_sec}")
        
        if "yolo_conf" in params:
            self.config.yolo_conf = float(params["yolo_conf"])
            logger.info(f"[CONFIG] yolo_conf = {self.config.yolo_conf}")
        
        if "yolo_fps" in params:
            self.config.yolo_fps = float(params["yolo_fps"])
            logger.info(f"[CONFIG] yolo_fps = {self.config.yolo_fps}")
        
        if "signal_cooldown_sec" in params:
            self.config.signal_cooldown_sec = float(params["signal_cooldown_sec"])
            logger.info(f"[CONFIG] signal_cooldown_sec = {self.config.signal_cooldown_sec}")
        
        if "valid_pins" in params:
            self.config.valid_pins = list(params["valid_pins"])
            logger.info(f"[CONFIG] valid_pins 已更新")
        
        if "keypad_node_id" in params:
            self.config.keypad_node_id = int(params["keypad_node_id"])
            logger.info(f"[CONFIG] keypad_node_id = {self.config.keypad_node_id}")
        
        if "delivery_max_duration_sec" in params:
            self.config.delivery_max_duration_sec = float(params["delivery_max_duration_sec"])
            # 同步更新 LogisticsSM
            if hasattr(self, '_logistics_sm') and self._logistics_sm:
                self._logistics_sm.config.delivery_max_duration_sec = self.config.delivery_max_duration_sec
            logger.info(f"[CONFIG] delivery_max_duration_sec = {self.config.delivery_max_duration_sec}")
        
        if "delivery_min_duration_sec" in params:
            self.config.delivery_min_duration_sec = float(params["delivery_min_duration_sec"])
            # 同步更新 LogisticsSM
            if hasattr(self, '_logistics_sm') and self._logistics_sm:
                self._logistics_sm.config.delivery_min_duration_sec = self.config.delivery_min_duration_sec
            logger.info(f"[CONFIG] delivery_min_duration_sec = {self.config.delivery_min_duration_sec}")
        
        if "camera_clear_timeout_sec" in params:
            self.config.camera_clear_timeout_sec = float(params["camera_clear_timeout_sec"])
            logger.info(f"[CONFIG] camera_clear_timeout_sec = {self.config.camera_clear_timeout_sec}")
    
    def _apply_camera_config(self, cam_id: str, params: dict):
        """应用单个摄像头的配置参数"""
        if cam_id not in self.config.cameras:
            logger.warning(f"[CONFIG] 未知摄像头: {cam_id}")
            return
        
        cam_cfg = self.config.cameras[cam_id]
        
        if "ip" in params:
            cam_cfg.ip = str(params["ip"])
            logger.info(f"[CONFIG] {cam_id}.ip = {cam_cfg.ip}")
        
        if "zone_mode" in params:
            cam_cfg.zone_mode = str(params["zone_mode"])
            logger.info(f"[CONFIG] {cam_id}.zone_mode = {cam_cfg.zone_mode}")
        
        if "direction" in params:
            cam_cfg.direction = str(params["direction"])
            logger.info(f"[CONFIG] {cam_id}.direction = {cam_cfg.direction}")
        
        if "door_threshold" in params:
            cam_cfg.door_threshold = float(params["door_threshold"])
            logger.info(f"[CONFIG] {cam_id}.door_threshold = {cam_cfg.door_threshold}")
        
        if "yard_threshold" in params:
            cam_cfg.yard_threshold = float(params["yard_threshold"])
            logger.info(f"[CONFIG] {cam_id}.yard_threshold = {cam_cfg.yard_threshold}")
        
        if "has_siren" in params:
            cam_cfg.has_siren = bool(params["has_siren"])
            logger.info(f"[CONFIG] {cam_id}.has_siren = {cam_cfg.has_siren}")
        
        if "has_light" in params:
            cam_cfg.has_light = bool(params["has_light"])
            logger.info(f"[CONFIG] {cam_id}.has_light = {cam_cfg.has_light}")
    
    def _load_runtime_config(self):
        """从文件加载运行时配置"""
        import json
        import os
        config_path = os.path.join(os.path.dirname(__file__), "../../data/runtime_config.json")
        try:
            if os.path.exists(config_path):
                with open(config_path, 'r') as f:
                    params = json.load(f)
                self._apply_config(params)
                logger.info(f"[CONFIG] 已加载配置: {config_path}")
        except Exception as e:
            logger.warning(f"[CONFIG] 加载配置失败: {e}")
    
    def _save_runtime_config(self):
        """保存运行时配置到文件"""
        import json
        import os
        config_path = os.path.join(os.path.dirname(__file__), "../../data/runtime_config.json")
        try:
            config_data = {
                "entry_delay_sec": self.config.entry_delay_sec,
                "yolo_conf": self.config.yolo_conf,
                "yolo_fps": self.config.yolo_fps,
                "yolo_confirm_frames": self.config.yolo_confirm_frames,
                "signal_cooldown_sec": self.config.signal_cooldown_sec,
                "valid_pins": self.config.valid_pins,
                "keypad_node_id": self.config.keypad_node_id,
                "delivery_max_duration_sec": self.config.delivery_max_duration_sec,
                "delivery_min_duration_sec": self.config.delivery_min_duration_sec,
                "camera_clear_timeout_sec": self.config.camera_clear_timeout_sec,
                "saved_at": datetime.now(timezone.utc).isoformat(),
            }
            with open(config_path, 'w') as f:
                json.dump(config_data, f, indent=2)
            logger.info(f"[CONFIG] 已保存配置: {config_path}")
        except Exception as e:
            logger.error(f"[CONFIG] 保存配置失败: {e}")
    
    def _save_cameras_config(self):
        """保存摄像头配置到文件"""
        import json
        import os
        config_path = os.path.join(os.path.dirname(__file__), "../../data/cameras.json")
        try:
            cameras_data = {}
            for cam_id, cam_cfg in self.config.cameras.items():
                cameras_data[cam_id] = {
                    "camera_id": cam_cfg.camera_id,
                    "name": cam_cfg.name,
                    "ip": cam_cfg.ip,
                    "username": cam_cfg.username,
                    "password": cam_cfg.password,
                    "entrypoint_id": cam_cfg.entrypoint_id,
                    "zone_id": cam_cfg.zone_id,
                    "role": cam_cfg.role.value.lower(),
                    "stream_type": cam_cfg.stream_type,
                    "has_siren": cam_cfg.has_siren,
                    "has_light": cam_cfg.has_light,
                    "zone_mode": cam_cfg.zone_mode,
                    "direction": cam_cfg.direction,
                    "door_threshold": cam_cfg.door_threshold,
                    "yard_threshold": cam_cfg.yard_threshold,
                }
            
            data = {
                "cameras": cameras_data,
                "saved_at": datetime.now(timezone.utc).isoformat(),
            }
            with open(config_path, 'w') as f:
                json.dump(data, f, indent=2)
            logger.info(f"[CONFIG] 已保存摄像头配置: {config_path}")
        except Exception as e:
            logger.error(f"[CONFIG] 保存摄像头配置失败: {e}")
    
    async def _publish_hmi_config(self):
        """发布配置到 MQTT"""
        if not self.mqtt_client:
            return
        try:
            import json
            config_data = {
                "entry_delay_sec": self.config.entry_delay_sec,
                "yolo_conf": self.config.yolo_conf,
                "yolo_fps": self.config.yolo_fps,
                "yolo_confirm_frames": self.config.yolo_confirm_frames,
                "signal_cooldown_sec": self.config.signal_cooldown_sec,
                "valid_pins": self.config.valid_pins,
                "keypad_node_id": self.config.keypad_node_id,
                "delivery_max_duration_sec": self.config.delivery_max_duration_sec,
                "delivery_min_duration_sec": self.config.delivery_min_duration_sec,
                "camera_clear_timeout_sec": self.config.camera_clear_timeout_sec,
            }
            await self.mqtt_client.publish(
                "ng/config",
                json.dumps(config_data)
            )
            logger.info(f"[HMI] 配置已发布")
        except Exception as e:
            logger.error(f"[HMI] 配置发布错误: {e}")
    
    async def _publish_hmi_cameras(self):
        """发布摄像头配置到 MQTT"""
        if not self.mqtt_client:
            return
        try:
            import json
            cameras_data = {}
            for cam_id, cam_cfg in self.config.cameras.items():
                cameras_data[cam_id] = {
                    "camera_id": cam_cfg.camera_id,
                    "name": cam_cfg.name,
                    "ip": cam_cfg.ip,
                    "entrypoint_id": cam_cfg.entrypoint_id,
                    "zone_id": cam_cfg.zone_id,
                    "has_siren": cam_cfg.has_siren,
                    "has_light": cam_cfg.has_light,
                    "zone_mode": cam_cfg.zone_mode,
                    "direction": cam_cfg.direction,
                    "door_threshold": cam_cfg.door_threshold,
                    "yard_threshold": cam_cfg.yard_threshold,
                }
            await self.mqtt_client.publish(
                "ng/cameras",
                json.dumps(cameras_data)
            )
            logger.info(f"[HMI] 摄像头配置已发布")
        except Exception as e:
            logger.error(f"[HMI] 摄像头配置发布错误: {e}")
    
    def _record_event(self, event_type: str, message: str, level: str = "info", device_id: str = None):
        """记录事件到历史"""
        event = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "type": event_type,
            "message": message,
            "level": level,
            "device_id": device_id,
        }
        self._event_history.append(event)
        # 保持最大数量
        if len(self._event_history) > self._max_events:
            self._event_history = self._event_history[-self._max_events:]
    
    def _update_sensor_status(self, device_id: str, signal_type: str, value: Any = None):
        """更新传感器状态"""
        now = datetime.now(timezone.utc).isoformat()
        if device_id not in self._sensor_status:
            self._sensor_status[device_id] = {
                "device_id": device_id,
                "first_seen": now,
                "signal_count": 0,
            }
        self._sensor_status[device_id].update({
            "last_signal": now,
            "last_type": signal_type,
            "last_value": value,
            "signal_count": self._sensor_status[device_id].get("signal_count", 0) + 1,
        })
    
    async def _publish_hmi_status(self):
        """发布 HMI 状态到 MQTT"""
        if not self.mqtt_client:
            return
        
        try:
            import json
            # 威胁级别优先级
            threat_priority = {
                "none": 0, "pre_l1": 1, "pre_l2": 2, "pre_l3": 3,
                "pending": 4, "triggered": 5
            }
            
            # 获取全局威胁状态（取所有入口点的最高状态）
            alarm_state = "none"
            max_priority = 0
            if self.coordinator and self._ep_to_cameras:
                for ep_id in self._ep_to_cameras.keys():
                    try:
                        threat = self.coordinator.get_threat_state(ep_id)
                        if threat:
                            priority = threat_priority.get(threat.value, 0)
                            if priority > max_priority:
                                max_priority = priority
                                alarm_state = threat.value
                    except:
                        pass
            
            # 构建传感器状态列表
            sensors = []
            for dev_name, dev_cfg in self.config.zigbee_devices.items():
                sensor_info = {
                    "device_id": dev_name,
                    "type": dev_cfg.device_type,
                    "zone": dev_cfg.zone_id,
                    "entrypoint": dev_cfg.entrypoint_id,
                }
                if dev_name in self._sensor_status:
                    sensor_info.update(self._sensor_status[dev_name])
                sensors.append(sensor_info)
            
            # 添加摄像头状态
            for cam_id, cam_cfg in self.config.cameras.items():
                cam_info = {
                    "device_id": cam_id,
                    "type": "camera",
                    "zone": cam_cfg.zone_id,
                    "entrypoint": cam_cfg.entrypoint_id,
                    "online": cam_id in self.cameras and self.cameras[cam_id] is not None,
                }
                if cam_id in self._sensor_status:
                    cam_info.update(self._sensor_status[cam_id])
                sensors.append(cam_info)
            
            status = {
                "house_mode": self.config.house_mode.value,
                "running": self.running,
                "alarm_state": alarm_state,
                "cameras_online": len([c for c in self.cameras.values() if c]),
                "cameras_total": len(self.config.cameras),
                "zigbee_devices": len(self.config.zigbee_devices),
                "stats": self.stats,
                "sensors": sensors,
                "events": self._event_history[-20:],  # 最近 20 条事件
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }
            await self.mqtt_client.publish(
                self.config.hmi_status_topic,
                json.dumps(status)
            )
            logger.info(f"[HMI] 状态已发布")
        except Exception as e:
            logger.error(f"[HMI] 状态发布错误: {e}")
    
    # =========================================================================
    # Ring Keypad 处理
    # =========================================================================
    
    async def _keypad_listener(self):
        """Ring Keypad 监听 - 优先使用 MQTT"""
        
        if self.config.keypad_use_mqtt:
            await self._keypad_listener_mqtt()
        else:
            await self._keypad_listener_websocket()
    
    async def _keypad_listener_mqtt(self):
        """Ring Keypad MQTT 监听（通过 Z-Wave JS UI MQTT 网关）"""
        try:
            from ng_edge.hardware.ring_keypad_zwavejs_mqtt import (
                RingKeypadZwaveJsMqtt, KeypadEvent, KeypadEventData
            )
        except ImportError as e:
            logger.error(f"[Keypad] 导入失败: {e}")
            return
        
        logger.info(f"[Keypad] 连接 MQTT (Node ID: {self.config.keypad_node_id})...")
        
        try:
            self.keypad = RingKeypadZwaveJsMqtt(
                node_id=self.config.keypad_node_id,
                mqtt_host=self.config.mqtt_host,
                mqtt_port=self.config.mqtt_port,
                key_mapping=self.config.keypad_key_mapping,
            )
            
            # 设置事件回调
            self.keypad.on_keypad_event = self._handle_keypad_event_mqtt
            
            # 连接
            if not self.keypad.connect():
                logger.error("[Keypad] MQTT 连接失败")
                return
            
            logger.info("[Keypad] ✅ 已连接")
            
            # 保持运行
            while self.running:
                await asyncio.sleep(1)
        
        except Exception as e:
            logger.error(f"[Keypad] 错误: {e}")
        
        finally:
            if self.keypad:
                self.keypad.disconnect()
    
    async def _keypad_listener_websocket(self):
        """Ring Keypad WebSocket 监听（直接连接 Z-Wave JS）"""
        try:
            from ng_edge.hardware.ring_keypad_zwave import RingKeypadZWave, KeypadEvent, KeypadState
        except ImportError as e:
            logger.error(f"[Keypad] 导入失败: {e}")
            return
        
        logger.info(f"[Keypad] 连接 Z-Wave JS {self.config.keypad_ws_url}...")
        logger.info(f"[Keypad] Node ID: {self.config.keypad_node_id}")
        
        try:
            self.keypad = RingKeypadZWave(
                ws_url=self.config.keypad_ws_url,
                node_id=self.config.keypad_node_id,
            )
            
            # 设置事件回调
            self.keypad.on_keypad_event = self._handle_keypad_event
            
            # 连接
            if not await self.keypad.connect():
                logger.error("[Keypad] 连接失败")
                return
            
            logger.info("[Keypad] ✅ 已连接")
            
            # 保持运行
            while self.running:
                await asyncio.sleep(1)
        
        except Exception as e:
            logger.error(f"[Keypad] 错误: {e}")
        
        finally:
            if self.keypad:
                await self.keypad.disconnect()
    
    def _handle_keypad_event_mqtt(self, event):
        """处理 Keypad MQTT 事件"""
        from ng_edge.hardware.ring_keypad_zwavejs_mqtt import KeypadEvent
        
        logger.info(f"[Keypad] 事件: {event.event_type.value}")
        
        if event.event_type == KeypadEvent.DISARM_PRESSED:
            self._handle_keypad_disarm(event.pin)
        
        elif event.event_type == KeypadEvent.OK_PRESSED:
            # OK 按钮通常用于确认 PIN
            self._handle_keypad_pin(event.pin)
        
        elif event.event_type == KeypadEvent.AWAY_PRESSED:
            self._handle_keypad_arm("AWAY", event.pin)
        
        elif event.event_type == KeypadEvent.HOME_PRESSED:
            self._handle_keypad_arm("HOME", event.pin)
    
    def _handle_keypad_event(self, event):
        """处理 Keypad 事件"""
        from ng_edge.hardware.ring_keypad_zwave import KeypadEvent, KeypadState
        
        logger.info(f"[Keypad] 事件: {event.event_type.value}")
        
        if event.event_type == KeypadEvent.DISARM_PRESSED:
            self._handle_keypad_disarm(event.pin)
        
        elif event.event_type == KeypadEvent.PIN_ENTERED:
            self._handle_keypad_pin(event.pin)
        
        elif event.event_type == KeypadEvent.AWAY_PRESSED:
            self._handle_keypad_arm("AWAY", event.pin)
        
        elif event.event_type == KeypadEvent.HOME_PRESSED:
            self._handle_keypad_arm("HOME", event.pin)
    
    def _get_current_security_level(self) -> int:
        """
        获取当前安全等级
        
        等级定义：
          0 = DISARMED (撤防)
          1 = HOME (在家)
          2 = AWAY (离家)
          3 = PENDING/TRIGGERED (威胁状态)
        """
        # 检查是否有活跃的 Entry Delay（PENDING 状态）
        if self._entry_delay_tasks:
            for task in self._entry_delay_tasks.values():
                if not task.done():
                    return 3  # PENDING
        
        # 检查任一 Deterrent System 是否在 TRIGGERED 状态
        for ds in self.deterrent_systems.values():
            if ds._triggered_active:
                return 3  # TRIGGERED
        
        # 根据 house_mode 返回等级
        mode = self.coordinator.house_mode
        if mode == HouseMode.DISARMED:
            return 0
        elif mode == HouseMode.HOME:
            return 1
        elif mode == HouseMode.AWAY:
            return 2
        else:
            return 0
    
    def _get_target_security_level(self, target_mode: str) -> int:
        """获取目标安全等级"""
        levels = {
            "DISARMED": 0, "disarm": 0,
            "HOME": 1, "home": 1,
            "AWAY": 2, "away": 2,
        }
        return levels.get(target_mode, 0)
    
    def _verify_pin(self, pin: Optional[str]) -> bool:
        """验证 PIN 码"""
        if not pin:
            return False
        return pin in self.config.valid_pins
    
    def _handle_keypad_disarm(self, pin: Optional[str]):
        """
        处理 Keypad 撤防
        
        安全规则：降级安全等级必须提供有效 PIN
        """
        current_level = self._get_current_security_level()
        target_level = 0  # DISARMED
        
        logger.warning(f"[Keypad] 🔓 DISARM 按下 (当前等级: {current_level})" + 
                      (f" PIN: ***" if pin else " 无PIN"))
        
        # 安全检查：降级需要 PIN
        if target_level < current_level:
            if not self._verify_pin(pin):
                logger.error(f"[Keypad] ❌ 拒绝：降低安全等级需要有效 PIN")
                self.stats["keypad_invalid_pins"] += 1
                return
        
        # 撤防成功
        logger.warning("[Keypad] ✅ 撤防成功!")
        self.stats["keypad_disarms"] += 1
        
        # 取消所有 Entry Delay
        self._cancel_all_entry_delays()
        
        # 撤防协调器
        self.disarm()
        
        # 设置 Keypad 状态（如果支持）
        if self.keypad and hasattr(self.keypad, 'set_state'):
            try:
                from ng_edge.hardware.ring_keypad_zwave import KeypadState
                asyncio.create_task(self.keypad.set_state(KeypadState.DISARMED))
            except:
                pass
        
        # 回调
        if self.on_keypad_disarm:
            self.on_keypad_disarm()
    
    def _handle_keypad_pin(self, pin: Optional[str]):
        """处理单独 PIN 输入（OK 按钮）"""
        if not pin:
            logger.warning("[Keypad] OK 按下但无 PIN 输入")
            return
        
        if self._verify_pin(pin):
            logger.info(f"[Keypad] ✅ PIN 有效")
        else:
            logger.warning(f"[Keypad] ❌ PIN 无效")
            self.stats["keypad_invalid_pins"] += 1
    
    def _handle_keypad_arm(self, mode: str, pin: Optional[str]):
        """
        处理 Keypad 布防
        
        安全规则：
          - 提升安全等级（disarm→home→away）：不需要 PIN
          - 降低安全等级（away→home）：需要有效 PIN
        """
        current_level = self._get_current_security_level()
        target_level = self._get_target_security_level(mode)
        
        logger.info(f"[Keypad] {mode} 按下 (当前等级: {current_level} → 目标: {target_level})" +
                   (f" PIN: ***" if pin else ""))
        
        # 安全检查
        if target_level < current_level:
            # 降级需要 PIN
            if not self._verify_pin(pin):
                logger.error(f"[Keypad] ❌ 拒绝：降低安全等级需要有效 PIN")
                self.stats["keypad_invalid_pins"] += 1
                return
        elif target_level == current_level:
            logger.info(f"[Keypad] 已经是 {mode} 模式")
            return
        # target_level > current_level: 升级不需要 PIN
        
        # 如果提供了 PIN，验证它（即使不需要）
        if pin and not self._verify_pin(pin):
            logger.warning(f"[Keypad] ⚠️ PIN 无效（但升级不需要 PIN，继续执行）")
        
        # 设置模式
        if mode == "AWAY":
            self.set_mode(HouseMode.AWAY)
            logger.info("[Keypad] ✅ 已设置 AWAY 模式")
        elif mode == "HOME":
            self.set_mode(HouseMode.HOME)
            logger.info("[Keypad] ✅ 已设置 HOME 模式")
    
    # =========================================================================
    # Camera 处理
    # =========================================================================
    
    async def _camera_processor(self, cam_id: str, cam_cfg: CameraDeviceConfig):
        """摄像头处理任务"""
        # 创建配置
        config = CameraConfig(
            name=cam_cfg.name,
            ip=cam_cfg.ip,
            username=cam_cfg.username,
            password=cam_cfg.password,
            stream_type=StreamType.SUB if cam_cfg.stream_type == "sub" else StreamType.MAIN,
            use_tcp=True,
        )
        
        logger.info(f"[{cam_id}] 连接 {cam_cfg.ip}...")
        camera = ReolinkUltrawideClient(config)
        
        if not camera.connect():
            logger.error(f"[{cam_id}] 无法连接")
            return
        
        logger.info(f"[{cam_id}] 已连接 ({camera.actual_width}x{camera.actual_height})")
        self.cameras[cam_id] = camera
        
        frame_interval = 1.0 / self.config.yolo_fps
        last_detect_time = 0
        
        # 检测状态（参考旧版本 yolo11_multi_camera.py 的做法）
        person_active = False           # 是否已确认有人
        current_level = 0               # 当前威慑级别
        current_zone = ""               # 当前分区
        consecutive_detections = 0      # 连续检测计数
        clear_timeout = self.config.camera_clear_timeout_sec  # 人员离开判断时间
        last_person_time = 0
        CONFIRM_FRAMES = 2              # 进入确认帧数
        
        # Camera Tamper 检测状态 (PRD §8.1 Phase 1)
        tamper_consecutive_black_frames = 0
        tamper_black_threshold = 30  # 连续 30 帧黑屏 (~3秒 @10fps)
        tamper_last_mean_brightness = None
        tamper_brightness_drop_threshold = 0.7  # 亮度骤降 70% 触发
        tamper_blackout_reported = False  # 避免重复报告
        
        # Camera Offline 检测 (PRD §8.1)
        offline_start_time = None  # 离线开始时间
        offline_confirm_sec = 90.0  # PRD: offline_confirm_sec = 90s
        offline_reported = False  # 避免重复报告
        
        # ===== 感应灯功能 (DISARMED/HOME 模式) =====
        motion_light_on = False  # 当前灯状态
        motion_light_last_person = 0  # 最后检测到人的时间
        motion_light_off_delay = 30.0  # 人离开后延迟关灯时间（秒）
        
        while self.running:
            ret, frame = camera.read_frame()
            if not ret or frame is None:
                # ===== Camera Offline 检测 =====
                now = time.time()
                if offline_start_time is None:
                    offline_start_time = now
                    logger.warning(f"[{cam_id}] ⚠️ 帧读取失败，开始离线计时")
                
                offline_duration = now - offline_start_time
                # 仅记录离线事件，不触发威慑
                # 注意：当前实现不是 PRD §8.1 定义的完整 Tamper-C 确认流程
                if offline_duration >= offline_confirm_sec and not offline_reported:
                    logger.info(f"[{cam_id}] camera_offline 事件: 离线 {offline_duration:.1f}s (仅记录，不触发威慑)")
                    if self.on_tamper_detected:
                        self.on_tamper_detected(cam_id, cam_cfg.entrypoint_id, "camera_offline")
                    offline_reported = True
                
                await asyncio.sleep(0.1)
                continue
            
            # 帧读取成功，重置离线状态
            if offline_start_time is not None:
                logger.info(f"[{cam_id}] ✅ 摄像头恢复在线")
                offline_start_time = None
                offline_reported = False
            
            # ===== Camera Tamper Phase 1: 黑屏/强降质检测 (仅记录，不触发威慑) =====
            # 注意：当前实现不是 PRD §8.1 定义的完整 Tamper-C 确认流程
            # 完整 Tamper-C 需要：双摄独立域、与 door/glass 的时间窗口相关、Tier gating 等
            if self.config.house_mode == HouseMode.AWAY:
                import cv2
                gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
                mean_brightness = gray.mean()
                
                # 黑屏检测（亮度 < 10）- 仅记录
                if mean_brightness < 10:
                    tamper_consecutive_black_frames += 1
                    if tamper_consecutive_black_frames == tamper_black_threshold and not tamper_blackout_reported:
                        logger.info(f"[{cam_id}] camera_blackout 事件: 亮度={mean_brightness:.1f} (仅记录，不触发威慑)")
                        if self.on_tamper_detected:
                            self.on_tamper_detected(cam_id, cam_cfg.entrypoint_id, "camera_blackout")
                        tamper_blackout_reported = True
                else:
                    tamper_consecutive_black_frames = 0
                    tamper_blackout_reported = False
                
                # 亮度骤降检测 - 仅记录
                if tamper_last_mean_brightness is not None and tamper_last_mean_brightness > 20:
                    brightness_ratio = mean_brightness / tamper_last_mean_brightness
                    if brightness_ratio < (1 - tamper_brightness_drop_threshold):
                        logger.info(f"[{cam_id}] camera_brightness_drop 事件: {tamper_last_mean_brightness:.1f}→{mean_brightness:.1f} (仅记录，不触发威慑)")
                        if self.on_tamper_detected:
                            self.on_tamper_detected(cam_id, cam_cfg.entrypoint_id, "camera_brightness_drop")
                
                tamper_last_mean_brightness = mean_brightness
            # ===== End Camera Tamper =====
            
            # ===== 感应灯关灯检查 (每帧都检查，不依赖 YOLO) =====
            # 只在非警戒模式下启用
            if self.config.house_mode in (HouseMode.DISARMED, HouseMode.HOME):
                now_for_light = time.time()
                if motion_light_on and (now_for_light - motion_light_last_person > motion_light_off_delay):
                    motion_light_on = False
                    logger.info(f"[{cam_id}] 💡 感应灯 OFF (无人 {motion_light_off_delay:.0f}s)")
                    asyncio.create_task(self._motion_light_off(cam_id))
            
            # 帧采样
            now = time.time()
            if now - last_detect_time < frame_interval:
                await asyncio.sleep(0.01)
                continue
            
            last_detect_time = now
            
            # YOLO 检测 - 找到最高优先级的人
            best_detection = None
            all_persons = []  # 调试：记录所有人检测
            if self.detector:
                detections, _ = self.detector.detect(frame, visualize=False)
                
                for det in detections:
                    if det.class_name == "person":
                        frame_width = camera.actual_width or 640
                        frame_height = camera.actual_height or 480
                        zone, pre_level = self._get_zone_and_level(cam_cfg, det.bbox, frame_width, frame_height)
                        
                        # 调试：记录所有人检测
                        x, y, w, h = det.bbox
                        y2 = y + h
                        all_persons.append(f"y2={y2} conf={det.confidence:.2f} → {zone}/L{pre_level}")
                        
                        if pre_level > 0:  # 忽略 street (L0)
                            if best_detection is None or pre_level > best_detection[2]:
                                best_detection = (det, zone, pre_level)
            
            # ===== 时间戳（供后续日志使用）=====
            ts = datetime.now().strftime("%H:%M:%S.%f")[:-3]
            # ===== 调试日志已注释（v2.39 验证延迟问题已解决）=====
            # if best_detection:
            #     det, zone, pre_level = best_detection
            #     x, y, w, h = det.bbox
            #     y2 = y + h
            #     print(f"[{ts}] [{cam_id}] DETECT: y2={y2} conf={det.confidence:.2f} zone={zone} L{pre_level} | active={person_active} curr_L={current_level}")
            # else:
            #     if person_active:
            #         gap = now - last_person_time
            #         print(f"[{ts}] [{cam_id}] NO_DET: gap={gap:.1f}s | active={person_active} curr_L={current_level}")
            
            # 状态机（参考旧版本 yolo11_multi_camera.py）
            if best_detection:
                det, zone, pre_level = best_detection
                last_person_time = now
                consecutive_detections += 1
                
                # 详细日志：每次检测（debug 级别避免影响性能）
                logger.debug(f"[{cam_id}] 👤 conf={det.confidence:.2f} zone={zone} L{pre_level} | person_active={person_active} current_level={current_level} consecutive={consecutive_detections}")
                
                if not person_active:
                    # 等待确认帧数后才进入
                    if consecutive_detections >= CONFIRM_FRAMES:
                        person_active = True
                        current_zone = zone
                        current_level = pre_level
                        
                        logger.info(f"[{cam_id}] ========== PERSON ENTER | {current_zone} L{current_level} ==========")
                        
                        # 报告威慑级别（根据模式转换）
                        effective_level = self._get_deterrent_level(pre_level)
                        logger.info(f"[{cam_id}] → report_sensor(L{effective_level}) [ENTER]")
                        self._report_sensor_to_ep(cam_id, effective_level)
                        
                        # LOGISTICS: 通知人员进入 (PRD §13.x)
                        self._logistics_sm.on_person_enter(cam_id, current_zone, current_level, now)
                        
                        # 发送信号（后台执行，不阻塞检测）
                        asyncio.create_task(self._process_camera_detection(cam_id, cam_cfg, det, now))
                else:
                    # 已有人，检查级别变化 - 立即响应，不需要重新确认
                    if pre_level != current_level:
                        old_level = current_level
                        current_zone = zone
                        current_level = pre_level
                        
                        direction = "⬆️" if current_level > old_level else "⬇️"
                        logger.info(f"[{cam_id}] {direction} L{old_level} → L{current_level} ({current_zone})")
                        
                        # 报告新的威慑级别（根据模式转换）
                        effective_level = self._get_deterrent_level(current_level)
                        logger.info(f"[{cam_id}] → report_sensor(L{effective_level}) [CHANGE {old_level}→{current_level}]")
                        self._report_sensor_to_ep(cam_id, effective_level)
                        
                        # LOGISTICS: 通知位置更新 (PRD §13.x)
                        self._logistics_sm.on_person_update(cam_id, current_zone, current_level, now)
                        
                        # 发送信号（后台执行，不阻塞检测）
                        asyncio.create_task(self._process_camera_detection(cam_id, cam_cfg, det, now))
                    else:
                        # 级别不变，持续报告以刷新传感器超时（静默）
                        effective_level = self._get_deterrent_level(current_level)
                        self._report_sensor_to_ep(cam_id, effective_level)
            else:
                # 无人检测
                if not person_active:
                    consecutive_detections = 0
                else:
                    # 已有人但当前帧没检测到，等待超时
                    if now - last_person_time > clear_timeout:
                        logger.info(f"[{cam_id}] ========== PERSON LEAVE ==========")
                        logger.info(f"[{cam_id}] → report_sensor(L0) [LEAVE after {clear_timeout}s gap]")
                        
                        # LOGISTICS: 通知人员离开 (PRD §13.x)
                        self._logistics_sm.on_person_leave(cam_id, now)
                        
                        # 报告无人（级别0）
                        self._report_sensor_to_ep(cam_id, 0)
                        
                        person_active = False
                        current_zone = ""
                        current_level = 0
                        consecutive_detections = 0
                    else:
                        # ✅ 修复：检测间隙期间持续刷新传感器，防止 SENSOR_TIMEOUT
                        effective_level = self._get_deterrent_level(current_level)
                        self._report_sensor_to_ep(cam_id, effective_level)
            
            # ===== 感应灯亮灯 (DISARMED/HOME 模式) =====
            # 关灯检查已在帧采样之前执行
            if self.config.house_mode in (HouseMode.DISARMED, HouseMode.HOME):
                if best_detection and cam_cfg.has_light:
                    # 检测到人 → 亮灯 + 刷新时间
                    motion_light_last_person = now
                    if not motion_light_on:
                        motion_light_on = True
                        logger.info(f"[{cam_id}] 💡 感应灯 ON")
                        asyncio.create_task(self._motion_light_on(cam_id))
            
            await asyncio.sleep(0.01)
        
        camera.disconnect()
    
    async def _process_camera_detection(self, cam_id: str, cam_cfg: CameraDeviceConfig, det, now: float):
        """处理摄像头检测"""
        # 冷却检查
        last_time = self.last_signal_time.get(cam_id, 0)
        if now - last_time < self.config.signal_cooldown_sec:
            return
        self.last_signal_time[cam_id] = now
        
        # 获取帧尺寸（从检测结果推断或使用默认值）
        camera = self.cameras.get(cam_id)
        if camera:
            frame_width = camera.actual_width or 640
            frame_height = camera.actual_height or 480
        else:
            frame_width, frame_height = 640, 480
        
        # 计算分区和 PRE 级别
        zone, pre_level = self._get_zone_and_level(cam_cfg, det.bbox, frame_width, frame_height)
        
        # PRE-L0 (street) 不触发威慑
        if pre_level == 0:
            logger.debug(f"[{cam_id}] person in street zone, skipping")
            return
        
        # 创建 SignalEnvelope
        envelope = SignalEnvelope.from_camera(
            device_id=cam_id,
            signal_kind="person_detected",
            zone_id=cam_cfg.zone_id,
            entrypoint_id=cam_cfg.entrypoint_id,
            camera_role=cam_cfg.role,
            confidence=det.confidence,
            bbox=det.bbox,
            class_name=det.class_name,
        )
        
        self.stats["camera_detections"] += 1
        logger.info(f"[{cam_id}] person conf={det.confidence:.2f} zone={zone} PRE-L{pre_level} → {cam_cfg.entrypoint_id}")
        
        # 处理信号（传递 PRE 级别）
        await self._process_signal(envelope, pre_level=pre_level)
    
    def _get_zone_and_level(self, cam_cfg: CameraDeviceConfig, bbox: List[int], 
                            frame_width: int, frame_height: int) -> Tuple[str, int]:
        """
        根据检测框位置判断分区和 PRE 级别
        
        bbox 格式: (x, y, w, h) 来自 yolo_detector
        
        zone_mode="horizontal" (俯视): 用 y2 判断（脚的 y 位置）
        zone_mode="vertical" (水平视角): 用 x 坐标判断
          - direction="left_to_right": 门在右边，用 x2 判断
          - direction="right_to_left": 门在左边，用 x1 判断
        
        Returns:
            (zone_name, pre_level): ("door", 2) / ("yard", 1) / ("street", 0)
        """
        x, y, w, h = bbox
        
        if cam_cfg.zone_mode == "vertical":
            # 水平视角：用 x 坐标判断
            if cam_cfg.direction == "right_to_left":
                # 门在左边：用 x1（人的左边缘）判断
                pos = x
                door_pos = int(frame_width * (1.0 - cam_cfg.door_threshold))  # 反转阈值
                yard_pos = int(frame_width * (1.0 - cam_cfg.yard_threshold)) if cam_cfg.yard_threshold > 0 else frame_width
                
                # pos <= door_pos → door L2（靠近左边的门）
                if pos <= door_pos:
                    zone, level = "door", 2
                elif pos <= yard_pos:
                    zone, level = "yard", 1
                else:
                    zone, level = "street", 0
                
                logger.debug(f"[ZONE] x1={pos} door_pos={door_pos} yard_pos={yard_pos} → {zone} L{level}")
            else:
                # 门在右边：用 x2（人的右边缘）判断
                pos = x + w
                door_pos = int(frame_width * cam_cfg.door_threshold)
                yard_pos = int(frame_width * cam_cfg.yard_threshold) if cam_cfg.yard_threshold > 0 else 0
                
                # pos >= door_pos → door L2（靠近右边的门）
                if pos >= door_pos:
                    zone, level = "door", 2
                elif pos >= yard_pos:
                    zone, level = "yard", 1
                else:
                    zone, level = "street", 0
                
                logger.debug(f"[ZONE] x2={pos} door_pos={door_pos} yard_pos={yard_pos} → {zone} L{level}")
        else:
            # 俯视（horizontal）：用 y 坐标判断
            y2 = y + h  # 脚的位置
            door_y = int(frame_height * cam_cfg.door_threshold)
            yard_y = int(frame_height * cam_cfg.yard_threshold) if cam_cfg.yard_threshold > 0 else 0
            
            # y2 >= door_y → door L2
            if y2 >= door_y:
                zone, level = "door", 2
            elif y2 >= yard_y:
                zone, level = "yard", 1
            else:
                zone, level = "street", 0
            
            logger.debug(f"[ZONE] y2={y2} door_y={door_y} yard_y={yard_y} → {zone} L{level}")
        
        return zone, level
    
    def _get_deterrent_level(self, raw_level: int) -> int:
        """
        根据 HouseMode 获取有效威慑级别
        
        模式规则：
        - DISARMED: 返回 0（所有情况都不报警）
        - HOME: 返回 0（人员检测不报警，只有玻璃破碎才报警）
        - AWAY: 返回原始级别（全部走报警程序）
        """
        if self.coordinator.house_mode == HouseMode.DISARMED:
            return 0
        if self.coordinator.house_mode == HouseMode.HOME:
            return 0  # HOME 模式下人员检测不触发威慑
        return raw_level
    
    # =========================================================================
    # 信号处理
    # =========================================================================
    
    async def _process_signal(self, envelope: SignalEnvelope, pre_level: int = None):
        """
        处理信号
        
        Args:
            envelope: 信号包
            pre_level: PRE 级别 (1=L1, 2=L2, 3=L3)，仅用于摄像头检测
        """
        # 回调
        if self.on_signal:
            self.on_signal(envelope)
        
        # 发送到协调器
        result = self.coordinator.process_envelope(envelope)
        
        if result.threat_changed:
            logger.info(f"  → 状态变化: {result.from_threat} → {result.to_threat}")
        
        # 摄像头检测：直接根据 PRE 级别报告威慑
        # (根据 HouseMode 转换级别，DISARMED 时输入 0)
        if pre_level is not None and pre_level > 0:
            effective_level = self._get_deterrent_level(pre_level)
            if effective_level > 0:
                self._report_sensor_to_ep(envelope.device_id, effective_level)
        
        # 检查动作权限
        if result.threat_state in {ThreatState.PRE_L2, ThreatState.PRE_L3}:
            self._check_action(ActionType.PUSH_NOTIFICATION, result.threat_state)
        
        if result.threat_state == ThreatState.TRIGGERED:
            self._check_action(ActionType.SIREN_ACTIVATE, result.threat_state)
            self._check_action(ActionType.SMS_ALERT, result.threat_state)
    
    def _check_action(self, action: ActionType, threat_state: ThreatState):
        """检查并记录动作权限"""
        gate_result = self.action_gate.check(action, threat_state)
        
        if gate_result.decision == GateDecision.ALLOW:
            self.stats["actions_allowed"] += 1
            logger.info(f"  → 动作允许: {action.value}")
        else:
            self.stats["actions_denied"] += 1
            logger.debug(f"  → 动作拒绝: {action.value}")
        
        if self.on_action:
            self.on_action(action, gate_result.decision)
    
    def _on_state_transition(self, result: ProcessResult):
        """状态转换回调"""
        self.stats["state_changes"] += 1
        
        # HMI: 记录状态变化事件
        event_level = "critical" if result.to_threat == ThreatState.TRIGGERED else "warning"
        self._record_event(
            "state_change",
            f"状态: {result.from_threat.value} → {result.to_threat.value} ({result.entry_point_id})",
            event_level,
            result.entry_point_id
        )
        
        logger.warning("=" * 50)
        logger.warning(f"🔔 STATE CHANGE: {result.from_threat} → {result.to_threat}")
        logger.warning(f"   Entry Point: {result.entry_point_id}")
        logger.warning(f"   Incident: {result.incident_id}")
        logger.warning(f"   Reason: {result.reason_code}")
        logger.warning("=" * 50)
        
        # 检测 PENDING 状态 → 启动 Entry Delay
        if result.to_threat == ThreatState.PENDING and result.from_threat != ThreatState.PENDING:
            # 获取入口点配置的延迟时间
            delay_sec = self.config.entry_delay_sec
            self._start_entry_delay(result.entry_point_id, delay_sec)
            
            # 设置 Keypad Entry Delay 状态
            if self.keypad and hasattr(self.keypad, 'set_state'):
                try:
                    from ng_edge.hardware.ring_keypad_zwave import KeypadState
                    asyncio.create_task(self.keypad.set_state(KeypadState.ENTRY_DELAY, countdown=delay_sec))
                except:
                    pass
        
        # 检测离开 PENDING → 取消 Entry Delay
        if result.from_threat == ThreatState.PENDING and result.to_threat != ThreatState.PENDING:
            self._cancel_entry_delay(result.entry_point_id)
        
        # 检测 TRIGGERED → 设置 Keypad Triggered 状态
        if result.to_threat == ThreatState.TRIGGERED:
            if self.keypad and hasattr(self.keypad, 'set_state'):
                try:
                    from ng_edge.hardware.ring_keypad_zwave import KeypadState
                    asyncio.create_task(self.keypad.set_state(KeypadState.TRIGGERED))
                except:
                    pass
        
        # 威慑控制 - 只处理 TRIGGERED 和 NONE
        # PRE_L1/L2/L3 威慑由摄像头检测独立控制 (report_sensor)
        if result.to_threat == ThreatState.TRIGGERED:
            # TRIGGERED: 对应 entry_point 的威慑系统进入 TRIGGERED 模式
            ep_id = result.entry_point_id
            logger.info(f"[DETERRENT] TRIGGERED ep_id={ep_id}, available={list(self.deterrent_systems.keys())}")
            if ep_id and ep_id in self.deterrent_systems:
                logger.info(f"[DETERRENT] 只触发 {ep_id} 的威慑系统")
                self.deterrent_systems[ep_id].set_triggered(True)
            else:
                # 如果没有指定 entry_point，对所有系统操作
                logger.warning(f"[DETERRENT] ep_id={ep_id} 不在 deterrent_systems 中，触发所有系统")
                for ds in self.deterrent_systems.values():
                    ds.set_triggered(True)
        elif result.to_threat == ThreatState.PENDING:
            # PENDING 停止 PRE 威慑（进入 Entry Delay 状态）
            # 注意：这里不 force_stop，让传感器超时自然降级
            pass
        elif result.to_threat == ThreatState.NONE:
            # 恢复到 NONE → 停止对应 entry_point 的威慑
            ep_id = result.entry_point_id
            if ep_id and ep_id in self.deterrent_systems:
                self.deterrent_systems[ep_id].set_triggered(False)
                self.deterrent_systems[ep_id].force_stop()
            else:
                # 如果没有指定 entry_point，对所有系统操作
                for ds in self.deterrent_systems.values():
                    ds.set_triggered(False)
                    ds.force_stop()
        
        if self.on_state_change:
            self.on_state_change(result)
        
        # 发布 HMI 状态
        asyncio.create_task(self._publish_hmi_status())
    
    def _on_delivery_detected(self, event: LogisticsEvent):
        """
        LOGISTICS 快递检测回调
        
        由 LogisticsSM 在检测到快递行为时调用
        """
        logger.warning("=" * 50)
        logger.warning(f"📦 DELIVERY DETECTED")
        logger.warning(f"   Camera: {event.camera_id}")
        logger.warning(f"   Duration: {event.duration_sec}s")
        logger.warning(f"   Confidence: {event.confidence}")
        logger.warning("=" * 50)
        
        # 检查是否有活跃的 SECURITY 状态（输出仲裁）
        # PRD §13.x.7: TRIGGER > PENDING > PRE > LOGISTICS
        for ep_id in self._ep_to_cameras.keys():
            threat = self.coordinator.get_threat_state(ep_id)
            if threat in [ThreatState.TRIGGERED, ThreatState.PENDING]:
                logger.info(f"[LOGISTICS] 通知被抑制 (SECURITY state={threat.value})")
                return
            elif threat in [ThreatState.PRE_L1, ThreatState.PRE_L2, ThreatState.PRE_L3]:
                logger.info(f"[LOGISTICS] 通知降级为静默 (SECURITY state={threat.value})")
                # 可以继续处理，但不发送 push notification
        
        # 触发外部回调
        if self.on_delivery_detected:
            self.on_delivery_detected(event)
    
    # =========================================================================
    # 控制接口
    # =========================================================================
    
    def set_mode(self, house_mode: HouseMode, user_mode: UserMode = None):
        """设置模式"""
        if user_mode is None:
            user_mode = self.coordinator.user_mode
        
        old_mode = self.config.house_mode
        self.config.house_mode = house_mode  # 更新配置
        self.coordinator.set_modes(house_mode, user_mode)
        
        # DISARMED 时停止所有威慑
        if house_mode == HouseMode.DISARMED:
            for ds in self.deterrent_systems.values():
                ds.force_stop()
        
        # 切换到 AWAY 时关闭感应灯（让威慑系统接管）
        if house_mode == HouseMode.AWAY and old_mode in (HouseMode.DISARMED, HouseMode.HOME):
            logger.info("[感应灯] 切换到 AWAY 模式，关闭所有感应灯")
            # 安全地调度异步任务（可能从非事件循环线程调用）
            try:
                loop = asyncio.get_running_loop()
                asyncio.create_task(self._turn_off_all_motion_lights())
            except RuntimeError:
                # 没有运行中的事件循环，使用 run_coroutine_threadsafe
                try:
                    loop = asyncio.get_event_loop()
                    if loop.is_running():
                        asyncio.run_coroutine_threadsafe(self._turn_off_all_motion_lights(), loop)
                    else:
                        logger.warning("[感应灯] 无法关闭感应灯：事件循环未运行")
                except Exception as e:
                    logger.warning(f"[感应灯] 调度失败: {e}")
        
        logger.info(f"模式变更: {house_mode.value}")
    
    def disarm(self):
        """撤防"""
        # 取消所有 entry delay 定时器
        self._cancel_all_entry_delays()
        
        # 获取所有入口点并撤防
        entry_points = set()
        for dev_cfg in self.config.zigbee_devices.values():
            if dev_cfg.entrypoint_id:
                entry_points.add(dev_cfg.entrypoint_id)
        for cam_cfg in self.config.cameras.values():
            if cam_cfg.entrypoint_id:
                entry_points.add(cam_cfg.entrypoint_id)
        
        # 撤防所有入口点
        for ep_id in entry_points:
            self.coordinator.cancel(ep_id)
            logger.debug(f"撤防入口点: {ep_id}")
        
        # 也撤防全局
        self.coordinator.cancel("_global")
        
        # 切换到 DISARMED 模式（会调用 force_stop 停止威慑）
        self.set_mode(HouseMode.DISARMED)
        
        logger.info("系统已撤防")
    
    def get_status(self) -> Dict:
        """获取状态"""
        return {
            "running": self.running,
            "house_mode": self.config.house_mode.value,
            "cameras_connected": len(self.cameras),
            "entry_delays": {
                ep_id: remaining 
                for ep_id, remaining in self._entry_delay_remaining.items()
                if remaining > 0
            },
            "stats": self.stats.copy(),
        }
    
    def get_entry_delay_remaining(self, entry_point_id: str) -> float:
        """获取入口点剩余延迟时间"""
        return self._entry_delay_remaining.get(entry_point_id, 0)
    
    # =========================================================================
    # Entry Delay 定时器
    # =========================================================================
    
    def _start_entry_delay(self, entry_point_id: str, delay_sec: int):
        """启动 Entry Delay 倒计时"""
        # 取消已有定时器
        self._cancel_entry_delay(entry_point_id)
        
        self.stats["entry_delays_started"] += 1
        self._entry_delay_remaining[entry_point_id] = delay_sec
        
        logger.warning(f"⏱️ [{entry_point_id}] Entry Delay 开始: {delay_sec}s")
        
        # 创建倒计时任务
        task = asyncio.create_task(self._entry_delay_countdown(entry_point_id, delay_sec))
        self._entry_delay_tasks[entry_point_id] = task
    
    async def _entry_delay_countdown(self, entry_point_id: str, delay_sec: int):
        """Entry Delay 倒计时任务"""
        remaining = delay_sec
        
        try:
            while remaining > 0 and self.running:
                self._entry_delay_remaining[entry_point_id] = remaining
                
                # 回调
                if self.on_entry_delay_tick:
                    self.on_entry_delay_tick(entry_point_id, remaining)
                
                # 每秒日志 (最后 10 秒或每 5 秒)
                if remaining <= 10 or remaining % 5 == 0:
                    logger.warning(f"⏱️ [{entry_point_id}] Entry Delay: {remaining}s 剩余")
                
                await asyncio.sleep(1)
                remaining -= 1
            
            # 倒计时结束
            if remaining <= 0 and self.running:
                await self._entry_delay_expired(entry_point_id)
        
        except asyncio.CancelledError:
            logger.info(f"⏱️ [{entry_point_id}] Entry Delay 已取消")
            self.stats["entry_delays_cancelled"] += 1
        
        finally:
            self._entry_delay_remaining[entry_point_id] = 0
            if entry_point_id in self._entry_delay_tasks:
                del self._entry_delay_tasks[entry_point_id]
    
    async def _entry_delay_expired(self, entry_point_id: str):
        """Entry Delay 超时 → TRIGGERED"""
        self.stats["entry_delays_expired"] += 1
        
        logger.error("!" * 60)
        logger.error(f"🚨 [{entry_point_id}] ENTRY DELAY EXPIRED → TRIGGERED")
        logger.error("!" * 60)
        
        # 调用协调器
        result = self.coordinator.trigger_entry_delay_expired(entry_point_id)
        
        if result.threat_state == ThreatState.TRIGGERED:
            self.stats["triggered_count"] += 1
            
            # 触发动作
            self._check_action(ActionType.SIREN_ACTIVATE, ThreatState.TRIGGERED)
            self._check_action(ActionType.SMS_ALERT, ThreatState.TRIGGERED)
            self._check_action(ActionType.PUSH_NOTIFICATION, ThreatState.TRIGGERED)
            
            # 🚨 激活声光报警 - 只激活对应 entry_point 的威慑系统
            await self._activate_alarm_ep(entry_point_id)
            
            # 回调
            if self.on_triggered:
                self.on_triggered(entry_point_id, result.incident_id)
    
    # =========================================================================
    # 声光控制 (Reolink) - 威慑系统
    # =========================================================================
    # 
    # 威慑策略（基于硬件测试）：
    # - L1: 常亮灯 + 每30秒警报(1秒)
    # - L2: 闪灯(5s亮/5s灭) + 每10秒警报(2秒)
    # - TRIGGERED: 闪灯(4s间隔) + 每3秒警报(3秒)
    # 
    # 硬件限制：
    # - 灯光 API 耗时 3-7 秒，闪灯间隔必须 > 4秒
    # - set_siren(duration=N) 可设置警报持续时间
    # =========================================================================
    
    async def _init_reolink_hosts(self):
        """初始化 Reolink API 客户端"""
        try:
            from reolink_aio.api import Host
        except ImportError:
            logger.warning("[Reolink] reolink_aio 未安装，声光控制不可用")
            return
        
        for cam_id, cam_cfg in self.config.cameras.items():
            if cam_cfg.has_siren or cam_cfg.has_light:
                try:
                    host = Host(cam_cfg.ip, cam_cfg.username, cam_cfg.password)
                    await host.get_host_data()
                    self.reolink_hosts[cam_id] = host
                    logger.info(f"[Reolink] {cam_id} API 已连接 ({cam_cfg.ip})")
                except Exception as e:
                    logger.error(f"[Reolink] {cam_id} API 连接失败: {e}")
    
    # =========================================================================
    # 威慑输出控制 - 按 Entry Point 隔离
    # =========================================================================
    
    async def _deterrent_spotlight_ep(self, on: bool, entry_point_id: str):
        """按 Entry Point 的灯光控制"""
        cameras = self._ep_to_cameras.get(entry_point_id, [])
        logger.debug(f"[DETERRENT] _deterrent_spotlight_ep({on}, {entry_point_id}) cameras={cameras}")
        
        if not cameras:
            logger.warning(f"[DETERRENT] ⚠️ {entry_point_id} 没有关联摄像头")
            return
        
        for cam_id in cameras:
            cam_cfg = self.config.cameras.get(cam_id)
            host = self.reolink_hosts.get(cam_id)
            
            logger.debug(f"[DETERRENT] {cam_id}: host={host is not None}, cam_cfg={cam_cfg is not None}, has_light={cam_cfg.has_light if cam_cfg else 'N/A'}")
            
            if host and cam_cfg and cam_cfg.has_light:
                try:
                    await host.set_whiteled(0, state=on)
                    if on:
                        self.stats["light_activations"] += 1
                        logger.info(f"[DETERRENT] 💡 {entry_point_id}/{cam_id} 灯光 ON")
                    else:
                        logger.info(f"[DETERRENT] 💡 {entry_point_id}/{cam_id} 灯光 OFF")
                except Exception as e:
                    logger.warning(f"[DETERRENT] ⚠️ {cam_id} 灯光控制失败: {e}")
            else:
                reasons = []
                if not host:
                    reasons.append("host=None")
                if not cam_cfg:
                    reasons.append("cam_cfg=None")
                elif not cam_cfg.has_light:
                    reasons.append("has_light=False")
                logger.warning(f"[DETERRENT] ⚠️ {entry_point_id}/{cam_id} 灯光跳过: {', '.join(reasons)}")
    
    async def _deterrent_siren_ep(self, duration: float, entry_point_id: str):
        """按 Entry Point 的警报控制"""
        cameras = self._ep_to_cameras.get(entry_point_id, [])
        logger.debug(f"[DETERRENT] _deterrent_siren_ep({duration}, {entry_point_id}) cameras={cameras}")
        
        if not cameras:
            logger.warning(f"[DETERRENT] ⚠️ {entry_point_id} 没有关联摄像头")
            return
        
        for cam_id in cameras:
            cam_cfg = self.config.cameras.get(cam_id)
            host = self.reolink_hosts.get(cam_id)
            
            logger.debug(f"[DETERRENT] {cam_id}: host={host is not None}, cam_cfg={cam_cfg is not None}, has_siren={cam_cfg.has_siren if cam_cfg else 'N/A'}")
            
            if host and cam_cfg and cam_cfg.has_siren:
                try:
                    await host.set_siren(0, True, duration=int(duration))
                    self.stats["siren_activations"] += 1
                    logger.info(f"[DETERRENT] 🔔 {entry_point_id}/{cam_id} 警报 ({duration}s)")
                except Exception as e:
                    logger.warning(f"[DETERRENT] ⚠️ {cam_id} 警报失败: {e}")
            else:
                reasons = []
                if not host:
                    reasons.append("host=None")
                if not cam_cfg:
                    reasons.append("cam_cfg=None")
                elif not cam_cfg.has_siren:
                    reasons.append("has_siren=False")
                logger.warning(f"[DETERRENT] ⚠️ {entry_point_id}/{cam_id} 警报跳过: {', '.join(reasons)}")
    
    # =========================================================================
    # 威慑输出控制 - 全局 (兼容旧接口)
    # =========================================================================
    
    async def _deterrent_spotlight(self, on: bool):
        """威慑系统灯光回调"""
        if on:
            await self._spotlight_on()
        else:
            await self._spotlight_off()
    
    async def _deterrent_siren(self, duration: float):
        """威慑系统警报回调"""
        await self._trigger_siren(int(duration))
    
    async def _spotlight_on(self):
        """开灯（全局）"""
        for cam_id, cam_cfg in self.config.cameras.items():
            host = self.reolink_hosts.get(cam_id)
            if host and cam_cfg.has_light:
                try:
                    await host.set_whiteled(0, state=True)
                    self.stats["light_activations"] += 1
                except Exception as e:
                    logger.debug(f"[{cam_id}] 开灯失败: {e}")
    
    async def _spotlight_off(self):
        """关灯"""
        for cam_id, cam_cfg in self.config.cameras.items():
            host = self.reolink_hosts.get(cam_id)
            if host and cam_cfg.has_light:
                try:
                    await host.set_whiteled(0, state=False)
                except Exception as e:
                    logger.debug(f"[{cam_id}] 关灯失败: {e}")
    
    # =========================================================================
    # 感应灯功能 (DISARMED/HOME 模式)
    # =========================================================================
    
    async def _motion_light_on(self, cam_id: str):
        """感应灯开启（单个摄像头）"""
        try:
            host = self.reolink_hosts.get(cam_id)
            if host:
                await host.set_whiteled(0, state=True)
                logger.info(f"[{cam_id}] 💡 感应灯已开启")
        except Exception as e:
            logger.debug(f"[{cam_id}] 感应灯开启失败: {e}")
    
    async def _motion_light_off(self, cam_id: str):
        """感应灯关闭（单个摄像头）"""
        try:
            host = self.reolink_hosts.get(cam_id)
            if host:
                await host.set_whiteled(0, state=False)
                logger.info(f"[{cam_id}] 💡 感应灯已关闭")
        except Exception as e:
            logger.debug(f"[{cam_id}] 感应灯关闭失败: {e}")
    
    async def _turn_off_all_motion_lights(self):
        """关闭所有摄像头的感应灯（模式切换时调用）"""
        for cam_id, cam_cfg in self.config.cameras.items():
            if cam_cfg.has_light:
                await self._motion_light_off(cam_id)
    
    async def _trigger_siren(self, duration: int):
        """触发警报（使用 duration 参数）"""
        for cam_id, cam_cfg in self.config.cameras.items():
            host = self.reolink_hosts.get(cam_id)
            if host and cam_cfg.has_siren:
                try:
                    await host.set_siren(0, True, duration=duration)
                    self.stats["siren_activations"] += 1
                    logger.info(f"[DETERRENT] 🔔 警报 (duration={duration}s)")
                except Exception as e:
                    logger.debug(f"[{cam_id}] 警报失败: {e}")
    
    async def _siren_off(self):
        """关闭警报"""
        for cam_id, cam_cfg in self.config.cameras.items():
            host = self.reolink_hosts.get(cam_id)
            if host and cam_cfg.has_siren:
                try:
                    await host.set_siren(0, False)
                except:
                    pass
    
    async def _activate_alarm_ep(self, entry_point_id: str):
        """激活 TRIGGERED 威慑（只针对指定 Entry Point）"""
        ds = self.deterrent_systems.get(entry_point_id)
        if ds:
            logger.info(f"[DETERRENT] 🚨 激活 {entry_point_id} 的威慑系统")
            ds.set_triggered(True)
        else:
            logger.warning(f"[DETERRENT] 未找到 {entry_point_id} 的威慑系统")
    
    async def _activate_alarm(self):
        """激活 TRIGGERED 威慑（所有 Entry Point）"""
        for ep_id, ds in self.deterrent_systems.items():
            logger.info(f"[DETERRENT] 🚨 激活 {ep_id} 的威慑系统")
            ds.set_triggered(True)
    
    async def _deactivate_alarm(self):
        """关闭所有摄像头的声光报警"""
        logger.info("[DETERRENT] 关闭声光")
        await self._spotlight_off()
        await self._siren_off()
    
    def _cancel_entry_delay(self, entry_point_id: str):
        """取消单个入口点的 Entry Delay"""
        task = self._entry_delay_tasks.get(entry_point_id)
        if task and not task.done():
            task.cancel()
    
    def _cancel_all_entry_delays(self):
        """取消所有 Entry Delay"""
        for entry_point_id in list(self._entry_delay_tasks.keys()):
            self._cancel_entry_delay(entry_point_id)


# =============================================================================
# 主函数
# =============================================================================

async def main():
    """测试入口"""
    import argparse
    
    parser = argparse.ArgumentParser(description="EdgeRuntime")
    parser.add_argument("--duration", type=int, default=None, help="运行时长（秒）")
    parser.add_argument("--no-cameras", action="store_true", help="不启动摄像头")
    parser.add_argument("--no-zigbee", action="store_true", help="不启动 Zigbee")
    args = parser.parse_args()
    
    config = get_default_config()
    
    if args.no_cameras:
        config.cameras = {}
    if args.no_zigbee:
        config.zigbee_devices = {}
    
    runtime = EdgeRuntime(config)
    
    try:
        if args.duration:
            # 限时运行
            async def run_with_timeout():
                task = asyncio.create_task(runtime.start())
                await asyncio.sleep(args.duration)
                runtime.running = False
                await task
            await run_with_timeout()
        else:
            await runtime.start()
    except KeyboardInterrupt:
        logger.info("用户中断")
        await runtime.stop()


if __name__ == "__main__":
    asyncio.run(main())
