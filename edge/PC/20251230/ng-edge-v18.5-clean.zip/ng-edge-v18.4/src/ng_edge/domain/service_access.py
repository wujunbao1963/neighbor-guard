"""
Service Access Window Models - PRD v7.5.0 §1.3.1

Defines models for authorized access windows (e.g., vacation construction/maintenance).
"""

from pydantic import BaseModel, Field
from typing import List, Optional
from datetime import time


class ServiceWindowActions(BaseModel):
    """Actions to take when access is authorized within window."""
    
    suppress_alarm_outputs: bool = True
    """Suppress siren/strobe during authorized access"""
    
    suppress_neighbor_notifications: bool = True
    """Don't notify neighbors during authorized access"""
    
    still_record_evidence: bool = True
    """Still record evidence for audit trail"""
    
    override_follower_acceleration: bool = False
    """Disable follower acceleration during window"""


class ServiceWindowSession(BaseModel):
    """Session management for authorized access."""
    
    idle_timeout_sec: int = Field(default=900, ge=60, le=7200)
    """Idle timeout in seconds (default 15 min)"""
    
    summary_notification: str = Field(default="silent")
    """Notification type: silent | digest | none"""


class ServiceAccessWindow(BaseModel):
    """
    Service Access Window configuration.
    
    Allows authorized access during specific time windows for
    maintenance/construction while vacation mode is active.
    
    PRD v7.5.0 §1.3.1
    """
    
    service_window_id: str
    """Unique window ID"""
    
    name: str
    """Human-readable name (e.g., 'Painter - Daytime')"""
    
    timezone: str = "America/Edmonton"
    """Timezone for time calculations"""
    
    start_at_local: str = Field(..., pattern=r"^\d{2}:\d{2}$")
    """Start time in HH:MM format (local time)"""
    
    end_at_local: str = Field(..., pattern=r"^\d{2}:\d{2}$")
    """End time in HH:MM format (local time)"""
    
    days_of_week: List[str] = Field(default_factory=list)
    """Days of week: MON, TUE, WED, THU, FRI, SAT, SUN"""
    
    allowed_entry_point_ids: List[str] = Field(default_factory=list)
    """Entry points allowed during window"""
    
    allowed_zone_ids: List[str] = Field(default_factory=list)
    """Zones allowed during window"""
    
    restricted_zone_ids: List[str] = Field(default_factory=list)
    """Zones that are always restricted (bedrooms, office, etc.)"""
    
    actions: ServiceWindowActions = Field(default_factory=ServiceWindowActions)
    """Actions to take during authorized access"""
    
    session: ServiceWindowSession = Field(default_factory=ServiceWindowSession)
    """Session management settings"""
    
    enabled: bool = True
    """Whether this window is currently active"""
    
    def get_start_time(self) -> time:
        """Parse start_at_local to time object."""
        h, m = map(int, self.start_at_local.split(':'))
        return time(hour=h, minute=m)
    
    def get_end_time(self) -> time:
        """Parse end_at_local to time object."""
        h, m = map(int, self.end_at_local.split(':'))
        return time(hour=h, minute=m)
    
    def is_active_day(self, day_of_week: str) -> bool:
        """
        Check if window is active on given day.
        
        Args:
            day_of_week: MON, TUE, WED, THU, FRI, SAT, SUN
        
        Returns:
            True if window is active on this day
        """
        if not self.enabled:
            return False
        if not self.days_of_week:
            return True  # No restriction = all days
        return day_of_week.upper() in [d.upper() for d in self.days_of_week]


class AccessEvaluation(BaseModel):
    """
    Result of access policy evaluation.
    
    Used internally by AccessPolicyResolver.
    """
    
    decision: str  # AccessDecision enum value
    """AUTHORIZED | UNAUTHORIZED | NOT_IN_WINDOW | OVERRIDE_FORCED"""
    
    active_window_id: Optional[str] = None
    """ID of active service window (if any)"""
    
    reason: Optional[str] = None
    """Human-readable reason for decision"""
    
    override_reason: Optional[str] = None
    """Reason for override (if decision is UNAUTHORIZED or OVERRIDE_FORCED)"""
    
    matched_window: Optional[ServiceAccessWindow] = None
    """The window that was matched (if any)"""
