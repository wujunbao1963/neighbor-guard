"""
独立状态机架构 v5.3

变更 (v5.3):
- 添加 min_pending_sec 配置：确保 PENDING 至少有最小纠错窗口
- 添加 quick_cancel_sec 配置：door_close 快速取消 PENDING
- DISARMED 模式记录 core evidence（PRD: "core evidence remains"）
- 明确 PENDING 超时由外部调度器触发

变更 (v5.2):
- PRD v7.6.1: motion/presence 不能直接触发 TRIGGERED（包括 PRE 状态）
- 移除所有 from_inside 启发式判断（语义不可解释）
- 统一门打开处理逻辑

=== 统一行为矩阵 ===
| Signal/Mode      | DISARMED | HOME      | AWAY    | NIGHT_OCC | NIGHT_PERI |
|------------------|----------|-----------|---------|-----------|------------|
| exterior person  | QUIET    | PRE       | PRE     | PRE       | PRE        |
| door open        | QUIET    | PRE/ATTEN | PENDING | PENDING   | PENDING    |
| door close       | QUIET    | QUIET     | *QC     | *QC       | *QC        |
| interior motion  | QUIET    | QUIET     | QUIET   | QUIET     | QUIET      |
| glass break      | QUIET    | TRIGGER   | TRIGGER | TRIGGERED | TRIGGERED  |

*QC = Quick Cancel: 如果在 quick_cancel_sec 内关门，取消 PENDING

关键原则 (PRD v7.6.1):
- motion/presence 永远不能直接触发 TRIGGERED（无论何种状态）
- 只有 GLASS_BREAK 可以直接触发 TRIGGERED
- door_open 必须先进入 PENDING（可撤销窗口）
- PENDING 至少持续 min_pending_sec（即使 entry_delay=0）

PENDING 超时机制：
- 状态机本身不自动触发超时
- 由外部调度器调用 trigger_entry_delay_expired()
- 外部使用 get_effective_delay() 获取有效延迟时间
- 外部使用 get_pending_elapsed() 获取已经过时间

状态定义：
- QUIET: 正常/静默状态
- ATTENTION: 注意状态（通知后立即回QUIET）
- PRE: 预警状态（Cancel→QUIET）
- PENDING: 倒计时（Cancel→QUIET, 超时→TRIGGERED）
- TRIGGERED: 报警触发（Resolve→QUIET）
"""

from dataclasses import dataclass, field
from datetime import datetime, timezone, timedelta
from enum import Enum
from typing import Optional, Callable, List, Dict, Any
import uuid


# =============================================================================
# 枚举定义
# =============================================================================

class AlarmState(str, Enum):
    """报警状态"""
    QUIET = "quiet"
    ATTENTION = "attention"
    PRE = "pre"
    PENDING = "pending"
    TRIGGERED = "triggered"


class UserMode(str, Enum):
    """用户模式"""
    ALERT = "alert"   # 警觉模式 - 更多提醒
    QUIET = "quiet"   # 安静模式 - 减少打扰


class HouseMode(str, Enum):
    """房屋模式"""
    DISARMED = "disarmed"
    HOME = "home"
    AWAY = "away"
    NIGHT_OCCUPIED = "night_occupied"
    NIGHT_PERIMETER = "night_perimeter"


class ZoneType(str, Enum):
    """区域类型"""
    EXTERIOR = "exterior"
    ENTRY_EXIT = "entry_exit"
    INTERIOR = "interior"
    PERIMETER = "perimeter"


class SignalType(str, Enum):
    """信号类型"""
    PERSON_DETECTED = "person_detected"
    VEHICLE_DETECTED = "vehicle_detected"
    DOOR_OPEN = "door_open"
    DOOR_CLOSE = "door_close"
    MOTION_ACTIVE = "motion_active"
    GLASS_BREAK = "glass_break"


# =============================================================================
# 数据结构
# =============================================================================

@dataclass
class Signal:
    """传感器信号"""
    entry_point_id: str  # 关联的入口点
    zone_type: ZoneType
    signal_type: SignalType
    device_id: str = ""  # 触发信号的设备 ID（用于 quick cancel 匹配）
    from_inside: bool = False  # 保留但不再用于决策
    confidence: float = 1.0
    timestamp: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    signal_id: str = field(default_factory=lambda: f"sig_{uuid.uuid4().hex[:8]}")


@dataclass
class TransitionResult:
    """状态转换结果"""
    success: bool
    entry_point_id: str
    from_state: AlarmState
    to_state: AlarmState
    reason: str
    message: Optional[str] = None
    event_record: Optional['EventRecord'] = None


@dataclass
class EventRecord:
    """事件记录"""
    event_id: str
    entry_point_id: str
    start_time: datetime
    end_time: datetime
    start_state: AlarmState
    end_state: AlarmState
    end_reason: str
    signals: List[Signal] = field(default_factory=list)


# =============================================================================
# 单入口状态机
# =============================================================================

class EntryPointStateMachine:
    """
    单个入口点的状态机
    
    每个 Entry Point（门、窗等）有独立的状态机实例
    """
    
    def __init__(
        self,
        entry_point_id: str,
        entry_point_name: str = "",
        house_mode: HouseMode = HouseMode.DISARMED,
        user_mode: UserMode = UserMode.QUIET,
        entry_delay_sec: int = 30,
        min_pending_sec: int = 2,  # 最小 PENDING 窗口（即使 entry_delay=0）
        quick_cancel_sec: int = 3,  # door_close 快速取消窗口
        on_state_change: Optional[Callable[['EntryPointStateMachine', TransitionResult], None]] = None,
    ):
        self.entry_point_id = entry_point_id
        self.entry_point_name = entry_point_name or entry_point_id
        self._house_mode = house_mode
        self._user_mode = user_mode
        self._entry_delay_sec = entry_delay_sec
        self._min_pending_sec = min_pending_sec
        self._quick_cancel_sec = quick_cancel_sec
        self._state = AlarmState.QUIET
        self._pending_started_at: Optional[datetime] = None
        self._pending_door_device: Optional[str] = None  # 触发 PENDING 的门设备
        self._event_start_time: Optional[datetime] = None
        self._event_signals: List[Signal] = []
        self._events: List[EventRecord] = []
        
        # 用于 HOME 模式的链条检测（Quiet 模式特有）
        self._recent_exterior_person: Optional[datetime] = None
        self._chain_window_sec = 30
        
        # 回调
        self.on_state_change = on_state_change
    
    @property
    def state(self) -> AlarmState:
        return self._state
    
    @property
    def house_mode(self) -> HouseMode:
        return self._house_mode
    
    @property
    def user_mode(self) -> UserMode:
        return self._user_mode
    
    def set_modes(self, house_mode: HouseMode, user_mode: UserMode):
        """设置模式并重置状态"""
        self._house_mode = house_mode
        self._user_mode = user_mode
        self.reset()
    
    def process(self, signal: Signal) -> TransitionResult:
        """处理信号
        
        处理顺序：
        1. PENDING 状态下的 DOOR_CLOSE quick cancel 检查
        2. 路由到具体模式处理
        
        注意：PENDING 超时由外部调度器通过 trigger_entry_delay_expired() 触发
        """
        print(f"\n{'='*60}")
        print(f"🎯 [PROCESS] Entry Point: {self.entry_point_id}")
        print(f"  Signal: {signal.signal_type} | Zone: {signal.zone_type}")
        print(f"  Current State: {self._state}")
        print(f"  House Mode: {self._house_mode} | User Mode: {self._user_mode}")
        print(f"{'='*60}")
        
        # =====================================================================
        # PENDING 状态下的 DOOR_CLOSE quick cancel 检查
        # PRD: door_close within quick_cancel_sec → 取消 PENDING
        # =====================================================================
        if self._state == AlarmState.PENDING and signal.signal_type == SignalType.DOOR_CLOSE:
            # 设备匹配检查：
            # - 如果有 device_id，必须匹配触发门
            # - 如果没有 device_id（空字符串），跳过设备匹配，只检查时间窗口
            device_match = (
                not signal.device_id or  # 没有 device_id，跳过匹配
                not self._pending_door_device or  # 没有记录触发门，跳过匹配
                signal.device_id == self._pending_door_device  # 设备匹配
            )
            
            if device_match:
                elapsed = self.get_pending_elapsed()
                if elapsed <= self._quick_cancel_sec:
                    print(f"  🚪 DOOR_CLOSE quick cancel: {elapsed:.1f}s <= {self._quick_cancel_sec}s")
                    return self._quick_cancel_pending(signal, f"Quick cancel: door closed within {elapsed:.1f}s")
                else:
                    print(f"  🚪 DOOR_CLOSE after quick cancel window: {elapsed:.1f}s > {self._quick_cancel_sec}s")
            else:
                print(f"  🚪 DOOR_CLOSE from different device: {signal.device_id} != {self._pending_door_device}")
            
            # DOOR_CLOSE 不匹配触发门或超出窗口，记录但不改变状态
            self._event_signals.append(signal)
            return TransitionResult(
                success=True,
                entry_point_id=self.entry_point_id,
                from_state=self._state,
                to_state=self._state,
                reason="DOOR_CLOSE recorded in PENDING state",
            )
        
        # 根据 house_mode 和 user_mode 选择处理逻辑
        if self._house_mode == HouseMode.DISARMED:
            print(f"  路由到: _process_disarmed")
            return self._process_disarmed(signal)
        elif self._house_mode == HouseMode.HOME:
            if self._user_mode == UserMode.ALERT:
                print(f"  路由到: _process_home_alert")
                return self._process_home_alert(signal)
            else:
                print(f"  路由到: _process_home_quiet")
                return self._process_home_quiet(signal)
        elif self._house_mode == HouseMode.AWAY:
            print(f"  路由到: _process_away")
            return self._process_away(signal)
        elif self._house_mode == HouseMode.NIGHT_OCCUPIED:
            if self._user_mode == UserMode.ALERT:
                print(f"  路由到: _process_night_occupied_alert")
                return self._process_night_occupied_alert(signal)
            else:
                print(f"  路由到: _process_night_occupied_quiet")
                return self._process_night_occupied_quiet(signal)
        elif self._house_mode == HouseMode.NIGHT_PERIMETER:
            print(f"  路由到: _process_night_perimeter")
            return self._process_night_perimeter(signal)
        else:
            print(f"  ⚠ 未知模式")
            return self._stay_quiet("Unknown mode")
    
    # =========================================================================
    # DISARMED - 所有信号忽略
    # =========================================================================
    
    def _process_disarmed(self, signal: Signal) -> TransitionResult:
        """DISARMED: 所有信号忽略，但记录 core evidence
        
        PRD: "PRE disabled; core evidence remains"
        """
        # 记录信号（core evidence）
        self._event_signals.append(signal)
        return TransitionResult(
            success=True,
            entry_point_id=self.entry_point_id,
            from_state=AlarmState.QUIET,
            to_state=AlarmState.QUIET,
            reason="DISARMED - signal recorded but no state change",
        )
    
    # =========================================================================
    # HOME - Alert 模式 (更多提醒)
    # =========================================================================
    
    def _process_home_alert(self, signal: Signal) -> TransitionResult:
        """HOME + Alert: 传感器触发 → PRE
        
        PRD: 移除 from_inside 启发式判断（语义不可解释）
        """
        # Glass break 直接触发
        if signal.signal_type == SignalType.GLASS_BREAK:
            return self._to_triggered(signal, "🚨 玻璃破碎!")
        
        # Exterior person → PRE
        if signal.zone_type == ZoneType.EXTERIOR and signal.signal_type == SignalType.PERSON_DETECTED:
            return self._to_pre(signal, "👁️ 外部检测到人")
        
        # Door open → PRE (统一处理，不区分方向)
        if signal.signal_type == SignalType.DOOR_OPEN:
            return self._to_pre(signal, "🚪 门被打开")
        
        # Interior motion - HOME 模式忽略（用户在家）
        # PRD v7.6.1: motion/presence 不触发
        
        return self._stay_quiet("Signal ignored in HOME Alert mode")
    
    # =========================================================================
    # HOME - Quiet 模式 (减少打扰)
    # =========================================================================
    
    def _process_home_quiet(self, signal: Signal) -> TransitionResult:
        """HOME + Quiet: 外部人员和门打开通知
        
        PRD: 移除 from_inside 启发式判断（语义不可解释）
        """
        # Glass break 直接触发
        if signal.signal_type == SignalType.GLASS_BREAK:
            return self._to_triggered(signal, "🚨 玻璃破碎!")
        
        # Exterior person → ATTENTION (直接通知)
        if signal.zone_type == ZoneType.EXTERIOR and signal.signal_type == SignalType.PERSON_DETECTED:
            return self._to_attention(signal, "👁️ 外部检测到人")
        
        # Door open → ATTENTION (统一处理，不区分方向)
        if signal.signal_type == SignalType.DOOR_OPEN:
            return self._to_attention(signal, "🚪 门被打开")
        
        # Interior motion - 忽略
        return self._stay_quiet("Signal ignored in HOME Quiet mode")
    
    # =========================================================================
    # AWAY - Alert/Quiet 相同
    # =========================================================================
    
    def _process_away(self, signal: Signal) -> TransitionResult:
        """AWAY: 外部人=PRE, 门=PENDING, 玻璃破碎=TRIGGERED
        
        PRD v7.6.1: motion/presence 不能直接触发 TRIGGERED
        室内 motion 在 QUIET 状态下被忽略（高误报率）
        """
        # 处理非 QUIET 状态
        if self._state == AlarmState.PRE:
            if signal.signal_type == SignalType.DOOR_OPEN:
                return self._to_pending(signal, "⏱️ 入侵检测，请输入密码")
            # PRD v7.6.1: 只有 GLASS_BREAK 可以直接触发，MOTION_ACTIVE 不触发
            if signal.signal_type == SignalType.GLASS_BREAK:
                return self._to_triggered(signal, "🚨 玻璃破碎!")
            # PRE 状态下的其他信号（包括 MOTION_ACTIVE）：保持 PRE，记录
            self._event_signals.append(signal)
            return TransitionResult(
                success=True,
                entry_point_id=self.entry_point_id,
                from_state=AlarmState.PRE,
                to_state=AlarmState.PRE,
                reason="Signal recorded in PRE state",
            )
        
        if self._state == AlarmState.PENDING:
            # PENDING期间：Entry Delay倒计时
            # 用户有时间走到Keypad输入PIN码
            # 只有GLASS_BREAK立即触发，其他信号都记录
            if signal.signal_type == SignalType.GLASS_BREAK:
                return self._to_triggered(signal, "🚨 玻璃破碎!")
            
            # 其他信号（包括MOTION_ACTIVE）只记录，等待倒计时
            self._event_signals.append(signal)
            return TransitionResult(
                success=True,
                entry_point_id=self.entry_point_id,
                from_state=AlarmState.PENDING,
                to_state=AlarmState.PENDING,
                reason="Signal recorded in PENDING state (waiting for entry delay)",
            )
        
        if self._state == AlarmState.TRIGGERED:
            self._event_signals.append(signal)
            return TransitionResult(
                success=True,
                entry_point_id=self.entry_point_id,
                from_state=AlarmState.TRIGGERED,
                to_state=AlarmState.TRIGGERED,
                reason="Additional signal recorded",
            )
        
        # QUIET 状态
        if signal.signal_type == SignalType.GLASS_BREAK:
            return self._to_triggered(signal, "🚨 玻璃破碎!")
        
        # PRD v7.6.1: motion/presence 不能直接触发 TRIGGERED
        # INTERIOR + MOTION_ACTIVE 在 QUIET 状态下忽略（高误报率）
        # 入侵者必须先开门(→PENDING)或破窗(→TRIGGERED)才能进入室内
        # if signal.zone_type == ZoneType.INTERIOR and signal.signal_type == SignalType.MOTION_ACTIVE:
        #     return self._to_triggered(signal, "🚨 室内移动检测!")
        
        if signal.signal_type == SignalType.DOOR_OPEN:
            return self._to_pending(signal, "⏱️ 门被打开，请输入密码")
        
        if signal.zone_type == ZoneType.EXTERIOR and signal.signal_type == SignalType.PERSON_DETECTED:
            return self._to_pre(signal, "⚠️ 外部检测到人员")
        
        return self._stay_quiet("Signal ignored in AWAY mode")
    
    # =========================================================================
    # NIGHT_OCCUPIED - Alert 模式
    # =========================================================================
    
    def _process_night_occupied_alert(self, signal: Signal) -> TransitionResult:
        """NIGHT_OCC + Alert: 与 AWAY 模式相同逻辑
        
        PRD: 移除 from_inside 启发式判断（语义不可解释）
        门打开统一进入 PENDING，由用户输入 PIN 码解除
        """
        # 处理非 QUIET 状态
        if self._state == AlarmState.PRE:
            if signal.signal_type == SignalType.DOOR_OPEN:
                return self._to_pending(signal, "⏱️ 门被打开，请输入密码")
            if signal.signal_type == SignalType.GLASS_BREAK:
                return self._to_triggered(signal, "🚨 玻璃破碎!")
            # PRE 状态下的其他信号：保持 PRE，记录信号
            self._event_signals.append(signal)
            return TransitionResult(
                success=True,
                entry_point_id=self.entry_point_id,
                from_state=AlarmState.PRE,
                to_state=AlarmState.PRE,
                reason="Signal recorded in PRE state",
            )
        
        if self._state == AlarmState.PENDING:
            # PENDING期间：Entry Delay倒计时
            # 只有GLASS_BREAK立即触发
            if signal.signal_type == SignalType.GLASS_BREAK:
                return self._to_triggered(signal, "🚨 玻璃破碎!")
            
            # 其他信号只记录，等待倒计时
            self._event_signals.append(signal)
            return TransitionResult(
                success=True,
                entry_point_id=self.entry_point_id,
                from_state=AlarmState.PENDING,
                to_state=AlarmState.PENDING,
                reason="Signal recorded in PENDING state (waiting for entry delay)",
            )
        
        if self._state == AlarmState.TRIGGERED:
            self._event_signals.append(signal)
            return TransitionResult(
                success=True,
                entry_point_id=self.entry_point_id,
                from_state=AlarmState.TRIGGERED,
                to_state=AlarmState.TRIGGERED,
                reason="Additional signal recorded",
            )
        
        # QUIET 状态
        if signal.signal_type == SignalType.GLASS_BREAK:
            return self._to_triggered(signal, "🚨 玻璃破碎!")
        
        if signal.zone_type == ZoneType.EXTERIOR and signal.signal_type == SignalType.PERSON_DETECTED:
            return self._to_pre(signal, "⚠️ 夜间外部检测到人员")
        
        if signal.signal_type == SignalType.DOOR_OPEN:
            return self._to_pending(signal, "⏱️ 门被打开，请输入密码")
        
        # PRD v7.6.1: motion/presence 不能直接触发
        # Interior motion 在 QUIET 状态下忽略
        
        return self._stay_quiet("Signal ignored in NIGHT_OCC Alert mode")
    
    # =========================================================================
    # NIGHT_OCCUPIED - Quiet 模式
    # =========================================================================
    
    def _process_night_occupied_quiet(self, signal: Signal) -> TransitionResult:
        """NIGHT_OCC + Quiet: 与 AWAY 模式相同逻辑
        
        PRD: 移除 from_inside 启发式判断（语义不可解释）
        门打开统一进入 PENDING，由用户输入 PIN 码解除
        """
        # 处理非 QUIET 状态
        if self._state == AlarmState.PRE:
            if signal.signal_type == SignalType.DOOR_OPEN:
                return self._to_pending(signal, "⏱️ 门被打开，请输入密码")
            if signal.signal_type == SignalType.GLASS_BREAK:
                return self._to_triggered(signal, "🚨 玻璃破碎!")
            # PRE 状态下的其他信号：保持 PRE，记录信号
            self._event_signals.append(signal)
            return TransitionResult(
                success=True,
                entry_point_id=self.entry_point_id,
                from_state=AlarmState.PRE,
                to_state=AlarmState.PRE,
                reason="Signal recorded in PRE state",
            )
        
        if self._state == AlarmState.PENDING:
            # PENDING期间：Entry Delay倒计时
            # 只有GLASS_BREAK立即触发
            if signal.signal_type == SignalType.GLASS_BREAK:
                return self._to_triggered(signal, "🚨 玻璃破碎!")
            
            # 其他信号只记录，等待倒计时
            self._event_signals.append(signal)
            return TransitionResult(
                success=True,
                entry_point_id=self.entry_point_id,
                from_state=AlarmState.PENDING,
                to_state=AlarmState.PENDING,
                reason="Signal recorded in PENDING state (waiting for entry delay)",
            )
        
        if self._state == AlarmState.TRIGGERED:
            self._event_signals.append(signal)
            return TransitionResult(
                success=True,
                entry_point_id=self.entry_point_id,
                from_state=AlarmState.TRIGGERED,
                to_state=AlarmState.TRIGGERED,
                reason="Additional signal recorded",
            )
        
        # QUIET 状态
        if signal.signal_type == SignalType.GLASS_BREAK:
            return self._to_triggered(signal, "🚨 玻璃破碎!")
        
        if signal.zone_type == ZoneType.EXTERIOR and signal.signal_type == SignalType.PERSON_DETECTED:
            return self._to_pre(signal, "⚠️ 夜间外部检测到人员")
        
        if signal.signal_type == SignalType.DOOR_OPEN:
            return self._to_pending(signal, "⏱️ 门被打开，请输入密码")
        
        # PRD v7.6.1: motion/presence 不能直接触发
        # Interior motion 在 QUIET 状态下忽略（起夜）
        
        return self._stay_quiet("Signal ignored in NIGHT_OCC Quiet mode")
    
    # =========================================================================
    # NIGHT_PERIMETER - 无延迟，立即触发
    # =========================================================================
    
    def _process_night_perimeter(self, signal: Signal) -> TransitionResult:
        """NIGHT_PERIMETER: 与 AWAY 模式相同逻辑
        
        PRD v7.6.1: motion/presence 不能直接触发
        门打开进入 PENDING，由 entry delay 或 PIN 码控制
        """
        # 处理非 QUIET 状态
        if self._state == AlarmState.PRE:
            if signal.signal_type == SignalType.DOOR_OPEN:
                return self._to_pending(signal, "⏱️ 门被打开，请输入密码")
            if signal.signal_type == SignalType.GLASS_BREAK:
                return self._to_triggered(signal, "🚨 玻璃破碎!")
            # PRE 状态下的其他信号：保持 PRE，记录信号
            self._event_signals.append(signal)
            return TransitionResult(
                success=True,
                entry_point_id=self.entry_point_id,
                from_state=AlarmState.PRE,
                to_state=AlarmState.PRE,
                reason="Signal recorded in PRE state",
            )
        
        if self._state == AlarmState.PENDING:
            # PENDING期间：只有GLASS_BREAK立即触发
            if signal.signal_type == SignalType.GLASS_BREAK:
                return self._to_triggered(signal, "🚨 玻璃破碎!")
            # 其他信号只记录
            self._event_signals.append(signal)
            return TransitionResult(
                success=True,
                entry_point_id=self.entry_point_id,
                from_state=AlarmState.PENDING,
                to_state=AlarmState.PENDING,
                reason="Signal recorded in PENDING state (waiting for entry delay)",
            )
        
        if self._state == AlarmState.TRIGGERED:
            self._event_signals.append(signal)
            return TransitionResult(
                success=True,
                entry_point_id=self.entry_point_id,
                from_state=AlarmState.TRIGGERED,
                to_state=AlarmState.TRIGGERED,
                reason="Additional signal recorded",
            )
        
        # QUIET 状态
        if signal.signal_type == SignalType.GLASS_BREAK:
            return self._to_triggered(signal, "🚨 玻璃破碎!")
        
        if signal.signal_type == SignalType.DOOR_OPEN:
            return self._to_pending(signal, "⏱️ 门被打开，请输入密码")
        
        if signal.zone_type == ZoneType.EXTERIOR and signal.signal_type == SignalType.PERSON_DETECTED:
            return self._to_pre(signal, "⚠️ 夜间周界检测到人员")
        
        # PRD v7.6.1: motion/presence 不能直接触发
        # Interior motion 在 QUIET 状态下忽略
        
        return self._stay_quiet("Signal ignored in NIGHT_PERIMETER mode")
    
    # =========================================================================
    # 用户操作
    # =========================================================================
    
    def cancel(self) -> TransitionResult:
        """取消 PRE/PENDING"""
        if self._state in (AlarmState.PRE, AlarmState.PENDING):
            return self._record_and_return_quiet("canceled", f"{self._state.value} canceled by user")
        return TransitionResult(
            success=False,
            entry_point_id=self.entry_point_id,
            from_state=self._state,
            to_state=self._state,
            reason=f"Cannot cancel from {self._state.value}",
        )
    
    def _quick_cancel_pending(self, signal: Signal, reason: str) -> TransitionResult:
        """快速取消 PENDING（DOOR_CLOSE 在窗口期内）
        
        PRD: QUICK_OPEN_CLOSE - door_close within quick_cancel_sec
        """
        from_state = self._state
        self._event_signals.append(signal)
        
        event_record = EventRecord(
            event_id=f"evt_{uuid.uuid4().hex[:8]}",
            entry_point_id=self.entry_point_id,
            start_time=self._event_start_time or datetime.now(timezone.utc),
            end_time=datetime.now(timezone.utc),
            start_state=from_state,
            end_state=AlarmState.QUIET,
            end_reason="quick_canceled",
            signals=list(self._event_signals),
        )
        self._events.append(event_record)
        
        self._state = AlarmState.QUIET
        self._pending_started_at = None
        self._pending_door_device = None
        self._event_start_time = None
        self._event_signals.clear()
        
        result = TransitionResult(
            success=True,
            entry_point_id=self.entry_point_id,
            from_state=from_state,
            to_state=AlarmState.QUIET,
            reason=reason,
            message="🚪 Quick cancel: door closed quickly",
            event_record=event_record,
        )
        if self.on_state_change:
            self.on_state_change(self, result)
        return result
    
    def resolve(self) -> TransitionResult:
        """解除 TRIGGERED"""
        if self._state == AlarmState.TRIGGERED:
            return self._record_and_return_quiet("resolved", "TRIGGERED resolved by user")
        return TransitionResult(
            success=False,
            entry_point_id=self.entry_point_id,
            from_state=self._state,
            to_state=self._state,
            reason=f"Cannot resolve from {self._state.value}",
        )
    
    def trigger_entry_delay_expired(self) -> TransitionResult:
        """入口延迟超时"""
        if self._state == AlarmState.PENDING:
            from_state = self._state
            self._state = AlarmState.TRIGGERED
            result = TransitionResult(
                success=True,
                entry_point_id=self.entry_point_id,
                from_state=from_state,
                to_state=AlarmState.TRIGGERED,
                reason="Entry delay expired",
                message="⚠️ ALARM TRIGGERED!",
            )
            if self.on_state_change:
                self.on_state_change(self, result)
            return result
        return TransitionResult(
            success=False,
            entry_point_id=self.entry_point_id,
            from_state=self._state,
            to_state=self._state,
            reason="Not in PENDING state",
        )
    
    def reset(self):
        """重置状态"""
        self._state = AlarmState.QUIET
        self._pending_started_at = None
        self._pending_door_device = None
        self._event_start_time = None
        self._event_signals.clear()
        self._recent_exterior_person = None
    
    def get_effective_delay(self) -> int:
        """获取有效的 PENDING 延迟时间（供外部调度器使用）"""
        return max(self._entry_delay_sec, self._min_pending_sec)
    
    def get_pending_elapsed(self) -> float:
        """获取 PENDING 已经过的时间（秒）"""
        if self._pending_started_at is None:
            return 0.0
        return (datetime.now(timezone.utc) - self._pending_started_at).total_seconds()
    
    # =========================================================================
    # 辅助方法
    # =========================================================================
    
    def _check_chain(self) -> bool:
        """检查是否在链条窗口期内"""
        if self._recent_exterior_person is None:
            return False
        elapsed = (datetime.now(timezone.utc) - self._recent_exterior_person).total_seconds()
        return elapsed <= self._chain_window_sec
    
    def _start_event(self, signal: Signal):
        if self._event_start_time is None:
            self._event_start_time = datetime.now(timezone.utc)
        self._event_signals.append(signal)
    
    def _record_and_return_quiet(self, end_reason: str, reason: str) -> TransitionResult:
        from_state = self._state
        
        event_record = EventRecord(
            event_id=f"evt_{uuid.uuid4().hex[:8]}",
            entry_point_id=self.entry_point_id,
            start_time=self._event_start_time or datetime.now(timezone.utc),
            end_time=datetime.now(timezone.utc),
            start_state=from_state,
            end_state=AlarmState.QUIET,
            end_reason=end_reason,
            signals=list(self._event_signals),
        )
        self._events.append(event_record)
        
        self._state = AlarmState.QUIET
        self._pending_started_at = None
        self._event_start_time = None
        self._event_signals.clear()
        
        result = TransitionResult(
            success=True,
            entry_point_id=self.entry_point_id,
            from_state=from_state,
            to_state=AlarmState.QUIET,
            reason=reason,
            event_record=event_record,
        )
        if self.on_state_change:
            self.on_state_change(self, result)
        return result
    
    def _to_attention(self, signal: Signal, message: str) -> TransitionResult:
        self._start_event(signal)
        
        event_record = EventRecord(
            event_id=f"evt_{uuid.uuid4().hex[:8]}",
            entry_point_id=self.entry_point_id,
            start_time=self._event_start_time or datetime.now(timezone.utc),
            end_time=datetime.now(timezone.utc),
            start_state=AlarmState.QUIET,
            end_state=AlarmState.QUIET,
            end_reason="attention_logged",
            signals=list(self._event_signals),
        )
        self._events.append(event_record)
        
        self._event_start_time = None
        self._event_signals.clear()
        
        result = TransitionResult(
            success=True,
            entry_point_id=self.entry_point_id,
            from_state=AlarmState.QUIET,
            to_state=AlarmState.QUIET,
            reason="ATTENTION logged",
            message=message,
            event_record=event_record,
        )
        if self.on_state_change:
            self.on_state_change(self, result)
        return result
    
    def _to_pre(self, signal: Signal, message: str) -> TransitionResult:
        from_state = self._state
        self._state = AlarmState.PRE
        self._start_event(signal)
        result = TransitionResult(
            success=True,
            entry_point_id=self.entry_point_id,
            from_state=from_state,
            to_state=AlarmState.PRE,
            reason="Entered PRE state",
            message=message,
        )
        if self.on_state_change:
            self.on_state_change(self, result)
        return result
    
    def _to_pending(self, signal: Signal, message: str) -> TransitionResult:
        from_state = self._state
        self._state = AlarmState.PENDING
        self._pending_started_at = datetime.now(timezone.utc)
        self._pending_door_device = signal.device_id  # 记录触发 PENDING 的门设备
        self._start_event(signal)
        
        # 计算有效延迟：至少 min_pending_sec
        effective_delay = max(self._entry_delay_sec, self._min_pending_sec)
        
        result = TransitionResult(
            success=True,
            entry_point_id=self.entry_point_id,
            from_state=from_state,
            to_state=AlarmState.PENDING,
            reason=f"Entered PENDING ({effective_delay}s countdown)",
            message=message,
        )
        if self.on_state_change:
            self.on_state_change(self, result)
        return result
    
    def _to_triggered(self, signal: Signal, message: str) -> TransitionResult:
        from_state = self._state
        self._state = AlarmState.TRIGGERED
        self._start_event(signal)
        result = TransitionResult(
            success=True,
            entry_point_id=self.entry_point_id,
            from_state=from_state,
            to_state=AlarmState.TRIGGERED,
            reason="TRIGGERED!",
            message=message,
        )
        if self.on_state_change:
            self.on_state_change(self, result)
        return result
    
    def _stay_quiet(self, reason: str) -> TransitionResult:
        return TransitionResult(
            success=False,  # 信号未被接受/忽略
            entry_point_id=self.entry_point_id,
            from_state=self._state,  # 使用当前实际状态
            to_state=self._state,    # 保持当前状态  
            reason=reason,
        )


# =============================================================================
# 全局协调器
# =============================================================================

class SecurityCoordinator:
    """
    全局安全协调器
    
    管理所有 Entry Point 的状态机，提供统一接口
    """
    
    def __init__(
        self,
        house_mode: HouseMode = HouseMode.DISARMED,
        user_mode: UserMode = UserMode.QUIET,
        entry_delay_sec: int = 30,
        min_pending_sec: int = 2,  # 最小 PENDING 窗口
        quick_cancel_sec: int = 3,  # DOOR_CLOSE 快速取消窗口
        on_global_state_change: Optional[Callable[[str, TransitionResult], None]] = None,
    ):
        self._house_mode = house_mode
        self._user_mode = user_mode
        self._entry_delay_sec = entry_delay_sec
        self._min_pending_sec = min_pending_sec
        self._quick_cancel_sec = quick_cancel_sec
        self._entry_points: Dict[str, EntryPointStateMachine] = {}
        self._global_events: List[EventRecord] = []
        self.on_global_state_change = on_global_state_change
        
        # 创建默认的全局入口（用于非入口点信号）
        self._create_entry_point("_global", "Global")
    
    def _on_entry_state_change(self, sm: EntryPointStateMachine, result: TransitionResult):
        """入口状态变化回调"""
        if result.event_record:
            self._global_events.append(result.event_record)
        if self.on_global_state_change:
            self.on_global_state_change(sm.entry_point_id, result)
    
    def _create_entry_point(self, entry_point_id: str, name: str = "", entry_delay_sec: int = None) -> EntryPointStateMachine:
        """创建入口状态机"""
        delay = entry_delay_sec if entry_delay_sec is not None else self._entry_delay_sec
        sm = EntryPointStateMachine(
            entry_point_id=entry_point_id,
            entry_point_name=name or entry_point_id,
            house_mode=self._house_mode,  # 使用当前模式！
            user_mode=self._user_mode,    # 使用当前模式！
            entry_delay_sec=delay,
            min_pending_sec=self._min_pending_sec,
            quick_cancel_sec=self._quick_cancel_sec,
            on_state_change=self._on_entry_state_change,
        )
        self._entry_points[entry_point_id] = sm
        return sm
    
    def register_entry_point(self, entry_point_id: str, name: str = "", entry_delay_sec: int = None) -> EntryPointStateMachine:
        """注册入口点"""
        if entry_point_id in self._entry_points:
            # 更新已存在的入口点的名称和延时
            sm = self._entry_points[entry_point_id]
            sm.entry_point_name = name or entry_point_id
            if entry_delay_sec is not None:
                sm._entry_delay_sec = entry_delay_sec
            # 只在模式不同步时才调用 set_modes（避免重置状态）
            if sm._house_mode != self._house_mode or sm._user_mode != self._user_mode:
                print(f"⚠️ [SYNC] Entry Point {entry_point_id} 模式不同步，同步模式")
                sm.set_modes(self._house_mode, self._user_mode)
            return sm
        return self._create_entry_point(entry_point_id, name, entry_delay_sec)
    
    def get_entry_point(self, entry_point_id: str) -> Optional[EntryPointStateMachine]:
        """获取入口状态机"""
        return self._entry_points.get(entry_point_id)
    
    def set_modes(self, house_mode: HouseMode, user_mode: UserMode):
        """设置全局模式"""
        self._house_mode = house_mode
        self._user_mode = user_mode
        for sm in self._entry_points.values():
            sm.set_modes(house_mode, user_mode)
    
    @property
    def house_mode(self) -> HouseMode:
        return self._house_mode
    
    @property
    def user_mode(self) -> UserMode:
        return self._user_mode
    
    def process(self, signal: Signal) -> TransitionResult:
        """处理信号，路由到对应的入口状态机"""
        entry_point_id = signal.entry_point_id or "_global"
        
        # 自动创建入口点（如果不存在）
        if entry_point_id not in self._entry_points:
            self._create_entry_point(entry_point_id)
        
        sm = self._entry_points[entry_point_id]
        return sm.process(signal)
    
    def cancel(self, entry_point_id: str = "_global") -> TransitionResult:
        """取消指定入口的报警"""
        sm = self._entry_points.get(entry_point_id)
        if not sm:
            return TransitionResult(
                success=False,
                entry_point_id=entry_point_id,
                from_state=AlarmState.QUIET,
                to_state=AlarmState.QUIET,
                reason=f"Entry point not found: {entry_point_id}",
            )
        return sm.cancel()
    
    def cancel_all(self) -> List[TransitionResult]:
        """取消所有入口的报警"""
        results = []
        for sm in self._entry_points.values():
            if sm.state in (AlarmState.PRE, AlarmState.PENDING):
                results.append(sm.cancel())
        return results
    
    def resolve(self, entry_point_id: str = "_global") -> TransitionResult:
        """解除指定入口的报警"""
        sm = self._entry_points.get(entry_point_id)
        if not sm:
            return TransitionResult(
                success=False,
                entry_point_id=entry_point_id,
                from_state=AlarmState.QUIET,
                to_state=AlarmState.QUIET,
                reason=f"Entry point not found: {entry_point_id}",
            )
        return sm.resolve()
    
    def resolve_all(self) -> List[TransitionResult]:
        """解除所有入口的报警"""
        results = []
        for sm in self._entry_points.values():
            if sm.state == AlarmState.TRIGGERED:
                results.append(sm.resolve())
        return results
    
    def reset(self):
        """重置所有状态"""
        for sm in self._entry_points.values():
            sm.reset()
        self._global_events.clear()
    
    def get_status(self) -> Dict[str, Any]:
        """获取全局状态"""
        entry_states = {}
        highest_state = AlarmState.QUIET
        priority = {
            AlarmState.QUIET: 0,
            AlarmState.ATTENTION: 1,
            AlarmState.PRE: 2,
            AlarmState.PENDING: 3,
            AlarmState.TRIGGERED: 4,
        }
        
        for ep_id, sm in self._entry_points.items():
            # _global 不显示在 entry_states 列表中，但参与 highest_state 计算
            if priority[sm.state] > priority[highest_state]:
                highest_state = sm.state
            
            if ep_id == "_global":
                continue
            
            entry_states[ep_id] = {
                "name": sm.entry_point_name,
                "state": sm.state.value,
            }
        
        return {
            "house_mode": self._house_mode.value,
            "user_mode": self._user_mode.value,
            "global_state": highest_state.value,
            "entry_points": entry_states,
            "event_count": len(self._global_events),
        }
    
    def get_events(self, limit: int = 50) -> List[EventRecord]:
        """获取最近的事件"""
        return self._global_events[-limit:]
