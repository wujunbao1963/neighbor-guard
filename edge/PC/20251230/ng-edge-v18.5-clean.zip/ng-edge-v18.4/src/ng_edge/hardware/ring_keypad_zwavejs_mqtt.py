"""
Ring Keypad Z-Wave JS UI MQTT Integration

通过 Z-Wave JS UI 的 MQTT 网关与 Ring Keypad 交互

Topic 格式: zwave/nodeID_X/111/0/...
- 111 是 Entry Control Command Class
- 按键事件没有 value 字段
- 数字缓存更新有 value 字段
"""

import asyncio
import json
import time
from typing import Optional, Dict, Any, Callable
from datetime import datetime, timezone
from enum import Enum
import logging

logger = logging.getLogger(__name__)

# paho-mqtt 是可选依赖
try:
    import paho.mqtt.client as mqtt
    HAS_MQTT = True
except ImportError:
    HAS_MQTT = False
    logger.warning("paho-mqtt not installed, Ring Keypad integration disabled")


class KeypadEvent(str, Enum):
    """Keypad 事件类型"""
    KEY_PRESSED = "key_pressed"
    PIN_ENTERED = "pin_entered"
    DISARM_PRESSED = "disarm_pressed"
    HOME_PRESSED = "home_pressed"
    AWAY_PRESSED = "away_pressed"
    OK_PRESSED = "ok_pressed"
    CANCEL_PRESSED = "cancel_pressed"
    PANIC_PRESSED = "panic_pressed"
    CONNECTED = "connected"
    DISCONNECTED = "disconnected"


class KeypadEventData:
    """Keypad 事件数据"""
    
    def __init__(
        self,
        event_type: KeypadEvent,
        timestamp: datetime,
        key: Optional[str] = None,
        pin: Optional[str] = None,
        topic: Optional[str] = None,
        raw_payload: Optional[Dict] = None,
    ):
        self.event_type = event_type
        self.timestamp = timestamp
        self.key = key
        self.pin = pin
        self.topic = topic
        self.raw_payload = raw_payload or {}
    
    def __repr__(self):
        return f"KeypadEvent({self.event_type.value}, key={self.key}, pin={'***' if self.pin else None})"


class RingKeypadZwaveJsMqtt:
    """
    Ring Keypad Z-Wave JS UI MQTT 客户端
    
    通过 Z-Wave JS UI 的 MQTT 网关与 Ring Keypad 交互
    
    Topic 格式:
        zwave/nodeID_3/111/0/...  (Entry Control Command Class)
    """
    
    # 默认的按键 topic 映射（可以通过 learn_keys 学习）
    DEFAULT_KEY_MAPPING = {
        # 这些值需要通过实际测试确定
        # "disarm": "zwave/nodeID_3/111/0/xxx/0",
        # "away": "zwave/nodeID_3/111/0/xxx/0",
        # "home": "zwave/nodeID_3/111/0/xxx/0",
    }
    
    def __init__(
        self,
        node_id: int = 3,
        mqtt_host: str = "localhost",
        mqtt_port: int = 1883,
        key_mapping: Optional[Dict[str, str]] = None,
    ):
        """
        初始化 Ring Keypad Z-Wave JS UI MQTT 客户端
        
        Args:
            node_id: Ring Keypad 的 Z-Wave Node ID
            mqtt_host: MQTT broker 主机
            mqtt_port: MQTT broker 端口
            key_mapping: 按键 topic 映射
        """
        if not HAS_MQTT:
            raise RuntimeError("paho-mqtt not installed. Install: pip install paho-mqtt")
        
        self.node_id = node_id
        self.mqtt_host = mqtt_host
        self.mqtt_port = mqtt_port
        
        # Topic 前缀
        self.topic_prefix = f"zwave/nodeID_{node_id}"
        self.subscribe_topic = f"{self.topic_prefix}/#"
        
        # 按键映射 (topic -> key_name)
        self.key_mapping = {}
        if key_mapping:
            # 反转映射: key_name -> topic 变为 topic -> key_name
            self.key_mapping = {v: k for k, v in key_mapping.items()}
        
        # MQTT 客户端
        self.client: Optional[mqtt.Client] = None
        self.connected = False
        
        # 回调函数
        self.on_keypad_event: Optional[Callable[[KeypadEventData], None]] = None
        
        # PIN 缓冲
        self.pin_buffer = ""
        self.pin_timeout_sec = 10
        self.last_key_time = 0
        
        # 学习模式
        self.learning_mode = False
        self.learned_mappings = {}
    
    def connect(self) -> bool:
        """连接到 MQTT broker"""
        try:
            self.client = mqtt.Client(
                client_id=f"ng_edge_keypad_{self.node_id}",
                callback_api_version=mqtt.CallbackAPIVersion.VERSION1
            )
            
            self.client.on_connect = self._on_connect
            self.client.on_disconnect = self._on_disconnect
            self.client.on_message = self._on_message
            
            logger.info(f"[Keypad] 连接 MQTT {self.mqtt_host}:{self.mqtt_port}...")
            self.client.connect(self.mqtt_host, self.mqtt_port, keepalive=60)
            self.client.loop_start()
            
            return True
        
        except Exception as e:
            logger.error(f"[Keypad] MQTT 连接失败: {e}")
            return False
    
    def disconnect(self):
        """断开 MQTT 连接"""
        if self.client:
            self.client.loop_stop()
            self.client.disconnect()
            self.connected = False
            logger.info("[Keypad] MQTT 已断开")
    
    def _on_connect(self, client, userdata, flags, rc):
        """MQTT 连接回调"""
        if rc == 0:
            self.connected = True
            logger.info(f"[Keypad] ✅ MQTT 已连接")
            
            # 订阅 Keypad 相关 topic
            client.subscribe(self.subscribe_topic)
            logger.info(f"[Keypad] 📡 订阅: {self.subscribe_topic}")
            
            # 触发连接事件
            if self.on_keypad_event:
                event = KeypadEventData(
                    event_type=KeypadEvent.CONNECTED,
                    timestamp=datetime.now(timezone.utc),
                )
                self.on_keypad_event(event)
        else:
            logger.error(f"[Keypad] MQTT 连接失败: rc={rc}")
    
    def _on_disconnect(self, client, userdata, rc):
        """MQTT 断开回调"""
        self.connected = False
        logger.warning(f"[Keypad] MQTT 断开: rc={rc}")
        
        if self.on_keypad_event:
            event = KeypadEventData(
                event_type=KeypadEvent.DISCONNECTED,
                timestamp=datetime.now(timezone.utc),
            )
            self.on_keypad_event(event)
    
    def _on_message(self, client, userdata, msg):
        """MQTT 消息回调"""
        topic = msg.topic
        
        try:
            payload_str = msg.payload.decode("utf-8", errors="ignore")
            try:
                payload = json.loads(payload_str)
            except json.JSONDecodeError:
                payload = payload_str
        except:
            return
        
        # 只处理 Entry Control 消息 (Command Class 111)
        if "/111/0/" not in topic:
            return
        
        # 检查是否是数字缓存更新（有 value 字段）
        if isinstance(payload, dict) and "value" in payload:
            value = payload.get("value")
            if isinstance(value, str) and value.isdigit():
                self._handle_pin_update(value)
            return
        
        # 动作事件（没有 value 字段）
        self._handle_action_event(topic, payload)
    
    def _handle_pin_update(self, digits: str):
        """处理 PIN 输入更新"""
        now = time.time()
        
        # 检查超时，重置缓冲区
        if now - self.last_key_time > self.pin_timeout_sec:
            self.pin_buffer = ""
        
        self.pin_buffer = digits
        self.last_key_time = now
        
        logger.debug(f"[Keypad] PIN 缓冲: {'*' * len(digits)}")
    
    def _handle_action_event(self, topic: str, payload: Any):
        """处理按键动作事件"""
        now = datetime.now(timezone.utc)
        
        # 检查已知映射
        key_name = self.key_mapping.get(topic)
        
        if key_name:
            logger.info(f"[Keypad] 🔑 按键: {key_name}")
            self._trigger_key_event(key_name, now, topic, payload)
        else:
            # 未知按键，记录日志
            logger.info(f"[Keypad] ❓ 未知按键: {topic}")
            logger.debug(f"[Keypad]    payload: {payload}")
            
            # 如果在学习模式，记录这个 topic
            if self.learning_mode:
                self.learned_mappings[topic] = {
                    "timestamp": now.isoformat(),
                    "payload": payload,
                }
    
    def _trigger_key_event(self, key_name: str, timestamp: datetime, topic: str, payload: Any):
        """触发按键事件"""
        if not self.on_keypad_event:
            return
        
        # 映射按键名到事件类型
        event_map = {
            "disarm": KeypadEvent.DISARM_PRESSED,
            "away": KeypadEvent.AWAY_PRESSED,
            "home": KeypadEvent.HOME_PRESSED,
            "ok": KeypadEvent.OK_PRESSED,
            "cancel": KeypadEvent.CANCEL_PRESSED,
        }
        
        event_type = event_map.get(key_name, KeypadEvent.KEY_PRESSED)
        
        # 获取当前 PIN（如果有）
        pin = self.pin_buffer if self.pin_buffer else None
        
        event = KeypadEventData(
            event_type=event_type,
            timestamp=timestamp,
            key=key_name,
            pin=pin,
            topic=topic,
            raw_payload=payload if isinstance(payload, dict) else {"raw": payload},
        )
        
        # 触发回调
        self.on_keypad_event(event)
        
        # 清空 PIN 缓冲（模式按钮触发后）
        if event_type in [KeypadEvent.DISARM_PRESSED, KeypadEvent.AWAY_PRESSED, KeypadEvent.HOME_PRESSED]:
            self.pin_buffer = ""
    
    def start_learning(self):
        """开始学习模式"""
        self.learning_mode = True
        self.learned_mappings = {}
        logger.info("[Keypad] 🎓 进入学习模式")
        logger.info("[Keypad] 请依次按下 disarm, away, home, ok, cancel 按钮")
    
    def stop_learning(self) -> Dict[str, str]:
        """停止学习模式，返回学习到的映射"""
        self.learning_mode = False
        logger.info("[Keypad] 学习模式结束")
        return self.learned_mappings
    
    def set_key_mapping(self, mapping: Dict[str, str]):
        """
        设置按键映射
        
        Args:
            mapping: {key_name: topic} 格式的映射
        """
        # 反转为 {topic: key_name}
        self.key_mapping = {v: k for k, v in mapping.items()}
        logger.info(f"[Keypad] 按键映射已更新: {list(mapping.keys())}")


# 异步包装器
class RingKeypadZwaveJsMqttAsync:
    """异步包装器"""
    
    def __init__(self, *args, **kwargs):
        self.sync_client = RingKeypadZwaveJsMqtt(*args, **kwargs)
    
    async def connect(self) -> bool:
        return self.sync_client.connect()
    
    async def disconnect(self):
        self.sync_client.disconnect()
    
    @property
    def connected(self):
        return self.sync_client.connected
    
    @property
    def on_keypad_event(self):
        return self.sync_client.on_keypad_event
    
    @on_keypad_event.setter
    def on_keypad_event(self, callback):
        self.sync_client.on_keypad_event = callback
    
    def set_key_mapping(self, mapping):
        self.sync_client.set_key_mapping(mapping)


# 测试函数
def interactive_test():
    """交互式测试"""
    import time
    
    print("=" * 60)
    print("  Ring Keypad Z-Wave JS UI MQTT 测试")
    print("=" * 60)
    
    # 创建客户端
    keypad = RingKeypadZwaveJsMqtt(node_id=3)
    
    # 事件回调
    def on_event(event: KeypadEventData):
        print(f"\n🔔 事件: {event.event_type.value}")
        if event.key:
            print(f"   按键: {event.key}")
        if event.pin:
            print(f"   PIN: {'*' * len(event.pin)}")
        if event.topic:
            print(f"   Topic: {event.topic}")
    
    keypad.on_keypad_event = on_event
    
    # 连接
    if not keypad.connect():
        print("❌ 连接失败")
        return
    
    print("\n✅ 已连接，等待按键事件...")
    print("按 Ctrl+C 退出\n")
    
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\n\n退出...")
    finally:
        keypad.disconnect()


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    interactive_test()
