"""
Tests for Camera Output Channel

测试摄像头威慑输出通道
"""

import pytest
import asyncio
from unittest.mock import Mock, AsyncMock, patch, MagicMock
from datetime import datetime, timezone

from ng_edge.hardware.camera_output_channel import (
    CameraOutputChannel,
    CameraConfig,
    CameraState,
    DeterrentLevel,
)


# =============================================================================
# Test Fixtures
# =============================================================================

@pytest.fixture
def sample_camera_config():
    """创建测试摄像头配置"""
    return CameraConfig(
        camera_id="cam_test",
        ip="10.0.0.100",
        username="admin",
        password="testpass",
        name="Test Camera",
        entry_point_id="ep_back_door",
        zone_id="zone_backyard",
    )


@pytest.fixture
def mock_host():
    """Mock reolink_aio Host"""
    host = MagicMock()
    host.get_host_data = AsyncMock()
    host.camera_model = Mock(return_value="RLC-810WA")
    host.set_whiteled = AsyncMock()
    host.set_siren = AsyncMock()
    host.logout = AsyncMock()
    return host


# =============================================================================
# CameraConfig Tests
# =============================================================================

class TestCameraConfig:
    """CameraConfig 测试"""
    
    def test_create_config_minimal(self):
        """测试最小配置"""
        config = CameraConfig(
            camera_id="cam1",
            ip="10.0.0.1",
        )
        
        assert config.camera_id == "cam1"
        assert config.ip == "10.0.0.1"
        assert config.username == "admin"
        assert config.password == ""
        assert config.entry_point_id is None
    
    def test_create_config_full(self, sample_camera_config):
        """测试完整配置"""
        assert sample_camera_config.camera_id == "cam_test"
        assert sample_camera_config.ip == "10.0.0.100"
        assert sample_camera_config.entry_point_id == "ep_back_door"
        assert sample_camera_config.spotlight_brightness == 100


# =============================================================================
# CameraOutputChannel Tests
# =============================================================================

class TestCameraOutputChannel:
    """CameraOutputChannel 测试"""
    
    def test_create_empty_channel(self):
        """测试创建空通道"""
        channel = CameraOutputChannel()
        
        assert len(channel.cameras) == 0
        assert not channel._started
    
    def test_create_channel_with_cameras(self, sample_camera_config):
        """测试创建带摄像头的通道"""
        channel = CameraOutputChannel([sample_camera_config])
        
        assert len(channel.cameras) == 1
        assert "cam_test" in channel.cameras
        assert "cam_test" in channel.states
    
    def test_add_remove_camera(self, sample_camera_config):
        """测试添加和移除摄像头"""
        channel = CameraOutputChannel()
        
        # 添加
        channel.add_camera(sample_camera_config)
        assert len(channel.cameras) == 1
        
        # 移除
        channel.remove_camera("cam_test")
        assert len(channel.cameras) == 0
    
    @pytest.mark.asyncio
    async def test_start_stop(self, sample_camera_config, mock_host):
        """测试启动和停止"""
        channel = CameraOutputChannel([sample_camera_config])
        
        with patch('reolink_aio.api.Host', return_value=mock_host):
            await channel.start()
            
            assert channel._started
            assert channel.states["cam_test"].connected
            
            await channel.stop()
            
            assert not channel._started
            mock_host.logout.assert_called()
    
    @pytest.mark.asyncio
    async def test_on_state_change_triggered(self, sample_camera_config, mock_host):
        """测试状态变化 -> TRIGGERED"""
        channel = CameraOutputChannel([sample_camera_config])
        
        with patch('reolink_aio.api.Host', return_value=mock_host):
            await channel.start()
            
            # 模拟 TRIGGERED
            await channel.on_state_change("ep_back_door", "quiet", "triggered")
            
            # 验证调用了声光
            mock_host.set_whiteled.assert_called_with(0, state=True)
            mock_host.set_siren.assert_called_with(0, True)
            
            await channel.stop()
    
    @pytest.mark.asyncio
    async def test_on_state_change_pre(self, sample_camera_config, mock_host):
        """测试状态变化 -> PRE"""
        channel = CameraOutputChannel([sample_camera_config])
        
        with patch('reolink_aio.api.Host', return_value=mock_host):
            await channel.start()
            
            # 模拟 PRE
            await channel.on_state_change("ep_back_door", "quiet", "pre")
            
            # 验证只开了灯
            mock_host.set_whiteled.assert_called_with(0, state=True)
            # Siren 不应该被调用（或者至少不是 True）
            
            await channel.stop()
    
    @pytest.mark.asyncio
    async def test_on_state_change_quiet(self, sample_camera_config, mock_host):
        """测试状态变化 -> QUIET (停止威慑)"""
        channel = CameraOutputChannel([sample_camera_config])
        
        with patch('reolink_aio.api.Host', return_value=mock_host):
            await channel.start()
            
            # 先触发
            await channel.on_state_change("ep_back_door", "quiet", "triggered")
            
            # 然后停止
            mock_host.reset_mock()
            await channel.on_state_change("ep_back_door", "triggered", "quiet")
            
            # 验证停止了
            mock_host.set_whiteled.assert_called_with(0, state=False)
            mock_host.set_siren.assert_called_with(0, False)
            
            await channel.stop()
    
    @pytest.mark.asyncio
    async def test_get_cameras_for_entry_point(self, mock_host):
        """测试按入口点获取摄像头"""
        config1 = CameraConfig(
            camera_id="cam1",
            ip="10.0.0.1",
            entry_point_id="ep_front",
        )
        config2 = CameraConfig(
            camera_id="cam2",
            ip="10.0.0.2",
            entry_point_id="ep_back",
        )
        config3 = CameraConfig(
            camera_id="cam3",
            ip="10.0.0.3",
            entry_point_id="ep_back",
        )
        
        channel = CameraOutputChannel([config1, config2, config3])
        
        # ep_front 只有 1 个摄像头
        cams = channel._get_cameras_for_entry_point("ep_front")
        assert len(cams) == 1
        assert "cam1" in cams
        
        # ep_back 有 2 个摄像头
        cams = channel._get_cameras_for_entry_point("ep_back")
        assert len(cams) == 2
        assert "cam2" in cams
        assert "cam3" in cams
        
        # 不存在的入口点
        cams = channel._get_cameras_for_entry_point("ep_none")
        assert len(cams) == 0
    
    @pytest.mark.asyncio
    async def test_direct_control(self, sample_camera_config, mock_host):
        """测试直接控制方法"""
        channel = CameraOutputChannel([sample_camera_config])
        
        with patch('reolink_aio.api.Host', return_value=mock_host):
            await channel.start()
            
            # 测试 spotlight
            result = await channel.spotlight_on("cam_test")
            assert result is True
            mock_host.set_whiteled.assert_called_with(0, state=True)
            
            result = await channel.spotlight_off("cam_test")
            assert result is True
            mock_host.set_whiteled.assert_called_with(0, state=False)
            
            # 测试 siren
            result = await channel.siren_on("cam_test")
            assert result is True
            mock_host.set_siren.assert_called_with(0, True)
            
            result = await channel.siren_off("cam_test")
            assert result is True
            mock_host.set_siren.assert_called_with(0, False)
            
            await channel.stop()
    
    @pytest.mark.asyncio
    async def test_get_status(self, sample_camera_config, mock_host):
        """测试获取状态"""
        channel = CameraOutputChannel([sample_camera_config])
        
        with patch('reolink_aio.api.Host', return_value=mock_host):
            await channel.start()
            
            status = channel.get_status()
            
            assert status["started"] is True
            assert status["total_cameras"] == 1
            assert status["connected_cameras"] == 1
            assert "cam_test" in status["cameras"]
            assert status["cameras"]["cam_test"]["connected"] is True
            
            await channel.stop()


# =============================================================================
# DeterrentLevel Tests
# =============================================================================

class TestDeterrentLevel:
    """DeterrentLevel 测试"""
    
    def test_level_values(self):
        """测试级别值"""
        assert DeterrentLevel.OFF.value == 0
        assert DeterrentLevel.L0.value == 1
        assert DeterrentLevel.L1.value == 2
        assert DeterrentLevel.L2.value == 3
        assert DeterrentLevel.TRIGGERED.value == 4
    
    def test_level_ordering(self):
        """测试级别排序"""
        assert DeterrentLevel.OFF.value < DeterrentLevel.L0.value
        assert DeterrentLevel.L0.value < DeterrentLevel.L1.value
        assert DeterrentLevel.L1.value < DeterrentLevel.L2.value
        assert DeterrentLevel.L2.value < DeterrentLevel.TRIGGERED.value


# =============================================================================
# Integration Tests
# =============================================================================

class TestCameraOutputIntegration:
    """集成测试"""
    
    @pytest.mark.asyncio
    async def test_full_workflow(self, mock_host):
        """测试完整工作流"""
        # 创建多个摄像头
        configs = [
            CameraConfig(
                camera_id="cam_front",
                ip="10.0.0.1",
                entry_point_id="ep_front",
            ),
            CameraConfig(
                camera_id="cam_back",
                ip="10.0.0.2",
                entry_point_id="ep_back",
            ),
        ]
        
        channel = CameraOutputChannel(configs)
        
        with patch('reolink_aio.api.Host', return_value=mock_host):
            # 启动
            await channel.start()
            assert channel._started
            
            # 模拟报警序列: QUIET -> PRE -> PENDING -> TRIGGERED -> QUIET
            
            # 1. 进入 PRE
            await channel.on_state_change("ep_back", "quiet", "pre")
            assert channel.states["cam_back"].deterrent_level == DeterrentLevel.L2
            
            # 2. 进入 PENDING (保持状态)
            mock_host.reset_mock()
            await channel.on_state_change("ep_back", "pre", "pending")
            # PENDING 不改变威慑
            
            # 3. 进入 TRIGGERED
            await channel.on_state_change("ep_back", "pending", "triggered")
            assert channel.states["cam_back"].deterrent_level == DeterrentLevel.TRIGGERED
            
            # 4. 解除
            await channel.on_state_change("ep_back", "triggered", "quiet")
            assert channel.states["cam_back"].deterrent_level == DeterrentLevel.OFF
            
            # 停止
            await channel.stop()
            assert not channel._started


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
