#!/usr/bin/env python3
"""
Zigbee设备持久化模块 v2

设计思路：
1. 设备(Device) - 物理Zigbee设备，通过发现自动添加
2. 绑定(Binding) - 设备与Zone/EntryPoint的关联，用户手动配置

文件位置: 
- src/data/zigbee_devices.json  - 已发现的设备列表
- src/data/zigbee_bindings.json - 设备绑定配置

流程：
1. 发现设备 → 保存到devices.json (status: discovered)
2. 用户绑定 → 保存到bindings.json, 更新devices.json (status: bound)
3. 启动时 → 只加载已绑定的设备到路由器
"""

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional, Any


# 默认配置文件路径
DATA_DIR = Path(__file__).parent.parent.parent / "data"
DEVICES_FILE = DATA_DIR / "zigbee_devices.json"
BINDINGS_FILE = DATA_DIR / "zigbee_bindings.json"


class ZigbeeDeviceStore:
    """
    Zigbee设备存储
    
    管理已发现的物理设备（不含绑定信息）
    """
    
    def __init__(self, config_path: Optional[Path] = None):
        self.config_path = config_path or DEVICES_FILE
        self._ensure_directory()
    
    def _ensure_directory(self):
        self.config_path.parent.mkdir(parents=True, exist_ok=True)
    
    def _load(self) -> Dict[str, Any]:
        if not self.config_path.exists():
            return {"devices": {}, "saved_at": None}
        try:
            with open(self.config_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            print(f"[DeviceStore] ⚠️ 加载失败: {e}")
            return {"devices": {}, "saved_at": None}
    
    def _save(self, data: Dict[str, Any]):
        data["saved_at"] = datetime.now(timezone.utc).isoformat()
        temp_path = self.config_path.with_suffix('.json.tmp')
        with open(temp_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        temp_path.replace(self.config_path)
    
    def add_device(
        self,
        ieee_address: str,
        friendly_name: str,
        device_type: str,  # contact, motion, glass_break
        model: Optional[str] = None,
        **extra
    ) -> str:
        """
        添加发现的设备
        
        Returns:
            device_id: 设备ID
        """
        # 规范化IEEE地址
        ieee_clean = ieee_address.lower().strip()
        if not ieee_clean.startswith('0x'):
            ieee_clean = f"0x{ieee_clean}"
        
        # 生成device_id
        device_id = f"zigbee_{ieee_clean.replace('0x', '')}"
        
        data = self._load()
        
        # 检查是否已存在
        if device_id in data["devices"]:
            # 更新最后发现时间
            data["devices"][device_id]["last_seen"] = datetime.now(timezone.utc).isoformat()
            self._save(data)
            print(f"[DeviceStore] 设备已存在，更新: {friendly_name}")
            return device_id
        
        device = {
            "device_id": device_id,
            "ieee_address": ieee_clean,
            "friendly_name": friendly_name,
            "device_type": device_type,
            "model": model,
            "mqtt_topic": f"zigbee2mqtt/{friendly_name}",
            "status": "discovered",  # discovered | bound
            "discovered_at": datetime.now(timezone.utc).isoformat(),
            "last_seen": datetime.now(timezone.utc).isoformat(),
            **extra
        }
        
        data["devices"][device_id] = device
        self._save(data)
        
        print(f"[DeviceStore] ✅ 添加设备: {friendly_name} ({ieee_clean})")
        return device_id
    
    def remove_device(self, device_id: str) -> bool:
        data = self._load()
        if device_id not in data["devices"]:
            return False
        del data["devices"][device_id]
        self._save(data)
        print(f"[DeviceStore] ✅ 删除设备: {device_id}")
        return True
    
    def get_device(self, device_id: str) -> Optional[Dict[str, Any]]:
        data = self._load()
        return data["devices"].get(device_id)
    
    def get_device_by_ieee(self, ieee_address: str) -> Optional[Dict[str, Any]]:
        ieee_clean = ieee_address.lower().strip()
        if not ieee_clean.startswith('0x'):
            ieee_clean = f"0x{ieee_clean}"
        
        data = self._load()
        for device in data["devices"].values():
            if device.get("ieee_address") == ieee_clean:
                return device
        return None
    
    def get_device_by_name(self, friendly_name: str) -> Optional[Dict[str, Any]]:
        data = self._load()
        for device in data["devices"].values():
            if device.get("friendly_name") == friendly_name:
                return device
        return None
    
    def list_all(self) -> List[Dict[str, Any]]:
        data = self._load()
        return list(data["devices"].values())
    
    def list_unbound(self) -> List[Dict[str, Any]]:
        """列出未绑定的设备"""
        data = self._load()
        return [d for d in data["devices"].values() if d.get("status") == "discovered"]
    
    def list_bound(self) -> List[Dict[str, Any]]:
        """列出已绑定的设备"""
        data = self._load()
        return [d for d in data["devices"].values() if d.get("status") == "bound"]
    
    def update_status(self, device_id: str, status: str):
        """更新设备状态"""
        data = self._load()
        if device_id in data["devices"]:
            data["devices"][device_id]["status"] = status
            data["devices"][device_id]["updated_at"] = datetime.now(timezone.utc).isoformat()
            self._save(data)


class ZigbeeBindingStore:
    """
    Zigbee设备绑定存储
    
    管理设备与Zone/EntryPoint的绑定关系
    """
    
    def __init__(self, config_path: Optional[Path] = None):
        self.config_path = config_path or BINDINGS_FILE
        self._ensure_directory()
    
    def _ensure_directory(self):
        self.config_path.parent.mkdir(parents=True, exist_ok=True)
    
    def _load(self) -> Dict[str, Any]:
        if not self.config_path.exists():
            return {"bindings": {}, "saved_at": None}
        try:
            with open(self.config_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            print(f"[BindingStore] ⚠️ 加载失败: {e}")
            return {"bindings": {}, "saved_at": None}
    
    def _save(self, data: Dict[str, Any]):
        data["saved_at"] = datetime.now(timezone.utc).isoformat()
        temp_path = self.config_path.with_suffix('.json.tmp')
        with open(temp_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        temp_path.replace(self.config_path)
    
    def bind_device(
        self,
        device_id: str,
        ieee_address: str,
        friendly_name: str,
        device_type: str,
        entry_point_id: str,
        zone_id: str,
        zone_type: str,  # exterior, entry_exit, interior
        location_type: str = "outdoor",
    ) -> str:
        """
        绑定设备到Zone/EntryPoint
        
        Returns:
            sensor_id: 生成的Sensor ID
        """
        # 生成sensor_id
        sensor_id = f"sensor_{device_type}_{friendly_name.replace(' ', '_').lower()}"
        
        data = self._load()
        
        binding = {
            "sensor_id": sensor_id,
            "device_id": device_id,
            "ieee_address": ieee_address,
            "friendly_name": friendly_name,
            "device_type": device_type,
            "entry_point_id": entry_point_id,
            "zone_id": zone_id,
            "zone_type": zone_type,
            "location_type": location_type,
            "bound_at": datetime.now(timezone.utc).isoformat(),
        }
        
        data["bindings"][sensor_id] = binding
        self._save(data)
        
        print(f"[BindingStore] ✅ 绑定: {friendly_name} → {zone_id}/{entry_point_id} (zone_type={zone_type})")
        return sensor_id
    
    def unbind_device(self, sensor_id: str) -> bool:
        data = self._load()
        if sensor_id not in data["bindings"]:
            return False
        
        binding = data["bindings"].pop(sensor_id)
        self._save(data)
        
        print(f"[BindingStore] ✅ 解绑: {binding.get('friendly_name')}")
        return True
    
    def get_binding(self, sensor_id: str) -> Optional[Dict[str, Any]]:
        data = self._load()
        return data["bindings"].get(sensor_id)
    
    def get_binding_by_device(self, device_id: str) -> Optional[Dict[str, Any]]:
        data = self._load()
        for binding in data["bindings"].values():
            if binding.get("device_id") == device_id:
                return binding
        return None
    
    def list_all(self) -> List[Dict[str, Any]]:
        data = self._load()
        return list(data["bindings"].values())
    
    def update_binding(self, sensor_id: str, **updates) -> bool:
        data = self._load()
        if sensor_id not in data["bindings"]:
            return False
        
        data["bindings"][sensor_id].update(updates)
        data["bindings"][sensor_id]["updated_at"] = datetime.now(timezone.utc).isoformat()
        self._save(data)
        return True


# ============================================================================
# 组合管理器
# ============================================================================

class ZigbeeDeviceManager:
    """
    Zigbee设备管理器
    
    整合设备存储和绑定存储，提供完整的设备管理功能
    """
    
    def __init__(self):
        self.devices = ZigbeeDeviceStore()
        self.bindings = ZigbeeBindingStore()
    
    def discover_device(
        self,
        ieee_address: str,
        friendly_name: str,
        device_type: str,
        model: Optional[str] = None,
        **extra
    ) -> str:
        """
        发现并注册设备（不绑定）
        
        Returns:
            device_id
        """
        return self.devices.add_device(
            ieee_address=ieee_address,
            friendly_name=friendly_name,
            device_type=device_type,
            model=model,
            **extra
        )
    
    def bind_device(
        self,
        device_id: str,
        entry_point_id: str,
        zone_id: str,
        zone_type: str,
        location_type: str = "outdoor",
    ) -> Optional[str]:
        """
        绑定设备到Zone/EntryPoint
        
        Args:
            device_id: 设备ID
            entry_point_id: Entry Point ID
            zone_id: Zone ID
            zone_type: Zone类型 (exterior, entry_exit, interior)
            location_type: 位置类型
        
        Returns:
            sensor_id 或 None（如果设备不存在）
        """
        device = self.devices.get_device(device_id)
        if not device:
            print(f"[Manager] ❌ 设备不存在: {device_id}")
            return None
        
        # 检查是否已绑定
        existing = self.bindings.get_binding_by_device(device_id)
        if existing:
            print(f"[Manager] ⚠️ 设备已绑定: {existing.get('sensor_id')}")
            return existing.get('sensor_id')
        
        sensor_id = self.bindings.bind_device(
            device_id=device_id,
            ieee_address=device["ieee_address"],
            friendly_name=device["friendly_name"],
            device_type=device["device_type"],
            entry_point_id=entry_point_id,
            zone_id=zone_id,
            zone_type=zone_type,
            location_type=location_type,
        )
        
        # 更新设备状态
        self.devices.update_status(device_id, "bound")
        
        return sensor_id
    
    def unbind_device(self, sensor_id: str) -> bool:
        """解绑设备"""
        binding = self.bindings.get_binding(sensor_id)
        if not binding:
            return False
        
        device_id = binding.get("device_id")
        
        # 删除绑定
        self.bindings.unbind_device(sensor_id)
        
        # 更新设备状态
        if device_id:
            self.devices.update_status(device_id, "discovered")
        
        return True
    
    def remove_device(self, device_id: str) -> bool:
        """
        完全删除设备（包括绑定）
        """
        # 先检查是否有绑定
        binding = self.bindings.get_binding_by_device(device_id)
        if binding:
            self.bindings.unbind_device(binding["sensor_id"])
        
        return self.devices.remove_device(device_id)
    
    def get_bound_devices_for_router(self) -> List[Dict[str, Any]]:
        """
        获取所有已绑定设备的路由配置
        
        返回路由器注册所需的信息
        """
        bindings = self.bindings.list_all()
        result = []
        
        for b in bindings:
            # 从device_type获取sensor_type
            sensor_type = b["device_type"]
            
            # 自动修正：如果friendly_name包含"motion"但device_type是"contact"，修正为"motion"
            friendly_lower = b["friendly_name"].lower()
            if "motion" in friendly_lower and sensor_type == "contact":
                sensor_type = "motion"
                print(f"[Persistence] ⚠️ 自动修正sensor_type: {b['friendly_name']} -> motion")
            elif "contact" in friendly_lower and sensor_type == "motion":
                sensor_type = "contact"
                print(f"[Persistence] ⚠️ 自动修正sensor_type: {b['friendly_name']} -> contact")
            
            result.append({
                "sensor_id": b["sensor_id"],
                "ieee_address": b["ieee_address"],
                "friendly_name": b["friendly_name"],
                "sensor_type": sensor_type,
                "entry_point_id": b["entry_point_id"],
                "zone_type": b["zone_type"],
            })
        
        return result
    
    def list_devices(self, status: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        列出设备
        
        Args:
            status: 过滤状态 (None=全部, discovered=未绑定, bound=已绑定)
        """
        if status == "discovered":
            return self.devices.list_unbound()
        elif status == "bound":
            return self.devices.list_bound()
        else:
            return self.devices.list_all()
    
    def list_bindings(self) -> List[Dict[str, Any]]:
        """列出所有绑定"""
        return self.bindings.list_all()
    
    def get_device_info(self, device_id: str) -> Optional[Dict[str, Any]]:
        """获取设备完整信息（包含绑定）"""
        device = self.devices.get_device(device_id)
        if not device:
            return None
        
        binding = self.bindings.get_binding_by_device(device_id)
        
        return {
            **device,
            "binding": binding
        }


# ============================================================================
# 全局实例和便捷函数
# ============================================================================

_manager: Optional[ZigbeeDeviceManager] = None


def get_device_manager() -> ZigbeeDeviceManager:
    """获取全局设备管理器实例"""
    global _manager
    if _manager is None:
        _manager = ZigbeeDeviceManager()
    return _manager


# 兼容旧API的便捷函数
def save_zigbee_device(
    sensor_id: str,
    ieee_address: str,
    friendly_name: str,
    sensor_type: str,
    entry_point_id: str = "_global",
    zone_id: Optional[str] = None,
    zone_type: str = "exterior",
    location_type: str = "outdoor",
    model: Optional[str] = None,
    **extra
) -> bool:
    """兼容旧API：保存并绑定设备"""
    manager = get_device_manager()
    
    # 先发现设备
    device_id = manager.discover_device(
        ieee_address=ieee_address,
        friendly_name=friendly_name,
        device_type=sensor_type,
        model=model
    )
    
    # 再绑定
    result = manager.bind_device(
        device_id=device_id,
        entry_point_id=entry_point_id,
        zone_id=zone_id or "_global",
        zone_type=zone_type,
        location_type=location_type
    )
    
    return result is not None


def delete_zigbee_device(sensor_id: str) -> bool:
    """兼容旧API：解绑设备"""
    manager = get_device_manager()
    return manager.unbind_device(sensor_id)


def load_zigbee_devices_for_router() -> List[Dict[str, Any]]:
    """兼容旧API：加载路由器配置"""
    manager = get_device_manager()
    return manager.get_bound_devices_for_router()


def get_persistence():
    """兼容旧API：获取管理器"""
    return get_device_manager()


# ============================================================================
# 测试
# ============================================================================

def test_manager():
    """测试设备管理器"""
    import tempfile
    
    print("=" * 70)
    print("  Zigbee设备管理器测试")
    print("=" * 70)
    
    # 使用临时目录
    temp_dir = Path(tempfile.mkdtemp())
    
    devices = ZigbeeDeviceStore(temp_dir / "devices.json")
    bindings = ZigbeeBindingStore(temp_dir / "bindings.json")
    
    # 手动创建manager
    manager = ZigbeeDeviceManager()
    manager.devices = devices
    manager.bindings = bindings
    
    # 1. 发现设备
    print("\n1. 发现设备...")
    d1 = manager.discover_device(
        ieee_address="0xb40e060fffe290c7",
        friendly_name="Back Door Contact",
        device_type="contact",
        model="3RDS17BZ"
    )
    d2 = manager.discover_device(
        ieee_address="0x54ef4410014105aa",
        friendly_name="Back Door Motion",
        device_type="motion",
        model="lumi.motion.ac02"
    )
    print(f"   发现: {d1}, {d2}")
    
    # 2. 列出未绑定设备
    print("\n2. 未绑定设备:")
    for d in manager.list_devices("discovered"):
        print(f"   - {d['friendly_name']} ({d['device_type']})")
    
    # 3. 绑定设备
    print("\n3. 绑定设备...")
    s1 = manager.bind_device(
        device_id=d1,
        entry_point_id="ep_back_door",
        zone_id="zone_back_door",
        zone_type="entry_exit"  # 门是entry_exit
    )
    s2 = manager.bind_device(
        device_id=d2,
        entry_point_id="ep_back_door",
        zone_id="zone_back_door",
        zone_type="interior"  # Motion是interior
    )
    print(f"   绑定: {s1}, {s2}")
    
    # 4. 列出绑定
    print("\n4. 已绑定设备:")
    for b in manager.list_bindings():
        print(f"   - {b['sensor_id']}: {b['friendly_name']} → {b['zone_id']} (zone_type={b['zone_type']})")
    
    # 5. 获取路由器配置
    print("\n5. 路由器配置:")
    for r in manager.get_bound_devices_for_router():
        print(f"   - {r['friendly_name']}: {r['sensor_type']}, zone_type={r['zone_type']}")
    
    # 6. 查看文件内容
    print("\n6. devices.json:")
    with open(temp_dir / "devices.json", 'r') as f:
        print(f.read())
    
    print("7. bindings.json:")
    with open(temp_dir / "bindings.json", 'r') as f:
        print(f.read())
    
    # 清理
    import shutil
    shutil.rmtree(temp_dir)
    
    print("\n✅ 测试完成!")


if __name__ == "__main__":
    test_manager()
