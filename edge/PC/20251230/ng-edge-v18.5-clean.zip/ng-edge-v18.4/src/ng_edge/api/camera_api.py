"""
Camera API Endpoints for Edge Manager

Adds real camera input support to the Edge Manager API.
"""

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Optional
import asyncio
import threading

import threading
import time
from collections import deque

# This will be imported in manager.py
camera_router = APIRouter(prefix="/api/camera", tags=["camera"])

# Global camera state
camera_active = False
camera_thread = None
camera_source = None
recent_signals = []  # Store recent signals for display

# Frame cache for streaming (thread-safe)
latest_frame = None
frame_lock = threading.Lock()
frame_timestamp = 0


class CameraStartRequest(BaseModel):
    """Request to start camera"""
    sensor_id: str  # Sensor ID for binding (e.g., sensor_camera_backyard)
    zone_id: str  # Target zone for signals (e.g., zone_backyard)
    camera_ip: str
    detection_fps: float = 5.0
    confidence_threshold: float = 0.6
    camera_username: str = "admin"
    camera_password: str = "Zafac05@a"


class CameraStatusResponse(BaseModel):
    """Camera status"""
    active: bool
    camera_ip: Optional[str] = None
    detection_fps: Optional[float] = None
    stats: Optional[dict] = None


@camera_router.post("/start")
async def start_camera(request: CameraStartRequest):
    """Start real camera input"""
    global camera_active, camera_thread, camera_source
    
    if camera_active:
        raise HTTPException(status_code=400, detail="Camera already active")
    
    try:
        # Import here to avoid circular dependency
        import sys
        import os
        script_dir = os.path.dirname(os.path.abspath(__file__))
        sys.path.insert(0, os.path.join(script_dir, '../../..'))
        
        from camera_signal_source import CameraSignalSource, CameraSignalConfig
        from ng_edge.hardware.reolink_ultrawide import CameraConfig, StreamType
        
        # Create camera config
        camera_config = CameraConfig(
            name="Edge Manager Camera",
            ip=request.camera_ip,
            username=request.camera_username,
            password=request.camera_password,
            stream_type=StreamType.SUB,
            use_tcp=True,
        )
        
        signal_config = CameraSignalConfig(
            camera_name="Edge Manager Camera",
            sensor_id=request.sensor_id,  # Use specified sensor_id
            zone_id=request.zone_id,  # Use user-selected zone
            detection_fps=request.detection_fps,
            confidence_threshold=request.confidence_threshold,
            target_classes=["person", "car"],
            min_signal_confidence=request.confidence_threshold,
        )
        
        # Create camera source
        camera_source = CameraSignalSource(camera_config, signal_config)
        
        # Connect
        if not camera_source.connect():
            raise HTTPException(status_code=500, detail="Failed to connect to camera")
        
        # Start processing thread
        camera_active = True
        camera_thread = threading.Thread(target=camera_processing_loop, daemon=True)
        camera_thread.start()
        
        return {
            "status": "started",
            "camera_ip": request.camera_ip,
            "detection_fps": request.detection_fps
        }
        
    except Exception as e:
        camera_active = False
        raise HTTPException(status_code=500, detail=str(e))


@camera_router.post("/stop")
async def stop_camera():
    """Stop camera input"""
    global camera_active, camera_source, latest_frame, frame_lock
    
    if not camera_active:
        raise HTTPException(status_code=400, detail="Camera not active")
    
    camera_active = False
    
    if camera_source:
        camera_source.disconnect()
        camera_source = None
    
    # Clear cached frame
    with frame_lock:
        latest_frame = None
    
    return {"status": "stopped"}


@camera_router.get("/status")
async def get_camera_status():
    """Get camera status"""
    global recent_signals
    
    if not camera_active or not camera_source:
        return CameraStatusResponse(active=False)
    
    stats = camera_source.get_stats()
    
    # Add recent signals to stats
    if stats is None:
        stats = {}
    stats['recent_signals'] = recent_signals[:10]  # Return last 10 signals
    
    return CameraStatusResponse(
        active=True,
        camera_ip=camera_source.camera_config.ip,
        detection_fps=camera_source.signal_config.detection_fps,
        stats=stats
    )


@camera_router.get("/stream")
async def get_camera_stream():
    """Get current camera frame as JPEG (for testing) - uses cached frame"""
    global latest_frame, frame_lock, frame_timestamp
    
    if not camera_active or not camera_source:
        raise HTTPException(status_code=400, detail="Camera not active")
    
    try:
        # Get cached frame (thread-safe)
        with frame_lock:
            if latest_frame is None:
                raise HTTPException(status_code=503, detail="No frame available yet")
            
            frame_copy = latest_frame.copy()
            age = time.time() - frame_timestamp
        
        # Check if frame is too old (>5 seconds means stream died)
        if age > 5.0:
            raise HTTPException(status_code=503, detail=f"Frame too old ({age:.1f}s)")
        
        # Encode to JPEG
        import cv2
        success, jpeg = cv2.imencode('.jpg', frame_copy, [cv2.IMWRITE_JPEG_QUALITY, 85])
        
        if not success:
            raise HTTPException(status_code=500, detail="Failed to encode frame")
        
        from fastapi.responses import Response
        return Response(
            content=jpeg.tobytes(), 
            media_type="image/jpeg",
            headers={"Cache-Control": "no-cache, no-store, must-revalidate"}
        )
        
    except HTTPException:
        raise
    except Exception as e:
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=f"Stream error: {str(e)}")


@camera_router.get("/rtsp-url")
async def get_rtsp_url():
    """Get RTSP URL for direct streaming"""
    global camera_source
    
    if not camera_active or not camera_source:
        raise HTTPException(status_code=400, detail="Camera not active")
    
    return {
        "rtsp_url": camera_source.camera_config.get_rtsp_url(),
        "width": camera_source.camera_config.expected_width,
        "height": camera_source.camera_config.expected_height,
        "is_ultrawide": camera_source.camera_config.is_ultrawide
    }


def camera_processing_loop():
    """Background thread to process camera frames - SecurityCoordinator集成版本"""
    global camera_active, camera_source, recent_signals, latest_frame, frame_lock, frame_timestamp
    
    print("[Camera] Running with SecurityCoordinator integration")
    
    while camera_active:
        try:
            if camera_source:
                # Process frame
                signal = camera_source.process_frame()
                
                # Also update cached frame for streaming (even if no signal)
                # This ensures we always have a recent frame
                ret, frame = camera_source.camera.read_frame()
                if ret and frame is not None:
                    with frame_lock:
                        latest_frame = frame
                        frame_timestamp = time.time()
                
                if signal:
                    # Store signal for display
                    signal_data = {
                        'signal_type': signal.signal_type.value,
                        'zone_id': signal.zone_id,
                        'confidence': signal.confidence,
                        'timestamp': signal.timestamp.isoformat()
                    }
                    
                    recent_signals.insert(0, signal_data)
                    
                    # Keep only last 100 signals
                    if len(recent_signals) > 100:
                        recent_signals = recent_signals[:100]
                    
                    print(f"[Camera] Detected: {signal.signal_type.value}, "
                          f"Confidence: {signal.confidence:.3f}")
                    
                    # ===== 发送到SecurityCoordinator (与Zigbee相同) =====
                    try:
                        from . import manager
                        
                        if not manager.state or not manager.state.security_coordinator:
                            print(f"[Camera] Warning: SecurityCoordinator not available")
                        else:
                            # 获取sensor binding
                            binding = manager.state.sensors.get(signal.sensor_id)
                            if not binding:
                                print(f"[Camera] Warning: Sensor {signal.sensor_id} not found in bindings")
                            else:
                                # 导入SecurityCoordinator的枚举类型
                                from ..services.state_machine_v5 import (
                                    Signal as SMSignal,
                                    ZoneType as SMZoneType,
                                    SignalType as SMSignalType,
                                )
                                
                                # 映射zone_type
                                sm_zone_map = {
                                    "exterior": SMZoneType.EXTERIOR,
                                    "entry_exit": SMZoneType.ENTRY_EXIT,
                                    "interior": SMZoneType.INTERIOR,
                                    "perimeter": SMZoneType.PERIMETER,
                                }
                                
                                # 映射signal_type
                                sm_signal_map = {
                                    "person_detected": SMSignalType.PERSON_DETECTED,
                                    "vehicle_detected": SMSignalType.VEHICLE_DETECTED,
                                    "door_open": SMSignalType.DOOR_OPEN,
                                    "door_close": SMSignalType.DOOR_CLOSE,
                                    "motion_active": SMSignalType.MOTION_ACTIVE,
                                    "glass_break": SMSignalType.GLASS_BREAK,
                                }
                                
                                zone_type_str = binding.zone_type.value if binding.zone_type else "unknown"
                                sm_zone = sm_zone_map.get(zone_type_str, SMZoneType.EXTERIOR)
                                sm_signal = sm_signal_map.get(signal.signal_type.value)
                                
                                if not sm_signal:
                                    print(f"[Camera] Unsupported signal type: {signal.signal_type}")
                                else:
                                    # 获取entry_point_id
                                    entry_point_id = binding.entry_point_id or "_global"
                                    
                                    # 确保entry point已注册
                                    if entry_point_id != "_global":
                                        ep_config = manager.state.entry_points.get(entry_point_id)
                                        if ep_config:
                                            manager.state.security_coordinator.register_entry_point(
                                                entry_point_id,
                                                ep_config.name,
                                                entry_delay_sec=ep_config.entry_delay_away_sec
                                            )
                                        else:
                                            manager.state.security_coordinator.register_entry_point(entry_point_id, entry_point_id)
                                    
                                    # 创建v5 Signal对象
                                    sig = SMSignal(
                                        entry_point_id=entry_point_id,
                                        signal_type=sm_signal,
                                        zone_type=sm_zone,
                                        from_inside=False,
                                    )
                                    
                                    # 调用SecurityCoordinator处理信号
                                    print(f"[Camera] Sending to SecurityCoordinator: {signal.signal_type.value}")
                                    result = manager.state.security_coordinator.process(sig)
                                    
                                    if result:
                                        print(f"[Camera] Signal processed successfully")
                                        if hasattr(result, 'state_change') and result.state_change:
                                            print(f"[Camera] State transition: {result.state_change}")
                                    else:
                                        print(f"[Camera] Signal processed (no state change)")
                    
                    except ImportError as e:
                        print(f"[Camera] SecurityCoordinator not available: {e}")
                    except Exception as e:
                        print(f"[Camera] ERROR processing signal in SecurityCoordinator: {e}")
                        import traceback
                        traceback.print_exc()
                    # ===== SecurityCoordinator集成结束 =====
            
            # Small delay
            time.sleep(0.01)
            
        except Exception as e:
            print(f"[Camera] Error: {e}")
            import traceback
            traceback.print_exc()
            camera_active = False
            break
