"""
设备池API - 设备管理REST接口

提供设备的增删改查、绑定、自动发现等功能
"""

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any
from datetime import datetime

from ..hardware.device_pool import (
    DevicePoolManager,
    Device,
    DeviceType,
    DeviceStatus,
    AdapterType
)

# Router
device_pool_router = APIRouter(prefix="/api/devices", tags=["devices"])

# 全局设备池管理器
device_pool = DevicePoolManager()


# =============================================================================
# Request/Response Models
# =============================================================================

class DeviceCreateRequest(BaseModel):
    """创建设备请求"""
    friendly_name: str = Field(..., description="友好名称")
    device_type: DeviceType = Field(..., description="设备类型")
    adapter_type: AdapterType = Field(..., description="适配器类型")
    
    # 可选标识
    ieee_address: Optional[str] = Field(None, description="Zigbee IEEE地址")
    zwave_node_id: Optional[str] = Field(None, description="Z-Wave节点ID")
    camera_ip: Optional[str] = Field(None, description="摄像头IP")
    
    # 可选配置
    config: Optional[Dict[str, Any]] = Field(None, description="设备特定配置")


class DeviceUpdateRequest(BaseModel):
    """更新设备请求"""
    friendly_name: Optional[str] = None
    config: Optional[Dict[str, Any]] = None
    status: Optional[DeviceStatus] = None


class DeviceBindRequest(BaseModel):
    """绑定设备到拓扑"""
    entry_point_id: Optional[str] = Field(None, description="Entry Point ID")
    zone_id: Optional[str] = Field(None, description="Zone ID")
    sensor_id: Optional[str] = Field(None, description="Sensor ID (自动生成如果为空)")


class ZigbeeDiscoverRequest(BaseModel):
    """Zigbee设备自动发现请求"""
    friendly_name: str
    ieee_address: str
    model: str
    device_type_hint: Optional[str] = None


class CameraDiscoverRequest(BaseModel):
    """摄像头自动发现请求"""
    friendly_name: str
    camera_ip: str
    username: Optional[str] = "admin"
    password: Optional[str] = None


class DeviceResponse(BaseModel):
    """设备响应"""
    device_id: str
    friendly_name: str
    device_type: str
    adapter_type: str
    status: str
    
    ieee_address: Optional[str] = None
    camera_ip: Optional[str] = None
    
    bound_to_entry_point: Optional[str] = None
    bound_to_zone: Optional[str] = None
    sensor_id: Optional[str] = None
    
    last_seen: Optional[datetime] = None
    created_at: Optional[datetime] = None


class DeviceListResponse(BaseModel):
    """设备列表响应"""
    devices: List[DeviceResponse]
    total: int
    stats: Dict[str, Any]


# =============================================================================
# API Endpoints
# =============================================================================

@device_pool_router.get("/", response_model=DeviceListResponse)
async def list_devices(
    device_type: Optional[DeviceType] = None,
    status: Optional[DeviceStatus] = None,
    adapter_type: Optional[AdapterType] = None
):
    """
    列出所有设备
    
    支持按类型、状态、适配器过滤
    """
    devices = device_pool.list_devices(
        device_type=device_type,
        status=status,
        adapter_type=adapter_type
    )
    
    devices_response = [
        DeviceResponse(
            device_id=d.device_id,
            friendly_name=d.friendly_name,
            device_type=d.device_type.value,
            adapter_type=d.adapter_type.value,
            status=d.status.value,
            ieee_address=d.ieee_address,
            camera_ip=d.camera_ip,
            bound_to_entry_point=d.bound_to_entry_point,
            bound_to_zone=d.bound_to_zone,
            sensor_id=d.sensor_id,
            last_seen=d.last_seen,
            created_at=d.created_at
        )
        for d in devices
    ]
    
    stats = device_pool.get_stats()
    
    return DeviceListResponse(
        devices=devices_response,
        total=len(devices),
        stats=stats
    )


@device_pool_router.get("/unbound")
async def list_unbound_devices():
    """
    列出未绑定的设备
    
    这些设备已经被发现但还没有绑定到拓扑
    """
    devices = device_pool.list_devices(status=DeviceStatus.UNBOUND)
    
    return {
        "devices": [d.to_dict() for d in devices],
        "count": len(devices)
    }


@device_pool_router.get("/stats/summary")
async def get_device_stats():
    """获取设备统计信息"""
    stats = device_pool.get_stats()
    
    return {
        "total_devices": stats['total'],
        "by_type": stats['by_type'],
        "by_status": stats['by_status'],
        "unbound_devices": stats['unbound_count'],
        "bound_devices": stats['bound_count']
    }


@device_pool_router.get("/{device_id}")
async def get_device(device_id: str):
    """获取单个设备详情"""
    device = device_pool.get_device(device_id)
    if not device:
        raise HTTPException(status_code=404, detail="Device not found")
    
    return device.to_dict()


@device_pool_router.post("/")
async def create_device(request: DeviceCreateRequest):
    """手动创建设备"""
    device = Device(
        device_id="",  # 将自动生成
        friendly_name=request.friendly_name,
        device_type=request.device_type,
        adapter_type=request.adapter_type,
        ieee_address=request.ieee_address,
        zwave_node_id=request.zwave_node_id,
        camera_ip=request.camera_ip,
        config=request.config or {}
    )
    
    device = device_pool.add_device(device)
    
    return {
        "success": True,
        "device_id": device.device_id,
        "message": f"设备已创建: {device.friendly_name}"
    }


@device_pool_router.patch("/{device_id}")
async def update_device(device_id: str, request: DeviceUpdateRequest):
    """更新设备信息"""
    updates = {}
    if request.friendly_name:
        updates['friendly_name'] = request.friendly_name
    if request.config:
        updates['config'] = request.config
    if request.status:
        updates['status'] = request.status
    
    device = device_pool.update_device(device_id, updates)
    if not device:
        raise HTTPException(status_code=404, detail="Device not found")
    
    return {
        "success": True,
        "device_id": device.device_id,
        "message": "设备已更新"
    }


@device_pool_router.delete("/{device_id}")
async def delete_device(device_id: str):
    """删除设备"""
    success = device_pool.delete_device(device_id)
    if not success:
        raise HTTPException(status_code=404, detail="Device not found")
    
    return {
        "success": True,
        "message": "设备已删除"
    }


@device_pool_router.post("/{device_id}/bind")
async def bind_device(device_id: str, request: DeviceBindRequest):
    """
    绑定设备到拓扑
    
    将设备绑定到Entry Point和/或Zone
    绑定后设备开始工作
    """
    device = device_pool.bind_to_topology(
        device_id=device_id,
        entry_point_id=request.entry_point_id,
        zone_id=request.zone_id,
        sensor_id=request.sensor_id
    )
    
    if not device:
        raise HTTPException(status_code=404, detail="Device not found")
    
    return {
        "success": True,
        "device_id": device.device_id,
        "sensor_id": device.sensor_id,
        "bound_to_entry_point": device.bound_to_entry_point,
        "bound_to_zone": device.bound_to_zone,
        "message": f"设备已绑定: {device.friendly_name}"
    }


@device_pool_router.post("/{device_id}/unbind")
async def unbind_device(device_id: str):
    """
    解绑设备
    
    从拓扑中解绑设备，停止工作
    """
    device = device_pool.unbind_from_topology(device_id)
    if not device:
        raise HTTPException(status_code=404, detail="Device not found")
    
    return {
        "success": True,
        "device_id": device.device_id,
        "message": f"设备已解绑: {device.friendly_name}"
    }


@device_pool_router.post("/discover/zigbee")
async def discover_zigbee_device(request: ZigbeeDiscoverRequest):
    """
    Zigbee设备自动发现
    
    从Zigbee2MQTT发现新设备并自动添加到设备池
    """
    device = device_pool.auto_discover_zigbee_device(
        friendly_name=request.friendly_name,
        ieee_address=request.ieee_address,
        model=request.model,
        device_type_hint=request.device_type_hint
    )
    
    return {
        "success": True,
        "device_id": device.device_id,
        "device_type": device.device_type.value,
        "status": device.status.value,
        "message": f"Zigbee设备已发现: {device.friendly_name}"
    }


@device_pool_router.post("/discover/camera")
async def discover_camera(request: CameraDiscoverRequest):
    """
    摄像头自动发现
    
    添加新摄像头到设备池
    """
    camera_config = {
        "username": request.username,
        "password": request.password
    }
    
    device = device_pool.auto_discover_camera(
        friendly_name=request.friendly_name,
        camera_ip=request.camera_ip,
        camera_config=camera_config
    )
    
    return {
        "success": True,
        "device_id": device.device_id,
        "camera_ip": device.camera_ip,
        "message": f"摄像头已发现: {device.friendly_name}"
    }

