# NG-Edge API Module

## 状态
**独立组件** - 不被 EdgeRuntime 使用，作为可选的 Manager API 存在。

## 启动方式
```bash
python -m ng_edge.server
# 或
uvicorn ng_edge.api.manager:app --host 0.0.0.0 --port 8080
```

## 功能
- Zone/Entry Point/Sensor CRUD 管理
- Pipeline 控制
- Sensor 模拟触发
- Drill 演练执行

## 注意
此模块与 EdgeRuntime 独立运行，不是核心安全功能的一部分。
如果不需要 Web 管理界面，可以安全跳过此模块。
