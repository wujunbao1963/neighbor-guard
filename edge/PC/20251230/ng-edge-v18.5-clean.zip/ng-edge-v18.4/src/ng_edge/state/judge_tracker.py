"""
Judge Availability Tracker

跟踪 Judge 摄像头的可用性状态 (v2.2 §3.4)

当 Judge 摄像头离线时：
- PRE 升级被禁止（最高只能到 PRE_L1）
- Hard 信号处理不受影响
- 用户收到通知
"""

from dataclasses import dataclass, field
from datetime import datetime, timezone, timedelta
from typing import Dict, Optional, Callable, List
from enum import Enum

from ng_edge.state.states import JudgeAvailabilityState


@dataclass
class JudgeStatus:
    """单个 Judge 摄像头的状态"""
    camera_id: str
    state: JudgeAvailabilityState = JudgeAvailabilityState.AVAILABLE
    last_heartbeat: Optional[datetime] = None
    last_state_change: Optional[datetime] = None
    offline_since: Optional[datetime] = None
    consecutive_failures: int = 0


@dataclass
class JudgeConfig:
    """Judge 跟踪配置"""
    offline_threshold_sec: int = 90      # 多久没心跳算离线
    heartbeat_interval_sec: int = 30     # 期望的心跳间隔
    recovery_threshold: int = 2          # 恢复需要连续成功次数


class JudgeAvailabilityTracker:
    """
    Judge 摄像头可用性跟踪器
    
    使用方式:
        tracker = JudgeAvailabilityTracker()
        tracker.register_judge("cam_front", "ep_front")
        
        # 收到心跳
        tracker.record_heartbeat("cam_front")
        
        # 检查可用性
        if tracker.is_available("cam_front"):
            # 允许 PRE 升级
            pass
    """
    
    def __init__(self, config: Optional[JudgeConfig] = None):
        self.config = config or JudgeConfig()
        self._judges: Dict[str, JudgeStatus] = {}
        self._entrypoint_map: Dict[str, str] = {}  # camera_id → entrypoint_id
        
        # 回调
        self.on_state_change: Optional[Callable[[str, JudgeAvailabilityState, JudgeAvailabilityState], None]] = None
        
        # 统计
        self.stats = {
            "heartbeats_received": 0,
            "state_changes": 0,
            "degraded_events": 0,
            "recovery_events": 0,
        }
    
    def register_judge(
        self,
        camera_id: str,
        entrypoint_id: Optional[str] = None,
    ):
        """
        注册 Judge 摄像头
        
        Args:
            camera_id: 摄像头 ID
            entrypoint_id: 关联的入口点
        """
        self._judges[camera_id] = JudgeStatus(
            camera_id=camera_id,
            last_state_change=datetime.now(timezone.utc),
        )
        if entrypoint_id:
            self._entrypoint_map[camera_id] = entrypoint_id
    
    def record_heartbeat(self, camera_id: str) -> bool:
        """
        记录心跳
        
        Args:
            camera_id: 摄像头 ID
            
        Returns:
            bool: 状态是否变化
        """
        if camera_id not in self._judges:
            return False
        
        self.stats["heartbeats_received"] += 1
        
        judge = self._judges[camera_id]
        now = datetime.now(timezone.utc)
        judge.last_heartbeat = now
        judge.consecutive_failures = 0
        
        # 检查是否需要恢复
        if judge.state == JudgeAvailabilityState.DEGRADED:
            return self._try_recover(camera_id)
        
        return False
    
    def record_failure(self, camera_id: str) -> bool:
        """
        记录失败（连接失败、超时等）
        
        Returns:
            bool: 状态是否变化
        """
        if camera_id not in self._judges:
            return False
        
        judge = self._judges[camera_id]
        judge.consecutive_failures += 1
        
        # 检查是否需要降级
        if judge.state == JudgeAvailabilityState.AVAILABLE:
            if judge.consecutive_failures >= 3:  # 连续3次失败
                return self._degrade(camera_id)
        
        return False
    
    def check_timeouts(self) -> List[str]:
        """
        检查超时的 Judge
        
        应该定期调用（如每30秒）
        
        Returns:
            List[str]: 状态变化的 camera_id 列表
        """
        changed = []
        now = datetime.now(timezone.utc)
        threshold = timedelta(seconds=self.config.offline_threshold_sec)
        
        for camera_id, judge in self._judges.items():
            if judge.state == JudgeAvailabilityState.AVAILABLE:
                if judge.last_heartbeat:
                    if now - judge.last_heartbeat > threshold:
                        if self._degrade(camera_id):
                            changed.append(camera_id)
        
        return changed
    
    def is_available(self, camera_id: str) -> bool:
        """检查 Judge 是否可用"""
        judge = self._judges.get(camera_id)
        if not judge:
            return False
        return judge.state == JudgeAvailabilityState.AVAILABLE
    
    def is_any_available(self) -> bool:
        """检查是否有任何 Judge 可用"""
        return any(j.state == JudgeAvailabilityState.AVAILABLE for j in self._judges.values())
    
    def get_state(self, camera_id: str) -> Optional[JudgeAvailabilityState]:
        """获取 Judge 状态"""
        judge = self._judges.get(camera_id)
        return judge.state if judge else None
    
    def get_status(self, camera_id: str) -> Optional[JudgeStatus]:
        """获取完整状态"""
        return self._judges.get(camera_id)
    
    def get_entrypoint(self, camera_id: str) -> Optional[str]:
        """获取关联的入口点"""
        return self._entrypoint_map.get(camera_id)
    
    def _degrade(self, camera_id: str) -> bool:
        """降级 Judge"""
        judge = self._judges.get(camera_id)
        if not judge or judge.state == JudgeAvailabilityState.DEGRADED:
            return False
        
        old_state = judge.state
        judge.state = JudgeAvailabilityState.DEGRADED
        judge.offline_since = datetime.now(timezone.utc)
        judge.last_state_change = judge.offline_since
        
        self.stats["state_changes"] += 1
        self.stats["degraded_events"] += 1
        
        if self.on_state_change:
            self.on_state_change(camera_id, old_state, judge.state)
        
        return True
    
    def _try_recover(self, camera_id: str) -> bool:
        """尝试恢复 Judge"""
        judge = self._judges.get(camera_id)
        if not judge or judge.state == JudgeAvailabilityState.AVAILABLE:
            return False
        
        # 立即恢复（收到心跳就恢复）
        old_state = judge.state
        judge.state = JudgeAvailabilityState.AVAILABLE
        judge.offline_since = None
        judge.last_state_change = datetime.now(timezone.utc)
        
        self.stats["state_changes"] += 1
        self.stats["recovery_events"] += 1
        
        if self.on_state_change:
            self.on_state_change(camera_id, old_state, judge.state)
        
        return True
    
    def get_stats(self) -> Dict:
        """获取统计信息"""
        available_count = sum(1 for j in self._judges.values() 
                             if j.state == JudgeAvailabilityState.AVAILABLE)
        degraded_count = len(self._judges) - available_count
        
        return {
            **self.stats,
            "total_judges": len(self._judges),
            "available_judges": available_count,
            "degraded_judges": degraded_count,
        }
