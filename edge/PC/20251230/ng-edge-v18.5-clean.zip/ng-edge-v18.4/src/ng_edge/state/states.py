"""
NG-EDGE State Definitions (v2.2 Architecture)

双维度状态模型：
- ThreatState: 威胁级别（信号驱动）
- WorkflowState: 工作流状态（动作/用户驱动）
- JudgeAvailabilityState: Judge 摄像头可用性

符合 Architecture Spec v2.2 §3
"""

from enum import Enum
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Optional, List, Dict, Any


# =============================================================================
# 威胁状态 (Signal-driven)
# =============================================================================

class ThreatState(str, Enum):
    """
    威胁状态 (v2.2 §3.1)
    
    信号驱动，单调递增（带衰减）
    """
    NONE = "none"           # 无威胁
    PRE_L1 = "pre_l1"       # 预警 Level 1（轻微）
    PRE_L2 = "pre_l2"       # 预警 Level 2（中等）
    PRE_L3 = "pre_l3"       # 预警 Level 3（严重）
    PENDING = "pending"     # 等待确认（入口延迟）
    TRIGGERED = "triggered" # 已触发报警


class WorkflowState(str, Enum):
    """
    工作流状态 (v2.2 §3.1)
    
    动作/用户驱动
    """
    IDLE = "idle"               # 空闲
    NOTIFIED = "notified"       # 已通知
    VERIFYING = "verifying"     # 验证中
    ESCALATED = "escalated"     # 已升级
    RESOLVED = "resolved"       # 已解决
    CLOSED = "closed"           # 已关闭


class WorkflowSubPhase(str, Enum):
    """
    工作流子阶段 (v2.2 §3.3)
    
    仅用于 ESCALATED 状态
    """
    SIREN_ACTIVE = "siren_active"           # 警报响起中
    SIREN_TIMEOUT = "siren_timeout"         # 警报超时停止
    AWAITING_RESPONSE = "awaiting_response" # 等待响应
    DISPATCH_REQUESTED = "dispatch_requested"   # 请求派遣
    DISPATCH_CONFIRMED = "dispatch_confirmed"   # 派遣已确认
    DISPATCH_CANCELLED = "dispatch_cancelled"   # 派遣已取消


class JudgeAvailabilityState(str, Enum):
    """
    Judge 摄像头可用性状态 (v2.2 §3.4)
    """
    AVAILABLE = "available"   # 可用
    DEGRADED = "degraded"     # 降级（离线或不健康）


# =============================================================================
# 状态组合验证
# =============================================================================

# 有效的 ThreatState + WorkflowState 组合 (v2.2 §3.2)
VALID_STATE_COMBINATIONS = {
    ThreatState.NONE: {WorkflowState.IDLE, WorkflowState.CLOSED},
    ThreatState.PRE_L1: {WorkflowState.IDLE},
    ThreatState.PRE_L2: {WorkflowState.IDLE, WorkflowState.NOTIFIED},
    ThreatState.PRE_L3: {WorkflowState.IDLE, WorkflowState.NOTIFIED, WorkflowState.VERIFYING},
    ThreatState.PENDING: {WorkflowState.NOTIFIED, WorkflowState.VERIFYING},
    ThreatState.TRIGGERED: {WorkflowState.NOTIFIED, WorkflowState.VERIFYING, 
                           WorkflowState.ESCALATED, WorkflowState.RESOLVED},
}


def is_valid_combination(threat: ThreatState, workflow: WorkflowState) -> bool:
    """检查状态组合是否有效"""
    valid_workflows = VALID_STATE_COMBINATIONS.get(threat, set())
    return workflow in valid_workflows


# =============================================================================
# 转换原因码
# =============================================================================

class ReasonCode(str, Enum):
    """转换原因码 (v2.2 §3.8, §3.9)"""
    # 信号触发
    SIGNAL_DOOR_OPEN = "signal_door_open"
    SIGNAL_GLASS_BREAK = "signal_glass_break"
    SIGNAL_MOTION = "signal_motion"
    SIGNAL_PERSON = "signal_person"
    
    # PRE 衰减
    DECAY_SILENCE_L3 = "decay_silence_l3"
    DECAY_SILENCE_L2 = "decay_silence_l2"
    DECAY_SILENCE_L1 = "decay_silence_l1"
    
    # PENDING 取消
    QUICK_OPEN_CLOSE = "quick_open_close"
    USER_DISARM_PIN = "user_disarm_pin"
    USER_CONFIRM_SELF = "user_confirm_self"
    ENTRY_DELAY_EXPIRED = "entry_delay_expired"
    
    # Tamper
    TAMPER_SUSPECTED = "tamper_suspected"
    TAMPER_VERIFIED_BY_USER = "tamper_verified_by_user"
    TAMPER_FAULT = "tamper_fault"
    
    # 用户操作
    USER_CANCEL = "user_cancel"
    USER_RESOLVE = "user_resolve"
    USER_SILENCE_SIREN = "user_silence_siren"
    
    # 系统
    SIREN_TIMEOUT = "siren_timeout"
    JUDGE_OFFLINE = "judge_offline"
    JUDGE_ONLINE = "judge_online"


# =============================================================================
# 转换记录
# =============================================================================

@dataclass
class TransitionRecord:
    """
    状态转换记录 (v2.2 §3.13)
    
    每次状态变化必须记录
    """
    record_id: str
    timestamp: datetime
    incident_id: str
    
    # 转换维度
    dimension: str  # "threat", "workflow", "sub_phase", "judge_availability"
    from_state: str
    to_state: str
    
    # 规则信息
    rule_id: str = ""
    rule_version: str = ""
    is_canary: bool = False
    reason_code: str = ""
    
    # 触发信号
    trigger_signal_ids: List[str] = field(default_factory=list)
    trigger_signal_summary: Dict[str, Any] = field(default_factory=dict)
    
    # 上下文
    context: Dict[str, Any] = field(default_factory=dict)


# =============================================================================
# 事件状态容器
# =============================================================================

@dataclass
class IncidentState:
    """
    事件状态容器
    
    持有一个事件的完整状态
    """
    incident_id: str
    
    # 双维度状态
    threat_state: ThreatState = ThreatState.NONE
    workflow_state: WorkflowState = WorkflowState.IDLE
    sub_phase: Optional[WorkflowSubPhase] = None
    
    # Judge 可用性
    judge_available: bool = True
    
    # 时间
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    last_transition_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    
    # 关联
    zone_id: str = ""
    entrypoint_id: Optional[str] = None
    
    # 信号
    signal_ids: List[str] = field(default_factory=list)
    
    # 转换历史
    transitions: List[TransitionRecord] = field(default_factory=list)
    
    def is_active(self) -> bool:
        """事件是否活跃"""
        return self.threat_state != ThreatState.NONE or self.workflow_state not in {
            WorkflowState.IDLE, WorkflowState.CLOSED
        }
    
    def is_valid(self) -> bool:
        """状态组合是否有效"""
        return is_valid_combination(self.threat_state, self.workflow_state)
    
    def can_escalate_pre(self) -> bool:
        """是否可以升级 PRE"""
        return (
            self.judge_available and 
            self.threat_state in {ThreatState.NONE, ThreatState.PRE_L1, ThreatState.PRE_L2}
        )


# =============================================================================
# 与 v5 状态机的兼容映射
# =============================================================================

def alarm_state_to_threat(alarm_state) -> ThreatState:
    """
    将 v5 AlarmState 映射到 ThreatState
    """
    mapping = {
        "quiet": ThreatState.NONE,
        "attention": ThreatState.PRE_L1,
        "pre": ThreatState.PRE_L2,
        "pending": ThreatState.PENDING,
        "triggered": ThreatState.TRIGGERED,
    }
    state_value = alarm_state.value if hasattr(alarm_state, 'value') else str(alarm_state)
    return mapping.get(state_value, ThreatState.NONE)


def threat_to_alarm_state(threat: ThreatState) -> str:
    """
    将 ThreatState 映射回 v5 AlarmState 值
    """
    mapping = {
        ThreatState.NONE: "quiet",
        ThreatState.PRE_L1: "attention",
        ThreatState.PRE_L2: "pre",
        ThreatState.PRE_L3: "pre",  # v5 没有 L3，映射到 pre
        ThreatState.PENDING: "pending",
        ThreatState.TRIGGERED: "triggered",
    }
    return mapping.get(threat, "quiet")
