"""
LOGISTICS State Machine - 快递检测状态机

PRD Reference: §13.x Shared Perception & Dual State Machines

核心原则:
1. 与 SECURITY (AlarmSM) 完全隔离
2. 只产生信息性事件，不触发报警
3. 基于行为模式检测快递行为

行为模式:
- 人进入 yard (L1) → 开始追踪
- 人在 yard 短暂停留后离开 + 门未开 → 判定为快递员
- 人进入 door (L2) 或停留过长 → 不判定（由 SECURITY 处理）
"""

import asyncio
import logging
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Callable, Dict, List, Optional

logger = logging.getLogger(__name__)


class LogisticsState(str, Enum):
    """LOGISTICS 状态"""
    IDLE = "idle"           # 无活动
    TRACKING = "tracking"   # 追踪中（人已进入）
    DETECTED = "detected"   # 检测到快递行为
    NOTIFIED = "notified"   # 已通知用户
    HANDLED = "handled"     # 用户已确认


@dataclass
class LogisticsConfig:
    """LOGISTICS 配置"""
    # 快递员行为判定参数
    delivery_max_duration_sec: float = 30.0    # 最大停留时间（超过则不视为快递）
    delivery_min_duration_sec: float = 2.0     # 最小停留时间（太短可能是误检）
    
    # 事件超时
    detection_expire_sec: float = 300.0        # 检测事件 5 分钟后过期
    
    # 调试
    debug: bool = False


@dataclass
class TrackingSession:
    """追踪会话"""
    camera_id: str
    enter_time: float
    enter_zone: str          # "yard" or "door"
    enter_level: int         # 1 or 2
    
    # 追踪状态
    last_seen_time: float = 0.0
    last_zone: str = ""
    last_level: int = 0
    max_level: int = 0       # 最高威胁级别（用于判断是否进入过 L2）
    l2_enter_time: Optional[float] = None  # 首次进入 L2 的时间
    
    # 保险丝 #1：门磁活动（开或关都算）
    door_activity: bool = False
    
    def __post_init__(self):
        self.last_seen_time = self.enter_time
        self.last_zone = self.enter_zone
        self.last_level = self.enter_level
        self.max_level = self.enter_level


@dataclass
class LogisticsEvent:
    """LOGISTICS 事件"""
    event_type: str          # "delivery_detected", "delivery_notified", "delivery_handled"
    camera_id: str
    timestamp: float
    
    # 详情
    duration_sec: float = 0.0
    max_level: int = 0
    confidence: float = 0.0  # 置信度 (0-1)
    
    # 元数据
    metadata: Dict = field(default_factory=dict)


class LogisticsSM:
    """
    LOGISTICS 状态机
    
    职责:
    - 追踪人员进入/离开事件
    - 基于行为模式检测快递行为
    - 产生 LOGISTICS 事件（不触发报警）
    
    隔离保证:
    - 不访问 SecurityCoordinator
    - 不访问 DeterrentSystem
    - 不调用 set_triggered()
    - 不产生 SignalEnvelope
    """
    
    def __init__(self, config: LogisticsConfig = None):
        self.config = config or LogisticsConfig()
        
        # 状态
        self._state = LogisticsState.IDLE
        self._sessions: Dict[str, TrackingSession] = {}  # camera_id → session
        self._pending_events: List[LogisticsEvent] = []
        
        # 门磁状态
        self._door_states: Dict[str, bool] = {}  # door_id → is_open
        
        # 回调
        self.on_delivery_detected: Optional[Callable[[LogisticsEvent], None]] = None
        self.on_state_change: Optional[Callable[[LogisticsState, LogisticsState], None]] = None
        
        # 统计
        self._stats = {
            "sessions_started": 0,
            "sessions_completed": 0,
            "deliveries_detected": 0,
            "false_positives": 0,  # 门有活动的情况
        }
    
    @property
    def state(self) -> LogisticsState:
        return self._state
    
    @property
    def stats(self) -> Dict:
        return self._stats.copy()
    
    def _set_state(self, new_state: LogisticsState):
        """内部状态转换"""
        if new_state != self._state:
            old_state = self._state
            self._state = new_state
            logger.info(f"[LOGISTICS] State: {old_state.value} → {new_state.value}")
            if self.on_state_change:
                self.on_state_change(old_state, new_state)
    
    # =========================================================================
    # 感知事件接口（由 EdgeRuntime 调用）
    # =========================================================================
    
    def on_person_enter(self, camera_id: str, zone: str, level: int, timestamp: float = None):
        """
        人员进入事件
        
        由 _camera_processor 在 PERSON ENTER 时调用
        """
        timestamp = timestamp or time.time()
        
        # 如果已有会话，更新
        if camera_id in self._sessions:
            session = self._sessions[camera_id]
            session.last_seen_time = timestamp
            session.last_zone = zone
            session.last_level = level
            session.max_level = max(session.max_level, level)
            
            # 记录首次进入 L2 时间
            if level >= 2 and session.l2_enter_time is None:
                session.l2_enter_time = timestamp
                logger.debug(f"[LOGISTICS] [{camera_id}] 首次进入 L2")
            
            return
        
        # 新会话
        session = TrackingSession(
            camera_id=camera_id,
            enter_time=timestamp,
            enter_zone=zone,
            enter_level=level,
        )
        
        self._sessions[camera_id] = session
        self._stats["sessions_started"] += 1
        
        logger.info(f"[LOGISTICS] [{camera_id}] 开始追踪 | zone={zone} L{level}")
        
        # 状态转换
        if self._state == LogisticsState.IDLE:
            self._set_state(LogisticsState.TRACKING)
    
    def on_person_update(self, camera_id: str, zone: str, level: int, timestamp: float = None):
        """
        人员位置更新
        
        由 _camera_processor 在检测到人员时持续调用
        """
        timestamp = timestamp or time.time()
        
        session = self._sessions.get(camera_id)
        if not session:
            # 没有会话，当作进入处理
            self.on_person_enter(camera_id, zone, level, timestamp)
            return
        
        # 更新会话
        session.last_seen_time = timestamp
        session.last_zone = zone
        session.last_level = level
        session.max_level = max(session.max_level, level)
        
        # 记录首次进入 L2 时间
        if level >= 2 and session.l2_enter_time is None:
            session.l2_enter_time = timestamp
    
    def on_person_leave(self, camera_id: str, timestamp: float = None):
        """
        人员离开事件
        
        由 _camera_processor 在 PERSON LEAVE 时调用
        """
        timestamp = timestamp or time.time()
        
        session = self._sessions.get(camera_id)
        if not session:
            logger.debug(f"[LOGISTICS] [{camera_id}] 离开但无会话")
            return
        
        # 计算停留时间
        duration = timestamp - session.enter_time
        
        logger.info(f"[LOGISTICS] [{camera_id}] 人员离开 | duration={duration:.1f}s enter_L{session.enter_level}→last_L{session.last_level} door_activity={session.door_activity}")
        
        # 判断是否为快递行为
        is_delivery = self._evaluate_delivery(session, duration, timestamp)
        
        if is_delivery:
            self._emit_delivery_detected(session, duration, timestamp)
        
        # 清理会话
        del self._sessions[camera_id]
        self._stats["sessions_completed"] += 1
        
        # 状态转换（如果没有其他活跃会话，重置回 IDLE）
        if not self._sessions:
            self._set_state(LogisticsState.IDLE)
    
    def on_door_state_change(self, door_id: str, is_open: bool, timestamp: float = None):
        """
        门磁状态变化
        
        保险丝 #1：只有在 session 期间发生"开门"动作才否决快递
        - 开门 = 有人要进出，否决快递
        - 关门 = 可能是之前就开着的门，不否决
        
        由 EdgeRuntime 在门磁事件时调用
        """
        timestamp = timestamp or time.time()
        
        old_state = self._door_states.get(door_id, False)
        self._door_states[door_id] = is_open
        
        # 只有状态真正变化才处理
        if is_open == old_state:
            return
        
        action = "打开" if is_open else "关闭"
        logger.debug(f"[LOGISTICS] 门{action}: {door_id}")
        
        # 只有"开门"动作才标记活动（关门不算，可能是之前就开着的）
        if is_open:
            for session in self._sessions.values():
                session.door_activity = True
                logger.info(f"[LOGISTICS] [{session.camera_id}] 检测到开门 (保险丝#1)")
    
    # =========================================================================
    # 内部逻辑
    # =========================================================================
    
    def _evaluate_delivery(self, session: TrackingSession, duration: float, timestamp: float) -> bool:
        """
        评估是否为快递行为
        
        条件:
        1. 停留时间在合理范围内 (min < duration < max)
        2. 保险丝 #1: 门无活动
        3. 保险丝 #2: 进入和离开都在门外（非出门/回家）
        """
        cfg = self.config
        
        # 条件 1: 停留时间
        if duration < cfg.delivery_min_duration_sec:
            logger.info(f"[LOGISTICS] ❌ 判定: 停留太短 ({duration:.1f}s < {cfg.delivery_min_duration_sec}s)")
            return False
        
        if duration > cfg.delivery_max_duration_sec:
            logger.info(f"[LOGISTICS] ❌ 判定: 停留太长 ({duration:.1f}s > {cfg.delivery_max_duration_sec}s)")
            return False
        
        # 保险丝 #1: 门无活动
        if session.door_activity:
            logger.info(f"[LOGISTICS] ❌ 判定: 门有活动（保险丝#1，可能是住户）")
            self._stats["false_positives"] += 1
            return False
        
        # 保险丝 #2: 方向判断
        # 快递特征：从门外进入（L1 或 L0），从门外离开（L1 或 L0）
        # 出门特征：直接在门口出现（L2）
        # 回家特征：在门口消失（L2）
        
        if session.enter_level >= 2:
            # 直接在门口(L2)出现，说明是从里面出来的（出门）
            logger.info(f"[LOGISTICS] ❌ 判定: 直接在门口出现 enter_L{session.enter_level}（保险丝#2，可能是出门）")
            self._stats["false_positives"] += 1
            return False
        
        if session.last_level >= 2:
            # 在门口(L2)消失，说明进门了（回家）
            logger.info(f"[LOGISTICS] ❌ 判定: 在门口消失 last_L{session.last_level}（保险丝#2，可能是回家）")
            self._stats["false_positives"] += 1
            return False
        
        # 通过所有条件
        logger.info(f"[LOGISTICS] ✅ 判定为快递行为 | duration={duration:.1f}s enter_L{session.enter_level}→last_L{session.last_level}")
        return True
    
    def _calculate_confidence(self, session: TrackingSession, duration: float) -> float:
        """
        计算置信度
        
        基于:
        - 停留时间（越接近典型值越高）
        - 最高威胁级别（L1 比 L2 置信度高）
        """
        cfg = self.config
        
        # 典型快递时间 5-10 秒
        typical_duration = 7.0
        duration_score = 1.0 - min(abs(duration - typical_duration) / 10.0, 1.0)
        
        # 级别评分（只在 L1 停留置信度更高）
        level_score = 1.0 if session.max_level == 1 else 0.7
        
        # 综合
        confidence = (duration_score * 0.6 + level_score * 0.4)
        return round(confidence, 2)
    
    def _emit_delivery_detected(self, session: TrackingSession, duration: float, timestamp: float):
        """发送快递检测事件"""
        confidence = self._calculate_confidence(session, duration)
        
        event = LogisticsEvent(
            event_type="delivery_detected",
            camera_id=session.camera_id,
            timestamp=timestamp,
            duration_sec=round(duration, 1),
            max_level=session.max_level,
            confidence=confidence,
            metadata={
                "enter_zone": session.enter_zone,
                "enter_level": session.enter_level,
                "enter_time": session.enter_time,
            }
        )
        
        self._pending_events.append(event)
        self._stats["deliveries_detected"] += 1
        
        logger.warning(f"[LOGISTICS] 📦 快递检测 | camera={session.camera_id} duration={duration:.1f}s confidence={confidence}")
        
        # 状态转换
        self._set_state(LogisticsState.DETECTED)
        
        # 回调
        if self.on_delivery_detected:
            self.on_delivery_detected(event)
    
    # =========================================================================
    # 用户交互
    # =========================================================================
    
    def mark_notified(self, event_id: str = None):
        """标记已通知用户"""
        if self._state == LogisticsState.DETECTED:
            self._set_state(LogisticsState.NOTIFIED)
    
    def mark_handled(self, event_id: str = None):
        """标记用户已确认处理"""
        if self._state in [LogisticsState.DETECTED, LogisticsState.NOTIFIED]:
            self._set_state(LogisticsState.HANDLED)
            
            # 清理过期事件后返回 IDLE
            self._pending_events.clear()
            self._set_state(LogisticsState.IDLE)
    
    def dismiss(self):
        """忽略当前检测"""
        self._pending_events.clear()
        self._set_state(LogisticsState.IDLE)
    
    # =========================================================================
    # 查询接口
    # =========================================================================
    
    def get_pending_events(self) -> List[LogisticsEvent]:
        """获取待处理事件"""
        return self._pending_events.copy()
    
    def get_active_sessions(self) -> Dict[str, TrackingSession]:
        """获取活跃会话"""
        return self._sessions.copy()
    
    def has_active_tracking(self) -> bool:
        """是否有活跃追踪"""
        return len(self._sessions) > 0
    
    # =========================================================================
    # 清理
    # =========================================================================
    
    def cleanup_expired(self, current_time: float = None):
        """清理过期事件"""
        current_time = current_time or time.time()
        expire_threshold = current_time - self.config.detection_expire_sec
        
        # 清理过期事件
        self._pending_events = [
            e for e in self._pending_events
            if e.timestamp > expire_threshold
        ]
        
        # 如果没有待处理事件，返回 IDLE
        if not self._pending_events and self._state in [LogisticsState.DETECTED, LogisticsState.NOTIFIED]:
            self._set_state(LogisticsState.IDLE)
    
    def reset(self):
        """重置状态机"""
        self._state = LogisticsState.IDLE
        self._sessions.clear()
        self._pending_events.clear()
        self._door_states.clear()
        logger.info("[LOGISTICS] 状态机已重置")
