"""
NG-EDGE Core Signal Definitions

统一信号包络定义，符合 Architecture Spec v2.2 §1.1

所有信号必须遵循此格式，以确保：
1. 系统内一致性
2. Replay 可重放性
3. 跨组件互操作性
"""

from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Dict, Any, Optional, Literal, List
import uuid


# =============================================================================
# 枚举定义
# =============================================================================

class SourceType(str, Enum):
    """信号来源类型"""
    CAMERA = "camera"
    SENSOR = "sensor"
    HEALTH = "health"
    CONTEXT = "context"


class Hardness(str, Enum):
    """信号硬度 - 决定处理优先级"""
    SOFT = "soft"   # 可采样/丢弃，不能直接触发 PENDING/TRIGGERED
    HARD = "hard"   # 必须处理，可触发 PENDING/TRIGGERED


class PreLevel(str, Enum):
    """PRE 级别 (仅用于 soft 信号)"""
    L1 = "PRE_L1"
    L2 = "PRE_L2"
    L3 = "PRE_L3"


class CameraRole(str, Enum):
    """摄像头角色 (v2.2 §1.4)"""
    JUDGE = "judge"       # 唯一决策源，可推进 PRE
    WITNESS = "witness"   # 仅验证/证据，不参与决策


class ContextGateType(str, Enum):
    """上下文门控类型 (v2.2 §1.3)"""
    YARD_CONFIRMED = "yard_confirmed"
    PORCH_CONFIRMED = "porch_confirmed"


# =============================================================================
# 信号硬度映射表 (固定规则，v2.2 §1.2)
# =============================================================================

SIGNAL_HARDNESS_MAP: Dict[str, Hardness] = {
    # Camera 信号 - 全部是 SOFT
    "person_detected": Hardness.SOFT,
    "vehicle_detected": Hardness.SOFT,
    "loitering": Hardness.SOFT,
    "motion_camera": Hardness.SOFT,
    
    # Sensor 信号 - 全部是 HARD
    "door_open": Hardness.HARD,
    "door_close": Hardness.HARD,
    "glass_break": Hardness.HARD,
    "motion_pir": Hardness.HARD,
    
    # Health 信号 - 混合
    "tamper_s": Hardness.SOFT,      # 疑似篡改
    "tamper_c": Hardness.HARD,      # 确认篡改
    "offline": Hardness.SOFT,
    "battery_low": Hardness.SOFT,
    
    # Context 信号 - 全部是 SOFT
    "context_gate": Hardness.SOFT,
}


def get_signal_hardness(signal_kind: str) -> Hardness:
    """
    获取信号硬度
    
    Args:
        signal_kind: 信号类型
        
    Returns:
        Hardness: 信号硬度，未知类型默认为 SOFT
    """
    return SIGNAL_HARDNESS_MAP.get(signal_kind, Hardness.SOFT)


# =============================================================================
# 核心数据结构
# =============================================================================

@dataclass
class SignalEnvelope:
    """
    统一信号包络 (v2.2 Spec §1.1)
    
    所有进入系统的信号必须转换为此格式。
    
    Attributes:
        signal_id: 全局唯一标识，用于幂等处理
        source_type: 信号来源类型
        device_id: 产生信号的设备 ID
        zone_id: 区域 ID
        entrypoint_id: 入口点 ID (可选)
        signal_kind: 信号类型 (person_detected, door_open, etc.)
        hardness: 信号硬度 (soft/hard)
        level: PRE 级别 (仅用于 soft 信号)
        confidence: 置信度 (0.0 - 1.0)
        timestamp: 设备报告时间
        ingest_ts: Edge 接收时间 (排序和关联的权威时间)
        camera_role: 摄像头角色 (仅用于 camera 信号)
        attributes: 信号特定属性
        evidence_hints: 证据指针
    """
    
    # 标识
    signal_id: str = field(default_factory=lambda: f"sig_{uuid.uuid4().hex[:12]}")
    source_type: SourceType = SourceType.SENSOR
    device_id: str = ""
    
    # 空间归属
    zone_id: str = ""
    entrypoint_id: Optional[str] = None
    
    # 分类
    signal_kind: str = ""
    hardness: Hardness = Hardness.SOFT
    level: Optional[PreLevel] = None
    confidence: float = 1.0
    
    # 时间
    timestamp: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    ingest_ts: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    
    # 摄像头特定
    camera_role: Optional[CameraRole] = None
    
    # 扩展属性
    attributes: Dict[str, Any] = field(default_factory=dict)
    evidence_hints: Dict[str, Any] = field(default_factory=dict)
    
    def __post_init__(self):
        """初始化后处理"""
        # 自动设置硬度（如果未指定）
        if self.signal_kind and self.hardness == Hardness.SOFT:
            self.hardness = get_signal_hardness(self.signal_kind)
    
    @classmethod
    def from_zigbee(
        cls,
        device_id: str,
        friendly_name: str,
        signal_kind: str,
        zone_id: str,
        entrypoint_id: Optional[str] = None,
        raw_payload: Optional[Dict[str, Any]] = None,
        **kwargs
    ) -> "SignalEnvelope":
        """
        从 Zigbee 消息创建信号
        
        Args:
            device_id: Zigbee IEEE 地址
            friendly_name: 设备友好名称
            signal_kind: 信号类型 (door_open, motion_pir, etc.)
            zone_id: 区域 ID
            entrypoint_id: 入口点 ID
            raw_payload: 原始 MQTT payload
        """
        now = datetime.now(timezone.utc)
        
        return cls(
            source_type=SourceType.SENSOR,
            device_id=device_id,
            zone_id=zone_id,
            entrypoint_id=entrypoint_id,
            signal_kind=signal_kind,
            hardness=get_signal_hardness(signal_kind),
            confidence=1.0,  # 传感器信号置信度为 1.0
            timestamp=now,
            ingest_ts=now,
            attributes={
                "friendly_name": friendly_name,
                "raw_payload": raw_payload or {},
                **kwargs
            }
        )
    
    @classmethod
    def from_camera(
        cls,
        device_id: str,
        signal_kind: str,
        zone_id: str,
        camera_role: CameraRole = CameraRole.JUDGE,
        confidence: float = 0.8,
        level: Optional[PreLevel] = None,
        entrypoint_id: Optional[str] = None,
        bbox: Optional[tuple] = None,
        track_id: Optional[str] = None,
        **kwargs
    ) -> "SignalEnvelope":
        """
        从摄像头检测创建信号
        
        Args:
            device_id: 摄像头 ID
            signal_kind: 信号类型 (person_detected, vehicle_detected, etc.)
            zone_id: 区域 ID
            camera_role: 摄像头角色
            confidence: 检测置信度
            level: PRE 级别
            bbox: 检测框 (x, y, w, h)
            track_id: 跟踪 ID
        """
        now = datetime.now(timezone.utc)
        
        attributes = {**kwargs}
        if bbox:
            attributes["bbox"] = bbox
        if track_id:
            attributes["track_id"] = track_id
        
        return cls(
            source_type=SourceType.CAMERA,
            device_id=device_id,
            zone_id=zone_id,
            entrypoint_id=entrypoint_id,
            signal_kind=signal_kind,
            hardness=Hardness.SOFT,  # 摄像头信号始终是 SOFT
            level=level,
            confidence=confidence,
            timestamp=now,
            ingest_ts=now,
            camera_role=camera_role,
            attributes=attributes
        )
    
    @classmethod
    def context_gate(
        cls,
        gate_type: ContextGateType,
        zone_id: str,
        source_device: str,
        ttl_sec: int = 120,
        **kwargs
    ) -> "SignalEnvelope":
        """
        创建上下文门控信号 (v2.2 §1.3)
        
        Args:
            gate_type: 门控类型 (yard_confirmed, porch_confirmed)
            zone_id: 区域 ID
            source_device: 产生此门控的设备
            ttl_sec: 有效期（秒）
        """
        now = datetime.now(timezone.utc)
        
        return cls(
            source_type=SourceType.CONTEXT,
            device_id=source_device,
            zone_id=zone_id,
            signal_kind="context_gate",
            hardness=Hardness.SOFT,
            confidence=1.0,
            timestamp=now,
            ingest_ts=now,
            attributes={
                "gate_type": gate_type.value,
                "ttl_sec": ttl_sec,
                "expires_at": (now.timestamp() + ttl_sec),
                **kwargs
            }
        )
    
    def is_hard(self) -> bool:
        """是否为硬信号"""
        return self.hardness == Hardness.HARD
    
    def is_soft(self) -> bool:
        """是否为软信号"""
        return self.hardness == Hardness.SOFT
    
    def is_from_judge(self) -> bool:
        """是否来自 Judge 摄像头"""
        return self.camera_role == CameraRole.JUDGE
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典（用于序列化）"""
        return {
            "signal_id": self.signal_id,
            "source_type": self.source_type.value,
            "device_id": self.device_id,
            "zone_id": self.zone_id,
            "entrypoint_id": self.entrypoint_id,
            "signal_kind": self.signal_kind,
            "hardness": self.hardness.value,
            "level": self.level.value if self.level else None,
            "confidence": self.confidence,
            "timestamp": self.timestamp.isoformat(),
            "ingest_ts": self.ingest_ts.isoformat(),
            "camera_role": self.camera_role.value if self.camera_role else None,
            "attributes": self.attributes,
            "evidence_hints": self.evidence_hints,
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "SignalEnvelope":
        """从字典创建（用于反序列化）"""
        return cls(
            signal_id=data.get("signal_id", ""),
            source_type=SourceType(data.get("source_type", "sensor")),
            device_id=data.get("device_id", ""),
            zone_id=data.get("zone_id", ""),
            entrypoint_id=data.get("entrypoint_id"),
            signal_kind=data.get("signal_kind", ""),
            hardness=Hardness(data.get("hardness", "soft")),
            level=PreLevel(data["level"]) if data.get("level") else None,
            confidence=data.get("confidence", 1.0),
            timestamp=datetime.fromisoformat(data["timestamp"]) if data.get("timestamp") else datetime.now(timezone.utc),
            ingest_ts=datetime.fromisoformat(data["ingest_ts"]) if data.get("ingest_ts") else datetime.now(timezone.utc),
            camera_role=CameraRole(data["camera_role"]) if data.get("camera_role") else None,
            attributes=data.get("attributes", {}),
            evidence_hints=data.get("evidence_hints", {}),
        )


# =============================================================================
# 兼容层：从旧格式转换
# =============================================================================

def convert_legacy_signal(
    entry_point_id: str,
    zone_type: str,
    signal_type: str,
    from_inside: bool = False,
    device_id: str = "",
    **kwargs
) -> SignalEnvelope:
    """
    从 state_machine_v5 的旧 Signal 格式转换
    
    Args:
        entry_point_id: 入口点 ID
        zone_type: 区域类型 (exterior, entry_exit, interior, perimeter)
        signal_type: 信号类型 (DOOR_OPEN, MOTION_ACTIVE, etc.)
        from_inside: 是否从内部触发
        device_id: 设备 ID
    """
    # 映射旧信号类型到新格式
    signal_kind_map = {
        "PERSON_DETECTED": "person_detected",
        "VEHICLE_DETECTED": "vehicle_detected",
        "DOOR_OPEN": "door_open",
        "DOOR_CLOSE": "door_close",
        "MOTION_ACTIVE": "motion_pir",
        "GLASS_BREAK": "glass_break",
    }
    
    signal_kind = signal_kind_map.get(signal_type, signal_type.lower())
    
    return SignalEnvelope(
        device_id=device_id or f"legacy_{entry_point_id}",
        zone_id=zone_type,
        entrypoint_id=entry_point_id,
        signal_kind=signal_kind,
        attributes={
            "from_inside": from_inside,
            "legacy_zone_type": zone_type,
            **kwargs
        }
    )
