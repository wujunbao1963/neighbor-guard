#!/usr/bin/env python3
"""
对比测试：有 bug 的版本 vs 修复后的版本

验证 finally 中 _deterrent_active = False 导致的竞争条件
"""

import asyncio
import time
import logging

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s.%(msecs)03d [%(levelname)s] %(message)s',
    datefmt='%H:%M:%S'
)
logger = logging.getLogger(__name__)


class BuggyDeterrentSystem:
    """有 bug 的版本 - finally 中设置 _deterrent_active = False"""
    
    def __init__(self):
        self._deterrent_active = False
        self._deterrent_level = None
        self._deterrent_task = None
        self.running = True
        self.light_state = False
        self.loop_exit_count = 0
    
    def _start_deterrent(self, level: str):
        if self._deterrent_level == level and self._deterrent_active:
            return
        
        if self._deterrent_active:
            logger.info(f"[BUGGY] 切换 {self._deterrent_level} → {level}")
            self._deterrent_active = False
            if self._deterrent_task:
                self._deterrent_task.cancel()
                self._deterrent_task = None
        
        self._deterrent_active = True
        self._deterrent_level = level
        
        logger.warning(f"[BUGGY] 🚨 启动 {level}")
        self._deterrent_task = asyncio.create_task(self._deterrent_loop(level))
    
    def _stop_deterrent(self):
        self._deterrent_active = False
        self._deterrent_level = None
        if self._deterrent_task:
            self._deterrent_task.cancel()
            self._deterrent_task = None
    
    async def _deterrent_loop(self, level: str):
        try:
            logger.info(f"[BUGGY] 💡 {level}: 开灯")
            self.light_state = True
            
            loop_count = 0
            while self._deterrent_active and self.running:
                loop_count += 1
                await asyncio.sleep(0.1)
            
            logger.info(f"[BUGGY] 循环退出 (loop_count={loop_count})")
            self.loop_exit_count += 1
                
        except asyncio.CancelledError:
            logger.info("[BUGGY] 威慑循环已取消")
        finally:
            # BUG: 这里会覆盖新任务的 _deterrent_active = True！
            self._deterrent_active = False
            self.light_state = False
            logger.info(f"[BUGGY] finally: _deterrent_active = False")


class FixedDeterrentSystem:
    """修复后的版本 - finally 中不修改 _deterrent_active"""
    
    def __init__(self):
        self._deterrent_active = False
        self._deterrent_level = None
        self._deterrent_task = None
        self.running = True
        self.light_state = False
        self.loop_exit_count = 0
    
    def _start_deterrent(self, level: str):
        if self._deterrent_level == level and self._deterrent_active:
            return
        
        if self._deterrent_active:
            logger.info(f"[FIXED] 切换 {self._deterrent_level} → {level}")
            self._deterrent_active = False
            if self._deterrent_task:
                self._deterrent_task.cancel()
                self._deterrent_task = None
        
        self._deterrent_active = True
        self._deterrent_level = level
        
        logger.warning(f"[FIXED] 🚨 启动 {level}")
        self._deterrent_task = asyncio.create_task(self._deterrent_loop(level))
    
    def _stop_deterrent(self):
        self._deterrent_active = False
        self._deterrent_level = None
        if self._deterrent_task:
            self._deterrent_task.cancel()
            self._deterrent_task = None
    
    async def _deterrent_loop(self, level: str):
        try:
            logger.info(f"[FIXED] 💡 {level}: 开灯")
            self.light_state = True
            
            loop_count = 0
            while self._deterrent_active and self.running:
                loop_count += 1
                await asyncio.sleep(0.1)
            
            logger.info(f"[FIXED] 循环退出 (loop_count={loop_count})")
            self.loop_exit_count += 1
                
        except asyncio.CancelledError:
            logger.info("[FIXED] 威慑循环已取消")
        finally:
            # 修复：不在这里修改 _deterrent_active
            if self._deterrent_level is None:
                self.light_state = False
            logger.info(f"[FIXED] finally: 不修改 _deterrent_active")


async def test_race_condition():
    """测试竞争条件"""
    
    print("\n" + "="*60)
    print("测试：连续同级别信号（模拟连续检测触发）")
    print("="*60)
    
    # 测试有 bug 的版本
    print("\n--- 有 bug 的版本 ---")
    buggy = BuggyDeterrentSystem()
    
    for i in range(10):
        buggy._start_deterrent("L1")
        await asyncio.sleep(0.05)  # 给 finally 执行的时间
    
    await asyncio.sleep(0.5)
    
    print(f"light_state: {buggy.light_state}")
    print(f"_deterrent_active: {buggy._deterrent_active}")
    print(f"loop_exit_count: {buggy.loop_exit_count}")
    
    buggy._stop_deterrent()
    await asyncio.sleep(0.2)
    
    # 测试修复后的版本
    print("\n--- 修复后的版本 ---")
    fixed = FixedDeterrentSystem()
    
    for i in range(10):
        fixed._start_deterrent("L1")
        await asyncio.sleep(0.05)
    
    await asyncio.sleep(0.5)
    
    print(f"light_state: {fixed.light_state}")
    print(f"_deterrent_active: {fixed._deterrent_active}")
    print(f"loop_exit_count: {fixed.loop_exit_count}")
    
    fixed._stop_deterrent()
    await asyncio.sleep(0.2)
    
    # 结果对比
    print("\n" + "="*60)
    print("结果对比")
    print("="*60)
    print(f"有 bug 的版本: light_state={buggy.light_state}, loop_exit={buggy.loop_exit_count}")
    print(f"修复后的版本: light_state={fixed.light_state}, loop_exit={fixed.loop_exit_count}")
    
    if buggy.loop_exit_count > 1:
        print("\n❌ 有 bug 的版本：循环多次异常退出！")
    if fixed.loop_exit_count <= 1:
        print("✅ 修复后的版本：循环正常运行")


if __name__ == "__main__":
    asyncio.run(test_race_condition())
