#!/usr/bin/env python3
"""
Reolink 摄像头声光能力测试

测试内容：
1. API 连接和能力查询
2. 灯光控制（开/关/模式）
3. 警报控制（开/关/duration参数）
4. 闪灯测试（不同频率）
5. 连续警报测试

使用方式：
    python tests/hardware/test_reolink_deterrent.py <ip> <user> <password> <command>

命令：
    info          - 查看摄像头能力和当前设置
    light_on      - 开灯
    light_off     - 关灯
    siren_on      - 开警报（默认2秒）
    siren_3s      - 警报持续3秒
    siren_5s      - 警报持续5秒
    siren_off     - 关警报
    flash_1hz     - 1Hz闪灯测试（10秒）
    flash_2s      - 2秒间隔闪灯测试（10秒）
    flash_slow    - 慢闪测试（3秒间隔，15秒）
    deterrent_l1  - L1威慑测试：常亮灯 + 30秒一次警报
    deterrent_l2  - L2威慑测试：5秒闪灯 + 10秒一次警报
    deterrent_triggered - TRIGGERED测试：持续闪灯 + 3秒一次警报
    stop          - 停止所有
"""

import asyncio
import sys
import time


async def main():
    if len(sys.argv) < 5:
        print(__doc__)
        return
    
    ip, user, password, command = sys.argv[1:5]
    
    print(f"[TEST] 连接 {ip}...")
    
    try:
        from reolink_aio.api import Host
    except ImportError:
        print("[ERROR] reolink_aio 未安装!")
        print("运行: pip install reolink-aio")
        return
    
    host = Host(ip, user, password)
    
    try:
        await host.get_host_data()
        model = host.camera_model(0)
        print(f"[TEST] ✅ 已连接: {model}")
        print()
        
        # =====================================================================
        # info - 查看能力
        # =====================================================================
        if command == "info":
            print("=" * 60)
            print("摄像头能力和设置")
            print("=" * 60)
            
            print("\n📌 基本信息:")
            print(f"  型号: {model}")
            print(f"  固件: {host.sw_version}")
            
            print("\n💡 灯光设置 (whiteled):")
            try:
                print(f"  状态: {host.whiteled_state(0)}")
                print(f"  亮度: {host.whiteled_brightness(0)}")
                print(f"  模式: {host.whiteled_mode(0)}")
                print(f"  可用模式: {host.whiteled_mode_list(0)}")
                print(f"  事件模式: {host.whiteled_event_mode(0)}")
                print(f"  事件闪烁时间: {host.whiteled_event_flash_time(0)}")
                print(f"  事件亮度: {host.whiteled_event_brightness(0)}")
                print(f"  完整设置: {host.whiteled_settings(0)}")
            except Exception as e:
                print(f"  [无法获取: {e}]")
            
            print("\n🔊 警报设置:")
            try:
                print(f"  音量: {host.alarm_volume}")
                print(f"  音频报警启用: {host.audio_alarm_enabled(0)}")
            except Exception as e:
                print(f"  [无法获取: {e}]")
            
            print("\n📋 其他能力:")
            for attr in ['ir_enabled', 'pir_enabled', 'push_enabled']:
                try:
                    val = getattr(host, attr)
                    if callable(val):
                        print(f"  {attr}: {val(0)}")
                    else:
                        print(f"  {attr}: {val}")
                except:
                    pass
        
        # =====================================================================
        # 灯光控制
        # =====================================================================
        elif command == "light_on":
            print("[TEST] 开灯...")
            await host.set_whiteled(0, state=True)
            print("[TEST] ✅ 灯已开")
        
        elif command == "light_off":
            print("[TEST] 关灯...")
            await host.set_whiteled(0, state=False)
            print("[TEST] ✅ 灯已关")
        
        # =====================================================================
        # 警报控制
        # =====================================================================
        elif command == "siren_on":
            print("[TEST] ⚠️ 开警报 (默认duration)...")
            await host.set_siren(0, True)
            print("[TEST] ✅ 警报已触发")
        
        elif command == "siren_3s":
            print("[TEST] ⚠️ 开警报 (duration=3)...")
            await host.set_siren(0, True, duration=3)
            print("[TEST] ✅ 警报已触发，持续3秒")
        
        elif command == "siren_5s":
            print("[TEST] ⚠️ 开警报 (duration=5)...")
            await host.set_siren(0, True, duration=5)
            print("[TEST] ✅ 警报已触发，持续5秒")
        
        elif command == "siren_off":
            print("[TEST] 关警报...")
            await host.set_siren(0, False)
            print("[TEST] ✅ 警报已关")
        
        # =====================================================================
        # 闪灯测试
        # =====================================================================
        elif command == "flash_1hz":
            print("[TEST] 1Hz 闪灯测试 (10秒)...")
            print("[TEST] 每秒切换一次")
            for i in range(10):
                state = i % 2 == 0
                t1 = time.time()
                await host.set_whiteled(0, state=state)
                t2 = time.time()
                print(f"  [{i+1}/10] {'ON ' if state else 'OFF'} (API耗时: {(t2-t1)*1000:.0f}ms)")
                await asyncio.sleep(1.0 - (t2 - t1))  # 补偿API耗时
            await host.set_whiteled(0, state=False)
            print("[TEST] ✅ 完成")
        
        elif command == "flash_2s":
            print("[TEST] 2秒间隔闪灯测试 (10秒)...")
            for i in range(5):
                t1 = time.time()
                await host.set_whiteled(0, state=True)
                t2 = time.time()
                print(f"  [{i+1}/5] ON  (API耗时: {(t2-t1)*1000:.0f}ms)")
                await asyncio.sleep(2.0)
                t1 = time.time()
                await host.set_whiteled(0, state=False)
                t2 = time.time()
                print(f"  [{i+1}/5] OFF (API耗时: {(t2-t1)*1000:.0f}ms)")
            print("[TEST] ✅ 完成")
        
        elif command == "flash_slow":
            print("[TEST] 慢闪测试 (3秒间隔，15秒)...")
            for i in range(5):
                state = i % 2 == 0
                t1 = time.time()
                await host.set_whiteled(0, state=state)
                t2 = time.time()
                print(f"  [{i+1}/5] {'ON ' if state else 'OFF'} (API耗时: {(t2-t1)*1000:.0f}ms)")
                await asyncio.sleep(3.0)
            await host.set_whiteled(0, state=False)
            print("[TEST] ✅ 完成")
        
        # =====================================================================
        # 威慑模式测试
        # =====================================================================
        elif command == "deterrent_l1":
            print("[TEST] L1 威慑测试 (30秒)")
            print("[TEST] 配置: 常亮灯 + 每30秒警报一次")
            print()
            
            # 开灯常亮
            await host.set_whiteled(0, state=True)
            print("[L1] 💡 灯已开（常亮）")
            
            # 触发一次警报
            print("[L1] 🔔 警报 #1")
            await host.set_siren(0, True, duration=1)
            
            # 等待30秒
            for i in range(30):
                print(f"\r[L1] 等待下一次警报... {30-i}s  ", end="", flush=True)
                await asyncio.sleep(1)
            
            print()
            print("[L1] 🔔 警报 #2")
            await host.set_siren(0, True, duration=1)
            
            await asyncio.sleep(2)
            await host.set_whiteled(0, state=False)
            print("[TEST] ✅ L1 测试完成")
        
        elif command == "deterrent_l2":
            print("[TEST] L2 威慑测试 (20秒)")
            print("[TEST] 配置: 5秒快闪 + 每10秒警报一次")
            print()
            
            start = time.time()
            flash_count = 0
            siren_count = 0
            
            while time.time() - start < 20:
                elapsed = time.time() - start
                cycle_pos = elapsed % 10  # 10秒一个周期
                
                # 前5秒闪灯
                if cycle_pos < 5:
                    state = int(cycle_pos * 2) % 2 == 0  # 0.5秒切换
                    await host.set_whiteled(0, state=state)
                    flash_count += 1
                elif cycle_pos < 6:
                    await host.set_whiteled(0, state=False)
                
                # 每10秒警报
                if int(elapsed) % 10 == 0 and int(elapsed) != siren_count * 10:
                    siren_count += 1
                    print(f"\n[L2] 🔔 警报 #{siren_count}")
                    await host.set_siren(0, True, duration=2)
                
                print(f"\r[L2] {elapsed:.1f}s 闪灯:{flash_count} 警报:{siren_count}  ", end="", flush=True)
                await asyncio.sleep(0.5)
            
            await host.set_whiteled(0, state=False)
            print()
            print("[TEST] ✅ L2 测试完成")
        
        elif command == "deterrent_triggered":
            print("[TEST] TRIGGERED 威慑测试 (15秒)")
            print("[TEST] 配置: 持续闪灯(2秒间隔) + 每3秒警报")
            print()
            print("⚠️  警告: 会有多次警报声!")
            await asyncio.sleep(2)
            
            start = time.time()
            flash_state = False
            last_siren = -999
            
            while time.time() - start < 15:
                elapsed = time.time() - start
                
                # 2秒间隔闪灯（降低API调用频率）
                if int(elapsed) % 2 == 0 and int(elapsed) != int(elapsed - 0.1):
                    flash_state = not flash_state
                    t1 = time.time()
                    await host.set_whiteled(0, state=flash_state)
                    t2 = time.time()
                    print(f"[TRIGGERED] 💡 {'ON ' if flash_state else 'OFF'} (API: {(t2-t1)*1000:.0f}ms)")
                
                # 每3秒警报
                if int(elapsed) % 3 == 0 and int(elapsed) != last_siren:
                    last_siren = int(elapsed)
                    print(f"[TRIGGERED] 🔔 警报 @ {int(elapsed)}s")
                    await host.set_siren(0, True, duration=3)
                
                await asyncio.sleep(0.5)
            
            await host.set_whiteled(0, state=False)
            print("[TEST] ✅ TRIGGERED 测试完成")
        
        # =====================================================================
        # 停止
        # =====================================================================
        elif command == "stop":
            print("[TEST] 停止所有...")
            await host.set_whiteled(0, state=False)
            await host.set_siren(0, False)
            print("[TEST] ✅ 已停止")
        
        else:
            print(f"[ERROR] 未知命令: {command}")
            print(__doc__)
    
    except Exception as e:
        print(f"[ERROR] 失败: {e}")
        import traceback
        traceback.print_exc()
    
    finally:
        try:
            await host.logout()
        except:
            pass


if __name__ == "__main__":
    asyncio.run(main())
