#!/usr/bin/env python3
"""
Camera 端到端硬件验证脚本

基于已工作的 realtime_detection.py，整合 v2.2 SignalEnvelope 和 CoordinatorV2

使用方式：
    python tests/hardware/test_camera_e2e.py
    python tests/hardware/test_camera_e2e.py --simulate  # 模拟模式
"""

import cv2
import time
import os
import sys
import argparse
from datetime import datetime
from typing import Optional

# 添加项目路径 (自动检测)
script_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.dirname(os.path.dirname(script_dir))
sys.path.insert(0, os.path.join(project_root, 'src'))

from ng_edge.core.signal import SignalEnvelope, CameraRole
from ng_edge.state.coordinator_v2 import SecurityCoordinatorV2, ProcessResult
from ng_edge.state.states import ThreatState
from ng_edge.services.state_machine_v5 import HouseMode, UserMode

from ng_edge.hardware.reolink_ultrawide import (
    ReolinkUltrawideClient,
    CameraConfig,
    StreamType,
)
from ng_edge.hardware.yolo_detector import YOLODetector


class CameraE2ETest:
    """
    Camera E2E 测试
    
    整合:
    - ReolinkUltrawideClient (RTSP 流)
    - YOLODetector (目标检测)
    - SignalEnvelope (v2.2 信号格式)
    - SecurityCoordinatorV2 (状态机)
    """
    
    # 摄像头配置
    CAMERAS = {
        "cam_back": {
            "name": "Back Door Camera",
            "ip": "10.0.0.155",
            "username": "admin",
            "password": "Zafac05@a",
            "entrypoint_id": "ep_back",
            "entrypoint_name": "Back Door",
        },
        "cam_front": {
            "name": "Front Door Camera",
            "ip": "10.0.0.122",
            "username": "admin",
            "password": "Zafac05@a",
            "entrypoint_id": "ep_front",
            "entrypoint_name": "Front Door",
        },
    }
    
    def __init__(
        self,
        camera_ids: list = None,  # None = 所有摄像头
        target_fps: float = 5.0,
        yolo_conf: float = 0.5,
        display: bool = True,
    ):
        # 选择摄像头
        if camera_ids is None:
            camera_ids = list(self.CAMERAS.keys())
        self.camera_ids = camera_ids
        
        self.target_fps = target_fps
        self.display = display
        self.frame_interval = 1.0 / target_fps
        
        # v2.2 协调器
        self.coordinator = SecurityCoordinatorV2(
            house_mode=HouseMode.AWAY,
            user_mode=UserMode.QUIET,
            entry_delay_sec=30,
        )
        
        # 注册入口点和 Judge
        for cam_id in self.camera_ids:
            cfg = self.CAMERAS[cam_id]
            self.coordinator.register_entry_point(cfg["entrypoint_id"], cfg["entrypoint_name"])
            self.coordinator.register_judge(cam_id, cfg["entrypoint_id"])
        
        self.coordinator.on_transition = self._on_state_change
        
        # 每个摄像头的状态
        self.cameras = {}  # cam_id -> ReolinkUltrawideClient
        self.last_detection_time = {}  # cam_id -> float
        self.last_signal_time = {}  # cam_id -> float
        self.signal_cooldown = 5.0
        
        # 创建 YOLO 检测器（共享）
        print("[YOLO] 加载模型...")
        self.detector = YOLODetector(
            model_name="yolo11n.pt",
            conf_threshold=yolo_conf,
            target_classes=["person"],
            device="cpu",
        )
        
        # 统计
        self.stats = {
            "total_frames": 0,
            "detection_frames": 0,
            "persons_detected": 0,
            "signals_sent": 0,
            "state_changes": 0,
        }
        self.start_time = None
    
    def start(self, duration_sec: Optional[int] = None):
        """开始测试"""
        # 连接所有摄像头
        for cam_id in self.camera_ids:
            cfg = self.CAMERAS[cam_id]
            
            camera_config = CameraConfig(
                name=cfg["name"],
                ip=cfg["ip"],
                username=cfg["username"],
                password=cfg["password"],
                stream_type=StreamType.SUB,
                use_tcp=True,
            )
            
            print(f"[{cam_id}] 连接 {cfg['ip']}...")
            camera = ReolinkUltrawideClient(camera_config)
            
            if not camera.connect():
                print(f"[{cam_id}] ❌ 无法连接")
                continue
            
            print(f"[{cam_id}] ✅ 已连接 ({camera.actual_width}x{camera.actual_height})")
            self.cameras[cam_id] = camera
            self.last_detection_time[cam_id] = 0
            self.last_signal_time[cam_id] = 0
        
        if not self.cameras:
            print("❌ 没有可用的摄像头")
            return False
        
        self.start_time = time.time()
        
        print("\n" + "=" * 70)
        print("🎥 Camera E2E 硬件验证测试 (多摄像头)")
        print("=" * 70)
        print(f"活动摄像头: {list(self.cameras.keys())}")
        print(f"检测 FPS: {self.target_fps}")
        print(f"YOLO 阈值: {self.detector.conf_threshold}")
        print(f"协调器模式: {self.coordinator.house_mode.value}")
        print("-" * 70)
        print("在摄像头前走动测试 person_detected")
        if self.display:
            print("按 'q' 退出")
        else:
            print("按 Ctrl+C 退出")
        print("=" * 70 + "\n")
        
        try:
            while True:
                # 检查运行时长
                if duration_sec and (time.time() - self.start_time) > duration_sec:
                    print(f"\n达到运行时长 {duration_sec}s，停止")
                    break
                
                # 处理每个摄像头
                for cam_id, camera in self.cameras.items():
                    self._process_camera_frame(cam_id, camera)
                
                # 显示
                if self.display:
                    key = cv2.waitKey(1) & 0xFF
                    if key == ord('q'):
                        print("\n用户退出")
                        break
            
            return True
        
        except KeyboardInterrupt:
            print("\n用户中断")
            return True
        
        finally:
            self._cleanup()
    
    def _process_camera_frame(self, cam_id: str, camera):
        """处理单个摄像头的一帧"""
        ret, frame = camera.read_frame()
        if not ret or frame is None:
            return
        
        self.stats["total_frames"] += 1
        
        # 帧采样
        current_time = time.time()
        time_since_last = current_time - self.last_detection_time.get(cam_id, 0)
        
        if time_since_last >= self.frame_interval:
            # 运行检测
            detections, vis_frame = self.detector.detect(frame, visualize=True)
            
            self.stats["detection_frames"] += 1
            self.last_detection_time[cam_id] = current_time
            
            # 处理人员检测
            for det in detections:
                if det.class_name == "person":
                    self.stats["persons_detected"] += 1
                    self._process_person_detection(cam_id, det, current_time)
            
            display_frame = vis_frame if vis_frame is not None else frame
        else:
            display_frame = frame
        
        # 显示
        if self.display:
            display_frame = self._draw_status(display_frame, cam_id)
            cv2.imshow(f"Camera: {cam_id}", display_frame)
    
    def _process_person_detection(self, cam_id: str, det, current_time: float):
        """处理人员检测，发送到协调器"""
        # 冷却检查
        if current_time - self.last_signal_time.get(cam_id, 0) < self.signal_cooldown:
            return
        
        self.last_signal_time[cam_id] = current_time
        
        cfg = self.CAMERAS[cam_id]
        
        # 创建 SignalEnvelope
        envelope = SignalEnvelope.from_camera(
            device_id=cam_id,
            signal_kind="person_detected",
            zone_id="exterior",  # 摄像头是外部区域
            entrypoint_id=cfg["entrypoint_id"],
            camera_role=CameraRole.JUDGE,
            confidence=det.confidence,
            bbox=det.bbox,
            class_name=det.class_name,
        )
        
        ts = datetime.now().strftime("%H:%M:%S.%f")[:-3]
        print(f"\n[{ts}] [{cam_id}] 🚶 PERSON DETECTED: conf={det.confidence:.2f}")
        print(f"[{ts}] ENVELOPE: kind={envelope.signal_kind}, ep={cfg['entrypoint_id']}, hardness={envelope.hardness.value}")
        
        # 发送到协调器
        result = self.coordinator.process_envelope(envelope)
        self.stats["signals_sent"] += 1
        
        status = "✓" if result.success else "✗"
        changed = "CHANGED" if result.threat_changed else "unchanged"
        print(f"[{ts}] RESULT {status}: threat={result.threat_state.value}, workflow={result.workflow_state.value}, {changed}")
    
    def _on_state_change(self, result: ProcessResult):
        """状态变化回调"""
        self.stats["state_changes"] += 1
        
        print("\n" + "!" * 60)
        print(f"🔔 [STATE CHANGE] {result.from_threat} → {result.to_threat}")
        print(f"   Entry Point: {result.entry_point_id}")
        print(f"   Incident: {result.incident_id}")
        print(f"   Reason: {result.reason_code}")
        print("!" * 60 + "\n")
    
    def _draw_status(self, frame, cam_id: str):
        """绘制状态信息"""
        frame = frame.copy()
        
        cfg = self.CAMERAS[cam_id]
        threat_state = self.coordinator.get_threat_state(cfg["entrypoint_id"])
        
        # 背景
        overlay = frame.copy()
        cv2.rectangle(overlay, (10, 10), (400, 140), (0, 0, 0), -1)
        cv2.addWeighted(overlay, 0.6, frame, 0.4, 0, frame)
        
        # 文字
        y = 30
        font = cv2.FONT_HERSHEY_SIMPLEX
        
        # 摄像头名称
        cv2.putText(frame, f"{cfg['name']}", (20, y), font, 0.6, (255, 255, 255), 2)
        y += 25
        
        # 威胁状态
        state_colors = {
            ThreatState.NONE: (0, 255, 0),
            ThreatState.PRE_L1: (0, 255, 255),
            ThreatState.PRE_L2: (0, 165, 255),
            ThreatState.PRE_L3: (0, 100, 255),
            ThreatState.PENDING: (0, 0, 255),
            ThreatState.TRIGGERED: (0, 0, 255),
        }
        color = state_colors.get(threat_state, (255, 255, 255))
        
        cv2.putText(frame, f"Threat: {threat_state.value}", (20, y), font, 0.6, color, 2)
        y += 25
        
        cv2.putText(frame, f"Persons: {self.stats['persons_detected']}", (20, y), font, 0.5, (0, 255, 0), 1)
        y += 20
        
        cv2.putText(frame, f"Signals: {self.stats['signals_sent']}", (20, y), font, 0.5, (0, 255, 0), 1)
        y += 20
        
        cv2.putText(frame, f"State Changes: {self.stats['state_changes']}", (20, y), font, 0.5, (0, 255, 0), 1)
        
        return frame
    
    def _cleanup(self):
        """清理资源"""
        print("\n清理资源...")
        
        for cam_id, camera in self.cameras.items():
            camera.disconnect()
        
        if self.display:
            cv2.destroyAllWindows()
        
        # 打印统计
        print("\n" + "=" * 70)
        print("📊 测试统计")
        print("=" * 70)
        print(f"总帧数: {self.stats['total_frames']}")
        print(f"检测帧数: {self.stats['detection_frames']}")
        print(f"人员检测: {self.stats['persons_detected']}")
        print(f"信号发送: {self.stats['signals_sent']}")
        print(f"状态变化: {self.stats['state_changes']}")
        print("=" * 70)


class SimulatedCameraTest:
    """模拟摄像头测试（不需要真实硬件）"""
    
    def __init__(self):
        self.coordinator = SecurityCoordinatorV2(
            house_mode=HouseMode.AWAY,
            user_mode=UserMode.QUIET,
        )
        self.coordinator.register_entry_point("ep_back", "Back Door")
        self.coordinator.register_judge("cam_back", "ep_back")
        self.coordinator.on_transition = self._on_transition
    
    def start(self, duration_sec=None):
        """运行模拟测试"""
        print("=" * 60)
        print("Camera 模拟测试 (无需真实硬件)")
        print("=" * 60)
        print()
        
        # 模拟检测序列
        test_cases = [
            {"class": "person", "confidence": 0.85, "desc": "高置信度人员检测 (→PRE_L2)"},
            {"class": "person", "confidence": 0.65, "desc": "中置信度人员检测 (→PRE_L1)"},
            {"class": "person", "confidence": 0.45, "desc": "低置信度 (低于阈值，忽略)"},
        ]
        
        for i, tc in enumerate(test_cases):
            print(f"\n--- 测试 {i+1}: {tc['desc']} ---")
            
            envelope = SignalEnvelope.from_camera(
                device_id="cam_back",
                signal_kind="person_detected",
                zone_id="entry_exit",
                entrypoint_id="ep_back",
                camera_role=CameraRole.JUDGE,
                confidence=tc["confidence"],
            )
            
            print(f"SignalEnvelope: confidence={envelope.confidence}, "
                  f"hardness={envelope.hardness.value}, "
                  f"level={envelope.level}")
            
            result = self.coordinator.process_envelope(envelope)
            
            print(f"Result: threat={result.threat_state.value}, "
                  f"changed={result.threat_changed}")
            
            time.sleep(1)
        
        print("\n" + "=" * 60)
        print("模拟测试完成")
        return True
    
    def _on_transition(self, result: ProcessResult):
        print(f"\n🔔 STATE CHANGE: {result.from_threat} → {result.to_threat}")


def main():
    parser = argparse.ArgumentParser(description="Camera E2E 硬件验证")
    parser.add_argument("--simulate", action="store_true", help="模拟模式")
    parser.add_argument("--cameras", nargs="+", default=None, 
                        choices=["cam_back", "cam_front"],
                        help="指定摄像头 (默认全部)")
    parser.add_argument("--fps", type=float, default=5.0, help="检测 FPS")
    parser.add_argument("--conf", type=float, default=0.5, help="YOLO 置信度")
    parser.add_argument("--duration", type=int, default=None, help="运行时长（秒）")
    parser.add_argument("--no-display", action="store_true", help="不显示窗口")
    
    args = parser.parse_args()
    
    if args.simulate:
        test = SimulatedCameraTest()
    else:
        test = CameraE2ETest(
            camera_ids=args.cameras,
            target_fps=args.fps,
            yolo_conf=args.conf,
            display=not args.no_display,
        )
    
    test.start(duration_sec=args.duration)


if __name__ == "__main__":
    main()
