#!/usr/bin/env python3
"""
简单灯光测试 - 验证基本控制能力

用法:
    python3 test_light_simple.py <ip> <user> <password> <command>

命令:
    on       - 开灯
    off      - 关灯
    flash5   - 5秒闪一次，持续30秒
    flash10  - 10秒闪一次，持续60秒
"""

import asyncio
import sys
import time

async def main():
    if len(sys.argv) < 5:
        print(__doc__)
        sys.exit(1)
    
    ip, user, password, cmd = sys.argv[1:5]
    
    # 连接
    from reolink_aio.api import Host
    host = Host(ip, user, password)
    await host.get_host_data()
    print(f"✅ 已连接 {ip}")
    
    if cmd == "on":
        print("💡 开灯...")
        t1 = time.time()
        await host.set_whiteled(0, state=True)
        t2 = time.time()
        print(f"✅ 灯已开 (耗时 {t2-t1:.2f}s)")
    
    elif cmd == "off":
        print("💡 关灯...")
        t1 = time.time()
        await host.set_whiteled(0, state=False)
        t2 = time.time()
        print(f"✅ 灯已关 (耗时 {t2-t1:.2f}s)")
    
    elif cmd == "flash5":
        print("💡 5秒闪灯测试 (30秒)...")
        light_on = False
        for i in range(6):
            light_on = not light_on
            t1 = time.time()
            await host.set_whiteled(0, state=light_on)
            t2 = time.time()
            print(f"  {'ON' if light_on else 'OFF'} (耗时 {t2-t1:.2f}s)")
            if i < 5:
                await asyncio.sleep(5)
        print("✅ 完成")
    
    elif cmd == "flash10":
        print("💡 10秒闪灯测试 (60秒)...")
        light_on = False
        for i in range(6):
            light_on = not light_on
            t1 = time.time()
            await host.set_whiteled(0, state=light_on)
            t2 = time.time()
            print(f"  {'ON' if light_on else 'OFF'} (耗时 {t2-t1:.2f}s)")
            if i < 5:
                await asyncio.sleep(10)
        print("✅ 完成")
    
    elif cmd == "steady":
        print("💡 常亮测试 (60秒)...")
        await host.set_whiteled(0, state=True)
        print("✅ 灯已开，等待60秒...")
        await asyncio.sleep(60)
        await host.set_whiteled(0, state=False)
        print("✅ 完成")
    
    else:
        print(f"未知命令: {cmd}")
    
    await host.logout()

if __name__ == "__main__":
    asyncio.run(main())
