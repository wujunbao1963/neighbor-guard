"""
Tests for Judge Availability Tracker
"""

import pytest
from datetime import datetime, timezone, timedelta
from unittest.mock import Mock

from ng_edge.state.states import JudgeAvailabilityState
from ng_edge.state.judge_tracker import (
    JudgeAvailabilityTracker,
    JudgeConfig,
    JudgeStatus,
)


class TestJudgeAvailabilityTracker:
    """JudgeAvailabilityTracker 测试"""
    
    def test_register_judge(self):
        """测试注册 Judge"""
        tracker = JudgeAvailabilityTracker()
        tracker.register_judge("cam_front", "ep_front")
        
        assert tracker.is_available("cam_front")
        assert tracker.get_entrypoint("cam_front") == "ep_front"
    
    def test_unknown_judge_not_available(self):
        """测试未注册的 Judge 不可用"""
        tracker = JudgeAvailabilityTracker()
        
        assert not tracker.is_available("unknown")
        assert tracker.get_state("unknown") is None
    
    def test_record_heartbeat(self):
        """测试记录心跳"""
        tracker = JudgeAvailabilityTracker()
        tracker.register_judge("cam_front")
        
        tracker.record_heartbeat("cam_front")
        
        status = tracker.get_status("cam_front")
        assert status.last_heartbeat is not None
        assert status.consecutive_failures == 0
    
    def test_degrade_on_failures(self):
        """测试连续失败后降级"""
        tracker = JudgeAvailabilityTracker()
        tracker.register_judge("cam_front")
        
        # 连续3次失败
        tracker.record_failure("cam_front")
        assert tracker.is_available("cam_front")
        
        tracker.record_failure("cam_front")
        assert tracker.is_available("cam_front")
        
        tracker.record_failure("cam_front")
        assert not tracker.is_available("cam_front")
        
        assert tracker.get_state("cam_front") == JudgeAvailabilityState.DEGRADED
    
    def test_recover_on_heartbeat(self):
        """测试心跳后恢复"""
        tracker = JudgeAvailabilityTracker()
        tracker.register_judge("cam_front")
        
        # 先降级
        for _ in range(3):
            tracker.record_failure("cam_front")
        assert not tracker.is_available("cam_front")
        
        # 收到心跳后恢复
        tracker.record_heartbeat("cam_front")
        assert tracker.is_available("cam_front")
    
    def test_timeout_check(self):
        """测试超时检查"""
        config = JudgeConfig(offline_threshold_sec=60)
        tracker = JudgeAvailabilityTracker(config)
        tracker.register_judge("cam_front")
        
        # 设置旧的心跳时间
        status = tracker.get_status("cam_front")
        status.last_heartbeat = datetime.now(timezone.utc) - timedelta(seconds=120)
        
        # 检查超时
        changed = tracker.check_timeouts()
        
        assert "cam_front" in changed
        assert not tracker.is_available("cam_front")
    
    def test_callback_on_degrade(self):
        """测试降级回调"""
        tracker = JudgeAvailabilityTracker()
        tracker.register_judge("cam_front")
        
        callback_args = []
        tracker.on_state_change = lambda *args: callback_args.append(args)
        
        # 触发降级
        for _ in range(3):
            tracker.record_failure("cam_front")
        
        assert len(callback_args) == 1
        camera_id, old_state, new_state = callback_args[0]
        assert camera_id == "cam_front"
        assert old_state == JudgeAvailabilityState.AVAILABLE
        assert new_state == JudgeAvailabilityState.DEGRADED
    
    def test_callback_on_recover(self):
        """测试恢复回调"""
        tracker = JudgeAvailabilityTracker()
        tracker.register_judge("cam_front")
        
        # 先降级
        for _ in range(3):
            tracker.record_failure("cam_front")
        
        callback_args = []
        tracker.on_state_change = lambda *args: callback_args.append(args)
        
        # 恢复
        tracker.record_heartbeat("cam_front")
        
        assert len(callback_args) == 1
        camera_id, old_state, new_state = callback_args[0]
        assert old_state == JudgeAvailabilityState.DEGRADED
        assert new_state == JudgeAvailabilityState.AVAILABLE
    
    def test_is_any_available(self):
        """测试是否有任何 Judge 可用"""
        tracker = JudgeAvailabilityTracker()
        tracker.register_judge("cam1")
        tracker.register_judge("cam2")
        
        assert tracker.is_any_available()
        
        # 降级 cam1
        for _ in range(3):
            tracker.record_failure("cam1")
        
        assert tracker.is_any_available()  # cam2 还可用
        
        # 降级 cam2
        for _ in range(3):
            tracker.record_failure("cam2")
        
        assert not tracker.is_any_available()
    
    def test_stats(self):
        """测试统计信息"""
        tracker = JudgeAvailabilityTracker()
        tracker.register_judge("cam1")
        tracker.register_judge("cam2")
        
        tracker.record_heartbeat("cam1")
        tracker.record_heartbeat("cam2")
        
        # 降级 cam1
        for _ in range(3):
            tracker.record_failure("cam1")
        
        stats = tracker.get_stats()
        assert stats["heartbeats_received"] == 2
        assert stats["total_judges"] == 2
        assert stats["available_judges"] == 1
        assert stats["degraded_judges"] == 1
        assert stats["degraded_events"] == 1


class TestJudgeConfig:
    """JudgeConfig 测试"""
    
    def test_default_config(self):
        """测试默认配置"""
        config = JudgeConfig()
        
        assert config.offline_threshold_sec == 90
        assert config.heartbeat_interval_sec == 30
    
    def test_custom_config(self):
        """测试自定义配置"""
        config = JudgeConfig(
            offline_threshold_sec=120,
            heartbeat_interval_sec=60,
        )
        
        assert config.offline_threshold_sec == 120
        assert config.heartbeat_interval_sec == 60
