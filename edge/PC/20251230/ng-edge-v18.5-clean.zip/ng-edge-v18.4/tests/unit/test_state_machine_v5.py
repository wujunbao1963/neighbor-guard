"""
Tests for State Machine v5 (SecurityCoordinator)

测试核心状态机逻辑，确保在重构前行为正确
"""

import pytest
from datetime import datetime, timezone
from unittest.mock import Mock, MagicMock

from ng_edge.services.state_machine_v5 import (
    SecurityCoordinator,
    EntryPointStateMachine,
    Signal,
    SignalType,
    ZoneType,
    HouseMode,
    UserMode,
    AlarmState,
    TransitionResult,
)


# =============================================================================
# Fixtures
# =============================================================================

@pytest.fixture
def coordinator_disarmed():
    """DISARMED 模式的协调器"""
    return SecurityCoordinator(
        house_mode=HouseMode.DISARMED,
        user_mode=UserMode.QUIET,
        entry_delay_sec=30,
    )


@pytest.fixture
def coordinator_away():
    """AWAY 模式的协调器"""
    return SecurityCoordinator(
        house_mode=HouseMode.AWAY,
        user_mode=UserMode.QUIET,
        entry_delay_sec=30,
    )


@pytest.fixture
def coordinator_home():
    """HOME 模式的协调器"""
    return SecurityCoordinator(
        house_mode=HouseMode.HOME,
        user_mode=UserMode.QUIET,
        entry_delay_sec=30,
    )


@pytest.fixture
def coordinator_night_occupied():
    """NIGHT_OCCUPIED 模式的协调器"""
    return SecurityCoordinator(
        house_mode=HouseMode.NIGHT_OCCUPIED,
        user_mode=UserMode.QUIET,
        entry_delay_sec=30,
    )


@pytest.fixture
def coordinator_night_perimeter():
    """NIGHT_PERIMETER 模式的协调器"""
    return SecurityCoordinator(
        house_mode=HouseMode.NIGHT_PERIMETER,
        user_mode=UserMode.QUIET,
        entry_delay_sec=30,
    )


def make_signal(
    entry_point_id: str = "ep_back_door",
    zone_type: ZoneType = ZoneType.ENTRY_EXIT,
    signal_type: SignalType = SignalType.DOOR_OPEN,
    from_inside: bool = False,
) -> Signal:
    """创建测试信号"""
    return Signal(
        entry_point_id=entry_point_id,
        zone_type=zone_type,
        signal_type=signal_type,
        from_inside=from_inside,
    )


# =============================================================================
# Basic Tests
# =============================================================================

class TestSecurityCoordinatorBasic:
    """SecurityCoordinator 基础测试"""
    
    def test_create_coordinator(self, coordinator_away):
        """测试创建协调器"""
        assert coordinator_away.house_mode == HouseMode.AWAY
        assert coordinator_away.user_mode == UserMode.QUIET
        assert "_global" in coordinator_away._entry_points
    
    def test_register_entry_point(self, coordinator_away):
        """测试注册入口点"""
        ep = coordinator_away.register_entry_point("ep_back_door", "Back Door")
        
        assert ep is not None
        assert ep.entry_point_id == "ep_back_door"
        assert ep.entry_point_name == "Back Door"
        assert coordinator_away.get_entry_point("ep_back_door") == ep
    
    def test_set_modes(self, coordinator_disarmed):
        """测试设置模式"""
        coordinator_disarmed.register_entry_point("ep_test", "Test")
        
        coordinator_disarmed.set_modes(HouseMode.AWAY, UserMode.ALERT)
        
        assert coordinator_disarmed.house_mode == HouseMode.AWAY
        assert coordinator_disarmed.user_mode == UserMode.ALERT
        
        ep = coordinator_disarmed.get_entry_point("ep_test")
        assert ep._house_mode == HouseMode.AWAY
        assert ep._user_mode == UserMode.ALERT


# =============================================================================
# DISARMED Mode Tests
# =============================================================================

class TestDisarmedMode:
    """DISARMED 模式测试 - 所有信号应被忽略"""
    
    def test_door_open_ignored(self, coordinator_disarmed):
        """DISARMED: door_open 应被忽略"""
        signal = make_signal(signal_type=SignalType.DOOR_OPEN)
        result = coordinator_disarmed.process(signal)
        
        assert result.to_state == AlarmState.QUIET
        assert "DISARMED" in result.reason or "ignored" in result.reason.lower()
    
    def test_motion_ignored(self, coordinator_disarmed):
        """DISARMED: motion 应被忽略"""
        signal = make_signal(
            zone_type=ZoneType.INTERIOR,
            signal_type=SignalType.MOTION_ACTIVE
        )
        result = coordinator_disarmed.process(signal)
        
        assert result.to_state == AlarmState.QUIET
    
    def test_glass_break_ignored(self, coordinator_disarmed):
        """DISARMED: glass_break 应被忽略"""
        signal = make_signal(signal_type=SignalType.GLASS_BREAK)
        result = coordinator_disarmed.process(signal)
        
        assert result.to_state == AlarmState.QUIET


# =============================================================================
# AWAY Mode Tests
# =============================================================================

class TestAwayMode:
    """AWAY 模式测试"""
    
    def test_door_open_entry_exit_triggers_pending(self, coordinator_away):
        """AWAY: entry_exit zone door_open → PENDING"""
        signal = make_signal(
            zone_type=ZoneType.ENTRY_EXIT,
            signal_type=SignalType.DOOR_OPEN,
            from_inside=False,
        )
        result = coordinator_away.process(signal)
        
        assert result.to_state == AlarmState.PENDING
        assert result.success
    
    def test_door_open_interior_triggers_pending(self, coordinator_away):
        """AWAY: interior zone door_open → PENDING (实际行为)"""
        signal = make_signal(
            zone_type=ZoneType.INTERIOR,
            signal_type=SignalType.DOOR_OPEN,
        )
        result = coordinator_away.process(signal)
        
        # 注：v5 实现中 interior door_open 进入 PENDING，不是直接 TRIGGERED
        assert result.to_state == AlarmState.PENDING
    
    def test_motion_interior_triggers_triggered(self, coordinator_away):
        """AWAY: interior motion → TRIGGERED"""
        signal = make_signal(
            zone_type=ZoneType.INTERIOR,
            signal_type=SignalType.MOTION_ACTIVE,
        )
        result = coordinator_away.process(signal)
        
        assert result.to_state == AlarmState.TRIGGERED
    
    def test_glass_break_triggers_triggered(self, coordinator_away):
        """AWAY: glass_break → TRIGGERED"""
        signal = make_signal(signal_type=SignalType.GLASS_BREAK)
        result = coordinator_away.process(signal)
        
        assert result.to_state == AlarmState.TRIGGERED
    
    def test_exterior_person_triggers_pre(self, coordinator_away):
        """AWAY: exterior person → PRE"""
        signal = make_signal(
            zone_type=ZoneType.EXTERIOR,
            signal_type=SignalType.PERSON_DETECTED,
        )
        result = coordinator_away.process(signal)
        
        assert result.to_state == AlarmState.PRE


# =============================================================================
# HOME Mode Tests
# =============================================================================

class TestHomeMode:
    """HOME 模式测试"""
    
    def test_door_open_outside_in_stays_quiet_in_quiet_mode(self, coordinator_home):
        """HOME (Quiet): door_open 外→内 → QUIET (Quiet 模式下忽略)"""
        signal = make_signal(
            zone_type=ZoneType.ENTRY_EXIT,
            signal_type=SignalType.DOOR_OPEN,
            from_inside=False,
        )
        result = coordinator_home.process(signal)
        
        # Quiet HOME 模式：外→内 = QUIET (实际行为)
        assert result.to_state == AlarmState.QUIET
    
    def test_door_open_inside_out_stays_quiet(self, coordinator_home):
        """HOME (Quiet): door_open 内→外 → QUIET"""
        signal = make_signal(
            zone_type=ZoneType.ENTRY_EXIT,
            signal_type=SignalType.DOOR_OPEN,
            from_inside=True,
        )
        result = coordinator_home.process(signal)
        
        # Quiet HOME 模式：内→外 = QUIET
        assert result.to_state == AlarmState.QUIET
    
    def test_interior_motion_ignored(self, coordinator_home):
        """HOME (Quiet): interior motion → QUIET (忽略)"""
        signal = make_signal(
            zone_type=ZoneType.INTERIOR,
            signal_type=SignalType.MOTION_ACTIVE,
        )
        result = coordinator_home.process(signal)
        
        assert result.to_state == AlarmState.QUIET
    
    def test_glass_break_triggers_triggered(self, coordinator_home):
        """HOME: glass_break → TRIGGERED"""
        signal = make_signal(signal_type=SignalType.GLASS_BREAK)
        result = coordinator_home.process(signal)
        
        assert result.to_state == AlarmState.TRIGGERED


# =============================================================================
# NIGHT_OCCUPIED Mode Tests
# =============================================================================

class TestNightOccupiedMode:
    """NIGHT_OCCUPIED 模式测试"""
    
    def test_door_open_outside_in_triggers_pending(self, coordinator_night_occupied):
        """NIGHT_OCCUPIED: door_open 外→内 → PENDING"""
        signal = make_signal(
            zone_type=ZoneType.ENTRY_EXIT,
            signal_type=SignalType.DOOR_OPEN,
            from_inside=False,
        )
        result = coordinator_night_occupied.process(signal)
        
        assert result.to_state == AlarmState.PENDING
    
    def test_door_open_inside_out_triggers_pre(self, coordinator_night_occupied):
        """NIGHT_OCCUPIED: door_open 内→外 → PRE"""
        signal = make_signal(
            zone_type=ZoneType.ENTRY_EXIT,
            signal_type=SignalType.DOOR_OPEN,
            from_inside=True,
        )
        result = coordinator_night_occupied.process(signal)
        
        assert result.to_state == AlarmState.PRE
    
    def test_glass_break_triggers_triggered(self, coordinator_night_occupied):
        """NIGHT_OCCUPIED: glass_break → TRIGGERED"""
        signal = make_signal(signal_type=SignalType.GLASS_BREAK)
        result = coordinator_night_occupied.process(signal)
        
        assert result.to_state == AlarmState.TRIGGERED


# =============================================================================
# NIGHT_PERIMETER Mode Tests
# =============================================================================

class TestNightPerimeterMode:
    """NIGHT_PERIMETER 模式测试 - 最敏感"""
    
    def test_door_open_triggers_triggered(self, coordinator_night_perimeter):
        """NIGHT_PERIMETER: door_open → TRIGGERED (无延迟)"""
        signal = make_signal(
            zone_type=ZoneType.ENTRY_EXIT,
            signal_type=SignalType.DOOR_OPEN,
        )
        result = coordinator_night_perimeter.process(signal)
        
        assert result.to_state == AlarmState.TRIGGERED
    
    def test_interior_motion_triggers_triggered(self, coordinator_night_perimeter):
        """NIGHT_PERIMETER: interior motion → TRIGGERED"""
        signal = make_signal(
            zone_type=ZoneType.INTERIOR,
            signal_type=SignalType.MOTION_ACTIVE,
        )
        result = coordinator_night_perimeter.process(signal)
        
        assert result.to_state == AlarmState.TRIGGERED
    
    def test_glass_break_triggers_triggered(self, coordinator_night_perimeter):
        """NIGHT_PERIMETER: glass_break → TRIGGERED"""
        signal = make_signal(signal_type=SignalType.GLASS_BREAK)
        result = coordinator_night_perimeter.process(signal)
        
        assert result.to_state == AlarmState.TRIGGERED


# =============================================================================
# User Actions Tests
# =============================================================================

class TestUserActions:
    """用户操作测试"""
    
    def test_cancel_from_pending(self, coordinator_away):
        """测试从 PENDING 取消"""
        # 先进入 PENDING
        signal = make_signal(
            zone_type=ZoneType.ENTRY_EXIT,
            signal_type=SignalType.DOOR_OPEN,
        )
        coordinator_away.process(signal)
        
        ep = coordinator_away.get_entry_point("ep_back_door")
        assert ep.state == AlarmState.PENDING
        
        # 取消
        result = coordinator_away.cancel("ep_back_door")
        
        assert result.success
        assert result.to_state == AlarmState.QUIET
        assert ep.state == AlarmState.QUIET
    
    def test_cancel_from_pre(self, coordinator_away):
        """测试从 PRE 取消"""
        # 先进入 PRE
        signal = make_signal(
            zone_type=ZoneType.EXTERIOR,
            signal_type=SignalType.PERSON_DETECTED,
        )
        coordinator_away.process(signal)
        
        ep = coordinator_away.get_entry_point("ep_back_door")
        assert ep.state == AlarmState.PRE
        
        # 取消
        result = coordinator_away.cancel("ep_back_door")
        
        assert result.success
        assert result.to_state == AlarmState.QUIET
    
    def test_resolve_from_triggered(self, coordinator_away):
        """测试从 TRIGGERED 解除"""
        # 先进入 TRIGGERED
        signal = make_signal(signal_type=SignalType.GLASS_BREAK)
        coordinator_away.process(signal)
        
        ep = coordinator_away.get_entry_point("ep_back_door")
        assert ep.state == AlarmState.TRIGGERED
        
        # 解除
        result = coordinator_away.resolve("ep_back_door")
        
        assert result.success
        assert result.to_state == AlarmState.QUIET
    
    def test_cannot_cancel_from_quiet(self, coordinator_away):
        """测试不能从 QUIET 取消"""
        coordinator_away.register_entry_point("ep_test", "Test")
        
        result = coordinator_away.cancel("ep_test")
        
        assert not result.success
    
    def test_cannot_resolve_from_pending(self, coordinator_away):
        """测试不能从 PENDING 解除"""
        # 先进入 PENDING
        signal = make_signal(
            zone_type=ZoneType.ENTRY_EXIT,
            signal_type=SignalType.DOOR_OPEN,
        )
        coordinator_away.process(signal)
        
        result = coordinator_away.resolve("ep_back_door")
        
        assert not result.success


# =============================================================================
# Entry Delay Tests
# =============================================================================

class TestEntryDelay:
    """入口延迟测试"""
    
    def test_pending_timeout_triggers(self, coordinator_away):
        """测试 PENDING 超时触发 TRIGGERED"""
        # 进入 PENDING
        signal = make_signal(
            zone_type=ZoneType.ENTRY_EXIT,
            signal_type=SignalType.DOOR_OPEN,
        )
        coordinator_away.process(signal)
        
        ep = coordinator_away.get_entry_point("ep_back_door")
        assert ep.state == AlarmState.PENDING
        
        # 模拟超时
        result = ep.trigger_entry_delay_expired()
        
        assert result.success
        assert result.to_state == AlarmState.TRIGGERED
        assert ep.state == AlarmState.TRIGGERED
    
    def test_timeout_from_non_pending_fails(self, coordinator_away):
        """测试非 PENDING 状态超时失败"""
        coordinator_away.register_entry_point("ep_test", "Test")
        ep = coordinator_away.get_entry_point("ep_test")
        
        result = ep.trigger_entry_delay_expired()
        
        assert not result.success


# =============================================================================
# Multi Entry Point Tests
# =============================================================================

class TestMultiEntryPoint:
    """多入口点测试"""
    
    def test_independent_entry_points(self, coordinator_away):
        """测试入口点独立"""
        coordinator_away.register_entry_point("ep_front", "Front Door")
        coordinator_away.register_entry_point("ep_back", "Back Door")
        
        # Front door 进入 PENDING
        signal_front = make_signal(
            entry_point_id="ep_front",
            zone_type=ZoneType.ENTRY_EXIT,
            signal_type=SignalType.DOOR_OPEN,
        )
        coordinator_away.process(signal_front)
        
        # Back door 应该仍然是 QUIET
        ep_front = coordinator_away.get_entry_point("ep_front")
        ep_back = coordinator_away.get_entry_point("ep_back")
        
        assert ep_front.state == AlarmState.PENDING
        assert ep_back.state == AlarmState.QUIET
    
    def test_multiple_entry_points_states(self, coordinator_away):
        """测试多入口点各自状态"""
        coordinator_away.register_entry_point("ep_front", "Front Door")
        coordinator_away.register_entry_point("ep_back", "Back Door")
        
        # Front door 进入 TRIGGERED
        signal = make_signal(
            entry_point_id="ep_front",
            signal_type=SignalType.GLASS_BREAK,
        )
        coordinator_away.process(signal)
        
        ep_front = coordinator_away.get_entry_point("ep_front")
        ep_back = coordinator_away.get_entry_point("ep_back")
        
        assert ep_front.state == AlarmState.TRIGGERED
        assert ep_back.state == AlarmState.QUIET


# =============================================================================
# Callback Tests
# =============================================================================

class TestCallbacks:
    """回调测试"""
    
    def test_state_change_callback(self, coordinator_away):
        """测试状态变化回调"""
        callback_called = []
        
        def on_change(entry_point_id: str, result: TransitionResult):
            callback_called.append((entry_point_id, result.to_state))
        
        coordinator = SecurityCoordinator(
            house_mode=HouseMode.AWAY,
            user_mode=UserMode.QUIET,
            on_global_state_change=on_change,
        )
        
        signal = make_signal(signal_type=SignalType.GLASS_BREAK)
        coordinator.process(signal)
        
        assert len(callback_called) == 1
        assert callback_called[0][1] == AlarmState.TRIGGERED


# =============================================================================
# Alert Mode Tests (More Sensitive)
# =============================================================================

class TestAlertMode:
    """Alert 模式测试（更敏感）"""
    
    def test_home_alert_door_triggers_pre(self):
        """HOME Alert: door_open → PRE (比 Quiet 模式更敏感)"""
        coordinator = SecurityCoordinator(
            house_mode=HouseMode.HOME,
            user_mode=UserMode.ALERT,
            entry_delay_sec=30,
        )
        
        signal = make_signal(
            zone_type=ZoneType.ENTRY_EXIT,
            signal_type=SignalType.DOOR_OPEN,
            from_inside=False,
        )
        result = coordinator.process(signal)
        
        # Alert HOME 模式：外→内 = PRE (比 ATTENTION 更敏感)
        assert result.to_state == AlarmState.PRE
