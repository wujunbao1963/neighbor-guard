"""
Tests for Context Gate Manager
"""

import pytest
from datetime import datetime, timezone, timedelta

from ng_edge.correlation.context_gate import (
    ContextGateManager,
    ContextGateConfig,
    ContextGateType,
    ContextGate,
    DEFAULT_GATE_TTL,
)


class TestContextGateBasic:
    """基础测试"""
    
    def test_create_manager(self):
        """测试创建管理器"""
        manager = ContextGateManager()
        assert manager.config.yard_confirmed_ttl_sec == 120
        assert manager.config.porch_confirmed_ttl_sec == 60
    
    def test_custom_config(self):
        """测试自定义配置"""
        config = ContextGateConfig(
            yard_confirmed_ttl_sec=180,
            porch_confirmed_ttl_sec=90,
        )
        manager = ContextGateManager(config)
        
        assert manager.config.yard_confirmed_ttl_sec == 180


class TestContextGateActivation:
    """门控激活测试"""
    
    def test_activate_gate(self):
        """测试激活门控"""
        manager = ContextGateManager()
        
        gate = manager.activate(
            gate_type=ContextGateType.YARD_CONFIRMED,
            zone_id="zone_front",
            source_device="cam_front",
        )
        
        assert gate is not None
        assert gate.gate_type == ContextGateType.YARD_CONFIRMED
        assert gate.zone_id == "zone_front"
        assert gate.is_valid()
        assert manager.stats["gates_activated"] == 1
    
    def test_activate_refreshes_existing(self):
        """测试激活刷新现有门控"""
        manager = ContextGateManager()
        
        gate1 = manager.activate(
            gate_type=ContextGateType.YARD_CONFIRMED,
            zone_id="zone_front",
            source_device="cam_front",
        )
        original_expires = gate1.expires_at
        
        # 等待一点时间（模拟）
        gate1.expires_at = datetime.now(timezone.utc) + timedelta(seconds=60)
        
        # 再次激活
        gate2 = manager.activate(
            gate_type=ContextGateType.YARD_CONFIRMED,
            zone_id="zone_front",
            source_device="cam_front",
        )
        
        # 应该是同一个门控，但过期时间被刷新
        assert gate2.gate_id == gate1.gate_id
        assert manager.stats["gates_refreshed"] == 1
    
    def test_activate_different_zones(self):
        """测试不同区域的门控独立"""
        manager = ContextGateManager()
        
        gate1 = manager.activate(
            gate_type=ContextGateType.YARD_CONFIRMED,
            zone_id="zone_front",
            source_device="cam_front",
        )
        
        gate2 = manager.activate(
            gate_type=ContextGateType.YARD_CONFIRMED,
            zone_id="zone_back",
            source_device="cam_back",
        )
        
        assert gate1.gate_id != gate2.gate_id
        assert manager.stats["gates_activated"] == 2


class TestContextGateValidity:
    """门控有效性测试"""
    
    def test_is_active(self):
        """测试门控是否活跃"""
        manager = ContextGateManager()
        
        manager.activate(
            gate_type=ContextGateType.YARD_CONFIRMED,
            zone_id="zone_front",
            source_device="cam_front",
        )
        
        assert manager.is_active(ContextGateType.YARD_CONFIRMED, "zone_front")
        assert not manager.is_active(ContextGateType.YARD_CONFIRMED, "zone_back")
        assert not manager.is_active(ContextGateType.PORCH_CONFIRMED, "zone_front")
    
    def test_gate_expires(self):
        """测试门控过期"""
        manager = ContextGateManager()
        
        gate = manager.activate(
            gate_type=ContextGateType.YARD_CONFIRMED,
            zone_id="zone_front",
            source_device="cam_front",
            ttl_sec=60,
        )
        
        # 模拟时间过去
        future = datetime.now(timezone.utc) + timedelta(seconds=120)
        
        assert not gate.is_valid(future)
        assert not manager.is_active(ContextGateType.YARD_CONFIRMED, "zone_front", future)
    
    def test_remaining_sec(self):
        """测试剩余时间"""
        manager = ContextGateManager()
        
        gate = manager.activate(
            gate_type=ContextGateType.YARD_CONFIRMED,
            zone_id="zone_front",
            source_device="cam_front",
            ttl_sec=120,
        )
        
        remaining = gate.remaining_sec()
        assert 115 < remaining <= 120  # 允许一点误差
    
    def test_get_gate(self):
        """测试获取门控"""
        manager = ContextGateManager()
        
        manager.activate(
            gate_type=ContextGateType.YARD_CONFIRMED,
            zone_id="zone_front",
            source_device="cam_front",
        )
        
        gate = manager.get_gate(ContextGateType.YARD_CONFIRMED, "zone_front")
        assert gate is not None
        
        # 不存在的门控
        no_gate = manager.get_gate(ContextGateType.PORCH_CONFIRMED, "zone_front")
        assert no_gate is None


class TestContextGateCleanup:
    """门控清理测试"""
    
    def test_invalidate(self):
        """测试手动使门控失效"""
        manager = ContextGateManager()
        
        manager.activate(
            gate_type=ContextGateType.YARD_CONFIRMED,
            zone_id="zone_front",
            source_device="cam_front",
        )
        
        assert manager.is_active(ContextGateType.YARD_CONFIRMED, "zone_front")
        
        result = manager.invalidate(ContextGateType.YARD_CONFIRMED, "zone_front")
        
        assert result
        assert not manager.is_active(ContextGateType.YARD_CONFIRMED, "zone_front")
        assert manager.stats["gates_expired"] == 1
    
    def test_cleanup_expired(self):
        """测试清理过期门控"""
        manager = ContextGateManager()
        
        gate = manager.activate(
            gate_type=ContextGateType.YARD_CONFIRMED,
            zone_id="zone_front",
            source_device="cam_front",
            ttl_sec=1,  # 1秒后过期
        )
        
        # 强制设置为过期
        gate.expires_at = datetime.now(timezone.utc) - timedelta(seconds=10)
        
        expired = manager.cleanup_expired()
        
        assert len(expired) == 1
        assert expired[0].zone_id == "zone_front"


class TestContextGateCallbacks:
    """回调测试"""
    
    def test_on_gate_activated(self):
        """测试激活回调"""
        manager = ContextGateManager()
        activated = []
        manager.on_gate_activated = lambda g: activated.append(g)
        
        manager.activate(
            gate_type=ContextGateType.YARD_CONFIRMED,
            zone_id="zone_front",
            source_device="cam_front",
        )
        
        assert len(activated) == 1
        assert activated[0].gate_type == ContextGateType.YARD_CONFIRMED
    
    def test_on_gate_expired(self):
        """测试过期回调"""
        manager = ContextGateManager()
        expired = []
        manager.on_gate_expired = lambda g: expired.append(g)
        
        manager.activate(
            gate_type=ContextGateType.YARD_CONFIRMED,
            zone_id="zone_front",
            source_device="cam_front",
        )
        
        manager.invalidate(ContextGateType.YARD_CONFIRMED, "zone_front")
        
        assert len(expired) == 1


class TestAcceleratedDwell:
    """加速 Dwell 测试"""
    
    def test_default_dwell_no_gate(self):
        """测试无门控时的默认 dwell"""
        config = ContextGateConfig(
            default_dwell_sec=90,
            yard_accelerated_dwell_sec=30,
        )
        manager = ContextGateManager(config)
        
        dwell = manager.get_accelerated_dwell("zone_front")
        
        assert dwell == 90
    
    def test_accelerated_dwell_with_yard(self):
        """测试有 yard_confirmed 时的加速 dwell"""
        config = ContextGateConfig(
            default_dwell_sec=90,
            yard_accelerated_dwell_sec=30,
        )
        manager = ContextGateManager(config)
        
        manager.activate(
            gate_type=ContextGateType.YARD_CONFIRMED,
            zone_id="zone_front",
            source_device="cam_front",
        )
        
        dwell = manager.get_accelerated_dwell("zone_front")
        
        assert dwell == 30
    
    def test_accelerated_dwell_with_porch(self):
        """测试有 porch_confirmed 时的加速 dwell"""
        config = ContextGateConfig(
            default_dwell_sec=90,
            yard_accelerated_dwell_sec=30,
        )
        manager = ContextGateManager(config)
        
        manager.activate(
            gate_type=ContextGateType.PORCH_CONFIRMED,
            zone_id="zone_front",
            source_device="cam_front",
        )
        
        dwell = manager.get_accelerated_dwell("zone_front")
        
        # porch 应该更短
        assert dwell == 15  # 30 // 2


class TestGetActiveGates:
    """获取活跃门控测试"""
    
    def test_get_all_active(self):
        """测试获取所有活跃门控"""
        manager = ContextGateManager()
        
        manager.activate(ContextGateType.YARD_CONFIRMED, "zone_front", "cam1")
        manager.activate(ContextGateType.PORCH_CONFIRMED, "zone_front", "cam1")
        manager.activate(ContextGateType.YARD_CONFIRMED, "zone_back", "cam2")
        
        gates = manager.get_active_gates()
        
        assert len(gates) == 3
    
    def test_get_active_by_zone(self):
        """测试按区域获取活跃门控"""
        manager = ContextGateManager()
        
        manager.activate(ContextGateType.YARD_CONFIRMED, "zone_front", "cam1")
        manager.activate(ContextGateType.PORCH_CONFIRMED, "zone_front", "cam1")
        manager.activate(ContextGateType.YARD_CONFIRMED, "zone_back", "cam2")
        
        front_gates = manager.get_active_gates("zone_front")
        
        assert len(front_gates) == 2
        assert all(g.zone_id == "zone_front" for g in front_gates)
