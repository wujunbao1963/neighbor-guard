"""
Tests for Security Coordinator V2
"""

import pytest
from datetime import datetime, timezone

from ng_edge.core.signal import SignalEnvelope, CameraRole, Hardness
from ng_edge.state.states import ThreatState, WorkflowState, ReasonCode
from ng_edge.state.coordinator_v2 import (
    SecurityCoordinatorV2,
    ProcessResult,
    envelope_to_legacy_signal,
)
from ng_edge.services.state_machine_v5 import HouseMode, UserMode, AlarmState


# =============================================================================
# Fixtures
# =============================================================================

@pytest.fixture
def coord_away():
    """AWAY 模式协调器"""
    coord = SecurityCoordinatorV2(
        house_mode=HouseMode.AWAY,
        user_mode=UserMode.QUIET,
        entry_delay_sec=30,
    )
    coord.register_entry_point("ep_front", "Front Door")
    coord.register_judge("cam_front", "ep_front")
    return coord


@pytest.fixture
def coord_disarmed():
    """DISARMED 模式协调器"""
    return SecurityCoordinatorV2(
        house_mode=HouseMode.DISARMED,
        user_mode=UserMode.QUIET,
    )


def make_door_open_envelope(entry_point_id: str = "ep_front") -> SignalEnvelope:
    """创建门打开信号"""
    return SignalEnvelope.from_zigbee(
        device_id="sensor_001",
        friendly_name="Front Door Contact",
        signal_kind="door_open",
        zone_id="entry_exit",
        entrypoint_id=entry_point_id,
    )


def make_person_envelope(
    camera_id: str = "cam_front",
    role: CameraRole = CameraRole.JUDGE,
    confidence: float = 0.85,
) -> SignalEnvelope:
    """创建人员检测信号"""
    return SignalEnvelope.from_camera(
        device_id=camera_id,
        signal_kind="person_detected",
        zone_id="exterior",
        camera_role=role,
        confidence=confidence,
    )


def make_glass_break_envelope(entry_point_id: str = "ep_front") -> SignalEnvelope:
    """创建玻璃破碎信号"""
    return SignalEnvelope.from_zigbee(
        device_id="sensor_glass",
        friendly_name="Glass Break Sensor",
        signal_kind="glass_break",
        zone_id="perimeter",
        entrypoint_id=entry_point_id,
    )


# =============================================================================
# Basic Tests
# =============================================================================

class TestSecurityCoordinatorV2Basic:
    """基础测试"""
    
    def test_create_coordinator(self, coord_away):
        """测试创建协调器"""
        assert coord_away.house_mode == HouseMode.AWAY
        assert coord_away.user_mode == UserMode.QUIET
    
    def test_register_entry_point(self, coord_away):
        """测试注册入口点"""
        coord_away.register_entry_point("ep_back", "Back Door")
        # 应该不报错
    
    def test_register_judge(self, coord_away):
        """测试注册 Judge"""
        coord_away.register_judge("cam_back", "ep_back")
        assert coord_away.is_judge_available("cam_back")


# =============================================================================
# Signal Processing Tests
# =============================================================================

class TestSignalProcessing:
    """信号处理测试"""
    
    def test_door_open_away_triggers_pending(self, coord_away):
        """AWAY 模式门打开 → PENDING"""
        envelope = make_door_open_envelope()
        result = coord_away.process_envelope(envelope)
        
        assert result.success
        assert result.threat_state == ThreatState.PENDING
        assert result.workflow_state == WorkflowState.NOTIFIED
        assert result.threat_changed
    
    def test_glass_break_triggers_triggered(self, coord_away):
        """玻璃破碎 → TRIGGERED"""
        envelope = make_glass_break_envelope()
        result = coord_away.process_envelope(envelope)
        
        assert result.success
        assert result.threat_state == ThreatState.TRIGGERED
        assert result.workflow_state == WorkflowState.ESCALATED
    
    def test_person_detected_triggers_pre(self, coord_away):
        """人员检测 → PRE"""
        envelope = make_person_envelope()
        result = coord_away.process_envelope(envelope)
        
        assert result.success
        assert result.threat_state == ThreatState.PRE_L2  # v5 的 PRE 映射到 PRE_L2
    
    def test_disarmed_ignores_signals(self, coord_disarmed):
        """DISARMED 模式忽略信号"""
        envelope = make_door_open_envelope()
        result = coord_disarmed.process_envelope(envelope)
        
        assert result.threat_state == ThreatState.NONE


# =============================================================================
# Judge Availability Tests
# =============================================================================

class TestJudgeAvailability:
    """Judge 可用性测试"""
    
    def test_judge_heartbeat(self, coord_away):
        """测试 Judge 心跳"""
        coord_away.record_judge_heartbeat("cam_front")
        assert coord_away.is_judge_available("cam_front")
    
    def test_judge_failure_degrades(self, coord_away):
        """测试 Judge 失败降级"""
        # 连续3次失败
        coord_away.record_judge_failure("cam_front")
        coord_away.record_judge_failure("cam_front")
        coord_away.record_judge_failure("cam_front")
        
        assert not coord_away.is_judge_available("cam_front")
    
    def test_judge_capped_limits_pre(self, coord_away):
        """测试 Judge 降级时限制 PRE"""
        # 降级 Judge
        for _ in range(3):
            coord_away.record_judge_failure("cam_front")
        
        # 发送人员检测信号
        envelope = make_person_envelope()
        result = coord_away.process_envelope(envelope)
        
        # PRE 应该被限制到 L1
        assert result.judge_capped
        assert result.threat_state == ThreatState.PRE_L1
    
    def test_hard_signal_not_affected_by_judge(self, coord_away):
        """测试 Hard 信号不受 Judge 影响"""
        # 降级 Judge
        for _ in range(3):
            coord_away.record_judge_failure("cam_front")
        
        # Hard 信号（玻璃破碎）应该正常处理
        envelope = make_glass_break_envelope()
        result = coord_away.process_envelope(envelope)
        
        assert result.threat_state == ThreatState.TRIGGERED
        assert not result.judge_capped


# =============================================================================
# User Actions Tests
# =============================================================================

class TestUserActions:
    """用户操作测试"""
    
    def test_cancel_from_pending(self, coord_away):
        """测试从 PENDING 取消"""
        # 先进入 PENDING
        envelope = make_door_open_envelope()
        coord_away.process_envelope(envelope)
        
        # 取消
        result = coord_away.cancel("ep_front")
        
        assert result.success
        assert result.threat_state == ThreatState.NONE
        assert result.reason_code == ReasonCode.USER_CANCEL.value
    
    def test_resolve_from_triggered(self, coord_away):
        """测试从 TRIGGERED 解除"""
        # 先进入 TRIGGERED
        envelope = make_glass_break_envelope()
        coord_away.process_envelope(envelope)
        
        # 解除
        result = coord_away.resolve("ep_front")
        
        assert result.success
        assert result.threat_state == ThreatState.NONE
        assert result.reason_code == ReasonCode.USER_RESOLVE.value
    
    def test_entry_delay_expired(self, coord_away):
        """测试入口延迟超时"""
        # 先进入 PENDING
        envelope = make_door_open_envelope()
        coord_away.process_envelope(envelope)
        
        # 超时
        result = coord_away.trigger_entry_delay_expired("ep_front")
        
        assert result.success
        assert result.threat_state == ThreatState.TRIGGERED
        assert result.reason_code == ReasonCode.ENTRY_DELAY_EXPIRED.value


# =============================================================================
# Transition Recording Tests
# =============================================================================

class TestTransitionRecording:
    """转换记录测试"""
    
    def test_records_transition(self, coord_away):
        """测试记录转换"""
        envelope = make_door_open_envelope()
        result = coord_away.process_envelope(envelope)
        
        transitions = coord_away.get_transitions(result.incident_id)
        
        assert len(transitions) >= 1
        assert transitions[0].dimension == "threat"
        assert transitions[0].to_state == ThreatState.PENDING.value
    
    def test_callback_on_transition(self, coord_away):
        """测试转换回调"""
        callback_results = []
        coord_away.on_transition = lambda r: callback_results.append(r)
        
        envelope = make_door_open_envelope()
        coord_away.process_envelope(envelope)
        
        assert len(callback_results) == 1
        assert callback_results[0].threat_changed


# =============================================================================
# Stats Tests
# =============================================================================

class TestStats:
    """统计测试"""
    
    def test_stats_count_signals(self, coord_away):
        """测试信号计数"""
        envelope1 = make_door_open_envelope()  # hard
        envelope2 = make_person_envelope()      # soft
        
        coord_away.process_envelope(envelope1)
        coord_away.process_envelope(envelope2)
        
        stats = coord_away.get_stats()
        
        assert stats["signals_processed"] == 2
        assert stats["hard_signals"] == 1
        assert stats["soft_signals"] == 1


# =============================================================================
# Envelope Conversion Tests
# =============================================================================

class TestEnvelopeConversion:
    """信号转换测试"""
    
    def test_convert_door_open(self):
        """测试转换 door_open"""
        envelope = make_door_open_envelope()
        legacy = envelope_to_legacy_signal(envelope)
        
        assert legacy is not None
        assert legacy.signal_type.value == "door_open"
        assert legacy.zone_type.value == "entry_exit"
    
    def test_convert_person_detected(self):
        """测试转换 person_detected"""
        envelope = make_person_envelope()
        legacy = envelope_to_legacy_signal(envelope)
        
        assert legacy is not None
        assert legacy.signal_type.value == "person_detected"
    
    def test_convert_unknown_returns_none(self):
        """测试未知类型返回 None"""
        envelope = SignalEnvelope(
            signal_kind="unknown_type",
            zone_id="exterior",
        )
        legacy = envelope_to_legacy_signal(envelope)
        
        assert legacy is None
