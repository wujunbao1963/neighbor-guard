#!/bin/bash
#
# NG Edge - Device Registration Helper
#
# This script helps you register your edge device with the NG server.
# 
# Prerequisites:
#   - Server running and accessible
#   - curl and jq installed
#
# Usage:
#   ./register_device.sh --server http://YOUR_SERVER:3000
#

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Defaults
SERVER_URL="http://localhost:3000"
USER_EMAIL="edge@example.com"
USER_NAME="Edge Device"
CIRCLE_NAME="My Home"
CONFIG_DIR="./config"

# Parse arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --server|-s)
            SERVER_URL="$2"
            shift 2
            ;;
        --email|-e)
            USER_EMAIL="$2"
            shift 2
            ;;
        --circle-name|-n)
            CIRCLE_NAME="$2"
            shift 2
            ;;
        --config-dir|-d)
            CONFIG_DIR="$2"
            shift 2
            ;;
        --help|-h)
            echo "Usage: $0 [options]"
            echo ""
            echo "Options:"
            echo "  --server, -s URL       Server URL (default: http://localhost:3000)"
            echo "  --email, -e EMAIL      User email for dev login (default: edge@example.com)"
            echo "  --circle-name, -n NAME Circle name (default: My Home)"
            echo "  --config-dir, -d DIR   Config directory (default: ./config)"
            echo "  --help, -h             Show this help"
            exit 0
            ;;
        *)
            echo "Unknown option: $1"
            exit 1
            ;;
    esac
done

echo "========================================"
echo "NG Edge - Device Registration"
echo "========================================"
echo -e "Server: ${YELLOW}${SERVER_URL}${NC}"
echo ""

# Check server health
echo -e "${YELLOW}Step 1: Checking server health...${NC}"
HEALTH=$(curl -s "${SERVER_URL}/health" || echo '{"error": "connection failed"}')
if echo "$HEALTH" | grep -q '"ok":true'; then
    echo -e "${GREEN}✓ Server is healthy${NC}"
else
    echo -e "${RED}✗ Server health check failed${NC}"
    echo "Response: $HEALTH"
    exit 1
fi

# Dev login
echo ""
echo -e "${YELLOW}Step 2: Getting user token (dev login)...${NC}"
LOGIN_RESPONSE=$(curl -s -X POST "${SERVER_URL}/api/auth/dev/login" \
    -H "Content-Type: application/json" \
    -d "{\"email\": \"${USER_EMAIL}\", \"displayName\": \"${USER_NAME}\"}")

TOKEN=$(echo "$LOGIN_RESPONSE" | grep -o '"accessToken":"[^"]*"' | cut -d'"' -f4)

if [ -z "$TOKEN" ]; then
    echo -e "${RED}✗ Failed to get token${NC}"
    echo "Response: $LOGIN_RESPONSE"
    exit 1
fi

echo -e "${GREEN}✓ Got user token${NC}"
echo "  Token: ${TOKEN:0:30}..."

# Create circle
echo ""
echo -e "${YELLOW}Step 3: Creating circle '${CIRCLE_NAME}'...${NC}"
CIRCLE_RESPONSE=$(curl -s -X POST "${SERVER_URL}/api/circles" \
    -H "Authorization: Bearer ${TOKEN}" \
    -H "Content-Type: application/json" \
    -d "{\"name\": \"${CIRCLE_NAME}\"}")

CIRCLE_ID=$(echo "$CIRCLE_RESPONSE" | grep -o '"circleId":"[^"]*"' | cut -d'"' -f4)

if [ -z "$CIRCLE_ID" ]; then
    # Maybe circle already exists, try to list
    echo "  Circle creation response: $CIRCLE_RESPONSE"
    echo "  Trying to list existing circles..."
    
    CIRCLES=$(curl -s -X GET "${SERVER_URL}/api/circles" \
        -H "Authorization: Bearer ${TOKEN}")
    
    CIRCLE_ID=$(echo "$CIRCLES" | grep -o '"id":"[^"]*"' | head -1 | cut -d'"' -f4)
    
    if [ -z "$CIRCLE_ID" ]; then
        echo -e "${RED}✗ Failed to create or find circle${NC}"
        exit 1
    fi
    echo -e "${GREEN}✓ Using existing circle${NC}"
else
    echo -e "${GREEN}✓ Circle created${NC}"
fi

echo "  Circle ID: ${CIRCLE_ID}"

# Run Python registration
echo ""
echo -e "${YELLOW}Step 4: Registering edge device...${NC}"
echo ""

cd "$(dirname "$0")"
python3 test_server_integration.py \
    --server "${SERVER_URL}" \
    --token "${TOKEN}" \
    --circle "${CIRCLE_ID}" \
    --config-dir "${CONFIG_DIR}"

echo ""
echo "========================================"
echo -e "${GREEN}Registration Complete!${NC}"
echo "========================================"
echo ""
echo "Your device credentials are saved in: ${CONFIG_DIR}/device_credentials.json"
echo ""
echo "To use these credentials in your edge application:"
echo "  from ng_edge.cloud import CloudConfig"
echo "  config = CloudConfig(config_dir='${CONFIG_DIR}')"
echo "  config.load_credentials()"
echo ""
