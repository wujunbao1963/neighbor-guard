# NG-Edge v18.4 → v18.5 重构报告

## 重构日期
2024-12-30

---

## 重构内容

### 1. PRD v7.6.1 合规性修改

#### 移除 motion/presence → TRIGGERED 规则（所有状态）
- **文件**: `services/state_machine_v5.py`
- **原规则**: AWAY/PRE 状态下 MOTION_ACTIVE → TRIGGERED ("入侵确认")
- **新规则**: MOTION_ACTIVE 在任何状态下都不触发 TRIGGERED
- **安全性**: 只有 GLASS_BREAK 可以直接触发 TRIGGERED

#### 移除所有 from_inside 启发式判断
- **文件**: `services/state_machine_v5.py`
- **影响范围**: HOME/Alert, HOME/Quiet, NIGHT_OCCUPIED, NIGHT_PERIMETER
- **修改**: 门打开统一处理，不区分方向
- **原因**: from_inside 语义不可解释，方向判断不可靠

### 2. PENDING 工程化改进 (v5.3)

#### min_pending_sec 配置
- **需求**: `entry_delay_sec=0` 时仍需给用户纠错窗口
- **实现**: `effective_delay = max(entry_delay_sec, min_pending_sec)`
- **默认值**: `min_pending_sec = 2` (秒)
- **测试验证**: ✅ entry_delay=0 时 effective_delay=2

#### DOOR_CLOSE quick cancel (QUICK_OPEN_CLOSE)
- **需求**: PRD 规定 door_close within 3s 可取消 PENDING
- **实现**: 
  - 新增 `quick_cancel_sec = 3` 配置
  - 在 `process()` 方法开始处检查 DOOR_CLOSE
  - 支持设备 ID 匹配（同一个门的开关）
- **测试验证**: ✅ 0.5s 内关门取消，3.5s 后关门保持 PENDING

#### PENDING 超时机制文档化
- **设计**: 状态机本身不自动触发超时
- **调度**: 由外部调度器调用 `trigger_entry_delay_expired()`
- **辅助方法**:
  - `get_effective_delay()` - 获取有效延迟时间
  - `get_pending_elapsed()` - 获取已经过时间

### 3. DISARMED 模式 core evidence
- **PRD 要求**: "PRE disabled; core evidence remains"
- **实现**: `_process_disarmed()` 记录所有信号但不改变状态
- **测试验证**: ✅ 3个信号都被记录，状态保持 QUIET

### 4. Signal 类增强
- **新增字段**: `device_id: str = ""` 
- **用途**: 支持 quick cancel 的设备匹配

### 5. 删除 DEPRECATED 代码
- 删除 27 个未使用的模块文件
- 清理空目录和备份文件

---

## 最终行为矩阵 (v5.3)

| Signal | DISARMED | HOME (A/Q) | AWAY | NIGHT_OCC | NIGHT_PERI |
|--------|----------|------------|------|-----------|------------|
| exterior person | QUIET* | PRE | PRE | PRE | PRE |
| door open | QUIET* | PRE/ATTEN | PENDING | PENDING | PENDING |
| door close | QUIET* | QUIET* | **QC** | **QC** | **QC** |
| interior motion | QUIET* | QUIET | QUIET | QUIET | QUIET |
| glass break | QUIET* | TRIG | TRIG | TRIG | TRIG |

*QUIET = 状态不变，但信号被记录 (core evidence)
**QC = Quick Cancel: 如果在 `quick_cancel_sec` 内关门，取消 PENDING

---

## 配置参数

| 参数 | 默认值 | 说明 |
|------|--------|------|
| `entry_delay_sec` | 30 | 标准 PENDING 延迟 |
| `min_pending_sec` | 2 | 最小 PENDING 窗口（即使 entry_delay=0） |
| `quick_cancel_sec` | 3 | DOOR_CLOSE 快速取消窗口 |

---

## ⚠️ 风险评估：未实现功能

### 1. Evidence 生命周期（中高优先级）
- `EvidencePolicy` 创建但未调用
- CANDIDATE 提交规则未实现
- 建议在 `_on_state_transition()` 中添加调用

### 2. 可审计/可回放能力（中优先级）
- 删除了 replay/contract, correlation/context_gate 等模块
- 当前 MVP 不需要，但影响未来扩展

---

## 测试验证

```bash
# 启动
PYTHONPATH=src python3 -m ng_edge.runtime.edge_runtime
python3 src/hmi_server.py

# 测试场景
1. AWAY + DOOR_OPEN → PENDING
2. AWAY + PENDING + DOOR_CLOSE (< 3s) → QUIET (quick cancel)
3. AWAY + PENDING + DOOR_CLOSE (> 3s) → PENDING (保持)
4. AWAY + PRE + MOTION → PRE (不升级到 TRIGGERED)
5. DISARMED + 任意信号 → QUIET (信号被记录)
6. entry_delay=0 → effective_delay=2 (min_pending_sec)
```

---

## 后续工作

1. **高优先级**: 实现 Evidence 生命周期
2. **中优先级**: 外部调度器的 PENDING 超时驱动
3. **低优先级**: 完善 Tamper-C 确认流程
