#!/bin/bash
# Zigbee传感器完整配置脚本
# 为Back Door Contact和Family Room Motion配置zones、entry points和sensors

echo "========================================="
echo "Zigbee传感器配置脚本"
echo "========================================="

BASE_URL="http://localhost:8000/api"

# ==========================================
# Step 1: 创建Zones
# ==========================================
echo ""
echo "Step 1: 创建Zones..."

# Zone 1: Back Door (ENTRY_EXIT)
echo "  创建 zone_back_door (ENTRY_EXIT)..."
curl -X POST "$BASE_URL/zones" \
  -H "Content-Type: application/json" \
  -d '{
    "zone_id": "zone_back_door",
    "name": "Back Door",
    "zone_type": "ENTRY_EXIT",
    "location_type": "indoor",
    "entry_point_ids": [],
    "adjacent_zone_ids": [],
    "is_bypass_home": false,
    "is_bypass_night_occupied": false,
    "capability_tier": "E"
  }' 2>/dev/null

echo ""

# Zone 2: Family Room (PERIMETER)
echo "  创建 zone_family_room (PERIMETER)..."
curl -X POST "$BASE_URL/zones" \
  -H "Content-Type: application/json" \
  -d '{
    "zone_id": "zone_family_room",
    "name": "Family Room",
    "zone_type": "PERIMETER",
    "location_type": "indoor",
    "entry_point_ids": [],
    "adjacent_zone_ids": [],
    "is_bypass_home": false,
    "is_bypass_night_occupied": true,
    "capability_tier": "E"
  }' 2>/dev/null

echo ""

# ==========================================
# Step 2: 创建Entry Point (Back Door)
# ==========================================
echo ""
echo "Step 2: 创建Entry Point..."

echo "  创建 ep_back_door..."
curl -X POST "$BASE_URL/entry-points" \
  -H "Content-Type: application/json" \
  -d '{
    "entry_point_id": "ep_back_door",
    "name": "Back Door Entry",
    "zone_id": "zone_back_door",
    "entry_delay_away_sec": 30,
    "entry_delay_night_sec": 15,
    "entry_delay_home_sec": 30,
    "is_primary_entry": false,
    "sensor_ids": ["zigbee_back_door_001"]
  }' 2>/dev/null

echo ""

# ==========================================
# Step 3: 创建Sensors
# ==========================================
echo ""
echo "Step 3: 创建Sensors..."

# Sensor 1: Back Door Contact
echo "  创建 zigbee_back_door_001 (door_contact)..."
curl -X POST "$BASE_URL/sensors" \
  -H "Content-Type: application/json" \
  -d '{
    "sensor_id": "zigbee_back_door_001",
    "sensor_type": "door_contact",
    "zone_id": "zone_back_door",
    "name": "Back Door Contact"
  }' 2>/dev/null

echo ""

# Sensor 2: Family Room Motion
echo "  创建 zigbee_family_room_001 (motion_pir)..."
curl -X POST "$BASE_URL/sensors" \
  -H "Content-Type: application/json" \
  -d '{
    "sensor_id": "zigbee_family_room_001",
    "sensor_type": "motion_pir",
    "zone_id": "zone_family_room",
    "name": "Family Room Motion"
  }' 2>/dev/null

echo ""

# ==========================================
# Step 4: 更新Zone的entry_point_ids
# ==========================================
echo ""
echo "Step 4: 更新Zone关联..."

echo "  更新 zone_back_door 关联 ep_back_door..."
curl -X PATCH "$BASE_URL/zones/zone_back_door" \
  -H "Content-Type: application/json" \
  -d '{
    "entry_point_ids": ["ep_back_door"]
  }' 2>/dev/null

echo ""

# ==========================================
# Step 5: 验证配置
# ==========================================
echo ""
echo "========================================="
echo "配置完成！验证结果..."
echo "========================================="

echo ""
echo "Zones:"
curl -s "$BASE_URL/zones" | jq '.zones | length' | xargs -I {} echo "  共 {} 个zones"

echo ""
echo "Entry Points:"
curl -s "$BASE_URL/entry-points" | jq '.entry_points | length' | xargs -I {} echo "  共 {} 个entry points"

echo ""
echo "Sensors:"
curl -s "$BASE_URL/sensors" | jq '.sensors | length' | xargs -I {} echo "  共 {} 个sensors"

echo ""
echo "Pipeline状态:"
curl -s "$BASE_URL/pipeline/status" | jq '{alarm_state, mode: .house_mode}'

echo ""
echo "Zigbee Pipeline集成状态:"
curl -s "$BASE_URL/zigbee/status" | jq '{pipeline_enabled, device_count, connected}'

echo ""
echo "========================================="
echo "配置脚本执行完毕"
echo "========================================="
echo ""
echo "下一步："
echo "1. 如果 pipeline_enabled = true，配置成功！"
echo "2. 设置AWAY模式测试: curl -X POST $BASE_URL/set-mode -d '{\"mode\":\"AWAY\"}'"
echo "3. 触发Back Door，观察Pipeline状态变化"
echo ""
