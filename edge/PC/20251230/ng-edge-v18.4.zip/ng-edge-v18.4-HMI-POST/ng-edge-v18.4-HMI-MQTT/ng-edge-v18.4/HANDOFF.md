# ng-edge v2.46 开发状态

## 当前版本
- **版本**: v2.46
- **日期**: 2025-12-29
- **硬件**: RTX 4060 + Ubuntu CUDA

## v2.46 更新：Keypad 安全等级控制

### PIN 码配置
```python
valid_pins=["8662", "1113"]
```

### 安全等级定义
| 等级 | 模式 | 说明 |
|------|------|------|
| 0 | DISARMED | 撤防 |
| 1 | HOME | 在家 |
| 2 | AWAY | 离家 |
| 3 | PENDING/TRIGGERED | 威胁状态 |

### 安全规则

| 操作 | 需要 PIN? | 说明 |
|------|-----------|------|
| disarm → home | ❌ | 升级安全 |
| disarm → away | ❌ | 升级安全 |
| home → away | ❌ | 升级安全 |
| away → home | ✅ | **降级需要PIN** |
| away → disarm | ✅ | **降级需要PIN** |
| home → disarm | ✅ | **降级需要PIN** |
| pending → disarm | ✅ | **降级需要PIN** |
| triggered → disarm | ✅ | **降级需要PIN** |

### 使用示例

**系统在 DISARMED 状态：**
- 按 AWAY → 直接切换到 AWAY ✓
- 按 HOME → 直接切换到 HOME ✓

**系统在 AWAY 状态：**
- 按 DISARM → 需要先输入 8662 或 1113，再按 DISARM
- 按 HOME → 需要先输入 PIN

**系统在 PENDING 状态（门打开触发 entry delay）：**
- 按 DISARM → 需要先输入 PIN 才能撤防

## 测试命令

```bash
cd ~/ng-edge-v18.4
PYTHONPATH=src python3 -m ng_edge.runtime.edge_runtime
```

## 预期日志

**无 PIN 升级（允许）：**
```
[Keypad] AWAY 按下 (当前等级: 0 → 目标: 2)
[Keypad] ✅ 已设置 AWAY 模式
```

**无 PIN 降级（拒绝）：**
```
[Keypad] 🔓 DISARM 按下 (当前等级: 2) 无PIN
[Keypad] ❌ 拒绝：降低安全等级需要有效 PIN
```

**有 PIN 降级（允许）：**
```
[Keypad] 🔓 DISARM 按下 (当前等级: 2) PIN: ***
[Keypad] ✅ 撤防成功!
```
