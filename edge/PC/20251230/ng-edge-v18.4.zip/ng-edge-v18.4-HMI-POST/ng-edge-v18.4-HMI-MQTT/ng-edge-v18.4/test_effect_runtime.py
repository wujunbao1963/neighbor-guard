#!/usr/bin/env python3
"""
Effect Runtime 测试

验证：
1. 去抖功能 - L0/L1 抖动不会频繁开关灯
2. 最短持续时间 - PRE_L2 至少持续5秒
3. 级别切换 - L1 → L2 → L1 的正确行为
4. 单线程执行 - 不会有多个循环同时运行
"""

import asyncio
import time
import logging
import sys
sys.path.insert(0, 'src')

from ng_edge.runtime.effect_runtime import EffectRuntime, EffectMode, threat_level_to_effect_mode

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s.%(msecs)03d [%(levelname)s] %(message)s',
    datefmt='%H:%M:%S'
)
logger = logging.getLogger(__name__)


class MockDevice:
    """模拟设备"""
    def __init__(self):
        self.light_on_count = 0
        self.light_off_count = 0
        self.siren_count = 0
        self.light_state = False
        self.last_action_time = 0
    
    async def spotlight_on(self):
        self.light_on_count += 1
        self.light_state = True
        self.last_action_time = time.time()
    
    async def spotlight_off(self):
        self.light_off_count += 1
        self.light_state = False
        self.last_action_time = time.time()
    
    async def siren_trigger(self, duration: float):
        self.siren_count += 1
    
    async def siren_off(self):
        pass
    
    def reset(self):
        self.light_on_count = 0
        self.light_off_count = 0
        self.siren_count = 0
        self.light_state = False


async def test_debounce_l0_l1():
    """测试1: L0/L1 去抖"""
    print("\n" + "="*60)
    print("测试1: L0/L1 去抖（2秒确认窗口）")
    print("="*60)
    
    device = MockDevice()
    runtime = EffectRuntime(
        spotlight_on=device.spotlight_on,
        spotlight_off=device.spotlight_off,
        siren_trigger=device.siren_trigger,
        siren_off=device.siren_off,
    )
    runtime.start()
    
    # 快速抖动 L0 → L1 → L0 → L1 → L0（每0.5秒切换）
    for i in range(10):
        mode = EffectMode.PRE_L1 if i % 2 == 0 else EffectMode.OFF
        runtime.set_desired(mode, source=f"抖动{i}")
        await asyncio.sleep(0.3)
    
    # 等待稳定
    await asyncio.sleep(3)
    
    runtime.stop()
    await asyncio.sleep(0.5)
    
    print(f"\n结果: light_on={device.light_on_count} light_off={device.light_off_count}")
    print(f"预期: 由于去抖，light_on <= 2（而不是5+）")
    
    if device.light_on_count <= 2:
        print("✅ 通过：去抖有效，避免了频繁开关")
        return True
    else:
        print("❌ 失败：开灯次数过多")
        return False


async def test_min_hold_pre_l2():
    """测试2: PRE_L2 最短持续时间"""
    print("\n" + "="*60)
    print("测试2: PRE_L2 最短持续5秒")
    print("="*60)
    
    device = MockDevice()
    runtime = EffectRuntime(
        spotlight_on=device.spotlight_on,
        spotlight_off=device.spotlight_off,
        siren_trigger=device.siren_trigger,
        siren_off=device.siren_off,
    )
    runtime.start()
    
    # 启动 L2
    runtime.set_desired(EffectMode.PRE_L2, source="进入L2")
    await asyncio.sleep(1)  # 只等1秒
    
    # 尝试关闭
    runtime.set_desired(EffectMode.OFF, source="尝试关闭")
    
    # 检查状态（应该还在 PRE_L2，因为最短持续时间）
    status = runtime.get_status()
    print(f"1秒后状态: confirmed={status['confirmed_mode']} pending={status['pending_mode']}")
    
    # 等待最短持续时间过去
    await asyncio.sleep(5)
    
    status = runtime.get_status()
    print(f"6秒后状态: confirmed={status['confirmed_mode']}")
    
    runtime.stop()
    await asyncio.sleep(0.5)
    
    if status['confirmed_mode'] == 'off':
        print("✅ 通过：最短持续时间后正确关闭")
        return True
    else:
        print("❌ 失败：未正确关闭")
        return False


async def test_level_switch():
    """测试3: 级别切换 L1 → L2 → L1"""
    print("\n" + "="*60)
    print("测试3: 级别切换")
    print("="*60)
    
    device = MockDevice()
    runtime = EffectRuntime(
        spotlight_on=device.spotlight_on,
        spotlight_off=device.spotlight_off,
        siren_trigger=device.siren_trigger,
        siren_off=device.siren_off,
    )
    runtime.start()
    
    # L1（常亮）
    runtime.set_desired(EffectMode.PRE_L1, source="L1")
    await asyncio.sleep(2)
    print(f"L1 状态: light={device.light_state} on_count={device.light_on_count}")
    
    # L2（闪灯）
    runtime.set_desired(EffectMode.PRE_L2, source="L2")
    await asyncio.sleep(3)
    print(f"L2 状态: light={device.light_state} on_count={device.light_on_count} off_count={device.light_off_count}")
    
    # 回到 L1
    runtime.set_desired(EffectMode.PRE_L1, source="回到L1")
    await asyncio.sleep(2)
    print(f"回到L1: light={device.light_state}")
    
    runtime.stop()
    await asyncio.sleep(0.5)
    
    # L2 应该有闪灯（至少开关各一次）
    if device.light_on_count >= 1 and device.light_off_count >= 1:
        print("✅ 通过：级别切换正常")
        return True
    else:
        print("❌ 失败：级别切换异常")
        return False


async def test_rapid_same_level():
    """测试4: 快速重复同级别信号"""
    print("\n" + "="*60)
    print("测试4: 快速重复 L1 信号（不应重复开灯）")
    print("="*60)
    
    device = MockDevice()
    runtime = EffectRuntime(
        spotlight_on=device.spotlight_on,
        spotlight_off=device.spotlight_off,
        siren_trigger=device.siren_trigger,
        siren_off=device.siren_off,
    )
    runtime.start()
    
    # 快速连续发送 L1（模拟每帧检测）
    for i in range(50):
        runtime.set_desired(EffectMode.PRE_L1, source=f"检测{i}")
        await asyncio.sleep(0.05)
    
    await asyncio.sleep(1)
    
    print(f"结果: light_on={device.light_on_count}")
    
    runtime.stop()
    await asyncio.sleep(0.5)
    
    if device.light_on_count == 1:
        print("✅ 通过：重复信号不会重复开灯")
        return True
    else:
        print(f"❌ 失败：开灯次数={device.light_on_count}（应该是1）")
        return False


async def test_l1_to_off_debounce():
    """测试5: L1 → OFF 去抖（模拟人短暂消失）"""
    print("\n" + "="*60)
    print("测试5: L1 → OFF 去抖（人短暂消失又出现）")
    print("="*60)
    
    device = MockDevice()
    runtime = EffectRuntime(
        spotlight_on=device.spotlight_on,
        spotlight_off=device.spotlight_off,
        siren_trigger=device.siren_trigger,
        siren_off=device.siren_off,
    )
    runtime.start()
    
    # 进入 L1
    runtime.set_desired(EffectMode.PRE_L1, source="进入")
    await asyncio.sleep(1)
    print(f"进入L1: light={device.light_state}")
    
    # 人消失（发送 OFF）
    runtime.set_desired(EffectMode.OFF, source="人消失")
    await asyncio.sleep(0.5)  # 短暂等待（小于去抖时间）
    
    # 人又出现（发送 L1）
    runtime.set_desired(EffectMode.PRE_L1, source="人又出现")
    await asyncio.sleep(1)
    
    # 灯应该一直亮着（因为 OFF 没来得及确认就被取消了）
    print(f"人又出现后: light={device.light_state} off_count={device.light_off_count}")
    
    runtime.stop()
    await asyncio.sleep(0.5)
    
    # 灯应该还亮着，off_count 应该是 0（关灯动作被取消了）
    if device.light_state and device.light_off_count == 0:
        print("✅ 通过：短暂消失不会关灯")
        return True
    else:
        print("❌ 失败：短暂消失错误地关了灯")
        return False


async def test_threat_level_mapping():
    """测试6: 威胁级别映射"""
    print("\n" + "="*60)
    print("测试6: threat_level_to_effect_mode 映射")
    print("="*60)
    
    assert threat_level_to_effect_mode(0) == EffectMode.OFF
    assert threat_level_to_effect_mode(1) == EffectMode.PRE_L1
    assert threat_level_to_effect_mode(2) == EffectMode.PRE_L2
    assert threat_level_to_effect_mode(3) == EffectMode.PRE_L3
    
    print("✅ 通过：映射正确")
    return True


async def main():
    results = []
    
    results.append(("L0/L1去抖", await test_debounce_l0_l1()))
    results.append(("PRE_L2最短持续", await test_min_hold_pre_l2()))
    results.append(("级别切换", await test_level_switch()))
    results.append(("快速重复信号", await test_rapid_same_level()))
    results.append(("L1→OFF去抖", await test_l1_to_off_debounce()))
    results.append(("威胁级别映射", await test_threat_level_mapping()))
    
    print("\n" + "="*60)
    print("测试汇总")
    print("="*60)
    for name, passed in results:
        status = "✅" if passed else "❌"
        print(f"  {status} {name}")
    
    all_passed = all(p for _, p in results)
    return all_passed


if __name__ == "__main__":
    success = asyncio.run(main())
    sys.exit(0 if success else 1)
