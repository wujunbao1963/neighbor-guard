#!/usr/bin/env python3
"""
实时 RTSP 分区测试 - 输出真实数据

用法：
    python3 test_rtsp_zone.py --rtsp 'rtsp://admin:XXX@10.0.0.155:554/h264Preview_01_sub'
    
会输出每个检测的详细信息到 zone_test_log.txt
"""

import argparse
import cv2
import time
from datetime import datetime
from ultralytics import YOLO


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--rtsp", required=True, help="RTSP URL")
    parser.add_argument("--door-y", type=int, default=400, help="door 分界线 (默认 400)")
    parser.add_argument("--model", default="yolo11s.pt", help="YOLO 模型")
    parser.add_argument("--duration", type=int, default=60, help="测试时长(秒)")
    args = parser.parse_args()
    
    print(f"[YOLO] 加载模型: {args.model}")
    model = YOLO(args.model)
    print("[YOLO] 模型已加载")
    
    print(f"[RTSP] 连接: {args.rtsp}")
    cap = cv2.VideoCapture(args.rtsp)
    if not cap.isOpened():
        print("[ERROR] 无法连接 RTSP")
        return
    
    w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    print(f"[INFO] 分辨率: {w}x{h}")
    print(f"[INFO] door_y = {args.door_y} (y2 >= {args.door_y} → door L2)")
    print(f"[INFO] 测试 {args.duration} 秒，结果写入 zone_test_log.txt")
    print()
    
    log_file = open("zone_test_log.txt", "w")
    log_file.write(f"=== RTSP 分区测试 ===\n")
    log_file.write(f"时间: {datetime.now()}\n")
    log_file.write(f"分辨率: {w}x{h}\n")
    log_file.write(f"door_y: {args.door_y}\n")
    log_file.write(f"规则: y2 >= {args.door_y} → door L2, 否则 yard L1\n")
    log_file.write(f"{'='*60}\n\n")
    log_file.flush()
    
    start_time = time.time()
    frame_count = 0
    detect_count = 0
    
    try:
        while time.time() - start_time < args.duration:
            ret, frame = cap.read()
            if not ret:
                continue
            
            frame_count += 1
            if frame_count % 5 != 0:  # 每 5 帧处理一次
                continue
            
            results = model(frame, verbose=False, conf=0.3)
            
            for r in results:
                for box in r.boxes:
                    cls_id = int(box.cls[0])
                    if model.names[cls_id] != "person":
                        continue
                    
                    detect_count += 1
                    conf = float(box.conf[0])
                    
                    # xyxy 格式
                    bbox_xyxy = [int(v) for v in box.xyxy[0].tolist()]
                    x1, y1, x2, y2 = bbox_xyxy
                    
                    # 分区判断
                    if y2 >= args.door_y:
                        zone, level = "door", 2
                    else:
                        zone, level = "yard", 1
                    
                    now = datetime.now().strftime("%H:%M:%S.%f")[:-3]
                    line = f"[{now}] bbox=({x1},{y1},{x2},{y2}) y2={y2} conf={conf:.2f} → {zone} L{level}"
                    
                    print(line)
                    log_file.write(line + "\n")
                    log_file.flush()
    
    except KeyboardInterrupt:
        print("\n[INFO] 手动停止")
    
    finally:
        cap.release()
        elapsed = time.time() - start_time
        summary = f"\n{'='*60}\n总计: {frame_count} 帧, {detect_count} 次检测, {elapsed:.1f} 秒\n"
        print(summary)
        log_file.write(summary)
        log_file.close()
        print("[INFO] 日志已保存到 zone_test_log.txt")


if __name__ == "__main__":
    main()
