#!/usr/bin/env python3
"""
Ring Keypad 按键学习工具

通过 Z-Wave JS UI 的 MQTT 网关学习 Ring Keypad 按键映射

使用方法:
    python3 learn_keypad_keys.py

然后依次按下 disarm, away, home, ok, cancel 按钮
"""

import json
import time
import threading
import sys

try:
    import paho.mqtt.client as mqtt
except ImportError:
    print("❌ paho-mqtt 未安装")
    print("   运行: pip install paho-mqtt --break-system-packages")
    sys.exit(1)

# 配置
MQTT_HOST = "localhost"
MQTT_PORT = 1883
NODE_ID = 3  # Ring Keypad Node ID

# 要学习的按键
KEYS_TO_LEARN = ["disarm", "away", "home", "ok", "cancel"]

# 结果
mapping = {}
lock = threading.Lock()


def parse_payload(b: bytes):
    """解析 MQTT payload"""
    s = b.decode("utf-8", errors="ignore")
    try:
        return json.loads(s)
    except:
        return s


def is_action_event(topic: str, payload_obj) -> bool:
    """检查是否是按键动作事件"""
    # Entry Control 事件在 /111/0/ topic 下
    # 动作事件没有 value 字段
    if "/111/0/" in topic and topic.endswith("/0"):
        if isinstance(payload_obj, dict):
            return "value" not in payload_obj
        return True
    return False


def on_message(client, userdata, msg):
    """MQTT 消息回调"""
    topic = msg.topic
    payload = parse_payload(msg.payload)
    
    # PIN 数字缓存更新（有 value 字段）
    if "/111/0/" in topic and isinstance(payload, dict) and "value" in payload:
        v = payload.get("value")
        if isinstance(v, str):
            print(f"⌨️  PIN 输入: {v}")
        return
    
    # 动作事件
    if is_action_event(topic, payload):
        with lock:
            # 检查是否已记录
            if topic in mapping.values():
                return
        
        print(f"\n🔔 检测到按键事件!")
        print(f"   Topic: {topic}")
        
        with lock:
            remaining = [k for k in KEYS_TO_LEARN if k not in mapping]
        
        if not remaining:
            return
        
        print(f"\n请输入你刚刚按下的按键名称:")
        print(f"可选: {', '.join(remaining)}")
        
        try:
            key = input(">>> ").strip().lower()
        except EOFError:
            return
        
        if key in remaining:
            with lock:
                mapping[key] = topic
            print(f"✅ 已记录: {key} → {topic}")
            
            with lock:
                if len(mapping) == len(KEYS_TO_LEARN):
                    print("\n" + "=" * 60)
                    print("🎉 所有按键学习完成!")
                    print("=" * 60)
                    print("\n按键映射:")
                    print(json.dumps(mapping, indent=2))
                    
                    # 保存到文件
                    with open("keypad_mapping.json", "w") as f:
                        json.dump(mapping, f, indent=2)
                    print(f"\n✅ 已保存到 keypad_mapping.json")
                    
                    # 生成配置代码
                    print("\n" + "-" * 60)
                    print("将以下内容添加到 edge_runtime.py 配置中:")
                    print("-" * 60)
                    print("keypad_key_mapping={")
                    for k, v in mapping.items():
                        print(f'    "{k}": "{v}",')
                    print("}")
                    print()
                else:
                    remaining = [k for k in KEYS_TO_LEARN if k not in mapping]
                    print(f"\n还需要学习: {', '.join(remaining)}")
        else:
            print(f"⚠️  无效的按键名称: {key}")


def main():
    print("=" * 60)
    print("  Ring Keypad 按键学习工具")
    print("=" * 60)
    print()
    print(f"MQTT: {MQTT_HOST}:{MQTT_PORT}")
    print(f"Node ID: {NODE_ID}")
    print()
    print(f"请依次按下以下按键:")
    for i, key in enumerate(KEYS_TO_LEARN, 1):
        print(f"  {i}. {key}")
    print()
    print("按 Ctrl+C 退出")
    print()
    
    # 创建 MQTT 客户端
    client = mqtt.Client(
        client_id="keypad_learner",
        callback_api_version=mqtt.CallbackAPIVersion.VERSION1
    )
    client.on_message = on_message
    
    try:
        print(f"连接 MQTT...")
        client.connect(MQTT_HOST, MQTT_PORT, 60)
        
        # 订阅 Keypad topic
        topic = f"zwave/nodeID_{NODE_ID}/#"
        client.subscribe(topic)
        print(f"✅ 已订阅: {topic}")
        print()
        print("等待按键事件...")
        print()
        
        client.loop_forever()
        
    except KeyboardInterrupt:
        print("\n\n退出...")
        
        if mapping:
            print("\n当前学习到的映射:")
            print(json.dumps(mapping, indent=2))
    
    finally:
        client.disconnect()


if __name__ == "__main__":
    main()
