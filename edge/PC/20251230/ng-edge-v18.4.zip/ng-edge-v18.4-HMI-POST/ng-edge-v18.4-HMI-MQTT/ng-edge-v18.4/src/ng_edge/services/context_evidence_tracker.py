"""
Context Evidence Tracker - PRD v7.5.0 §0.2.2

Tracks SUSPICION_LIGHT signals that can serve as context evidence
for subsequent SECURITY_HEAVY events.
"""

from typing import List, Optional, Tuple
from datetime import datetime, timedelta, timezone
from collections import deque
from threading import Lock

from ..domain.enums import SignalType, ZoneType, HouseMode, NightSubMode
from ..domain.models import Signal


class ContextSignalRecord:
    """
    Record of a SUSPICION_LIGHT signal for context evidence.
    
    Lighter than full Signal object, optimized for time-window lookups.
    """
    
    def __init__(
        self,
        signal_type: SignalType,
        timestamp: datetime,
        entry_point_id: Optional[str],
        zone_id: str,
        zone_type: ZoneType,
        confidence: float = 1.0
    ):
        self.signal_type = signal_type
        self.timestamp = timestamp
        self.entry_point_id = entry_point_id
        self.zone_id = zone_id
        self.zone_type = zone_type
        self.confidence = confidence


class ContextEvidenceTracker:
    """
    Tracks SUSPICION_LIGHT signals for context evidence.
    
    PRD §0.2.2:
    - Records approach_entry, loiter, person_detected signals
    - Maintains 30-second rolling window
    - Provides context boost for SECURITY_HEAVY events
    - Calculates shortened entry delay (Night Occupied only)
    """
    
    # Configuration (PRD §0.2.2 defaults)
    T_CONTEXT_SEC = 30  # Context window in seconds
    CONTEXT_DECAY_TAU_SEC = 15  # Context decay time constant
    CONTEXT_BONUS_SCORE = 0.8  # EPHE score bonus
    
    # Signals that count as context evidence
    CONTEXT_EVIDENCE_SIGNALS = frozenset({
        SignalType.APPROACH_ENTRY,
        SignalType.LOITER,
        SignalType.PERSON_DETECTED,  # Only if in EXTERIOR near entry
    })
    
    # Triggers that can be enhanced by context
    CONTEXT_ENHANCEABLE_TRIGGERS = frozenset({
        SignalType.DOOR_OPEN,
        SignalType.WINDOW_OPEN,
        SignalType.GLASS_BREAK,
        SignalType.FORCED_ENTRY,
    })
    
    def __init__(
        self,
        context_window_sec: int = 30,
        decay_tau_sec: int = 15,
        bonus_score: float = 0.8,
        max_records: int = 100
    ):
        """
        Initialize context evidence tracker.
        
        Args:
            context_window_sec: Time window for context (default 30s)
            decay_tau_sec: Decay time constant (default 15s)
            bonus_score: EPHE bonus score (default 0.8)
            max_records: Maximum records to keep (default 100)
        """
        self.context_window_sec = context_window_sec
        self.decay_tau_sec = decay_tau_sec
        self.bonus_score = bonus_score
        self.max_records = max_records
        
        # Thread-safe deque for signal records
        self._records: deque = deque(maxlen=max_records)
        self._lock = Lock()
    
    def record_suspicion_signal(
        self,
        signal: Signal,
        zone_type: ZoneType
    ) -> bool:
        """
        Record a SUSPICION_LIGHT signal for context evidence.
        
        Args:
            signal: The signal to record
            zone_type: Zone type where signal occurred
        
        Returns:
            True if signal was recorded, False if not eligible
        """
        # Only record context-eligible signals
        if signal.signal_type not in self.CONTEXT_EVIDENCE_SIGNALS:
            return False
        
        # PERSON_DETECTED only counts if in EXTERIOR zone
        if signal.signal_type == SignalType.PERSON_DETECTED:
            if zone_type != ZoneType.EXTERIOR:
                return False
        
        # Create record
        record = ContextSignalRecord(
            signal_type=signal.signal_type,
            timestamp=signal.timestamp,
            entry_point_id=signal.entry_point_id,
            zone_id=signal.zone_id,
            zone_type=zone_type,
            confidence=signal.confidence
        )
        
        with self._lock:
            self._records.append(record)
            self._cleanup_old_records(signal.timestamp)
        
        return True
    
    def check_context_boost(
        self,
        trigger_signal: SignalType,
        trigger_timestamp: datetime,
        entry_point_id: Optional[str],
        house_mode: HouseMode,
        night_sub_mode: Optional[NightSubMode] = None
    ) -> Tuple[bool, int, float, Optional[int]]:
        """
        Check if trigger has context evidence and calculate boost.
        
        Args:
            trigger_signal: SECURITY_HEAVY trigger signal
            trigger_timestamp: When trigger occurred
            entry_point_id: Entry point ID (for matching)
            house_mode: Current house mode
            night_sub_mode: Night sub-mode (if applicable)
        
        Returns:
            Tuple of:
            - has_context: True if context evidence found
            - context_count: Number of matching context signals
            - boost_score: EPHE boost score (0.0 if no context)
            - shortened_delay_sec: Shortened entry delay (None if not applicable)
        
        PRD §0.2.2 Rules:
        1. Look back T_context_sec from trigger
        2. Match signals at same entry point
        3. Calculate boost score
        4. For Night_occupied ONLY: shorten delay
        """
        # Only certain triggers can be enhanced
        if trigger_signal not in self.CONTEXT_ENHANCEABLE_TRIGGERS:
            return False, 0, 0.0, None
        
        # Find matching context signals
        cutoff_time = trigger_timestamp - timedelta(seconds=self.context_window_sec)
        
        matching_signals = []
        with self._lock:
            for record in self._records:
                # Within time window
                if record.timestamp < cutoff_time:
                    continue
                if record.timestamp > trigger_timestamp:
                    continue
                
                # Match entry point (if specified)
                if entry_point_id and record.entry_point_id != entry_point_id:
                    continue
                
                matching_signals.append(record)
        
        # No context found
        if not matching_signals:
            return False, 0, 0.0, None
        
        # Calculate boost score (PRD: +0.8 for context)
        has_context = True
        context_count = len(matching_signals)
        boost_score = self.bonus_score
        
        # Calculate shortened entry delay (PRD §0.2.2)
        shortened_delay = self._calculate_shortened_delay(
            house_mode,
            night_sub_mode
        )
        
        return has_context, context_count, boost_score, shortened_delay
    
    def _calculate_shortened_delay(
        self,
        house_mode: HouseMode,
        night_sub_mode: Optional[NightSubMode]
    ) -> Optional[int]:
        """
        Calculate shortened entry delay.
        
        PRD §0.2.2:
        - Only for Night_occupied mode
        - min(10, floor(entryDelaySec/3))
        - NOT for Away (avoid false alarm acceleration)
        
        Args:
            house_mode: Current house mode
            night_sub_mode: Night sub-mode
        
        Returns:
            Shortened delay in seconds, or None if not applicable
        """
        # Only for NIGHT mode
        if house_mode != HouseMode.NIGHT:
            return None
        
        # Only for OCCUPIED sub-mode (PRD: 不得用于 Away)
        # PERIMETER sub-mode = not occupied
        if night_sub_mode == NightSubMode.NIGHT_PERIMETER:
            return None
        
        # Default to OCCUPIED if sub-mode not specified
        # This will be applied to base_entry_delay by caller
        # We return a marker value (10) since we don't know base delay here
        return 10  # Caller will use min(10, base_delay // 3)
    
    def get_context_explanation(
        self,
        trigger_timestamp: datetime,
        entry_point_id: Optional[str]
    ) -> Optional[str]:
        """
        Generate explanation text for context evidence.
        
        Args:
            trigger_timestamp: When trigger occurred
            entry_point_id: Entry point ID
        
        Returns:
            Human-readable explanation or None
        
        Example: "Person detected approaching entry 30 seconds before door opened"
        """
        cutoff_time = trigger_timestamp - timedelta(seconds=self.context_window_sec)
        
        matching_signals = []
        with self._lock:
            for record in self._records:
                if record.timestamp < cutoff_time:
                    continue
                if record.timestamp > trigger_timestamp:
                    continue
                if entry_point_id and record.entry_point_id != entry_point_id:
                    continue
                matching_signals.append(record)
        
        if not matching_signals:
            return None
        
        # Build explanation
        signal_types = [s.signal_type.value for s in matching_signals]
        time_before = int((trigger_timestamp - matching_signals[-1].timestamp).total_seconds())
        
        if len(matching_signals) == 1:
            return f"{signal_types[0].replace('_', ' ').title()} {time_before}s before entry"
        else:
            return f"{len(matching_signals)} suspicious activities in {self.context_window_sec}s before entry"
    
    def _cleanup_old_records(self, now: datetime) -> None:
        """
        Remove records older than context window.
        
        Args:
            now: Current time
        """
        cutoff = now - timedelta(seconds=self.context_window_sec * 2)
        
        # Remove old records from front of deque
        while self._records and self._records[0].timestamp < cutoff:
            self._records.popleft()
    
    def get_recent_signals(
        self,
        since: datetime,
        entry_point_id: Optional[str] = None
    ) -> List[ContextSignalRecord]:
        """
        Get recent context signals.
        
        Args:
            since: Get signals since this time
            entry_point_id: Filter by entry point (optional)
        
        Returns:
            List of matching signals
        """
        results = []
        with self._lock:
            for record in self._records:
                if record.timestamp < since:
                    continue
                if entry_point_id and record.entry_point_id != entry_point_id:
                    continue
                results.append(record)
        
        return results
    
    def get_statistics(self) -> dict:
        """Get tracker statistics."""
        with self._lock:
            total = len(self._records)
            
            # Count by signal type
            by_type = {}
            for record in self._records:
                signal_type = record.signal_type.value
                by_type[signal_type] = by_type.get(signal_type, 0) + 1
            
            # Get time range
            if total > 0:
                oldest = self._records[0].timestamp
                newest = self._records[-1].timestamp
                span_sec = (newest - oldest).total_seconds()
            else:
                span_sec = 0
            
            return {
                'total_records': total,
                'by_signal_type': by_type,
                'time_span_sec': span_sec,
                'capacity': self.max_records
            }
    
    def clear(self) -> None:
        """Clear all records."""
        with self._lock:
            self._records.clear()
