#!/usr/bin/env python3
"""
摄像头连接测试脚本 (使用 reolink_aio)

用法:
    python3 test_camera_reolink_aio.py 10.0.0.155 admin PASSWORD
    python3 test_camera_reolink_aio.py 10.0.0.155 admin PASSWORD light_on
"""

import asyncio
import sys
import logging

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s'
)

async def test_camera(ip: str, user: str, password: str, command: str = "test"):
    """测试摄像头"""
    
    print("=" * 60)
    print(f"测试摄像头: {ip}")
    print(f"命令: {command}")
    print("=" * 60)
    
    try:
        from reolink_aio.api import Host
    except ImportError:
        print("❌ 请先安装 reolink-aio:")
        print("   pip install reolink-aio")
        return
    
    host = None
    try:
        # 连接
        print("\n[1] 连接中...")
        host = Host(ip, user, password)
        await host.get_host_data()
        
        model = host.camera_model(0)
        print(f"✅ 已连接: {model}")
        
        # 执行命令
        if command == "test":
            print("\n[2] 测试完成!")
        
        elif command == "light_on":
            print("\n[2] 开灯...")
            await host.set_whiteled(0, state=True)
            print("✅ 灯已开启")
        
        elif command == "light_off":
            print("\n[2] 关灯...")
            await host.set_whiteled(0, state=False)
            print("✅ 灯已关闭")
        
        elif command == "siren_on":
            print("\n[2] 开启警报...")
            await host.set_siren(0, True)
            print("✅ 警报已开启")
        
        elif command == "siren_off":
            print("\n[2] 关闭警报...")
            await host.set_siren(0, False)
            print("✅ 警报已关闭")
        
        elif command == "deterrent":
            print("\n[2] 启动威慑 (灯+警报)...")
            await host.set_whiteled(0, state=True)
            await host.set_siren(0, True)
            print("✅ 威慑已启动")
            
            print("等待 3 秒...")
            await asyncio.sleep(3)
            
            print("\n[3] 停止威慑...")
            await host.set_whiteled(0, state=False)
            await host.set_siren(0, False)
            print("✅ 威慑已停止")
        
        else:
            print(f"❌ 未知命令: {command}")
    
    except Exception as e:
        print(f"❌ 错误: {e}")
        import traceback
        traceback.print_exc()
    
    finally:
        if host:
            try:
                await host.logout()
            except:
                pass
    
    print("\n" + "=" * 60)


def main():
    if len(sys.argv) < 4:
        print("用法:")
        print("  python3 test_camera_reolink_aio.py <ip> <user> <password> [command]")
        print("")
        print("命令:")
        print("  test       - 测试连接 (默认)")
        print("  light_on   - 开灯")
        print("  light_off  - 关灯")
        print("  siren_on   - 开警报")
        print("  siren_off  - 关警报")
        print("  deterrent  - 威慑模式 (灯+警报)")
        print("")
        print("示例:")
        print("  python3 test_camera_reolink_aio.py 10.0.0.155 admin MyPassword")
        print("  python3 test_camera_reolink_aio.py 10.0.0.155 admin MyPassword light_on")
        return
    
    ip = sys.argv[1]
    user = sys.argv[2]
    password = sys.argv[3]
    command = sys.argv[4] if len(sys.argv) > 4 else "test"
    
    asyncio.run(test_camera(ip, user, password, command))


if __name__ == "__main__":
    main()
