"""
Cloud Client

HTTP client for NeighborGuard Cloud Server communication.
Handles:
- Device registration (pairing)
- Event ingest (future)
- Evidence upload (future)
"""

from typing import Optional, Dict, Any, Tuple
from dataclasses import dataclass
from datetime import datetime, timezone
import asyncio
import uuid

# aiohttp is optional dependency
try:
    import aiohttp
    HAS_AIOHTTP = True
except ImportError:
    HAS_AIOHTTP = False

from .config import CloudConfig, DeviceCredentials


@dataclass
class CloudResponse:
    """Standardized cloud API response."""
    success: bool
    status_code: int
    data: Optional[Dict[str, Any]] = None
    error_code: Optional[str] = None
    error_message: Optional[str] = None
    
    @property
    def is_retryable(self) -> bool:
        """Check if error is retryable (transient)."""
        if self.success:
            return False
        # Retryable: 408, 429, 5xx
        return self.status_code in (408, 429) or self.status_code >= 500


class CloudClient:
    """
    HTTP client for NeighborGuard Cloud Server.
    
    Usage:
        config = CloudConfig(server_url="http://localhost:3000")
        client = CloudClient(config)
        
        # Register device (requires user token)
        config.user_token = "your_jwt_token"
        result = await client.register_device(circle_id="...")
        
        # After registration, device_key is stored in config
        # Use for subsequent API calls
    """
    
    def __init__(self, config: CloudConfig):
        if not HAS_AIOHTTP:
            raise RuntimeError("aiohttp is required for CloudClient. Install with: pip install aiohttp")
        
        self.config = config
        self._session: Optional[aiohttp.ClientSession] = None
    
    async def _get_session(self) -> aiohttp.ClientSession:
        """Get or create aiohttp session."""
        if self._session is None or self._session.closed:
            timeout = aiohttp.ClientTimeout(total=self.config.timeout_sec)
            self._session = aiohttp.ClientSession(timeout=timeout)
        return self._session
    
    async def close(self):
        """Close the HTTP session."""
        if self._session and not self._session.closed:
            await self._session.close()
            self._session = None
    
    def _build_url(self, path: str) -> str:
        """Build full URL from path."""
        base = self.config.server_url.rstrip('/')
        return f"{base}{path}"
    
    async def _request(
        self,
        method: str,
        path: str,
        json_data: Optional[Dict] = None,
        auth_header: Optional[str] = None,
    ) -> CloudResponse:
        """Make HTTP request with error handling."""
        url = self._build_url(path)
        headers = {
            "Content-Type": "application/json",
            "User-Agent": f"NG-Edge/{self.config.software_version}",
        }
        
        if auth_header:
            headers["Authorization"] = auth_header
        
        session = await self._get_session()
        
        try:
            async with session.request(
                method,
                url,
                json=json_data,
                headers=headers,
            ) as response:
                status = response.status
                
                # Try to parse JSON response
                try:
                    data = await response.json()
                except:
                    data = {"raw": await response.text()}
                
                if status in (200, 201, 202):
                    return CloudResponse(
                        success=True,
                        status_code=status,
                        data=data,
                    )
                else:
                    # Extract error info from response
                    error_code = data.get("errorCode", data.get("error", "UNKNOWN"))
                    error_message = data.get("message", data.get("error", str(data)))
                    
                    return CloudResponse(
                        success=False,
                        status_code=status,
                        data=data,
                        error_code=error_code,
                        error_message=error_message,
                    )
        
        except asyncio.TimeoutError:
            return CloudResponse(
                success=False,
                status_code=408,
                error_code="TIMEOUT",
                error_message=f"Request timed out after {self.config.timeout_sec}s",
            )
        
        except aiohttp.ClientConnectorError as e:
            return CloudResponse(
                success=False,
                status_code=503,
                error_code="CONNECTION_ERROR",
                error_message=f"Cannot connect to server: {e}",
            )
        
        except Exception as e:
            return CloudResponse(
                success=False,
                status_code=500,
                error_code="CLIENT_ERROR",
                error_message=f"Client error: {e}",
            )
    
    # =========================================================================
    # Device Registration
    # =========================================================================
    
    async def register_device(
        self,
        circle_id: str,
        device_name: Optional[str] = None,
        ha_instance_id: Optional[str] = None,
    ) -> Tuple[bool, Optional[DeviceCredentials], Optional[str]]:
        """
        Register this edge device with the cloud server.
        
        Args:
            circle_id: The circle to join
            device_name: Optional device name (defaults to config)
            ha_instance_id: Optional HA instance ID (defaults to config or generates UUID)
        
        Returns:
            Tuple of (success, credentials, error_message)
            
        Note:
            Requires config.user_token to be set (Bearer JWT from user login)
        """
        if not self.config.user_auth_header:
            return False, None, "User token not set. Set config.user_token first."
        
        # Use provided values or fall back to config/defaults
        name = device_name or self.config.device_name
        # haInstanceId must match only ONE of the oneOf schemas in contract
        # Using "ha-xxx" format to match string pattern, not UUID pattern
        ha_id = ha_instance_id or self.config.ha_instance_id or f"ha-{uuid.uuid4().hex[:12]}"
        
        # Build request payload per contract schema
        payload = {
            "deviceName": name,
            "platform": "home_assistant",
            "haInstanceId": ha_id,
            "softwareVersion": self.config.software_version,
            "publicKey": self._generate_public_key(),
            "capabilities": self.config.capabilities,
        }
        
        path = f"/api/circles/{circle_id}/edge/devices"
        
        print(f"[CLOUD] Registering device to circle {circle_id}...")
        print(f"[CLOUD] POST {path}")
        print(f"[CLOUD] Payload: {payload}")
        
        response = await self._request(
            method="POST",
            path=path,
            json_data=payload,
            auth_header=self.config.user_auth_header,
        )
        
        if response.success and response.data:
            # Extract credentials from response
            credentials = DeviceCredentials(
                device_id=response.data["deviceId"],
                device_key=response.data["deviceKey"],
                circle_id=circle_id,
                paired_at=response.data.get("pairedAt", datetime.now(timezone.utc).isoformat()),
                device_name=name,
            )
            
            # Store in config
            self.config.credentials = credentials
            self.config.ha_instance_id = ha_id
            
            # Save to file
            self.config.save_credentials()
            
            print(f"[CLOUD] ✓ Device registered successfully!")
            print(f"[CLOUD]   device_id: {credentials.device_id}")
            print(f"[CLOUD]   circle_id: {credentials.circle_id}")
            
            return True, credentials, None
        else:
            error = response.error_message or f"HTTP {response.status_code}"
            print(f"[CLOUD] ✗ Registration failed: {error}")
            print(f"[CLOUD]   Status code: {response.status_code}")
            print(f"[CLOUD]   Error code: {response.error_code}")
            print(f"[CLOUD]   Full response: {response.data}")
            return False, None, error
    
    def _generate_public_key(self) -> str:
        """Generate a placeholder public key for registration."""
        # For now, just use a random string
        # In production, this would be a real public key
        return uuid.uuid4().hex
    
    # =========================================================================
    # Health Check
    # =========================================================================
    
    async def health_check(self) -> Tuple[bool, Optional[Dict], Optional[str]]:
        """
        Check server health.
        
        Returns:
            Tuple of (healthy, data, error_message)
        """
        response = await self._request(
            method="GET",
            path="/health",
        )
        
        if response.success:
            return True, response.data, None
        else:
            return False, None, response.error_message
    
    # =========================================================================
    # Event Ingest
    # =========================================================================
    
    async def ingest_event(
        self,
        event_payload: Dict[str, Any],
        idempotency_key: Optional[str] = None,
    ) -> Tuple[bool, Optional[Dict], Optional[str]]:
        """
        Ingest a security event to the cloud server.
        
        Args:
            event_payload: The event object matching events.ingest.request schema
            idempotency_key: Optional idempotency key (auto-generated if not provided)
        
        Returns:
            Tuple of (success, response_data, error_message)
            response_data contains: accepted, eventId, serverReceivedAt, deduped
            
        Note:
            Requires device to be registered (uses Device auth)
        """
        if not self.config.is_registered:
            return False, None, "Device not registered. Call register_device() first."
        
        if not self.config.device_auth_header:
            return False, None, "No device key available."
        
        circle_id = self.config.credentials.circle_id
        
        # Build request payload
        payload = {
            "idempotencyKey": idempotency_key or str(uuid.uuid4()),
            "event": event_payload,
        }
        
        path = f"/api/circles/{circle_id}/events/ingest"
        
        print(f"[CLOUD] Ingesting event {event_payload.get('eventId', 'unknown')}...")
        print(f"[CLOUD] POST {path}")
        
        response = await self._request(
            method="POST",
            path=path,
            json_data=payload,
            auth_header=self.config.device_auth_header,
        )
        
        if response.success and response.data:
            deduped = response.data.get("deduped", False)
            event_id = response.data.get("eventId")
            
            if deduped:
                print(f"[CLOUD] ✓ Event deduplicated (already exists): {event_id}")
            else:
                print(f"[CLOUD] ✓ Event ingested successfully: {event_id}")
            
            return True, response.data, None
        else:
            error = response.error_message or f"HTTP {response.status_code}"
            print(f"[CLOUD] ✗ Event ingest failed: {error}")
            print(f"[CLOUD]   Status code: {response.status_code}")
            print(f"[CLOUD]   Error code: {response.error_code}")
            print(f"[CLOUD]   Full response: {response.data}")
            return False, None, error
    
    async def ingest_event_from_bundle(
        self,
        bundle: "EdgeExportBundle",
    ) -> Tuple[bool, Optional[Dict], Optional[str]]:
        """
        Ingest event from an EdgeExportBundle.
        
        Converts the edge export format to cloud ingest format.
        
        Args:
            bundle: EdgeExportBundle from edge processing
            
        Returns:
            Tuple of (success, response_data, error_message)
        """
        # Convert bundle to cloud ingest format
        event_payload = self._bundle_to_ingest_payload(bundle)
        return await self.ingest_event(
            event_payload=event_payload,
            idempotency_key=bundle.idempotency_key,
        )
    
    def _bundle_to_ingest_payload(self, bundle: "EdgeExportBundle") -> Dict[str, Any]:
        """Convert EdgeExportBundle to cloud ingest event payload."""
        # Map edge format to cloud contract format
        event = {
            "eventId": bundle.event_id,
            "occurredAt": bundle.created_at,
            "eventType": self._map_event_type(bundle.event_type),
            "severity": self._map_severity(bundle.user_alert_level_peak),
            "notificationLevel": self._map_notification_level(bundle.user_alert_level),
            "status": "OPEN",
            "title": self._generate_event_title(bundle),
            "description": None,
            "explainSummary": {
                "ruleId": bundle.workflow_class or "UNKNOWN",
                "keySignals": [],  # TODO: populate from bundle
                "mode": bundle.house_mode.upper() if bundle.house_mode else "DISARMED",
            },
        }
        
        # Optional fields
        if bundle.primary_zone_id:
            event["zoneId"] = bundle.primary_zone_id
        if bundle.entry_point_id:
            event["entryPointId"] = bundle.entry_point_id
        if bundle.alarm_state:
            event["alarmState"] = bundle.alarm_state.upper()
        
        # Edge-specific fields
        event["edge_schema_version"] = bundle.edge_schema_version
        event["workflowClass"] = bundle.workflow_class
        event["mode"] = bundle.house_mode.lower() if bundle.house_mode else "disarmed"
        event["userAlertLevel"] = bundle.user_alert_level
        event["dispatchReadinessLevel"] = bundle.dispatch_readiness_local
        
        # AVS assessment
        if bundle.avs_level > 0 or bundle.avs_level_peak > 0:
            event["edgeAssessment"] = {
                "avs": {
                    "avs_final_level": bundle.avs_level,
                    "avs_peak_level": bundle.avs_level_peak,
                }
            }
        
        return event
    
    def _map_event_type(self, edge_type: str) -> str:
        """Map edge event type to contract EventType enum."""
        # Contract types: fire_detected, co_detected, water_leak_detected,
        # break_in_attempt, perimeter_damage, suspicious_person, suspicious_vehicle,
        # package_delivered, package_removed, motion_detected
        mapping = {
            "intrusion": "break_in_attempt",
            "break_in": "break_in_attempt",
            "break_in_attempt": "break_in_attempt",
            "perimeter": "perimeter_damage",
            "perimeter_damage": "perimeter_damage",
            "suspicious_person": "suspicious_person",
            "suspicious_vehicle": "suspicious_vehicle",
            "motion": "motion_detected",
            "motion_detected": "motion_detected",
            "fire": "fire_detected",
            "fire_detected": "fire_detected",
            "package": "package_delivered",
            "package_delivered": "package_delivered",
        }
        return mapping.get(edge_type.lower(), "motion_detected")
    
    def _map_severity(self, alert_level: int) -> str:
        """Map user alert level to severity."""
        if alert_level >= 3:
            return "HIGH"
        elif alert_level >= 2:
            return "MEDIUM"
        else:
            return "LOW"
    
    def _map_notification_level(self, alert_level: int) -> str:
        """Map user alert level to notification level."""
        if alert_level >= 2:
            return "HIGH"
        elif alert_level >= 1:
            return "NORMAL"
        else:
            return "NONE"
    
    def _generate_event_title(self, bundle: "EdgeExportBundle") -> str:
        """Generate event title from bundle."""
        event_type = bundle.event_type or "Event"
        mode = bundle.house_mode or "unknown"
        return f"{event_type.replace('_', ' ').title()} detected ({mode} mode)"
    
    # =========================================================================
    # Status
    # =========================================================================
    
    def get_status(self) -> Dict[str, Any]:
        """Get client status."""
        return {
            "server_url": self.config.server_url,
            "is_registered": self.config.is_registered,
            "device_id": self.config.credentials.device_id if self.config.credentials else None,
            "circle_id": self.config.credentials.circle_id if self.config.credentials else None,
            "has_user_token": self.config.user_token is not None,
            "has_device_key": self.config.device_auth_header is not None,
        }
