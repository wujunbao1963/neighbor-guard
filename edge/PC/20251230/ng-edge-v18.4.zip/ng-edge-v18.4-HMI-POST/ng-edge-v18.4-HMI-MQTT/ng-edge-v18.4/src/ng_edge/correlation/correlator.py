"""
Signal Correlator

信号关联层 (v2.2 §2)

职责：
1. 将信号聚合到 IncidentCandidate
2. 管理 Lease (home_id, zone_id, entrypoint_id)
3. 处理 Split/Merge 规则
4. 纯聚合，不做状态决策
"""

from dataclasses import dataclass, field
from datetime import datetime, timezone, timedelta
from typing import Dict, Optional, List, Set, Callable
import uuid

from ng_edge.core.signal import SignalEnvelope, Hardness


@dataclass
class CorrelatorConfig:
    """关联器配置"""
    # 聚合窗口
    pre_aggregation_window_sec: int = 60     # Soft 信号聚合窗口
    hard_association_window_sec: int = 30    # Hard 信号关联窗口
    
    # Incident 活跃窗口
    incident_active_window_sec: int = 300    # 5分钟内无信号则关闭
    
    # Lease 配置
    max_incidents_per_zone: int = 3          # 每个 zone 最多同时 incidents


@dataclass
class Lease:
    """
    Lease 标识 (v2.2 §2.2)
    
    唯一标识一个 Incident 的归属
    """
    home_id: str = "default"
    zone_id: str = ""
    entrypoint_id: Optional[str] = None
    
    def matches(self, signal: SignalEnvelope) -> bool:
        """检查信号是否匹配此 Lease"""
        if self.zone_id and signal.zone_id != self.zone_id:
            return False
        if self.entrypoint_id and signal.entrypoint_id != self.entrypoint_id:
            return False
        return True
    
    def __hash__(self):
        return hash((self.home_id, self.zone_id, self.entrypoint_id))
    
    def __eq__(self, other):
        if not isinstance(other, Lease):
            return False
        return (self.home_id == other.home_id and 
                self.zone_id == other.zone_id and 
                self.entrypoint_id == other.entrypoint_id)


@dataclass
class IncidentCandidate:
    """
    事件候选 (v2.2 §2.3)
    
    关联层维护的聚合结构，不包含状态决策
    """
    candidate_id: str
    lease: Lease
    
    # 信号集合
    signal_ids: List[str] = field(default_factory=list)
    soft_signals: List[SignalEnvelope] = field(default_factory=list)
    hard_signals: List[SignalEnvelope] = field(default_factory=list)
    
    # 时间
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    last_signal_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    
    # Context Gates (从 ContextGateManager 同步)
    active_context_gates: List[str] = field(default_factory=list)  # gate_ids
    
    # 状态（由 Correlator 维护）
    is_active: bool = True
    promoted_to_incident: bool = False
    incident_id: Optional[str] = None  # 如果已提升为 Incident
    
    def add_signal(self, signal: SignalEnvelope):
        """添加信号"""
        if signal.signal_id not in self.signal_ids:
            self.signal_ids.append(signal.signal_id)
            
            if signal.is_hard():
                self.hard_signals.append(signal)
            else:
                self.soft_signals.append(signal)
            
            self.last_signal_at = signal.ingest_ts
    
    def signal_count(self) -> int:
        """信号总数"""
        return len(self.signal_ids)
    
    def has_hard_signal(self) -> bool:
        """是否有 Hard 信号"""
        return len(self.hard_signals) > 0


class SignalCorrelator:
    """
    信号关联器
    
    使用方式:
        correlator = SignalCorrelator()
        
        # 处理信号
        candidate = correlator.correlate(signal)
        
        # 检查是否需要创建 Incident
        if candidate.has_hard_signal():
            # 提升为 Incident
            pass
    """
    
    def __init__(self, config: Optional[CorrelatorConfig] = None):
        self.config = config or CorrelatorConfig()
        
        # 活跃的候选: candidate_id → IncidentCandidate
        self._candidates: Dict[str, IncidentCandidate] = {}
        
        # Lease 索引: Lease → candidate_id
        self._lease_index: Dict[Lease, str] = {}
        
        # 信号去重: signal_id → candidate_id
        self._signal_index: Dict[str, str] = {}
        
        # 回调
        self.on_candidate_created: Optional[Callable[[IncidentCandidate], None]] = None
        self.on_candidate_updated: Optional[Callable[[IncidentCandidate], None]] = None
        self.on_candidate_closed: Optional[Callable[[IncidentCandidate], None]] = None
        
        # 统计
        self.stats = {
            "signals_processed": 0,
            "signals_deduplicated": 0,
            "candidates_created": 0,
            "candidates_merged": 0,
            "candidates_closed": 0,
        }
        
        # ID 计数器
        self._candidate_counter = 0
    
    def correlate(self, signal: SignalEnvelope) -> IncidentCandidate:
        """
        关联信号到 IncidentCandidate
        
        这是主要入口点。
        
        Args:
            signal: 输入信号
            
        Returns:
            IncidentCandidate: 关联到的候选（新建或现有）
        """
        self.stats["signals_processed"] += 1
        
        # 信号去重
        if signal.signal_id in self._signal_index:
            self.stats["signals_deduplicated"] += 1
            candidate_id = self._signal_index[signal.signal_id]
            return self._candidates[candidate_id]
        
        # 查找匹配的 Lease
        lease = self._create_lease(signal)
        
        # 查找现有候选
        candidate = self._find_candidate(lease, signal)
        
        if candidate:
            # 添加到现有候选
            candidate.add_signal(signal)
            self._signal_index[signal.signal_id] = candidate.candidate_id
            
            if self.on_candidate_updated:
                self.on_candidate_updated(candidate)
        else:
            # 创建新候选
            candidate = self._create_candidate(lease, signal)
        
        return candidate
    
    def get_candidate(self, candidate_id: str) -> Optional[IncidentCandidate]:
        """获取候选"""
        return self._candidates.get(candidate_id)
    
    def get_candidate_by_lease(self, lease: Lease) -> Optional[IncidentCandidate]:
        """通过 Lease 获取候选"""
        candidate_id = self._lease_index.get(lease)
        if candidate_id:
            return self._candidates.get(candidate_id)
        return None
    
    def get_active_candidates(self, zone_id: str = None) -> List[IncidentCandidate]:
        """获取活跃的候选"""
        result = []
        for candidate in self._candidates.values():
            if candidate.is_active:
                if zone_id is None or candidate.lease.zone_id == zone_id:
                    result.append(candidate)
        return result
    
    def promote_to_incident(self, candidate_id: str, incident_id: str):
        """
        标记候选已提升为 Incident
        
        Args:
            candidate_id: 候选 ID
            incident_id: 创建的 Incident ID
        """
        candidate = self._candidates.get(candidate_id)
        if candidate:
            candidate.promoted_to_incident = True
            candidate.incident_id = incident_id
    
    def close_candidate(self, candidate_id: str, reason: str = ""):
        """
        关闭候选
        
        Args:
            candidate_id: 候选 ID
            reason: 关闭原因
        """
        candidate = self._candidates.get(candidate_id)
        if candidate and candidate.is_active:
            candidate.is_active = False
            self.stats["candidates_closed"] += 1
            
            # 从 Lease 索引中移除
            if candidate.lease in self._lease_index:
                del self._lease_index[candidate.lease]
            
            if self.on_candidate_closed:
                self.on_candidate_closed(candidate)
    
    def cleanup_inactive(self, max_age_sec: int = None) -> List[IncidentCandidate]:
        """
        清理不活跃的候选
        
        Args:
            max_age_sec: 最大不活跃时间（秒），默认使用配置
            
        Returns:
            List[IncidentCandidate]: 被清理的候选
        """
        max_age = max_age_sec or self.config.incident_active_window_sec
        now = datetime.now(timezone.utc)
        threshold = now - timedelta(seconds=max_age)
        
        closed = []
        for candidate_id, candidate in list(self._candidates.items()):
            if candidate.is_active and candidate.last_signal_at < threshold:
                self.close_candidate(candidate_id, "inactive_timeout")
                closed.append(candidate)
        
        return closed
    
    def get_stats(self) -> Dict:
        """获取统计信息"""
        active_count = sum(1 for c in self._candidates.values() if c.is_active)
        
        return {
            **self.stats,
            "active_candidates": active_count,
            "total_candidates": len(self._candidates),
        }
    
    # =========================================================================
    # 内部方法
    # =========================================================================
    
    def _create_lease(self, signal: SignalEnvelope) -> Lease:
        """根据信号创建 Lease"""
        return Lease(
            home_id="default",  # 目前单 home
            zone_id=signal.zone_id,
            entrypoint_id=signal.entrypoint_id,
        )
    
    def _find_candidate(self, lease: Lease, signal: SignalEnvelope) -> Optional[IncidentCandidate]:
        """
        查找匹配的候选
        
        规则：
        1. 精确 Lease 匹配
        2. 在聚合窗口内
        """
        # 精确匹配
        candidate_id = self._lease_index.get(lease)
        if candidate_id:
            candidate = self._candidates.get(candidate_id)
            if candidate and candidate.is_active:
                # 检查时间窗口
                window = (self.config.hard_association_window_sec 
                         if signal.is_hard() 
                         else self.config.pre_aggregation_window_sec)
                
                time_diff = (signal.ingest_ts - candidate.last_signal_at).total_seconds()
                
                if time_diff <= window:
                    return candidate
        
        # 如果 entrypoint 不匹配，尝试 zone 级别匹配
        if lease.entrypoint_id:
            zone_lease = Lease(
                home_id=lease.home_id,
                zone_id=lease.zone_id,
                entrypoint_id=None,
            )
            candidate_id = self._lease_index.get(zone_lease)
            if candidate_id:
                candidate = self._candidates.get(candidate_id)
                if candidate and candidate.is_active:
                    return candidate
        
        return None
    
    def _create_candidate(self, lease: Lease, signal: SignalEnvelope) -> IncidentCandidate:
        """创建新候选"""
        self._candidate_counter += 1
        candidate_id = f"cand_{self._candidate_counter:06d}"
        
        candidate = IncidentCandidate(
            candidate_id=candidate_id,
            lease=lease,
            created_at=signal.ingest_ts,
            last_signal_at=signal.ingest_ts,
        )
        candidate.add_signal(signal)
        
        self._candidates[candidate_id] = candidate
        self._lease_index[lease] = candidate_id
        self._signal_index[signal.signal_id] = candidate_id
        
        self.stats["candidates_created"] += 1
        
        if self.on_candidate_created:
            self.on_candidate_created(candidate)
        
        return candidate
