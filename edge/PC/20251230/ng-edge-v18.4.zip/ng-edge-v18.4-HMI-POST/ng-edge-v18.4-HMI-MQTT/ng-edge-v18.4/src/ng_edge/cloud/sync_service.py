"""
Cloud Sync Service

Background service for edge-to-cloud synchronization:
- Heartbeat: Check server health periodically
- Topology sync: Send topology updates to server
- Event forwarding: Send events to cloud when generated

Usage:
    from ng_edge.cloud.sync_service import CloudSyncService
    
    sync = CloudSyncService(config)
    await sync.start()
    
    # When event is generated:
    await sync.forward_event(event_payload)
    
    # On shutdown:
    await sync.stop()
"""

import asyncio
from typing import Optional, Dict, Any, Callable, List
from datetime import datetime, timezone
from dataclasses import dataclass, field
import uuid

from .config import CloudConfig
from .client import CloudClient


@dataclass
class SyncStats:
    """Statistics for sync service."""
    heartbeat_success: int = 0
    heartbeat_failure: int = 0
    last_heartbeat: Optional[datetime] = None
    last_heartbeat_ok: bool = False
    
    topo_sync_success: int = 0
    topo_sync_failure: int = 0
    last_topo_sync: Optional[datetime] = None
    
    events_forwarded: int = 0
    events_failed: int = 0
    events_queued: int = 0


class CloudSyncService:
    """
    Background service for cloud synchronization.
    
    Features:
    - Periodic heartbeat to check server health
    - Periodic topology sync
    - Event forwarding with local queue for failures
    """
    
    def __init__(
        self,
        config: CloudConfig,
        heartbeat_interval_sec: float = 30.0,
        topo_sync_interval_sec: float = 300.0,  # 5 minutes
        event_queue_size: int = 100,
    ):
        self.config = config
        self.client = CloudClient(config)
        
        self.heartbeat_interval = heartbeat_interval_sec
        self.topo_sync_interval = topo_sync_interval_sec
        self.event_queue_size = event_queue_size
        
        self.stats = SyncStats()
        self._running = False
        self._heartbeat_task: Optional[asyncio.Task] = None
        self._topo_task: Optional[asyncio.Task] = None
        self._event_queue: List[Dict[str, Any]] = []
        
        # Callbacks
        self._on_heartbeat: Optional[Callable[[bool], None]] = None
        self._on_connection_lost: Optional[Callable[[], None]] = None
        self._on_connection_restored: Optional[Callable[[], None]] = None
        
        # Topology provider (set externally)
        self._topo_provider: Optional[Callable[[], Dict[str, Any]]] = None
        
        # Connection state tracking
        self._was_connected = False
        self._consecutive_failures = 0
    
    # =========================================================================
    # Lifecycle
    # =========================================================================
    
    async def start(self):
        """Start the sync service."""
        if self._running:
            print("[SYNC] Service already running")
            return
        
        if not self.config.is_registered:
            print("[SYNC] Warning: Device not registered, loading credentials...")
            if not self.config.load_credentials():
                print("[SYNC] ERROR: No credentials available. Register device first.")
                return
        
        self._running = True
        print(f"[SYNC] Starting cloud sync service")
        print(f"[SYNC]   Server: {self.config.server_url}")
        print(f"[SYNC]   Device: {self.config.credentials.device_id}")
        print(f"[SYNC]   Heartbeat interval: {self.heartbeat_interval}s")
        print(f"[SYNC]   Topo sync interval: {self.topo_sync_interval}s")
        
        # Start background tasks
        self._heartbeat_task = asyncio.create_task(self._heartbeat_loop())
        self._topo_task = asyncio.create_task(self._topo_sync_loop())
        
        print("[SYNC] Service started")
    
    async def stop(self):
        """Stop the sync service."""
        if not self._running:
            return
        
        print("[SYNC] Stopping cloud sync service...")
        self._running = False
        
        # Cancel tasks
        if self._heartbeat_task:
            self._heartbeat_task.cancel()
            try:
                await self._heartbeat_task
            except asyncio.CancelledError:
                pass
        
        if self._topo_task:
            self._topo_task.cancel()
            try:
                await self._topo_task
            except asyncio.CancelledError:
                pass
        
        # Close client
        await self.client.close()
        
        print("[SYNC] Service stopped")
    
    # =========================================================================
    # Heartbeat
    # =========================================================================
    
    async def _heartbeat_loop(self):
        """Background heartbeat loop."""
        while self._running:
            try:
                await self._do_heartbeat()
            except Exception as e:
                print(f"[SYNC] Heartbeat error: {e}")
            
            await asyncio.sleep(self.heartbeat_interval)
    
    async def _do_heartbeat(self):
        """Perform a single heartbeat check."""
        healthy, data, error = await self.client.health_check()
        
        self.stats.last_heartbeat = datetime.now(timezone.utc)
        self.stats.last_heartbeat_ok = healthy
        
        if healthy:
            self.stats.heartbeat_success += 1
            self._consecutive_failures = 0
            
            # Check for connection restored
            if not self._was_connected:
                self._was_connected = True
                print(f"[SYNC] ✓ Server connected: {data}")
                if self._on_connection_restored:
                    self._on_connection_restored()
                # Retry queued events
                await self._retry_queued_events()
        else:
            self.stats.heartbeat_failure += 1
            self._consecutive_failures += 1
            
            # Check for connection lost (after 3 consecutive failures)
            if self._was_connected and self._consecutive_failures >= 3:
                self._was_connected = False
                print(f"[SYNC] ✗ Server connection lost: {error}")
                if self._on_connection_lost:
                    self._on_connection_lost()
            elif not self._was_connected:
                print(f"[SYNC] ✗ Heartbeat failed: {error}")
        
        if self._on_heartbeat:
            self._on_heartbeat(healthy)
    
    # =========================================================================
    # Topology Sync
    # =========================================================================
    
    def set_topology_provider(self, provider: Callable[[], Dict[str, Any]]):
        """Set the function that provides current topology."""
        self._topo_provider = provider
    
    async def _topo_sync_loop(self):
        """Background topology sync loop."""
        # Wait a bit before first sync
        await asyncio.sleep(10)
        
        while self._running:
            try:
                await self._do_topo_sync()
            except Exception as e:
                print(f"[SYNC] Topo sync error: {e}")
            
            await asyncio.sleep(self.topo_sync_interval)
    
    async def _do_topo_sync(self):
        """Perform topology sync."""
        if not self._topo_provider:
            # No topology provider set, skip
            return
        
        if not self._was_connected:
            # Server not available, skip
            return
        
        try:
            topo = self._topo_provider()
            if not topo:
                return
            
            success, error = await self._send_topology(topo)
            
            self.stats.last_topo_sync = datetime.now(timezone.utc)
            
            if success:
                self.stats.topo_sync_success += 1
                print(f"[SYNC] ✓ Topology synced")
            else:
                self.stats.topo_sync_failure += 1
                print(f"[SYNC] ✗ Topo sync failed: {error}")
        
        except Exception as e:
            self.stats.topo_sync_failure += 1
            print(f"[SYNC] ✗ Topo sync error: {e}")
    
    async def _send_topology(self, topo: Dict[str, Any]) -> tuple[bool, Optional[str]]:
        """Send topology to server."""
        if not self.config.is_registered:
            return False, "Not registered"
        
        circle_id = self.config.credentials.circle_id
        device_id = self.config.credentials.device_id
        
        # Try PUT to device topomap endpoint
        path = f"/api/circles/{circle_id}/edge/devices/{device_id}/topomap"
        
        response = await self.client._request(
            method="PUT",
            path=path,
            json_data=topo,
            auth_header=self.config.device_auth_header,
        )
        
        if response.success:
            return True, None
        else:
            # If PUT fails with 404, endpoint might not exist yet
            # That's OK for MVP, just log and continue
            if response.status_code == 404:
                return True, None  # Silently succeed if endpoint doesn't exist
            return False, response.error_message
    
    async def sync_topology_now(self):
        """Force an immediate topology sync."""
        await self._do_topo_sync()
    
    # =========================================================================
    # Event Forwarding
    # =========================================================================
    
    async def forward_event(self, event_payload: Dict[str, Any]) -> bool:
        """
        Forward an event to the cloud server.
        
        Args:
            event_payload: Event dict matching events.ingest.request schema
            
        Returns:
            True if sent successfully, False if queued for retry
        """
        if not self.config.is_registered:
            print("[SYNC] Cannot forward event: not registered")
            return False
        
        # If server not available, queue for later
        if not self._was_connected:
            self._queue_event(event_payload)
            return False
        
        # Try to send
        success, data, error = await self.client.ingest_event(event_payload)
        
        if success:
            self.stats.events_forwarded += 1
            deduped = data.get("deduped", False) if data else False
            if not deduped:
                print(f"[SYNC] ✓ Event forwarded: {event_payload.get('eventId', 'unknown')}")
            return True
        else:
            self.stats.events_failed += 1
            print(f"[SYNC] ✗ Event forward failed: {error}")
            
            # Queue for retry if it's a transient error
            if self._is_retryable_error(error):
                self._queue_event(event_payload)
            
            return False
    
    def _queue_event(self, event_payload: Dict[str, Any]):
        """Add event to retry queue."""
        if len(self._event_queue) >= self.event_queue_size:
            # Queue full, drop oldest
            dropped = self._event_queue.pop(0)
            print(f"[SYNC] Queue full, dropped event: {dropped.get('eventId', 'unknown')}")
        
        self._event_queue.append(event_payload)
        self.stats.events_queued = len(self._event_queue)
        print(f"[SYNC] Event queued for retry (queue size: {len(self._event_queue)})")
    
    async def _retry_queued_events(self):
        """Retry events in the queue."""
        if not self._event_queue:
            return
        
        print(f"[SYNC] Retrying {len(self._event_queue)} queued events...")
        
        # Copy and clear queue
        events_to_retry = self._event_queue.copy()
        self._event_queue.clear()
        self.stats.events_queued = 0
        
        for event in events_to_retry:
            success, _, _ = await self.client.ingest_event(event)
            if success:
                self.stats.events_forwarded += 1
            else:
                # Re-queue if still failing
                self._event_queue.append(event)
        
        self.stats.events_queued = len(self._event_queue)
        
        if self._event_queue:
            print(f"[SYNC] {len(self._event_queue)} events still queued")
        else:
            print(f"[SYNC] All queued events sent")
    
    def _is_retryable_error(self, error: Optional[str]) -> bool:
        """Check if error should trigger retry."""
        if not error:
            return True
        error_lower = error.lower()
        # Don't retry validation errors
        if "validation" in error_lower:
            return False
        if "invalid" in error_lower:
            return False
        return True
    
    # =========================================================================
    # Callbacks
    # =========================================================================
    
    def on_heartbeat(self, callback: Callable[[bool], None]):
        """Set callback for heartbeat results."""
        self._on_heartbeat = callback
    
    def on_connection_lost(self, callback: Callable[[], None]):
        """Set callback for when connection is lost."""
        self._on_connection_lost = callback
    
    def on_connection_restored(self, callback: Callable[[], None]):
        """Set callback for when connection is restored."""
        self._on_connection_restored = callback
    
    # =========================================================================
    # Status
    # =========================================================================
    
    def get_status(self) -> Dict[str, Any]:
        """Get sync service status."""
        return {
            "running": self._running,
            "connected": self._was_connected,
            "server_url": self.config.server_url,
            "device_id": self.config.credentials.device_id if self.config.credentials else None,
            "heartbeat": {
                "interval_sec": self.heartbeat_interval,
                "success_count": self.stats.heartbeat_success,
                "failure_count": self.stats.heartbeat_failure,
                "last_check": self.stats.last_heartbeat.isoformat() if self.stats.last_heartbeat else None,
                "last_ok": self.stats.last_heartbeat_ok,
            },
            "topo_sync": {
                "interval_sec": self.topo_sync_interval,
                "success_count": self.stats.topo_sync_success,
                "failure_count": self.stats.topo_sync_failure,
                "last_sync": self.stats.last_topo_sync.isoformat() if self.stats.last_topo_sync else None,
            },
            "events": {
                "forwarded": self.stats.events_forwarded,
                "failed": self.stats.events_failed,
                "queued": self.stats.events_queued,
            },
        }
    
    @property
    def is_connected(self) -> bool:
        """Check if currently connected to server."""
        return self._was_connected
