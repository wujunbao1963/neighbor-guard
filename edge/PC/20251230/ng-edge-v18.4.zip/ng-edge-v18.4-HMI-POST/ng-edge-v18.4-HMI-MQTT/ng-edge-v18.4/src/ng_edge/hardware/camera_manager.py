"""
Camera Management API for NeighborGuard EDGE v18.4

功能:
1. 摄像头配置管理（添加/删除/列表）
2. RTSP连接测试
3. 声光控制 (Siren/Spotlight)
4. 威慑模式 (Deterrent)
5. 与报警状态机集成
"""

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Optional, Dict, List, Any
from datetime import datetime, timezone
from enum import Enum
import threading
import asyncio
import json
import os
from pathlib import Path

router = APIRouter(prefix="/api/cameras", tags=["cameras"])


# =============================================================================
# 数据模型
# =============================================================================

class CameraTier(str, Enum):
    TIER_0 = "tier_0"  # 无摄像头
    TIER_1 = "tier_1"  # 单摄像头
    TIER_2 = "tier_2"  # 双摄像头


class CameraStatus(str, Enum):
    UNKNOWN = "unknown"
    ONLINE = "online"
    OFFLINE = "offline"
    CONNECTING = "connecting"
    ERROR = "error"


class CameraAddRequest(BaseModel):
    name: str
    ip: str
    port: int = 80
    username: str = "admin"
    password: str = ""
    model: str = ""
    entry_point_id: Optional[str] = None
    zone_id: Optional[str] = None


class DeterrentRequest(BaseModel):
    brightness: int = 100
    siren_times: int = 3


# =============================================================================
# 摄像头管理器
# =============================================================================

class CameraManager:
    """摄像头管理器"""
    
    DATA_DIR = Path(__file__).parent.parent.parent / "data"
    DATA_FILE = DATA_DIR / "cameras.json"
    
    def __init__(self):
        self.cameras: Dict[str, Dict[str, Any]] = {}
        self.status: Dict[str, CameraStatus] = {}
        self.capabilities: Dict[str, List[str]] = {}
        self.last_seen: Dict[str, datetime] = {}
        
        self._load()
    
    def _load(self):
        """加载摄像头配置"""
        try:
            if self.DATA_FILE.exists():
                with open(self.DATA_FILE, 'r') as f:
                    data = json.load(f)
                    self.cameras = data.get("cameras", {})
                    print(f"[CameraManager] 加载了 {len(self.cameras)} 个摄像头")
        except Exception as e:
            print(f"[CameraManager] 加载失败: {e}")
            self.cameras = {}
    
    def _save(self):
        """保存摄像头配置"""
        try:
            self.DATA_DIR.mkdir(parents=True, exist_ok=True)
            with open(self.DATA_FILE, 'w') as f:
                json.dump({
                    "cameras": self.cameras, 
                    "saved_at": datetime.now(timezone.utc).isoformat()
                }, f, indent=2)
        except Exception as e:
            print(f"[CameraManager] 保存失败: {e}")
    
    def add_camera(self, config: CameraAddRequest) -> str:
        """添加摄像头"""
        camera_id = f"cam_{config.ip.replace('.', '_')}"
        
        self.cameras[camera_id] = {
            "camera_id": camera_id,
            "name": config.name,
            "ip": config.ip,
            "port": config.port,
            "username": config.username,
            "password": config.password,
            "model": config.model,
            "entry_point_id": config.entry_point_id,
            "zone_id": config.zone_id,
            "added_at": datetime.now(timezone.utc).isoformat(),
        }
        
        self.status[camera_id] = CameraStatus.UNKNOWN
        self._save()
        
        print(f"[CameraManager] 添加摄像头: {config.name} ({config.ip})")
        return camera_id
    
    def remove_camera(self, camera_id: str) -> bool:
        """删除摄像头"""
        if camera_id in self.cameras:
            del self.cameras[camera_id]
            self.status.pop(camera_id, None)
            self.capabilities.pop(camera_id, None)
            self.last_seen.pop(camera_id, None)
            self._save()
            return True
        return False
    
    def list_cameras(self) -> List[Dict[str, Any]]:
        """列出所有摄像头"""
        result = []
        for cam_id, cam in self.cameras.items():
            cam_info = cam.copy()
            cam_info["status"] = self.status.get(cam_id, CameraStatus.UNKNOWN).value
            cam_info["capabilities"] = self.capabilities.get(cam_id, [])
            last_seen = self.last_seen.get(cam_id)
            cam_info["last_seen"] = last_seen.isoformat() if last_seen else None
            result.append(cam_info)
        return result
    
    def get_camera(self, camera_id: str) -> Optional[Dict[str, Any]]:
        """获取摄像头信息"""
        if camera_id in self.cameras:
            cam = self.cameras[camera_id].copy()
            cam["status"] = self.status.get(camera_id, CameraStatus.UNKNOWN).value
            cam["capabilities"] = self.capabilities.get(camera_id, [])
            return cam
        return None
    
    def _get_controller(self, camera_id: str):
        """获取摄像头控制器"""
        from .reolink_control import ReolinkCameraControl, CameraConnection
        
        cam = self.cameras.get(camera_id)
        if not cam:
            return None
        
        conn = CameraConnection(
            ip=cam["ip"],
            port=cam.get("port", 80),
            username=cam.get("username", "admin"),
            password=cam.get("password", ""),
        )
        return ReolinkCameraControl(conn)
    
    async def test_connection(self, camera_id: str) -> Dict[str, Any]:
        """测试摄像头连接并检测能力"""
        ctrl = self._get_controller(camera_id)
        if not ctrl:
            return {"success": False, "error": "Camera not found"}
        
        try:
            result = await ctrl.test_connection()
            
            if result["success"]:
                self.status[camera_id] = CameraStatus.ONLINE
                self.capabilities[camera_id] = result.get("capabilities", [])
                self.last_seen[camera_id] = datetime.now(timezone.utc)
                
                # 更新摄像头信息
                if "device" in result:
                    device = result["device"]
                    self.cameras[camera_id]["model"] = device.get("model", "")
                    self.cameras[camera_id]["firmware"] = device.get("firmware", "")
                    self._save()
            else:
                self.status[camera_id] = CameraStatus.OFFLINE
            
            return result
        finally:
            await ctrl.close()
    
    async def siren_on(self, camera_id: str, times: int = 2) -> Dict[str, Any]:
        """开启警报器"""
        ctrl = self._get_controller(camera_id)
        if not ctrl:
            return {"success": False, "error": "Camera not found"}
        
        try:
            result = await ctrl.siren_on(times)
            print(f"[CameraManager] Siren ON: {camera_id} -> {result}")
            return result
        finally:
            await ctrl.close()
    
    async def siren_off(self, camera_id: str) -> Dict[str, Any]:
        """关闭警报器"""
        ctrl = self._get_controller(camera_id)
        if not ctrl:
            return {"success": False, "error": "Camera not found"}
        
        try:
            result = await ctrl.siren_off()
            print(f"[CameraManager] Siren OFF: {camera_id} -> {result}")
            return result
        finally:
            await ctrl.close()
    
    async def spotlight_on(self, camera_id: str, brightness: int = 100) -> Dict[str, Any]:
        """开启LED灯"""
        ctrl = self._get_controller(camera_id)
        if not ctrl:
            return {"success": False, "error": "Camera not found"}
        
        try:
            result = await ctrl.spotlight_on(brightness)
            print(f"[CameraManager] Spotlight ON: {camera_id} -> {result}")
            return result
        finally:
            await ctrl.close()
    
    async def spotlight_off(self, camera_id: str) -> Dict[str, Any]:
        """关闭LED灯"""
        ctrl = self._get_controller(camera_id)
        if not ctrl:
            return {"success": False, "error": "Camera not found"}
        
        try:
            result = await ctrl.spotlight_off()
            print(f"[CameraManager] Spotlight OFF: {camera_id} -> {result}")
            return result
        finally:
            await ctrl.close()
    
    async def deterrent_start(self, camera_id: str, brightness: int = 100, siren_times: int = 3) -> Dict[str, Any]:
        """启动威慑模式 (声光齐发)"""
        ctrl = self._get_controller(camera_id)
        if not ctrl:
            return {"success": False, "error": "Camera not found"}
        
        try:
            result = await ctrl.deterrent_start(brightness, siren_times)
            print(f"[CameraManager] ⚡ Deterrent START: {camera_id} -> {result}")
            return result
        finally:
            await ctrl.close()
    
    async def deterrent_stop(self, camera_id: str) -> Dict[str, Any]:
        """停止威慑模式"""
        ctrl = self._get_controller(camera_id)
        if not ctrl:
            return {"success": False, "error": "Camera not found"}
        
        try:
            result = await ctrl.deterrent_stop()
            print(f"[CameraManager] Deterrent STOP: {camera_id} -> {result}")
            return result
        finally:
            await ctrl.close()
    
    async def deterrent_all(self, brightness: int = 100, siren_times: int = 3) -> Dict[str, Any]:
        """所有摄像头启动威慑模式"""
        results = {}
        for cam_id in self.cameras.keys():
            # 对所有摄像头尝试（不管状态）
            results[cam_id] = await self.deterrent_start(cam_id, brightness, siren_times)
        
        success_count = sum(1 for r in results.values() if r.get("success"))
        return {
            "success": success_count > 0,
            "total": len(results),
            "success_count": success_count,
            "results": results,
        }
    
    async def deterrent_stop_all(self) -> Dict[str, Any]:
        """所有摄像头停止威慑模式"""
        results = {}
        for cam_id in self.cameras.keys():
            results[cam_id] = await self.deterrent_stop(cam_id)
        
        return {"success": True, "results": results}
    
    def get_camera_tier(self) -> CameraTier:
        """获取当前摄像头能力层级"""
        online_cameras = [
            cam_id for cam_id, status in self.status.items()
            if status == CameraStatus.ONLINE
        ]
        
        if len(online_cameras) == 0:
            return CameraTier.TIER_0
        elif len(online_cameras) == 1:
            return CameraTier.TIER_1
        else:
            return CameraTier.TIER_2
    
    def get_online_cameras(self) -> List[str]:
        """获取在线摄像头列表"""
        return [
            cam_id for cam_id, status in self.status.items()
            if status == CameraStatus.ONLINE
        ]
    
    def get_cameras_with_capability(self, capability: str) -> List[str]:
        """获取具有指定能力的摄像头"""
        return [
            cam_id for cam_id, caps in self.capabilities.items()
            if capability in caps and self.status.get(cam_id) == CameraStatus.ONLINE
        ]


# 全局实例
_camera_manager: Optional[CameraManager] = None


def get_camera_manager() -> CameraManager:
    global _camera_manager
    if _camera_manager is None:
        _camera_manager = CameraManager()
    return _camera_manager


# =============================================================================
# API 端点
# =============================================================================

@router.get("")
async def list_cameras():
    """列出所有摄像头"""
    manager = get_camera_manager()
    cameras = manager.list_cameras()
    tier = manager.get_camera_tier()
    
    return {
        "success": True,
        "cameras": cameras,
        "count": len(cameras),
        "camera_tier": tier.value,
    }


@router.post("")
async def add_camera(request: CameraAddRequest):
    """添加摄像头"""
    manager = get_camera_manager()
    camera_id = manager.add_camera(request)
    
    return {
        "success": True,
        "camera_id": camera_id,
        "message": f"摄像头已添加: {request.name}",
    }


@router.get("/{camera_id}")
async def get_camera(camera_id: str):
    """获取摄像头信息"""
    manager = get_camera_manager()
    cam = manager.get_camera(camera_id)
    
    if not cam:
        raise HTTPException(404, "Camera not found")
    
    return {"success": True, "camera": cam}


@router.delete("/{camera_id}")
async def delete_camera(camera_id: str):
    """删除摄像头"""
    manager = get_camera_manager()
    success = manager.remove_camera(camera_id)
    
    if not success:
        raise HTTPException(404, "Camera not found")
    
    return {"success": True, "message": "摄像头已删除"}


@router.post("/{camera_id}/test")
async def test_camera_connection(camera_id: str):
    """测试摄像头连接并检测能力"""
    manager = get_camera_manager()
    result = await manager.test_connection(camera_id)
    return result


# =============================================================================
# 声光控制端点
# =============================================================================

@router.post("/{camera_id}/siren/on")
async def siren_on(camera_id: str, times: int = 2):
    """开启警报器"""
    manager = get_camera_manager()
    result = await manager.siren_on(camera_id, times)
    return result


@router.post("/{camera_id}/siren/off")
async def siren_off(camera_id: str):
    """关闭警报器"""
    manager = get_camera_manager()
    result = await manager.siren_off(camera_id)
    return result


@router.post("/{camera_id}/spotlight/on")
async def spotlight_on(camera_id: str, brightness: int = 100):
    """开启LED灯"""
    manager = get_camera_manager()
    result = await manager.spotlight_on(camera_id, brightness)
    return result


@router.post("/{camera_id}/spotlight/off")
async def spotlight_off(camera_id: str):
    """关闭LED灯"""
    manager = get_camera_manager()
    result = await manager.spotlight_off(camera_id)
    return result


@router.post("/{camera_id}/deterrent/start")
async def deterrent_start(camera_id: str, request: DeterrentRequest = None):
    """启动威慑模式 (声光齐发)"""
    if request is None:
        request = DeterrentRequest()
    
    manager = get_camera_manager()
    result = await manager.deterrent_start(camera_id, request.brightness, request.siren_times)
    return result


@router.post("/{camera_id}/deterrent/stop")
async def deterrent_stop(camera_id: str):
    """停止威慑模式"""
    manager = get_camera_manager()
    result = await manager.deterrent_stop(camera_id)
    return result


@router.post("/deterrent/all/start")
async def deterrent_all_start(request: DeterrentRequest = None):
    """所有摄像头启动威慑模式"""
    if request is None:
        request = DeterrentRequest()
    
    manager = get_camera_manager()
    result = await manager.deterrent_all(request.brightness, request.siren_times)
    return result


@router.post("/deterrent/all/stop")
async def deterrent_all_stop():
    """所有摄像头停止威慑模式"""
    manager = get_camera_manager()
    result = await manager.deterrent_stop_all()
    return result


# =============================================================================
# Tier信息
# =============================================================================

@router.get("/tier/info")
async def get_tier_info():
    """获取Camera Tier信息"""
    manager = get_camera_manager()
    tier = manager.get_camera_tier()
    
    tier_descriptions = {
        CameraTier.TIER_0: "无摄像头 - 无威慑能力",
        CameraTier.TIER_1: "单摄像头 - 基础威慑",
        CameraTier.TIER_2: "多摄像头 - 全面威慑",
    }
    
    siren_cameras = manager.get_cameras_with_capability("siren")
    spotlight_cameras = manager.get_cameras_with_capability("spotlight")
    
    return {
        "success": True,
        "tier": tier.value,
        "description": tier_descriptions.get(tier, "未知"),
        "online_count": len(manager.get_online_cameras()),
        "siren_capable_count": len(siren_cameras),
        "spotlight_capable_count": len(spotlight_cameras),
    }
