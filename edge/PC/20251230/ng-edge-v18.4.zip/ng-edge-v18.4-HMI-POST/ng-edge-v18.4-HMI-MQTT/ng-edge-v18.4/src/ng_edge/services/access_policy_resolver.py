"""
Access Policy Resolver - PRD v7.5.0 §1.3.1

Evaluates whether a signal/zone trip should be treated as authorized
access based on active Service Access Windows.
"""

from datetime import datetime, timezone
from typing import List, Optional
from zoneinfo import ZoneInfo

from ..domain.enums import SignalType, AccessDecision
from ..domain.models import Signal
from ..domain.service_access import ServiceAccessWindow, AccessEvaluation


class AccessPolicyResolver:
    """
    Resolves access authorization based on Service Access Windows.
    
    PRD v7.5.0 §1.3.1 Runtime Rules:
    1. Priority evaluation of authorization
    2. AUTHORIZED behavior (suspicion_light, no PENDING/TRIGGERED)
    3. UNAUTHORIZED / NOT_IN_WINDOW behavior (normal SECURITY_HEAVY)
    4. Forced entry override (glass_break/forced_entry always SECURITY_HEAVY)
    """
    
    # Forced entry signals always override authorization
    FORCED_ENTRY_SIGNALS = {
        SignalType.GLASS_BREAK,
        SignalType.FORCED_ENTRY,
    }
    
    def __init__(self, windows: Optional[List[ServiceAccessWindow]] = None):
        """
        Initialize resolver with service windows.
        
        Args:
            windows: List of service access windows to evaluate
        """
        self.windows = windows or []
    
    def update_windows(self, windows: List[ServiceAccessWindow]) -> None:
        """Update the list of service windows."""
        self.windows = windows
    
    def evaluate_access(
        self,
        signal: Signal,
        zone_id: str,
        entry_point_id: Optional[str] = None,
        now: Optional[datetime] = None
    ) -> AccessEvaluation:
        """
        Evaluate whether signal should be treated as authorized access.
        
        Args:
            signal: The signal to evaluate
            zone_id: Zone where signal occurred
            entry_point_id: Entry point ID (if applicable)
            now: Current time (for testing)
        
        Returns:
            AccessEvaluation with decision and details
        
        PRD §1.3.1 Runtime Rules:
        1. Check forced entry override first
        2. Find matching active window
        3. Check zone/entry point authorization
        4. Return decision
        """
        now = now or datetime.now(timezone.utc)
        
        # Rule 4: Forced entry override
        if signal.signal_type in self.FORCED_ENTRY_SIGNALS:
            return AccessEvaluation(
                decision=AccessDecision.OVERRIDE_FORCED.value,
                reason="Forced entry signal overrides authorization",
                override_reason="forced_entry_override"
            )
        
        # Find active window
        active_window = self._find_active_window(now)
        
        if not active_window:
            return AccessEvaluation(
                decision=AccessDecision.NOT_IN_WINDOW.value,
                reason="No active service window"
            )
        
        # Check zone authorization
        if zone_id in active_window.restricted_zone_ids:
            return AccessEvaluation(
                decision=AccessDecision.UNAUTHORIZED.value,
                active_window_id=active_window.service_window_id,
                reason=f"Zone {zone_id} is restricted",
                override_reason="restricted_zone_trip",
                matched_window=active_window
            )
        
        # Check if zone is explicitly allowed (if allowlist is defined)
        if active_window.allowed_zone_ids:
            if zone_id not in active_window.allowed_zone_ids:
                return AccessEvaluation(
                    decision=AccessDecision.UNAUTHORIZED.value,
                    active_window_id=active_window.service_window_id,
                    reason=f"Zone {zone_id} not in allowed list",
                    override_reason="zone_not_allowed",
                    matched_window=active_window
                )
        
        # Check entry point authorization (if applicable)
        if entry_point_id:
            if active_window.allowed_entry_point_ids:
                if entry_point_id not in active_window.allowed_entry_point_ids:
                    return AccessEvaluation(
                        decision=AccessDecision.UNAUTHORIZED.value,
                        active_window_id=active_window.service_window_id,
                        reason=f"Entry point {entry_point_id} not allowed",
                        override_reason="entry_point_not_allowed",
                        matched_window=active_window
                    )
        
        # All checks passed - AUTHORIZED
        return AccessEvaluation(
            decision=AccessDecision.AUTHORIZED.value,
            active_window_id=active_window.service_window_id,
            reason=f"Authorized access via {active_window.name}",
            matched_window=active_window
        )
    
    def _find_active_window(self, now: datetime) -> Optional[ServiceAccessWindow]:
        """
        Find active service window at given time.
        
        Args:
            now: Current time (UTC)
        
        Returns:
            Active ServiceAccessWindow or None
        """
        for window in self.windows:
            if not window.enabled:
                continue
            
            if self._is_window_active(window, now):
                return window
        
        return None
    
    def _is_window_active(
        self,
        window: ServiceAccessWindow,
        now: datetime
    ) -> bool:
        """
        Check if window is active at given time.
        
        Args:
            window: Service window to check
            now: Current time (UTC)
        
        Returns:
            True if window is active
        """
        try:
            # Convert UTC time to local time
            tz = ZoneInfo(window.timezone)
            local_time = now.astimezone(tz)
            
            # Check day of week
            day_names = ["MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN"]
            day_of_week = day_names[local_time.weekday()]
            
            if not window.is_active_day(day_of_week):
                return False
            
            # Check time range
            current_time = local_time.time()
            start_time = window.get_start_time()
            end_time = window.get_end_time()
            
            # Handle overnight windows (e.g., 22:00 - 06:00)
            if end_time < start_time:
                # Window crosses midnight
                return current_time >= start_time or current_time < end_time
            else:
                # Normal window
                return start_time <= current_time < end_time
                
        except Exception as e:
            # If timezone conversion fails, assume not active
            print(f"[AccessPolicyResolver] Error checking window: {e}")
            return False
    
    def get_active_windows_count(self, now: Optional[datetime] = None) -> int:
        """
        Get count of currently active windows.
        
        Args:
            now: Current time (for testing)
        
        Returns:
            Number of active windows
        """
        now = now or datetime.now(timezone.utc)
        return sum(1 for w in self.windows if w.enabled and self._is_window_active(w, now))
