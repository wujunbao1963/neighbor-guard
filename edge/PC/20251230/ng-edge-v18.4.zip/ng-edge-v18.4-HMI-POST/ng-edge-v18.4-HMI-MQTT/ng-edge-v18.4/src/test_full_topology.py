#!/usr/bin/env python3
"""
完整拓扑测试 - 真实Zigbee硬件集成

测试流程:
1. 启动NG Edge服务器
2. 加载标准配置
3. 启动Zigbee MQTT客户端（连接真实传感器）
4. 设置AWAY模式
5. 等待用户手动触发物理传感器
6. 验证状态转换
7. 验证完整报警流程

物理设备:
- Back Door Contact (Zigbee门磁)
- Family Room Motion (Zigbee PIR)
"""

import subprocess
import time
import requests
import sys
import os
import json

os.chdir(os.path.dirname(os.path.abspath(__file__)))

BASE_URL = "http://localhost:8000"

def print_section(title):
    """打印分节标题"""
    print("\n" + "=" * 70)
    print(f"  {title}")
    print("=" * 70)

def start_server():
    """启动服务器进程"""
    print_section("步骤1: 启动NG Edge服务器")
    
    # 停止任何现有服务器
    subprocess.run(["pkill", "-f", "uvicorn.*ng_edge"], 
                  stderr=subprocess.DEVNULL)
    time.sleep(1)
    
    # 启动服务器
    server_process = subprocess.Popen(
        ["uvicorn", "ng_edge.api.manager:app", "--host", "0.0.0.0", "--port", "8000"],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True
    )
    
    # 等待服务器就绪
    print("\n等待服务器启动...")
    for i in range(15):
        try:
            resp = requests.get(f"{BASE_URL}/api/pipeline/status", timeout=1)
            if resp.status_code == 200:
                print(f"✅ 服务器已就绪 (尝试 {i+1}/15)")
                return server_process
        except:
            pass
        time.sleep(1)
    
    print("❌ 服务器启动超时")
    server_process.terminate()
    return None

def load_config():
    """加载标准配置"""
    print_section("步骤2: 加载标准配置")
    
    try:
        resp = requests.post(f"{BASE_URL}/api/load-standard-config")
        if resp.status_code == 200:
            print("✅ 标准配置加载成功")
            return True
        else:
            print(f"❌ 配置加载失败: {resp.status_code}")
            return False
    except Exception as e:
        print(f"❌ 错误: {e}")
        return False

def start_zigbee():
    """启动Zigbee MQTT客户端"""
    print_section("步骤3: 启动Zigbee MQTT客户端")
    
    print("\n配置Zigbee设备:")
    print("  1. Back Door Contact -> sensor_door_back")
    print("  2. Family Room Motion -> sensor_pir_living")
    
    try:
        resp = requests.post(f"{BASE_URL}/api/zigbee/start",
            json={
                "mqtt_host": "localhost",
                "mqtt_port": 1883,
                "devices": [
                    {
                        "friendly_name": "Back Door Contact",
                        "sensor_id": "sensor_door_back",
                        "sensor_type": "door_contact",
                        "zone_id": "zone_back_door",
                        "device_type": "contact"
                    },
                    {
                        "friendly_name": "Family Room Motion",
                        "sensor_id": "sensor_pir_living",
                        "sensor_type": "motion_pir",
                        "zone_id": "zone_living_room",
                        "device_type": "motion"
                    }
                ]
            }
        )
        
        if resp.status_code == 200:
            print("\n✅ Zigbee客户端启动成功")
            return True
        else:
            result = resp.json()
            print(f"\n❌ Zigbee启动失败: {resp.status_code}")
            print(f"   错误: {result.get('detail', 'Unknown error')}")
            print("\n⚠️  可能的原因:")
            print("   - Zigbee2MQTT服务未运行 (检查: systemctl status zigbee2mqtt)")
            print("   - MQTT broker未运行 (检查: systemctl status mosquitto)")
            print("   - 设备名称不匹配 (检查Zigbee2MQTT Web UI)")
            return False
            
    except Exception as e:
        print(f"\n❌ 错误: {e}")
        return False

def set_away_mode():
    """设置AWAY模式"""
    print_section("步骤4: 设置AWAY模式")
    
    try:
        resp = requests.post(f"{BASE_URL}/api/pipeline/mode", json={"mode": "away"})
        if resp.status_code == 200:
            print("✅ 已设置AWAY模式")
            return True
        else:
            print(f"❌ 设置模式失败: {resp.status_code}")
            return False
    except Exception as e:
        print(f"❌ 错误: {e}")
        return False

def check_zigbee_status():
    """检查Zigbee状态"""
    try:
        resp = requests.get(f"{BASE_URL}/api/zigbee/status")
        zigbee = resp.json()
        
        print("\nZigbee状态:")
        print(f"  - Active: {zigbee.get('active')}")
        print(f"  - Connected: {zigbee.get('connected')}")
        print(f"  - Device count: {zigbee.get('device_count')}")
        print(f"  - Pipeline enabled: {zigbee.get('pipeline_enabled')}")
        
        recent = zigbee.get('recent_signals', [])
        if recent:
            print(f"\n最近的信号 (共{len(recent)}条):")
            for i, sig in enumerate(recent[:3], 1):
                ts = sig.get('timestamp', '')[:19]
                print(f"  {i}. {sig.get('signal_type')} from {sig.get('sensor_id')} at {ts}")
        
        return zigbee.get('active', False) and zigbee.get('connected', False)
        
    except Exception as e:
        print(f"❌ 获取状态失败: {e}")
        return False

def monitor_system(duration=60):
    """监控系统状态"""
    print_section("步骤5: 监控系统（物理传感器测试）")
    
    print("\n📋 测试指南:")
    print("  1. 打开物理后门 → 触发Door Contact → 预期: PENDING")
    print("  2. 在Family Room走动 → 触发Motion → 预期: TRIGGERED")
    print()
    print(f"将监控 {duration} 秒...")
    print("按 Ctrl+C 提前停止")
    print()
    
    start_time = time.time()
    last_alarm_state = None
    last_ep_state = {}
    signal_count = 0
    
    try:
        while time.time() - start_time < duration:
            # 获取状态
            try:
                resp = requests.get(f"{BASE_URL}/api/pipeline/status", timeout=1)
                status = resp.json()
                
                current_time = time.strftime("%H:%M:%S")
                mode = status.get('mode', 'unknown')
                alarm = status.get('alarm_state', 'unknown')
                
                # 检查状态变化
                if alarm != last_alarm_state:
                    print(f"[{current_time}] 🚨 Alarm状态变化: {last_alarm_state} → {alarm}")
                    last_alarm_state = alarm
                
                # 检查entry point状态
                ep_states = status.get('entry_point_states', {})
                for ep_id, state in ep_states.items():
                    if state != last_ep_state.get(ep_id):
                        print(f"[{current_time}] 🚪 EntryPoint {ep_id}: {last_ep_state.get(ep_id, 'unknown')} → {state}")
                        last_ep_state[ep_id] = state
                
                # 检查新的Zigbee信号
                zigbee_resp = requests.get(f"{BASE_URL}/api/zigbee/status", timeout=1)
                zigbee = zigbee_resp.json()
                recent = zigbee.get('recent_signals', [])
                if len(recent) > signal_count:
                    # 有新信号
                    new_signals = recent[signal_count:len(recent)]
                    for sig in reversed(new_signals):
                        ts = sig.get('timestamp', '')[:19]
                        print(f"[{current_time}] 📡 Zigbee信号: {sig.get('signal_type')} from {sig.get('sensor_id')}")
                    signal_count = len(recent)
                
            except Exception as e:
                print(f"[监控错误] {e}")
            
            time.sleep(2)
        
        print(f"\n⏰ 监控时间结束 ({duration}秒)")
        
    except KeyboardInterrupt:
        print("\n\n⚠️  用户停止监控")

def show_final_status():
    """显示最终状态"""
    print_section("最终状态")
    
    try:
        # 系统状态
        resp = requests.get(f"{BASE_URL}/api/pipeline/status")
        status = resp.json()
        
        print("\n系统状态:")
        print(f"  Mode: {status.get('mode')}")
        print(f"  Alarm: {status.get('alarm_state')}")
        
        ep_states = status.get('entry_point_states', {})
        if ep_states:
            print("\nEntry Point状态:")
            for ep_id, state in ep_states.items():
                print(f"  {ep_id}: {state}")
        
        # Zigbee信号历史
        zigbee_resp = requests.get(f"{BASE_URL}/api/zigbee/status")
        zigbee = zigbee_resp.json()
        recent = zigbee.get('recent_signals', [])
        
        if recent:
            print(f"\nZigbee信号历史 (最近10条):")
            for i, sig in enumerate(recent[:10], 1):
                ts = sig.get('timestamp', '')[:19]
                print(f"  {i}. {sig.get('signal_type'):15s} from {sig.get('sensor_id'):20s} at {ts}")
        
    except Exception as e:
        print(f"❌ 获取状态失败: {e}")

def main():
    """主函数"""
    server_process = None
    
    try:
        print("\n" + "🎯" * 35)
        print("  完整拓扑测试 - 真实Zigbee硬件")
        print("🎯" * 35)
        
        # 1. 启动服务器
        server_process = start_server()
        if not server_process:
            return 1
        
        time.sleep(2)
        
        # 2. 加载配置
        if not load_config():
            return 1
        
        time.sleep(1)
        
        # 3. 启动Zigbee
        if not start_zigbee():
            print("\n⚠️  Zigbee启动失败，但可以继续测试（使用模拟信号）")
            print("   如需测试真实硬件，请:")
            print("   1. 确保Zigbee2MQTT服务运行: sudo systemctl start zigbee2mqtt")
            print("   2. 确保MQTT broker运行: sudo systemctl start mosquitto")
            print("   3. 重新运行此脚本")
        else:
            time.sleep(2)
            check_zigbee_status()
        
        time.sleep(1)
        
        # 4. 设置AWAY模式
        if not set_away_mode():
            return 1
        
        time.sleep(1)
        
        # 5. 监控系统
        monitor_system(duration=60)
        
        # 6. 显示最终状态
        show_final_status()
        
        # 总结
        print_section("测试完成")
        print("\n✅ 如果看到了状态转换，说明系统工作正常")
        print("\n📝 预期的转换序列:")
        print("   1. Door打开 → ep_back_door: quiet → pending")
        print("   2. Motion检测 → ep_back_door: pending → triggered")
        print("   3. Alarm: quiet → pending → triggered")
        
        print("\n服务器仍在运行...")
        print("Web UI: http://localhost:8000")
        print("按Ctrl+C停止")
        
        # 保持运行
        try:
            server_process.wait()
        except KeyboardInterrupt:
            print("\n\n停止服务器...")
        
        return 0
        
    except KeyboardInterrupt:
        print("\n\n测试中断")
        return 1
        
    finally:
        if server_process:
            server_process.terminate()
            try:
                server_process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                server_process.kill()

if __name__ == "__main__":
    sys.exit(main())
