#!/usr/bin/env python3
"""
NG Edge HMI Server - 独立 Web UI 进程

通过 MQTT 与 edge_runtime 通信：
- 订阅 ng/status 获取状态
- 发布 ng/command 发送命令

启动方式：
    python3 hmi_server.py
    
访问：
    http://localhost:8080
"""

import asyncio
import json
import threading
from datetime import datetime, timezone
from typing import Optional, Dict, Any

# FastAPI
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.middleware.cors import CORSMiddleware
import uvicorn

# MQTT
import paho.mqtt.client as mqtt

# =============================================================================
# 配置
# =============================================================================

MQTT_HOST = "localhost"
MQTT_PORT = 1883
HMI_STATUS_TOPIC = "ng/status"
HMI_CONFIG_TOPIC = "ng/config"
HMI_CAMERAS_TOPIC = "ng/cameras"
HMI_COMMAND_TOPIC = "ng/command"
HTTP_PORT = 8088

# =============================================================================
# 全局状态
# =============================================================================

latest_status: Dict[str, Any] = {
    "house_mode": "unknown",
    "running": False,
    "alarm_state": "unknown",
    "cameras_online": 0,
    "cameras_total": 0,
    "zigbee_devices": 0,
    "stats": {},
    "sensors": [],
    "events": [],
    "timestamp": None,
    "connected": False,
}

latest_config: Dict[str, Any] = {
    "entry_delay_sec": 30,
    "yolo_conf": 0.7,
    "yolo_fps": 5.0,
    "yolo_confirm_frames": 1,
    "signal_cooldown_sec": 5.0,
    "valid_pins": ["1234"],
    "keypad_node_id": 3,
    "delivery_max_duration_sec": 15.0,
    "delivery_min_duration_sec": 2.0,
    "camera_clear_timeout_sec": 4.0,
}

latest_cameras: Dict[str, Any] = {}

mqtt_client: Optional[mqtt.Client] = None

# =============================================================================
# MQTT 客户端
# =============================================================================

def on_mqtt_connect(client, userdata, flags, reason_code, properties):
    """MQTT 连接回调"""
    if reason_code == 0:
        print(f"[MQTT] ✅ 已连接到 {MQTT_HOST}:{MQTT_PORT}")
        client.subscribe(HMI_STATUS_TOPIC)
        client.subscribe(HMI_CONFIG_TOPIC)
        client.subscribe(HMI_CAMERAS_TOPIC)
        print(f"[MQTT] 📡 已订阅 {HMI_STATUS_TOPIC}, {HMI_CONFIG_TOPIC}, {HMI_CAMERAS_TOPIC}")
        latest_status["connected"] = True
    else:
        print(f"[MQTT] ❌ 连接失败: rc={reason_code}")
        latest_status["connected"] = False

def on_mqtt_disconnect(client, userdata, flags, reason_code, properties):
    """MQTT 断开回调"""
    print(f"[MQTT] ⚠️ 断开连接: rc={reason_code}")
    latest_status["connected"] = False

def on_mqtt_message(client, userdata, msg):
    """MQTT 消息回调"""
    global latest_status, latest_config, latest_cameras
    try:
        if msg.topic == HMI_STATUS_TOPIC:
            data = json.loads(msg.payload.decode())
            latest_status.update(data)
            latest_status["connected"] = True
            print(f"[MQTT] 📥 状态更新: mode={data.get('house_mode')}, alarm={data.get('alarm_state')}")
        elif msg.topic == HMI_CONFIG_TOPIC:
            data = json.loads(msg.payload.decode())
            latest_config.update(data)
            print(f"[MQTT] 📥 配置更新: entry_delay={data.get('entry_delay_sec')}s")
        elif msg.topic == HMI_CAMERAS_TOPIC:
            data = json.loads(msg.payload.decode())
            latest_cameras.update(data)
            print(f"[MQTT] 📥 摄像头配置更新: {len(data)} 个摄像头")
    except Exception as e:
        print(f"[MQTT] ❌ 消息处理错误: {e}")

def start_mqtt_client():
    """启动 MQTT 客户端（在后台线程）"""
    global mqtt_client
    mqtt_client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2)
    mqtt_client.on_connect = on_mqtt_connect
    mqtt_client.on_disconnect = on_mqtt_disconnect
    mqtt_client.on_message = on_mqtt_message
    
    try:
        mqtt_client.connect(MQTT_HOST, MQTT_PORT, 60)
        mqtt_client.loop_start()
        print(f"[MQTT] 🚀 客户端已启动")
    except Exception as e:
        print(f"[MQTT] ❌ 启动失败: {e}")

def send_command(command: str, **kwargs):
    """发送命令到 edge_runtime"""
    global mqtt_client
    if mqtt_client:
        payload = {"command": command, **kwargs}
        mqtt_client.publish(HMI_COMMAND_TOPIC, json.dumps(payload))
        print(f"[MQTT] 📤 发送命令: {payload}")

# =============================================================================
# FastAPI 应用
# =============================================================================

app = FastAPI(title="NG Edge HMI")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.on_event("startup")
async def startup():
    """启动时连接 MQTT"""
    start_mqtt_client()

@app.on_event("shutdown")
async def shutdown():
    """关闭时断开 MQTT"""
    global mqtt_client
    if mqtt_client:
        mqtt_client.loop_stop()
        mqtt_client.disconnect()

@app.get("/api/status")
async def get_status():
    """获取系统状态"""
    return JSONResponse(latest_status)

@app.post("/api/mode/{mode}")
async def set_mode(mode: str):
    """设置模式"""
    mode = mode.upper()
    if mode not in ["DISARMED", "HOME", "AWAY"]:
        return JSONResponse({"error": "Invalid mode"}, status_code=400)
    send_command("set_mode", mode=mode)
    return JSONResponse({"success": True, "mode": mode})

@app.post("/api/refresh")
async def refresh_status():
    """刷新状态"""
    send_command("get_status")
    return JSONResponse({"success": True})

@app.get("/api/config")
async def get_config():
    """获取配置"""
    send_command("get_config")
    return JSONResponse(latest_config)

@app.post("/api/config")
async def set_config(request: Request):
    """设置配置"""
    params = await request.json()
    send_command("set_config", params=params)
    return JSONResponse({"success": True, "params": params})

@app.get("/api/cameras")
async def get_cameras():
    """获取摄像头配置"""
    send_command("get_cameras")
    return JSONResponse(latest_cameras)

@app.post("/api/cameras/{camera_id}")
async def set_camera(camera_id: str, request: Request):
    """设置单个摄像头配置"""
    params = await request.json()
    send_command("set_camera", camera_id=camera_id, params=params)
    return JSONResponse({"success": True, "camera_id": camera_id, "params": params})

@app.get("/", response_class=HTMLResponse)
async def get_ui():
    """HMI Web 界面"""
    html = """<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NG Edge HMI</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        .mode-btn { transition: all 0.2s; }
        .mode-btn.active { transform: scale(1.05); box-shadow: 0 0 20px rgba(59, 130, 246, 0.5); }
        .blink { animation: blink 1s infinite; }
        @keyframes blink { 50% { opacity: 0.5; } }
        .tab-btn { transition: all 0.2s; }
        .tab-btn.active { background: #374151; border-bottom: 2px solid #3b82f6; }
    </style>
</head>
<body class="bg-gray-900 text-white min-h-screen p-4">
    <div class="max-w-5xl mx-auto">
        <h1 class="text-2xl font-bold mb-4 text-center">🏠 NG Edge 安防系统</h1>
        
        <!-- 连接状态 -->
        <div id="connectionStatus" class="text-center mb-4 text-sm">
            <span class="text-gray-500">连接中...</span>
        </div>
        
        <!-- 系统状态 + 模式控制 -->
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
            <!-- 系统状态 -->
            <div class="bg-gray-800 rounded-lg p-4">
                <h2 class="text-lg font-semibold mb-3">系统状态</h2>
                <div class="grid grid-cols-2 gap-3 text-sm">
                    <div><span class="text-gray-400">运行:</span> <span id="running" class="ml-1">-</span></div>
                    <div><span class="text-gray-400">报警:</span> <span id="alarm" class="ml-1">-</span></div>
                    <div><span class="text-gray-400">摄像头:</span> <span id="cameras" class="ml-1">-</span></div>
                    <div><span class="text-gray-400">Zigbee:</span> <span id="zigbee" class="ml-1">-</span></div>
                </div>
            </div>
            
            <!-- 模式控制 -->
            <div class="bg-gray-800 rounded-lg p-4">
                <h2 class="text-lg font-semibold mb-2">模式控制</h2>
                <div id="currentMode" class="text-center text-2xl font-bold mb-3">-</div>
                <div class="flex justify-center gap-2">
                    <button onclick="setMode('DISARMED')" id="btn-DISARMED" class="mode-btn bg-green-600 hover:bg-green-500 px-4 py-2 rounded-lg text-sm font-semibold">🟢 撤防</button>
                    <button onclick="setMode('HOME')" id="btn-HOME" class="mode-btn bg-blue-600 hover:bg-blue-500 px-4 py-2 rounded-lg text-sm font-semibold">🔵 在家</button>
                    <button onclick="setMode('AWAY')" id="btn-AWAY" class="mode-btn bg-red-600 hover:bg-red-500 px-4 py-2 rounded-lg text-sm font-semibold">🔴 离开</button>
                </div>
            </div>
        </div>
        
        <!-- Tab 导航 -->
        <div class="flex border-b border-gray-700 mb-4">
            <button onclick="showTab('sensors')" id="tab-sensors" class="tab-btn active px-4 py-2 text-sm">📡 传感器状态</button>
            <button onclick="showTab('events')" id="tab-events" class="tab-btn px-4 py-2 text-sm">📋 事件记录</button>
            <button onclick="showTab('config')" id="tab-config" class="tab-btn px-4 py-2 text-sm">⚙️ 参数设置</button>
            <button onclick="showTab('cameras')" id="tab-cameras" class="tab-btn px-4 py-2 text-sm">📹 摄像头设置</button>
            <button onclick="showTab('stats')" id="tab-stats" class="tab-btn px-4 py-2 text-sm">📊 统计信息</button>
        </div>
        
        <!-- 传感器状态 -->
        <div id="panel-sensors" class="bg-gray-800 rounded-lg p-4">
            <div id="sensorList" class="space-y-2">
                <div class="text-gray-500">加载中...</div>
            </div>
        </div>
        
        <!-- 事件记录 -->
        <div id="panel-events" class="bg-gray-800 rounded-lg p-4 hidden">
            <div id="eventList" class="space-y-1 max-h-96 overflow-y-auto">
                <div class="text-gray-500">加载中...</div>
            </div>
        </div>
        
        <!-- 参数设置 -->
        <div id="panel-config" class="bg-gray-800 rounded-lg p-4 hidden">
            <div class="space-y-4">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <!-- Entry Delay -->
                    <div class="bg-gray-700 p-3 rounded">
                        <label class="block text-sm text-gray-400 mb-1">Entry Delay (秒)</label>
                        <input type="number" id="cfg-entry_delay_sec" class="w-full bg-gray-600 text-white px-3 py-2 rounded" min="5" max="120" step="5">
                        <p class="text-xs text-gray-500 mt-1">入口延迟时间，允许用户在门打开后撤防</p>
                    </div>
                    
                    <!-- YOLO Confidence -->
                    <div class="bg-gray-700 p-3 rounded">
                        <label class="block text-sm text-gray-400 mb-1">YOLO 置信度阈值</label>
                        <input type="number" id="cfg-yolo_conf" class="w-full bg-gray-600 text-white px-3 py-2 rounded" min="0.3" max="0.95" step="0.05">
                        <p class="text-xs text-gray-500 mt-1">人员检测置信度，越高越准确但可能漏检</p>
                    </div>
                    
                    <!-- YOLO FPS -->
                    <div class="bg-gray-700 p-3 rounded">
                        <label class="block text-sm text-gray-400 mb-1">YOLO FPS</label>
                        <input type="number" id="cfg-yolo_fps" class="w-full bg-gray-600 text-white px-3 py-2 rounded" min="1" max="30" step="1">
                        <p class="text-xs text-gray-500 mt-1">视频检测帧率，越高越及时但 CPU 占用更高</p>
                    </div>
                    
                    <!-- Signal Cooldown -->
                    <div class="bg-gray-700 p-3 rounded">
                        <label class="block text-sm text-gray-400 mb-1">信号冷却时间 (秒)</label>
                        <input type="number" id="cfg-signal_cooldown_sec" class="w-full bg-gray-600 text-white px-3 py-2 rounded" min="1" max="60" step="1">
                        <p class="text-xs text-gray-500 mt-1">同一传感器重复信号的最小间隔</p>
                    </div>
                    
                    <!-- Keypad Node ID -->
                    <div class="bg-gray-700 p-3 rounded">
                        <label class="block text-sm text-gray-400 mb-1">Keypad Node ID</label>
                        <input type="number" id="cfg-keypad_node_id" class="w-full bg-gray-600 text-white px-3 py-2 rounded" min="1" max="255" step="1">
                        <p class="text-xs text-gray-500 mt-1">Ring Keypad 的 Z-Wave Node ID</p>
                    </div>
                    
                    <!-- Valid PINs -->
                    <div class="bg-gray-700 p-3 rounded">
                        <label class="block text-sm text-gray-400 mb-1">有效 PIN 码</label>
                        <input type="text" id="cfg-valid_pins" class="w-full bg-gray-600 text-white px-3 py-2 rounded" placeholder="1234,5678">
                        <p class="text-xs text-gray-500 mt-1">逗号分隔的有效 PIN 列表</p>
                    </div>
                    
                    <!-- Delivery Max Duration -->
                    <div class="bg-gray-700 p-3 rounded">
                        <label class="block text-sm text-gray-400 mb-1">快递最大停留 (秒)</label>
                        <input type="number" id="cfg-delivery_max_duration_sec" class="w-full bg-gray-600 text-white px-3 py-2 rounded" min="5" max="60" step="1">
                        <p class="text-xs text-gray-500 mt-1">超过此时间不视为快递</p>
                    </div>
                    
                    <!-- Delivery Min Duration -->
                    <div class="bg-gray-700 p-3 rounded">
                        <label class="block text-sm text-gray-400 mb-1">快递最小停留 (秒)</label>
                        <input type="number" id="cfg-delivery_min_duration_sec" class="w-full bg-gray-600 text-white px-3 py-2 rounded" min="0.5" max="10" step="0.5">
                        <p class="text-xs text-gray-500 mt-1">太短可能是误检</p>
                    </div>
                    
                    <!-- Camera Clear Timeout -->
                    <div class="bg-gray-700 p-3 rounded">
                        <label class="block text-sm text-gray-400 mb-1">人员离开判断 (秒)</label>
                        <input type="number" id="cfg-camera_clear_timeout_sec" class="w-full bg-gray-600 text-white px-3 py-2 rounded" min="1" max="30" step="1">
                        <p class="text-xs text-gray-500 mt-1">无检测多久后判定人员已离开</p>
                    </div>
                </div>
                
                <div class="flex justify-end gap-2 mt-4">
                    <button onclick="loadConfig()" class="bg-gray-600 hover:bg-gray-500 px-4 py-2 rounded text-sm">🔄 重新加载</button>
                    <button onclick="saveConfig()" class="bg-blue-600 hover:bg-blue-500 px-4 py-2 rounded text-sm font-semibold">💾 保存配置</button>
                </div>
            </div>
        </div>
        
        <!-- 摄像头设置 -->
        <div id="panel-cameras" class="bg-gray-800 rounded-lg p-4 hidden">
            <div id="cameraList" class="space-y-4">
                <div class="text-gray-500">加载中...</div>
            </div>
            <div class="flex justify-end gap-2 mt-4">
                <button onclick="loadCameras()" class="bg-gray-600 hover:bg-gray-500 px-4 py-2 rounded text-sm">🔄 重新加载</button>
            </div>
        </div>
        
        <!-- 统计信息 -->
        <div id="panel-stats" class="bg-gray-800 rounded-lg p-4 hidden">
            <div id="stats" class="grid grid-cols-2 md:grid-cols-3 gap-2 text-sm text-gray-400">
                <div>加载中...</div>
            </div>
        </div>
        
        <div class="text-right text-xs text-gray-500 mt-2">
            更新时间: <span id="timestamp">-</span>
        </div>
    </div>
    
    <script>
        let currentMode = 'unknown';
        let currentTab = 'sensors';
        
        function showTab(tab) {
            currentTab = tab;
            ['sensors', 'events', 'config', 'cameras', 'stats'].forEach(t => {
                document.getElementById('panel-' + t).classList.toggle('hidden', t !== tab);
                document.getElementById('tab-' + t).classList.toggle('active', t === tab);
            });
            if (tab === 'config') loadConfig();
            if (tab === 'cameras') loadCameras();
        }
        
        async function fetchStatus() {
            try {
                const res = await fetch('/api/status');
                const data = await res.json();
                
                // 连接状态
                const connEl = document.getElementById('connectionStatus');
                if (data.connected) {
                    connEl.innerHTML = '<span class="text-green-400">● 已连接</span>';
                } else {
                    connEl.innerHTML = '<span class="text-red-400 blink">● 未连接</span>';
                }
                
                // 运行状态
                document.getElementById('running').textContent = data.running ? '✅ 运行中' : '⏸️ 已停止';
                document.getElementById('running').className = data.running ? 'ml-1 text-green-400' : 'ml-1 text-yellow-400';
                
                // 报警状态
                const alarmEl = document.getElementById('alarm');
                const alarmText = {
                    'none': '✅ 正常', 'pre_l1': '⚠️ PRE-L1', 'pre_l2': '⚠️ PRE-L2', 
                    'pre_l3': '🔶 PRE-L3', 'pending': '⏳ 等待', 'triggered': '🚨 触发'
                };
                const alarmColor = {
                    'none': 'text-green-400', 'pre_l1': 'text-yellow-400', 'pre_l2': 'text-yellow-400',
                    'pre_l3': 'text-orange-400', 'pending': 'text-yellow-400 blink', 'triggered': 'text-red-400 blink'
                };
                alarmEl.textContent = alarmText[data.alarm_state] || data.alarm_state;
                alarmEl.className = 'ml-1 ' + (alarmColor[data.alarm_state] || 'text-gray-400');
                
                // 设备状态
                document.getElementById('cameras').textContent = `${data.cameras_online}/${data.cameras_total}`;
                document.getElementById('zigbee').textContent = data.zigbee_devices;
                
                // 模式
                currentMode = data.house_mode?.toUpperCase() || 'UNKNOWN';
                const modeText = {'DISARMED': '🟢 撤防', 'HOME': '🔵 在家布防', 'AWAY': '🔴 离开布防'};
                const modeColor = {'DISARMED': 'text-green-400', 'HOME': 'text-blue-400', 'AWAY': 'text-red-400'};
                document.getElementById('currentMode').textContent = modeText[currentMode] || currentMode;
                document.getElementById('currentMode').className = 'text-center text-2xl font-bold mb-3 ' + (modeColor[currentMode] || 'text-white');
                updateModeButtons();
                
                // 传感器状态
                if (data.sensors && data.sensors.length > 0) {
                    const sensorHtml = data.sensors.map(s => {
                        const typeIcon = s.type === 'camera' ? '📹' : (s.type === 'contact_sensor' ? '🚪' : '📡');
                        const online = s.online !== false;
                        const statusClass = online ? 'text-green-400' : 'text-red-400';
                        const lastSignal = s.last_signal ? new Date(s.last_signal).toLocaleString('zh-CN') : '-';
                        const signalCount = s.signal_count || 0;
                        return `<div class="flex justify-between items-center p-2 bg-gray-700 rounded text-sm">
                            <div>
                                <span class="mr-2">${typeIcon}</span>
                                <span class="font-medium">${s.device_id}</span>
                                <span class="text-gray-500 ml-2">${s.zone || ''}</span>
                            </div>
                            <div class="text-right">
                                <span class="${statusClass}">${s.last_type || (online ? '在线' : '离线')}</span>
                                <div class="text-xs text-gray-500">${lastSignal} (${signalCount}次)</div>
                            </div>
                        </div>`;
                    }).join('');
                    document.getElementById('sensorList').innerHTML = sensorHtml;
                } else {
                    document.getElementById('sensorList').innerHTML = '<div class="text-gray-500">无传感器数据</div>';
                }
                
                // 事件记录
                if (data.events && data.events.length > 0) {
                    const eventHtml = data.events.slice().reverse().map(e => {
                        const levelColor = {
                            'info': 'text-blue-400', 'warning': 'text-yellow-400', 'critical': 'text-red-400'
                        };
                        const levelIcon = {'info': 'ℹ️', 'warning': '⚠️', 'critical': '🚨'};
                        const ts = new Date(e.timestamp).toLocaleTimeString('zh-CN');
                        return `<div class="flex items-start gap-2 p-1 text-sm border-b border-gray-700">
                            <span>${levelIcon[e.level] || 'ℹ️'}</span>
                            <span class="text-gray-500 text-xs w-16">${ts}</span>
                            <span class="${levelColor[e.level] || 'text-gray-300'}">${e.message}</span>
                        </div>`;
                    }).join('');
                    document.getElementById('eventList').innerHTML = eventHtml;
                } else {
                    document.getElementById('eventList').innerHTML = '<div class="text-gray-500">无事件记录</div>';
                }
                
                // 统计
                if (data.stats) {
                    const statsHtml = Object.entries(data.stats).map(([k, v]) => 
                        `<div><span class="text-gray-500">${k}:</span> ${v}</div>`
                    ).join('');
                    document.getElementById('stats').innerHTML = statsHtml || '<div>无数据</div>';
                }
                
                // 时间戳
                if (data.timestamp) {
                    const ts = new Date(data.timestamp);
                    document.getElementById('timestamp').textContent = ts.toLocaleString('zh-CN');
                }
                
            } catch (e) {
                console.error('Status fetch error:', e);
                document.getElementById('connectionStatus').innerHTML = '<span class="text-red-400">● 获取失败</span>';
            }
        }
        
        function updateModeButtons() {
            ['DISARMED', 'HOME', 'AWAY'].forEach(m => {
                const btn = document.getElementById('btn-' + m);
                if (btn) btn.classList.toggle('active', m === currentMode);
            });
        }
        
        async function setMode(mode) {
            try {
                const res = await fetch('/api/mode/' + mode, { method: 'POST' });
                const data = await res.json();
                if (data.success) {
                    setTimeout(fetchStatus, 500);
                } else {
                    alert('设置失败: ' + (data.error || '未知错误'));
                }
            } catch (e) {
                alert('请求失败: ' + e.message);
            }
        }
        
        async function loadConfig() {
            try {
                const res = await fetch('/api/config');
                const data = await res.json();
                
                document.getElementById('cfg-entry_delay_sec').value = data.entry_delay_sec || 30;
                document.getElementById('cfg-yolo_conf').value = data.yolo_conf || 0.7;
                document.getElementById('cfg-yolo_fps').value = data.yolo_fps || 5;
                document.getElementById('cfg-signal_cooldown_sec').value = data.signal_cooldown_sec || 5;
                document.getElementById('cfg-keypad_node_id').value = data.keypad_node_id || 3;
                document.getElementById('cfg-valid_pins').value = (data.valid_pins || ['1234']).join(',');
                document.getElementById('cfg-delivery_max_duration_sec').value = data.delivery_max_duration_sec || 15;
                document.getElementById('cfg-delivery_min_duration_sec').value = data.delivery_min_duration_sec || 2;
                document.getElementById('cfg-camera_clear_timeout_sec').value = data.camera_clear_timeout_sec || 4;
                
                console.log('配置已加载', data);
            } catch (e) {
                console.error('加载配置失败:', e);
            }
        }
        
        async function saveConfig() {
            const params = {
                entry_delay_sec: parseInt(document.getElementById('cfg-entry_delay_sec').value),
                yolo_conf: parseFloat(document.getElementById('cfg-yolo_conf').value),
                yolo_fps: parseFloat(document.getElementById('cfg-yolo_fps').value),
                signal_cooldown_sec: parseFloat(document.getElementById('cfg-signal_cooldown_sec').value),
                keypad_node_id: parseInt(document.getElementById('cfg-keypad_node_id').value),
                valid_pins: document.getElementById('cfg-valid_pins').value.split(',').map(p => p.trim()).filter(p => p),
                delivery_max_duration_sec: parseFloat(document.getElementById('cfg-delivery_max_duration_sec').value),
                delivery_min_duration_sec: parseFloat(document.getElementById('cfg-delivery_min_duration_sec').value),
                camera_clear_timeout_sec: parseFloat(document.getElementById('cfg-camera_clear_timeout_sec').value),
            };
            
            try {
                const res = await fetch('/api/config', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify(params)
                });
                const data = await res.json();
                if (data.success) {
                    alert('✅ 配置已保存');
                    setTimeout(loadConfig, 500);
                } else {
                    alert('保存失败: ' + (data.error || '未知错误'));
                }
            } catch (e) {
                alert('请求失败: ' + e.message);
            }
        }
        
        async function loadCameras() {
            try {
                const res = await fetch('/api/cameras');
                const data = await res.json();
                
                const camListEl = document.getElementById('cameraList');
                if (Object.keys(data).length === 0) {
                    camListEl.innerHTML = '<div class="text-gray-500">无摄像头配置</div>';
                    return;
                }
                
                let html = '';
                for (const [camId, cam] of Object.entries(data)) {
                    html += `
                    <div class="bg-gray-700 p-4 rounded">
                        <div class="flex justify-between items-center mb-3">
                            <h3 class="font-semibold">📹 ${cam.name || camId}</h3>
                            <span class="text-xs text-gray-400">${camId}</span>
                        </div>
                        <div class="grid grid-cols-2 md:grid-cols-3 gap-3 text-sm">
                            <div>
                                <label class="block text-gray-400 text-xs">IP 地址</label>
                                <input type="text" id="cam-${camId}-ip" value="${cam.ip || ''}" class="w-full bg-gray-600 text-white px-2 py-1 rounded text-sm">
                            </div>
                            <div>
                                <label class="block text-gray-400 text-xs">区域模式</label>
                                <select id="cam-${camId}-zone_mode" class="w-full bg-gray-600 text-white px-2 py-1 rounded text-sm">
                                    <option value="horizontal" ${cam.zone_mode === 'horizontal' ? 'selected' : ''}>俯视 (horizontal)</option>
                                    <option value="vertical" ${cam.zone_mode === 'vertical' ? 'selected' : ''}>水平 (vertical)</option>
                                </select>
                            </div>
                            <div>
                                <label class="block text-gray-400 text-xs">进入方向</label>
                                <select id="cam-${camId}-direction" class="w-full bg-gray-600 text-white px-2 py-1 rounded text-sm">
                                    <option value="bottom_to_top" ${cam.direction === 'bottom_to_top' ? 'selected' : ''}>下→上</option>
                                    <option value="top_to_bottom" ${cam.direction === 'top_to_bottom' ? 'selected' : ''}>上→下</option>
                                    <option value="left_to_right" ${cam.direction === 'left_to_right' ? 'selected' : ''}>左→右</option>
                                    <option value="right_to_left" ${cam.direction === 'right_to_left' ? 'selected' : ''}>右→左</option>
                                </select>
                            </div>
                            <div>
                                <label class="block text-gray-400 text-xs">门区阈值 (L2)</label>
                                <input type="number" id="cam-${camId}-door_threshold" value="${cam.door_threshold || 0.55}" step="0.01" min="0" max="1" class="w-full bg-gray-600 text-white px-2 py-1 rounded text-sm">
                            </div>
                            <div>
                                <label class="block text-gray-400 text-xs">院区阈值 (L1)</label>
                                <input type="number" id="cam-${camId}-yard_threshold" value="${cam.yard_threshold || 0.2}" step="0.01" min="0" max="1" class="w-full bg-gray-600 text-white px-2 py-1 rounded text-sm">
                            </div>
                            <div class="flex items-end gap-2">
                                <label class="flex items-center gap-1 text-xs">
                                    <input type="checkbox" id="cam-${camId}-has_siren" ${cam.has_siren ? 'checked' : ''}>
                                    警报
                                </label>
                                <label class="flex items-center gap-1 text-xs">
                                    <input type="checkbox" id="cam-${camId}-has_light" ${cam.has_light ? 'checked' : ''}>
                                    灯光
                                </label>
                            </div>
                        </div>
                        <div class="flex justify-end mt-3">
                            <button onclick="saveCamera('${camId}')" class="bg-blue-600 hover:bg-blue-500 px-3 py-1 rounded text-sm">💾 保存</button>
                        </div>
                    </div>`;
                }
                camListEl.innerHTML = html;
                
                console.log('摄像头配置已加载', data);
            } catch (e) {
                console.error('加载摄像头配置失败:', e);
            }
        }
        
        async function saveCamera(camId) {
            const params = {
                ip: document.getElementById('cam-' + camId + '-ip').value,
                zone_mode: document.getElementById('cam-' + camId + '-zone_mode').value,
                direction: document.getElementById('cam-' + camId + '-direction').value,
                door_threshold: parseFloat(document.getElementById('cam-' + camId + '-door_threshold').value),
                yard_threshold: parseFloat(document.getElementById('cam-' + camId + '-yard_threshold').value),
                has_siren: document.getElementById('cam-' + camId + '-has_siren').checked,
                has_light: document.getElementById('cam-' + camId + '-has_light').checked,
            };
            
            try {
                const res = await fetch('/api/cameras/' + camId, {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify(params)
                });
                const data = await res.json();
                if (data.success) {
                    alert('✅ 摄像头 ' + camId + ' 配置已保存');
                    setTimeout(loadCameras, 500);
                } else {
                    alert('保存失败: ' + (data.error || '未知错误'));
                }
            } catch (e) {
                alert('请求失败: ' + e.message);
            }
        }
        
        // 初始化
        fetchStatus();
        setInterval(fetchStatus, 2000);
        setTimeout(loadConfig, 1000);
        setTimeout(loadCameras, 1500);
    </script>
</body>
</html>"""
    return HTMLResponse(content=html)

# =============================================================================
# 主入口
# =============================================================================

if __name__ == "__main__":
    print("=" * 60)
    print("NG Edge HMI Server")
    print("=" * 60)
    print(f"  MQTT: {MQTT_HOST}:{MQTT_PORT}")
    print(f"  HTTP: http://0.0.0.0:{HTTP_PORT}")
    print("=" * 60)
    
    uvicorn.run(app, host="0.0.0.0", port=HTTP_PORT)
