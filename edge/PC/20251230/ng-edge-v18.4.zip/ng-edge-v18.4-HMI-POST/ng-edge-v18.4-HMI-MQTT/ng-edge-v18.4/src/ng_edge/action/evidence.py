"""
Evidence Policy - 证据收集策略 (v2.2 §7)

控制什么时候收集什么类型的证据。

设计原则：
1. CANDIDATE 模式：怀疑阶段就开始收集
2. 分层收集：PRE 收集 snapshot，TRIGGERED 收集 clip
3. 本地优先：先存本地，后台上传
"""

from dataclasses import dataclass, field
from datetime import datetime, timezone, timedelta
from typing import Dict, List, Optional, Set, Callable
from enum import Enum
import uuid

from ng_edge.state.states import ThreatState, WorkflowState


class EvidenceType(str, Enum):
    """证据类型"""
    SNAPSHOT = "snapshot"           # 静态图片
    VIDEO_CLIP = "video_clip"       # 视频片段
    AUDIO_CLIP = "audio_clip"       # 音频片段
    SENSOR_LOG = "sensor_log"       # 传感器日志
    TIMELINE = "timeline"           # 时间线数据


class EvidenceStatus(str, Enum):
    """证据状态"""
    PENDING = "pending"             # 待收集
    COLLECTING = "collecting"       # 收集中
    LOCAL = "local"                 # 已存本地
    UPLOADING = "uploading"         # 上传中
    UPLOADED = "uploaded"           # 已上传
    FAILED = "failed"               # 失败


class EvidencePriority(str, Enum):
    """证据优先级"""
    LOW = "low"
    NORMAL = "normal"
    HIGH = "high"
    CRITICAL = "critical"


@dataclass
class EvidenceRequest:
    """证据收集请求"""
    request_id: str
    evidence_type: EvidenceType
    priority: EvidencePriority
    
    # 来源
    incident_id: str
    device_id: str
    zone_id: str = ""
    
    # 时间范围
    start_time: Optional[datetime] = None
    end_time: Optional[datetime] = None
    duration_sec: int = 0
    
    # 状态
    status: EvidenceStatus = EvidenceStatus.PENDING
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    
    # 结果
    local_path: str = ""
    cloud_url: str = ""
    file_size_bytes: int = 0
    
    # 元数据
    metadata: Dict = field(default_factory=dict)


@dataclass
class EvidencePolicyConfig:
    """证据策略配置"""
    # 触发条件
    collect_on_pre_l1: bool = False       # PRE_L1 不收集
    collect_on_pre_l2: bool = True        # PRE_L2 开始 snapshot
    collect_on_pre_l3: bool = True        # PRE_L3 继续收集
    collect_on_pending: bool = True       # PENDING 收集
    collect_on_triggered: bool = True     # TRIGGERED 收集
    
    # 收集类型
    pre_evidence_types: Set[EvidenceType] = field(default_factory=lambda: {
        EvidenceType.SNAPSHOT,
    })
    
    pending_evidence_types: Set[EvidenceType] = field(default_factory=lambda: {
        EvidenceType.SNAPSHOT,
        EvidenceType.SENSOR_LOG,
    })
    
    triggered_evidence_types: Set[EvidenceType] = field(default_factory=lambda: {
        EvidenceType.SNAPSHOT,
        EvidenceType.VIDEO_CLIP,
        EvidenceType.SENSOR_LOG,
        EvidenceType.TIMELINE,
    })
    
    # 视频片段配置
    pre_clip_duration_sec: int = 10       # PRE 阶段录制 10 秒
    triggered_clip_duration_sec: int = 60 # TRIGGERED 录制 60 秒
    max_clip_duration_sec: int = 300      # 最大 5 分钟
    
    # 保留策略
    local_retention_hours: int = 24       # 本地保留 24 小时
    cloud_retention_days: int = 30        # 云端保留 30 天
    
    # 上传策略
    upload_on_triggered: bool = True      # TRIGGERED 时上传
    upload_delay_sec: int = 5             # 上传延迟（等待更多证据）


class EvidencePolicy:
    """
    证据收集策略控制器
    
    使用方式:
        policy = EvidencePolicy()
        
        # 状态变化时检查是否需要收集证据
        requests = policy.on_state_change(
            incident_id="inc_001",
            new_threat=ThreatState.PRE_L2,
            devices=["cam_front", "cam_side"],
        )
        
        for req in requests:
            collector.collect(req)
    """
    
    def __init__(self, config: Optional[EvidencePolicyConfig] = None):
        self.config = config or EvidencePolicyConfig()
        
        # 请求队列
        self._pending_requests: Dict[str, EvidenceRequest] = {}
        self._completed_requests: Dict[str, EvidenceRequest] = {}
        
        # 事件 → 请求映射
        self._incident_requests: Dict[str, List[str]] = {}
        
        # 回调
        self.on_request_created: Optional[Callable[[EvidenceRequest], None]] = None
        self.on_request_completed: Optional[Callable[[EvidenceRequest], None]] = None
        
        # 统计
        self.stats = {
            "requests_created": 0,
            "requests_completed": 0,
            "requests_failed": 0,
            "snapshots_collected": 0,
            "clips_collected": 0,
        }
    
    def on_state_change(
        self,
        incident_id: str,
        new_threat: ThreatState,
        devices: List[str],
        zone_id: str = "",
        old_threat: Optional[ThreatState] = None,
    ) -> List[EvidenceRequest]:
        """
        状态变化时触发证据收集
        
        Args:
            incident_id: 事件 ID
            new_threat: 新威胁状态
            devices: 相关设备列表
            zone_id: 区域 ID
            old_threat: 旧威胁状态（可选）
            
        Returns:
            List[EvidenceRequest]: 创建的证据请求
        """
        if not self._should_collect(new_threat):
            return []
        
        evidence_types = self._get_evidence_types(new_threat)
        if not evidence_types:
            return []
        
        requests = []
        priority = self._get_priority(new_threat)
        
        for device_id in devices:
            for etype in evidence_types:
                request = self._create_request(
                    incident_id=incident_id,
                    device_id=device_id,
                    zone_id=zone_id,
                    evidence_type=etype,
                    priority=priority,
                    threat_state=new_threat,
                )
                requests.append(request)
        
        return requests
    
    def get_pending_requests(self, incident_id: str = None) -> List[EvidenceRequest]:
        """获取待处理的请求"""
        if incident_id:
            request_ids = self._incident_requests.get(incident_id, [])
            return [
                self._pending_requests[rid]
                for rid in request_ids
                if rid in self._pending_requests
            ]
        return list(self._pending_requests.values())
    
    def get_requests_by_incident(self, incident_id: str) -> List[EvidenceRequest]:
        """获取事件的所有请求（包括已完成）"""
        request_ids = self._incident_requests.get(incident_id, [])
        requests = []
        
        for rid in request_ids:
            if rid in self._pending_requests:
                requests.append(self._pending_requests[rid])
            elif rid in self._completed_requests:
                requests.append(self._completed_requests[rid])
        
        return requests
    
    def update_status(
        self,
        request_id: str,
        status: EvidenceStatus,
        local_path: str = "",
        cloud_url: str = "",
        file_size: int = 0,
    ) -> Optional[EvidenceRequest]:
        """
        更新请求状态
        
        Args:
            request_id: 请求 ID
            status: 新状态
            local_path: 本地路径
            cloud_url: 云端 URL
            file_size: 文件大小
            
        Returns:
            EvidenceRequest: 更新后的请求
        """
        request = self._pending_requests.get(request_id)
        if not request:
            return None
        
        request.status = status
        
        if local_path:
            request.local_path = local_path
        if cloud_url:
            request.cloud_url = cloud_url
        if file_size:
            request.file_size_bytes = file_size
        
        # 完成或失败时移动到 completed
        if status in {EvidenceStatus.UPLOADED, EvidenceStatus.FAILED, EvidenceStatus.LOCAL}:
            self._pending_requests.pop(request_id, None)
            self._completed_requests[request_id] = request
            
            if status == EvidenceStatus.FAILED:
                self.stats["requests_failed"] += 1
            else:
                self.stats["requests_completed"] += 1
                
                if request.evidence_type == EvidenceType.SNAPSHOT:
                    self.stats["snapshots_collected"] += 1
                elif request.evidence_type == EvidenceType.VIDEO_CLIP:
                    self.stats["clips_collected"] += 1
            
            if self.on_request_completed:
                self.on_request_completed(request)
        
        return request
    
    def should_upload(self, threat_state: ThreatState) -> bool:
        """检查是否应该上传"""
        if not self.config.upload_on_triggered:
            return False
        return threat_state == ThreatState.TRIGGERED
    
    def get_clip_duration(self, threat_state: ThreatState) -> int:
        """获取视频片段时长"""
        if threat_state == ThreatState.TRIGGERED:
            return self.config.triggered_clip_duration_sec
        return self.config.pre_clip_duration_sec
    
    def get_stats(self) -> Dict:
        """获取统计信息"""
        return {
            **self.stats,
            "pending_requests": len(self._pending_requests),
            "completed_requests": len(self._completed_requests),
        }
    
    # =========================================================================
    # 内部方法
    # =========================================================================
    
    def _should_collect(self, threat_state: ThreatState) -> bool:
        """检查是否应该收集"""
        if threat_state == ThreatState.NONE:
            return False
        if threat_state == ThreatState.PRE_L1:
            return self.config.collect_on_pre_l1
        if threat_state == ThreatState.PRE_L2:
            return self.config.collect_on_pre_l2
        if threat_state == ThreatState.PRE_L3:
            return self.config.collect_on_pre_l3
        if threat_state == ThreatState.PENDING:
            return self.config.collect_on_pending
        if threat_state == ThreatState.TRIGGERED:
            return self.config.collect_on_triggered
        return False
    
    def _get_evidence_types(self, threat_state: ThreatState) -> Set[EvidenceType]:
        """获取应收集的证据类型"""
        if threat_state in {ThreatState.PRE_L1, ThreatState.PRE_L2, ThreatState.PRE_L3}:
            return self.config.pre_evidence_types
        if threat_state == ThreatState.PENDING:
            return self.config.pending_evidence_types
        if threat_state == ThreatState.TRIGGERED:
            return self.config.triggered_evidence_types
        return set()
    
    def _get_priority(self, threat_state: ThreatState) -> EvidencePriority:
        """获取优先级"""
        if threat_state == ThreatState.TRIGGERED:
            return EvidencePriority.CRITICAL
        if threat_state == ThreatState.PENDING:
            return EvidencePriority.HIGH
        if threat_state == ThreatState.PRE_L3:
            return EvidencePriority.NORMAL
        return EvidencePriority.LOW
    
    def _create_request(
        self,
        incident_id: str,
        device_id: str,
        zone_id: str,
        evidence_type: EvidenceType,
        priority: EvidencePriority,
        threat_state: ThreatState,
    ) -> EvidenceRequest:
        """创建证据请求"""
        request_id = f"ev_{uuid.uuid4().hex[:8]}"
        now = datetime.now(timezone.utc)
        
        # 计算时间范围
        duration = 0
        if evidence_type == EvidenceType.VIDEO_CLIP:
            duration = self.get_clip_duration(threat_state)
        
        request = EvidenceRequest(
            request_id=request_id,
            evidence_type=evidence_type,
            priority=priority,
            incident_id=incident_id,
            device_id=device_id,
            zone_id=zone_id,
            start_time=now,
            duration_sec=duration,
            metadata={
                "threat_state": threat_state.value,
            },
        )
        
        # 注册请求
        self._pending_requests[request_id] = request
        
        if incident_id not in self._incident_requests:
            self._incident_requests[incident_id] = []
        self._incident_requests[incident_id].append(request_id)
        
        self.stats["requests_created"] += 1
        
        if self.on_request_created:
            self.on_request_created(request)
        
        return request
