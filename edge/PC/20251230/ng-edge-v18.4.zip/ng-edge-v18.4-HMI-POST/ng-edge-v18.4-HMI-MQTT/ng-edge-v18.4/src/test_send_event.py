#!/usr/bin/env python3
"""
NG Edge - Event Send Test (No external dependencies)

测试从 Edge 发送安防事件到服务器

Usage:
    DEVICE_KEY=$(sudo cat /var/lib/ng-edge/device_key)
    python3 test_send_event.py --server http://10.0.0.136:3001 --device-key "$DEVICE_KEY"
"""

import argparse
import json
import sys
from datetime import datetime, timezone
from urllib.request import Request, urlopen
from urllib.error import URLError, HTTPError
import uuid


def http_request(url: str, method: str = "GET", data: dict = None, headers: dict = None) -> tuple:
    """Make HTTP request using stdlib."""
    headers = headers or {}
    headers["Content-Type"] = "application/json"
    
    body = json.dumps(data).encode() if data else None
    req = Request(url, data=body, headers=headers, method=method)
    
    try:
        with urlopen(req, timeout=10) as resp:
            response_data = json.loads(resp.read().decode())
            return resp.status, response_data
    except HTTPError as e:
        try:
            response_data = json.loads(e.read().decode())
        except:
            response_data = {"error": str(e)}
        return e.code, response_data
    except URLError as e:
        return 0, {"error": str(e.reason)}
    except Exception as e:
        return 0, {"error": str(e)}


def create_motion_event() -> dict:
    """创建一个运动检测事件"""
    return {
        "eventType": "MOTION",
        "title": f"运动检测 - 测试事件 {datetime.now().strftime('%H:%M:%S')}",
        "description": "Edge 发送的测试运动检测事件",
        "severity": "LOW",
        "occurredAt": datetime.now(timezone.utc).isoformat(),
    }


def create_intrusion_event() -> dict:
    """创建一个入侵检测事件"""
    return {
        "eventType": "INTRUSION",
        "title": f"入侵警报 - 测试事件 {datetime.now().strftime('%H:%M:%S')}",
        "description": "前门打开 + 室内 PIR 检测到移动 (离家模式)",
        "severity": "HIGH",
        "occurredAt": datetime.now(timezone.utc).isoformat(),
    }


def create_door_event() -> dict:
    """创建一个门窗事件"""
    return {
        "eventType": "DOOR_OPEN",
        "title": f"前门打开 - 测试事件 {datetime.now().strftime('%H:%M:%S')}",
        "description": "前门传感器检测到门被打开",
        "severity": "MEDIUM",
        "occurredAt": datetime.now(timezone.utc).isoformat(),
    }


def main():
    parser = argparse.ArgumentParser(description="Test Event Send")
    parser.add_argument("--server", "-s", default="http://10.0.0.136:3001")
    parser.add_argument("--device-key", "-k", required=True, help="Device key")
    parser.add_argument("--type", "-t", choices=["motion", "intrusion", "door"], 
                        default="motion", help="Event type to send")
    parser.add_argument("--custom-title", help="Custom event title")
    
    args = parser.parse_args()
    
    server = args.server.rstrip("/")
    device_key = args.device_key.strip()
    
    print("=" * 60)
    print("NG Edge - Event Send Test")
    print("=" * 60)
    print(f"Server:     {server}")
    print(f"Device Key: {device_key[:30]}...")
    print(f"Event Type: {args.type}")
    print()
    
    # Create event based on type
    if args.type == "motion":
        event = create_motion_event()
    elif args.type == "intrusion":
        event = create_intrusion_event()
    elif args.type == "door":
        event = create_door_event()
    
    # Override title if custom provided
    if args.custom_title:
        event["title"] = args.custom_title
    
    print("Event Payload:")
    print("-" * 40)
    print(json.dumps(event, indent=2, ensure_ascii=False))
    print("-" * 40)
    print()
    
    # Send event
    print("Sending event to server...")
    url = f"{server}/api/edge/events"
    headers = {"Authorization": f"Device {device_key}"}
    
    print(f"  URL: {url}")
    print(f"  Auth: Device {device_key[:20]}...")
    
    status, data = http_request(url, method="POST", data=event, headers=headers)
    
    print()
    print(f"Response Status: {status}")
    print(f"Response Body:")
    print(json.dumps(data, indent=2, ensure_ascii=False))
    print()
    
    if status == 200 and data.get("success"):
        event_id = data.get("event", {}).get("id", "unknown")
        print("=" * 60)
        print("✓ EVENT SENT SUCCESSFULLY")
        print("=" * 60)
        print(f"Event ID: {event_id}")
        print()
        print("验证方法:")
        print(f"  1. 在服务器 UI 中查看事件列表")
        print(f"  2. 或通过 API 查询: GET /api/events/<circle_id>")
        return 0
    else:
        print("=" * 60)
        print("✗ EVENT SEND FAILED")
        print("=" * 60)
        print(f"Error: {data}")
        return 1


if __name__ == "__main__":
    sys.exit(main())
