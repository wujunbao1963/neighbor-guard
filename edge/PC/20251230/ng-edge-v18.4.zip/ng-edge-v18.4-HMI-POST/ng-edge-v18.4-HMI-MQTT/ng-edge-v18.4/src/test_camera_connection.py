#!/usr/bin/env python3
"""
摄像头连接测试脚本

测试 Reolink 摄像头的:
1. 基础连接
2. 能力检测 (Siren/Spotlight)
3. Siren 开关
4. Spotlight 开关
5. 威慑模式
"""

import asyncio
import sys
import json

# 添加路径
sys.path.insert(0, '.')

from ng_edge.hardware.reolink_control import (
    ReolinkCameraControl,
    CameraConnection,
)


async def test_camera(ip: str, username: str, password: str):
    """测试单个摄像头"""
    print("=" * 60)
    print(f"测试摄像头: {ip}")
    print("=" * 60)
    
    conn = CameraConnection(
        ip=ip,
        username=username,
        password=password,
        port=80,
        timeout=10,
    )
    
    ctrl = ReolinkCameraControl(conn)
    
    try:
        # 1. 测试连接
        print("\n[1] 测试连接...")
        result = await ctrl.test_connection()
        
        if not result["success"]:
            print(f"  ❌ 连接失败: {result.get('error')}")
            return False
        
        print(f"  ✅ 连接成功!")
        
        if "device" in result:
            dev = result["device"]
            print(f"  📷 型号: {dev.get('model', 'unknown')}")
            print(f"  📋 固件: {dev.get('firmware', 'unknown')}")
        
        print(f"  🔧 能力: {result.get('capabilities', [])}")
        print(f"  🔔 有Siren: {result.get('has_siren', False)}")
        print(f"  💡 有Spotlight: {result.get('has_spotlight', False)}")
        
        # 2. 测试 Spotlight
        if result.get('has_spotlight'):
            print("\n[2] 测试 Spotlight...")
            
            print("  → 开启灯光...")
            r = await ctrl.spotlight_on(brightness=50)
            print(f"  结果: {r}")
            
            await asyncio.sleep(2)
            
            print("  → 关闭灯光...")
            r = await ctrl.spotlight_off()
            print(f"  结果: {r}")
        else:
            print("\n[2] 跳过 Spotlight 测试 (不支持)")
        
        # 3. 测试 Siren (可选，因为很吵)
        if result.get('has_siren'):
            print("\n[3] Siren 测试 (跳过，避免噪音)")
            print("  如需测试，请取消下面的注释")
            # print("  → 开启警报...")
            # r = await ctrl.siren_cycle(times=1)
            # print(f"  结果: {r}")
        else:
            print("\n[3] 跳过 Siren 测试 (不支持)")
        
        print("\n" + "=" * 60)
        print("✅ 测试完成!")
        print("=" * 60)
        return True
        
    except Exception as e:
        print(f"  ❌ 异常: {e}")
        import traceback
        traceback.print_exc()
        return False
    finally:
        await ctrl.close()


async def main():
    # 默认摄像头配置
    cameras = [
        {"ip": "10.0.0.155", "name": "Back Door"},
        {"ip": "10.0.0.156", "name": "Front Door"},
    ]
    
    username = "admin"
    password = "Zafac05@a"
    
    # 命令行参数覆盖
    if len(sys.argv) >= 4:
        cameras = [{"ip": sys.argv[1], "name": "CLI Camera"}]
        username = sys.argv[2]
        password = sys.argv[3]
    elif len(sys.argv) == 2:
        # 只测试指定 IP
        cameras = [{"ip": sys.argv[1], "name": "CLI Camera"}]
    
    print("Reolink 摄像头测试工具")
    print("=" * 60)
    
    for cam in cameras:
        print(f"\n>>> 测试 {cam['name']} ({cam['ip']})")
        await test_camera(cam["ip"], username, password)
        print()


if __name__ == "__main__":
    print("用法:")
    print("  python3 test_camera_connection.py              # 测试预配置摄像头")
    print("  python3 test_camera_connection.py <ip>         # 测试指定IP")
    print("  python3 test_camera_connection.py <ip> <user> <pass>  # 完整参数")
    print()
    
    asyncio.run(main())
