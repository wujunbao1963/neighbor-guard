"""
Camera Signal Adapter

将 CameraSignalSource 的输出转换为 SignalEnvelope 格式。
支持 camera_role 配置 (judge/witness)。
"""

from typing import Dict, Any, Optional, List
from datetime import datetime, timezone
from dataclasses import dataclass

from ng_edge.core.signal import (
    SignalEnvelope, 
    CameraRole, 
    PreLevel,
    SourceType,
    Hardness,
)


# 信号类型映射
CAMERA_SIGNAL_KIND_MAP = {
    "PERSON_DETECTED": "person_detected",
    "VEHICLE_DETECTED": "vehicle_detected",
    "person_detected": "person_detected",
    "vehicle_detected": "vehicle_detected",
}


@dataclass
class CameraRoleConfig:
    """摄像头角色配置"""
    camera_id: str
    role: CameraRole = CameraRole.JUDGE
    zone_id: str = ""
    entrypoint_id: Optional[str] = None


def convert_camera_signal(
    signal,  # ng_edge.domain.models.Signal
    camera_role: CameraRole = CameraRole.JUDGE,
    entrypoint_id: Optional[str] = None,
) -> Optional[SignalEnvelope]:
    """
    将 CameraSignalSource 的 Signal 转换为 SignalEnvelope
    
    Args:
        signal: 原始 Signal 对象 (from domain.models)
        camera_role: 摄像头角色 (judge/witness)
        entrypoint_id: 关联的入口点 ID
    
    Returns:
        SignalEnvelope 或 None
    """
    # 获取信号类型
    signal_type_str = str(signal.signal_type.value) if hasattr(signal.signal_type, 'value') else str(signal.signal_type)
    signal_kind = CAMERA_SIGNAL_KIND_MAP.get(signal_type_str, signal_type_str.lower())
    
    # 提取检测信息
    raw_payload = signal.raw_payload or {}
    best_detection = raw_payload.get("best_detection", {})
    
    # 计算 PRE level (基于置信度)
    confidence = signal.confidence
    level = None
    if confidence >= 0.85:
        level = PreLevel.L2
    elif confidence >= 0.7:
        level = PreLevel.L1
    
    # 构建属性
    attributes = {
        "sensor_id": signal.sensor_id,
        "detection_count": raw_payload.get("detection_count", 1),
        "class_name": best_detection.get("class", "unknown"),
        "raw_payload": raw_payload,
    }
    
    if best_detection.get("bbox"):
        attributes["bbox"] = tuple(best_detection["bbox"])
    
    # 创建 SignalEnvelope
    return SignalEnvelope(
        signal_id=signal.signal_id,
        source_type=SourceType.CAMERA,
        device_id=signal.sensor_id,
        zone_id=signal.zone_id or "",
        entrypoint_id=entrypoint_id,
        signal_kind=signal_kind,
        hardness=Hardness.SOFT,  # 摄像头信号始终是 SOFT
        level=level,
        confidence=confidence,
        timestamp=signal.timestamp,
        ingest_ts=datetime.now(timezone.utc),
        camera_role=camera_role,
        attributes=attributes,
        evidence_hints={
            "camera_name": raw_payload.get("camera", {}).get("name", ""),
        }
    )


class CameraSignalAdapter:
    """
    Camera 信号适配器
    
    管理多个摄像头的角色配置，并将信号转换为 SignalEnvelope。
    
    使用方式:
        adapter = CameraSignalAdapter()
        adapter.configure_camera("cam_front", CameraRole.JUDGE, "ep_front")
        adapter.configure_camera("cam_blink", CameraRole.WITNESS)
        
        envelope = adapter.convert(signal)
    """
    
    def __init__(self):
        self._camera_configs: Dict[str, CameraRoleConfig] = {}
        self.stats = {
            "signals_received": 0,
            "signals_converted": 0,
            "unknown_cameras": 0,
        }
    
    def configure_camera(
        self,
        camera_id: str,
        role: CameraRole = CameraRole.JUDGE,
        entrypoint_id: Optional[str] = None,
        zone_id: str = "",
    ):
        """
        配置摄像头角色
        
        Args:
            camera_id: 摄像头 ID (对应 signal.sensor_id)
            role: 角色 (JUDGE 或 WITNESS)
            entrypoint_id: 关联的入口点
            zone_id: 区域 ID
        """
        self._camera_configs[camera_id] = CameraRoleConfig(
            camera_id=camera_id,
            role=role,
            zone_id=zone_id,
            entrypoint_id=entrypoint_id,
        )
    
    def get_camera_config(self, camera_id: str) -> Optional[CameraRoleConfig]:
        """获取摄像头配置"""
        return self._camera_configs.get(camera_id)
    
    def convert(self, signal) -> Optional[SignalEnvelope]:
        """
        转换信号
        
        Args:
            signal: CameraSignalSource 生成的 Signal
        
        Returns:
            SignalEnvelope 或 None
        """
        self.stats["signals_received"] += 1
        
        camera_id = signal.sensor_id
        config = self._camera_configs.get(camera_id)
        
        if config:
            role = config.role
            entrypoint_id = config.entrypoint_id
        else:
            # 未配置的摄像头默认为 JUDGE
            self.stats["unknown_cameras"] += 1
            role = CameraRole.JUDGE
            entrypoint_id = None
        
        envelope = convert_camera_signal(signal, role, entrypoint_id)
        
        if envelope:
            self.stats["signals_converted"] += 1
        
        return envelope
    
    def get_stats(self) -> Dict[str, Any]:
        """获取统计信息"""
        return {
            **self.stats,
            "configured_cameras": len(self._camera_configs),
            "judge_cameras": sum(1 for c in self._camera_configs.values() if c.role == CameraRole.JUDGE),
            "witness_cameras": sum(1 for c in self._camera_configs.values() if c.role == CameraRole.WITNESS),
        }
