#!/bin/bash
# 摄像头连接测试脚本
# 用法: ./test_camera_curl.sh <ip> <user> <password>

IP=${1:-10.0.0.155}
USER=${2:-admin}
PASS=${3:-Zafac05@a}

echo "=================================================="
echo "测试摄像头: $IP"
echo "=================================================="

# 1. 测试基本连接 - GetDevInfo
echo ""
echo "[1] 测试连接 (GetDevInfo)..."
curl -s -X POST "http://$IP/cgi-bin/api.cgi?user=$USER&password=$PASS" \
  -d '[{"cmd":"GetDevInfo","action":0}]' | python3 -m json.tool 2>/dev/null || echo "连接失败"

echo ""
echo "[2] 测试能力 (GetAbility)..."
curl -s -X POST "http://$IP/cgi-bin/api.cgi?user=$USER&password=$PASS" \
  -d "[{\"cmd\":\"GetAbility\",\"action\":0,\"param\":{\"User\":{\"userName\":\"$USER\"}}}]" | head -c 500
echo "..."

echo ""
echo "[3] 测试 Spotlight (开灯 2 秒后关灯)..."
echo "  开灯..."
curl -s -X POST "http://$IP/cgi-bin/api.cgi?user=$USER&password=$PASS" \
  -d '[{"cmd":"SetWhiteLed","param":{"WhiteLed":{"bright":100,"channel":0,"mode":1,"state":1}}}]'
echo ""

sleep 2

echo "  关灯..."
curl -s -X POST "http://$IP/cgi-bin/api.cgi?user=$USER&password=$PASS" \
  -d '[{"cmd":"SetWhiteLed","param":{"WhiteLed":{"bright":100,"channel":0,"mode":0,"state":0}}}]'
echo ""

echo ""
echo "=================================================="
echo "测试完成"
echo "=================================================="
