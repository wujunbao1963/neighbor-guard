"""
威慑系统 - 单循环 + 去抖 + 多传感器聚合

设计原则：
1. 单一永不取消的循环，避免竞争条件
2. 多传感器独立报告，系统取最高级别
3. 去抖 + 最短持续时间，防止频繁切换
4. 可配置的缓冲期和警报延迟
5. TRIGGERED 独立于传感器，只能通过 disarm/resolve 结束

架构：
    ┌─────────────────────────────────────────────────────────────┐
    │ PRE 层（传感器驱动）          TRIGGERED 层（状态驱动）       │
    │ ┌─────────────────────┐      ┌─────────────────────┐        │
    │ │ _sensor_reports     │      │ _triggered_active   │        │
    │ │ cam_A: (L2, ts)     │      │ _triggered_start    │        │
    │ │ cam_B: (L1, ts)     │      │ _siren_timed_out    │        │
    │ └──────────┬──────────┘      └──────────┬──────────┘        │
    │            │                            │                   │
    │            ↓                            ↓                   │
    │      聚合 max()                    优先级覆盖               │
    │            │                            │                   │
    │            └────────────┬───────────────┘                   │
    │                         ↓                                   │
    │              get_effective_level() 返回最终级别              │
    │              - 如果 _triggered_active → 返回 TRIGGERED      │
    │              - 否则 → 返回 PRE max                          │
    └─────────────────────────────────────────────────────────────┘

TRIGGERED 结束条件（只有这三种）：
1. disarm - 用户撤防 → force_stop()
2. resolve - 用户确认解决 → set_triggered(False)
3. siren_timeout - 只停声光，状态仍是 TRIGGERED → siren_timeout()

使用方式：
    system = DeterrentSystem(
        on_spotlight=async_spotlight_func,
        on_siren=async_siren_func,
    )
    await system.start()
    
    # 摄像头检测回调中（PRE 层）
    system.report_sensor("cam_front", 2)  # L2
    system.report_sensor("cam_back", 1)   # L1
    
    # 状态机 TRIGGERED 时
    system.set_triggered(True)
    
    # 用户撤防时
    system.force_stop()
"""

import asyncio
import time
import logging
from typing import Callable, Awaitable, Optional, Dict, Any

logger = logging.getLogger(__name__)


class DeterrentSystem:
    """威慑系统 - 单循环 + 去抖 + 多传感器聚合 + TRIGGERED 独立管理"""
    
    # ========== 可配置参数 ==========
    
    # 传感器超时（秒）- 无报告视为离开
    # RTX 4060 检测快速稳定，2秒足够判断离开
    SENSOR_TIMEOUT = 2.0
    
    # 去抖时间（秒）- RTX 4060 + yolo11m 检测稳定，可减少去抖
    DEBOUNCE_UP = 0.3      # 升级去抖 - 快速响应威胁
    DEBOUNCE_DOWN = 1.0    # 降级去抖 - 从 2s 减少到 1s
    
    # 最短持续时间（秒）- RTX 4060 检测稳定，可减少
    MIN_HOLD_L1 = 2.0      # 从 3s 减少到 2s
    MIN_HOLD_L2 = 3.0      # 从 5s 减少到 3s
    MIN_HOLD_TRIGGERED = 10.0
    
    # L1 效果参数
    L1_START_DELAY = 0       # 缓冲期（默认无）
    L1_SIREN_DELAY = 20      # 警报延迟 20 秒（送快递场景，给人时间离开）
    L1_SIREN_INTERVAL = 30   # 警报间隔
    L1_SIREN_DURATION = 1    # 警报持续
    
    # L2 效果参数
    L2_START_DELAY = 0       # 缓冲期（默认无）
    L2_SIREN_DELAY = 0       # 警报延迟（默认无）
    L2_FLASH_ON = 5          # 闪灯亮时间
    L2_FLASH_OFF = 5         # 闪灯灭时间
    L2_SIREN_INTERVAL = 10   # 警报间隔
    L2_SIREN_DURATION = 2    # 警报持续
    
    # L3 效果参数（同 L2，可单独配置）
    L3_START_DELAY = 0
    L3_SIREN_DELAY = 0
    L3_FLASH_ON = 3
    L3_FLASH_OFF = 3
    L3_SIREN_INTERVAL = 5
    L3_SIREN_DURATION = 2
    
    # TRIGGERED 效果参数
    TRIGGERED_FLASH_ON = 1
    TRIGGERED_FLASH_OFF = 1
    TRIGGERED_SIREN_INTERVAL = 3
    TRIGGERED_SIREN_DURATION = 3
    TRIGGERED_MAX_DURATION = 180  # 声光最长持续时间（秒），之后只停声光，状态不变
    
    # 循环间隔
    LOOP_INTERVAL = 0.5
    
    # ========== 级别常量 ==========
    LEVEL_OFF = 0
    LEVEL_L1 = 1
    LEVEL_L2 = 2
    LEVEL_L3 = 3
    LEVEL_TRIGGERED = 10
    
    def __init__(
        self,
        on_spotlight: Optional[Callable[[bool], Awaitable[None]]] = None,
        on_siren: Optional[Callable[[float], Awaitable[None]]] = None,
        config: Optional[Dict[str, Any]] = None,
        entry_point_id: str = "unknown",
    ):
        """
        初始化威慑系统
        
        Args:
            on_spotlight: 灯光控制回调，参数为 True（开）或 False（关）
            on_siren: 警报控制回调，参数为持续时间（秒）
            config: 可选配置覆盖
            entry_point_id: 入口点 ID，用于日志标识
        """
        # Entry Point 标识
        self._ep_id = entry_point_id
        self._log_prefix = f"[DETERRENT:{entry_point_id}]"
        
        # 回调
        self._on_spotlight = on_spotlight
        self._on_siren = on_siren
        
        # 应用配置
        if config:
            self._apply_config(config)
        
        # ========== PRE 层状态（传感器驱动）==========
        # 多传感器报告：sensor_id → (level, timestamp)
        self._sensor_reports: Dict[str, tuple] = {}
        
        # ========== TRIGGERED 层状态（状态机驱动）==========
        self._triggered_active: bool = False      # TRIGGERED 是否激活
        self._triggered_start: float = 0          # TRIGGERED 开始时间
        self._siren_timed_out: bool = False       # 声光是否已超时（只停输出，状态保持）
        
        # ========== 聚合后的状态 ==========
        # 期望状态（聚合后的最高级别）
        self._desired_level: int = 0
        
        # 当前确认状态
        self._confirmed_level: int = 0
        self._confirmed_time: float = 0
        
        # 待确认状态（去抖中）
        self._pending_level: Optional[int] = None
        self._pending_time: float = 0
        self._pending_debounce: float = 0
        
        # 设备状态
        self._light_on: bool = False
        self._last_siren_time: float = 0
        
        # 控制
        self.running: bool = False
        self._task: Optional[asyncio.Task] = None
        
        # 统计
        self.level_changes: list = []
    
    def _apply_config(self, config: Dict[str, Any]):
        """应用配置"""
        for key, value in config.items():
            if hasattr(self, key.upper()):
                setattr(self, key.upper(), value)
                logger.debug(f"{self._log_prefix} 配置 {key}={value}")
    
    async def start(self):
        """启动威慑系统（只调用一次）"""
        if self.running:
            logger.warning(f"{self._log_prefix} 系统已在运行")
            return
        
        self.running = True
        self._task = asyncio.create_task(self._run_loop())
        logger.info(f"{self._log_prefix} 系统启动")
    
    async def stop(self):
        """停止威慑系统"""
        if not self.running:
            return
        
        self.running = False
        
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
        
        # 确保关闭所有设备
        await self._set_spotlight(False)
        logger.info(f"{self._log_prefix} 系统停止")
    
    # ========== PRE 层接口 ==========
    
    def report_sensor(self, sensor_id: str, level: int):
        """
        传感器报告检测结果（高频调用）
        
        多个传感器独立报告，系统取最高级别。
        注意：这只影响 PRE 层，不影响 TRIGGERED 状态。
        
        Args:
            sensor_id: 传感器标识（如 "cam_front", "cam_back"）
            level: 检测级别（0=OFF, 1=L1, 2=L2, 3=L3）
        """
        # 不允许通过传感器设置 TRIGGERED
        if level >= self.LEVEL_TRIGGERED:
            logger.warning(f"{self._log_prefix} 传感器不能设置 TRIGGERED 级别，忽略")
            return
        
        old_report = self._sensor_reports.get(sensor_id)
        self._sensor_reports[sensor_id] = (level, time.time())
        
        # 调试日志已注释（v2.39）
        # if old_report is None or old_report[0] != level:
        #     from datetime import datetime
        #     ts = datetime.now().strftime("%H:%M:%S.%f")[:-3]
        #     print(f"[{ts}] {self._log_prefix} sensor_reports[{sensor_id}] = L{level} (was L{old_report[0] if old_report else 'None'})")
    
    # ========== TRIGGERED 层接口 ==========
    
    def set_triggered(self, triggered: bool):
        """
        设置 TRIGGERED 状态（由 SecurityCoordinator 调用）
        
        TRIGGERED 独立于传感器检测，不会因传感器超时而结束。
        只能通过以下方式结束：
        1. set_triggered(False) - 状态机变为非 TRIGGERED
        2. force_stop() - 用户撤防
        
        Args:
            triggered: True 激活 TRIGGERED，False 解除
        """
        if triggered:
            if not self._triggered_active:
                self._triggered_active = True
                self._triggered_start = time.time()
                self._siren_timed_out = False
                logger.warning(f"{self._log_prefix} 🚨 TRIGGERED 激活")
        else:
            if self._triggered_active:
                self._triggered_active = False
                self._triggered_start = 0
                self._siren_timed_out = False
                logger.warning(f"{self._log_prefix} TRIGGERED 解除")
    
    def siren_timeout(self):
        """
        声光超时（只停输出，状态保持 TRIGGERED）
        
        这不会结束 TRIGGERED 状态，只是停止声光输出。
        用于实现 PRD 中的 siren_timeout 行为。
        """
        if self._triggered_active and not self._siren_timed_out:
            self._siren_timed_out = True
            # 立即降级到 OFF（不经过去抖），但 _triggered_active 保持 True
            self._confirmed_level = self.LEVEL_OFF
            self._confirmed_time = time.time()
            self._pending_level = None
            logger.warning(f"{self._log_prefix} ⏱️ TRIGGERED 声光超时，停止输出但状态保持")
    
    def force_stop(self):
        """
        强制停止所有威慑（如撤防）
        
        清理所有状态：PRE 传感器 + TRIGGERED
        """
        # 清理 PRE 层
        self._sensor_reports.clear()
        
        # 清理 TRIGGERED 层
        self._triggered_active = False
        self._triggered_start = 0
        self._siren_timed_out = False
        
        # 清理聚合状态
        self._desired_level = 0
        self._pending_level = None
        
        # 立即确认 OFF
        if self._confirmed_level != 0:
            self._confirmed_level = 0
            self._confirmed_time = time.time()
            logger.warning(f"{self._log_prefix} 强制停止 → L0")
    
    def get_state(self) -> Dict[str, Any]:
        """获取当前状态"""
        return {
            "desired": self._desired_level,
            "confirmed": self._confirmed_level,
            "pending": self._pending_level,
            "light_on": self._light_on,
            "triggered_active": self._triggered_active,
            "siren_timed_out": self._siren_timed_out,
            "sensors": dict(self._sensor_reports),
        }
    
    # ========== 内部方法 ==========
    
    def _aggregate_pre_sensors(self) -> int:
        """聚合 PRE 层传感器，取最高级别"""
        now = time.time()
        max_level = 0
        expired = []
        
        for sensor_id, (level, ts) in self._sensor_reports.items():
            age = now - ts
            if age < self.SENSOR_TIMEOUT:
                max_level = max(max_level, level)
            else:
                expired.append((sensor_id, level, age))
        
        # 清理超时的传感器
        for sensor_id, level, age in expired:
            del self._sensor_reports[sensor_id]
            # 调试日志已注释（v2.39）
            # from datetime import datetime
            # ts = datetime.now().strftime("%H:%M:%S.%f")[:-3]
            # print(f"[{ts}] {self._log_prefix} ⚠️ SENSOR_TIMEOUT: {sensor_id} L{level} (age={age:.1f}s > {self.SENSOR_TIMEOUT}s)")
        
        return max_level
    
    def _get_effective_level(self) -> int:
        """
        获取有效威慑级别
        
        优先级：TRIGGERED > PRE
        - 如果 TRIGGERED 激活 → 返回 TRIGGERED（除非声光超时）
        - 否则 → 返回 PRE 聚合结果
        """
        if self._triggered_active:
            if self._siren_timed_out:
                # 声光超时：返回 OFF（不执行效果），但 TRIGGERED 状态保持
                return self.LEVEL_OFF
            return self.LEVEL_TRIGGERED
        
        return self._aggregate_pre_sensors()
    
    async def _run_loop(self):
        """主循环 - 永不取消"""
        logger.info(f"{self._log_prefix} 循环启动")
        
        last_desired = -1  # 调试：追踪变化
        
        try:
            while self.running:
                now = time.time()
                
                # 1. 获取有效威慑级别（TRIGGERED 优先于 PRE）
                self._desired_level = self._get_effective_level()
                
                # 调试日志已注释（v2.39）
                # if self._desired_level != last_desired:
                #     from datetime import datetime
                #     ts = datetime.now().strftime("%H:%M:%S.%f")[:-3]
                #     print(f"[{ts}] {self._log_prefix} desired: L{last_desired} → L{self._desired_level} | confirmed: L{self._confirmed_level} | pending: {self._pending_level}")
                #     last_desired = self._desired_level
                
                # 2. 检查 TRIGGERED 声光超时
                if self._triggered_active and not self._siren_timed_out:
                    elapsed = now - self._triggered_start
                    if elapsed >= self.TRIGGERED_MAX_DURATION:
                        self.siren_timeout()
                
                # 3. 处理去抖
                self._process_debounce(now)
                
                # 4. 执行当前级别的效果
                await self._execute_effect(now)
                
                await asyncio.sleep(self.LOOP_INTERVAL)
                
        except asyncio.CancelledError:
            logger.info(f"{self._log_prefix} 循环取消")
        except Exception as e:
            logger.error(f"{self._log_prefix} 循环异常: {e}", exc_info=True)
        finally:
            await self._set_spotlight(False)
            logger.info(f"{self._log_prefix} 循环结束，设备已关闭")
    
    def _process_debounce(self, now: float):
        """去抖处理"""
        desired = self._desired_level
        confirmed = self._confirmed_level
        
        # 相同级别，取消待确认
        if desired == confirmed:
            if self._pending_level is not None:
                logger.debug(f"{self._log_prefix} 取消待确认 L{self._pending_level}")
                self._pending_level = None
            return
        
        # 新的待确认（级别变化）
        if self._pending_level != desired:
            elapsed = now - self._confirmed_time
            
            # 检查是否在缓冲期内
            in_buffer = self._is_in_buffer(confirmed, elapsed)
            
            if desired > confirmed:
                # 升级
                debounce = self.DEBOUNCE_UP
            else:
                # 降级
                if in_buffer:
                    # 缓冲期内降级：使用标准去抖，不受最短持续限制
                    debounce = self.DEBOUNCE_DOWN
                    logger.debug(f"{self._log_prefix} 缓冲期内降级")
                else:
                    # 检查最短持续
                    min_hold = self._get_min_hold(confirmed)
                    if elapsed < min_hold:
                        debounce = min_hold - elapsed
                    else:
                        debounce = self.DEBOUNCE_DOWN
            
            self._pending_level = desired
            self._pending_time = now
            self._pending_debounce = debounce
            logger.debug(f"{self._log_prefix} 待确认: L{confirmed} → L{desired} (去抖 {debounce:.1f}s)")
        
        # 检查是否可以确认
        if self._pending_level is not None:
            if now - self._pending_time >= self._pending_debounce:
                self._confirm_level(self._pending_level, now)
    
    def _is_in_buffer(self, level: int, elapsed: float) -> bool:
        """检查是否在缓冲期内"""
        if level == self.LEVEL_L1:
            return elapsed < self.L1_START_DELAY
        elif level == self.LEVEL_L2:
            return elapsed < self.L2_START_DELAY
        elif level == self.LEVEL_L3:
            return elapsed < self.L3_START_DELAY
        return False
    
    def _get_min_hold(self, level: int) -> float:
        """获取最短持续时间"""
        if level == self.LEVEL_L1:
            return self.MIN_HOLD_L1
        elif level == self.LEVEL_L2:
            return self.MIN_HOLD_L2
        elif level == self.LEVEL_L3:
            return self.MIN_HOLD_L2  # L3 同 L2
        elif level == self.LEVEL_TRIGGERED:
            return self.MIN_HOLD_TRIGGERED
        return 0
    
    def _confirm_level(self, level: int, now: float):
        """确认级别切换"""
        old = self._confirmed_level
        self._confirmed_level = level
        self._confirmed_time = now
        self._pending_level = None
        self._last_siren_time = 0
        
        # ✅ 修复：只有当新级别需要亮灯时才重置 _light_on
        # 这样 L2→L1 会重新发 ON，而 L1→OFF 会正确发 OFF
        if level > self.LEVEL_OFF:
            self._light_on = False
        
        self.level_changes.append((now, old, level))
        
        level_names = {0: "OFF", 1: "L1", 2: "L2", 3: "L3", 10: "TRIGGERED"}
        logger.warning(f"{self._log_prefix} 确认: {level_names.get(old, old)} → {level_names.get(level, level)}")
    
    async def _execute_effect(self, now: float):
        """执行当前级别的效果"""
        level = self._confirmed_level
        elapsed = now - self._confirmed_time
        
        if level == self.LEVEL_OFF:
            await self._execute_off()
        elif level == self.LEVEL_L1:
            await self._execute_l1(elapsed)
        elif level == self.LEVEL_L2:
            await self._execute_l2(elapsed)
        elif level == self.LEVEL_L3:
            await self._execute_l3(elapsed)
        elif level == self.LEVEL_TRIGGERED:
            await self._execute_triggered(elapsed)
    
    async def _execute_off(self):
        """OFF - 关灯"""
        if self._light_on:
            await self._set_spotlight(False)
    
    async def _execute_l1(self, elapsed: float):
        """L1 - 常亮 + 延迟后警报"""
        # 缓冲期检查
        if elapsed < self.L1_START_DELAY:
            if self._light_on:
                await self._set_spotlight(False)
            return
        
        effect_elapsed = elapsed - self.L1_START_DELAY
        
        # 常亮灯
        if not self._light_on:
            await self._set_spotlight(True)
        
        # 警报（延迟后）
        if effect_elapsed >= self.L1_SIREN_DELAY:
            siren_elapsed = effect_elapsed - self.L1_SIREN_DELAY
            await self._maybe_siren(siren_elapsed, self.L1_SIREN_INTERVAL, self.L1_SIREN_DURATION)
    
    async def _execute_l2(self, elapsed: float):
        """L2 - 闪灯 + 延迟后警报"""
        # 缓冲期检查
        if elapsed < self.L2_START_DELAY:
            if self._light_on:
                await self._set_spotlight(False)
            return
        
        effect_elapsed = elapsed - self.L2_START_DELAY
        
        # 闪灯
        cycle = self.L2_FLASH_ON + self.L2_FLASH_OFF
        should_on = (effect_elapsed % cycle) < self.L2_FLASH_ON
        if should_on != self._light_on:
            await self._set_spotlight(should_on)
        
        # 警报（延迟后）
        if effect_elapsed >= self.L2_SIREN_DELAY:
            siren_elapsed = effect_elapsed - self.L2_SIREN_DELAY
            await self._maybe_siren(siren_elapsed, self.L2_SIREN_INTERVAL, self.L2_SIREN_DURATION)
    
    async def _execute_l3(self, elapsed: float):
        """L3 - 同 L2，可单独配置"""
        # 缓冲期检查
        if elapsed < self.L3_START_DELAY:
            if self._light_on:
                await self._set_spotlight(False)
            return
        
        effect_elapsed = elapsed - self.L3_START_DELAY
        
        # 闪灯
        cycle = self.L3_FLASH_ON + self.L3_FLASH_OFF
        should_on = (effect_elapsed % cycle) < self.L3_FLASH_ON
        if should_on != self._light_on:
            await self._set_spotlight(should_on)
        
        # 警报（延迟后）
        if effect_elapsed >= self.L3_SIREN_DELAY:
            siren_elapsed = effect_elapsed - self.L3_SIREN_DELAY
            await self._maybe_siren(siren_elapsed, self.L3_SIREN_INTERVAL, self.L3_SIREN_DURATION)
    
    async def _execute_triggered(self, elapsed: float):
        """
        TRIGGERED - 快速闪灯 + 频繁警报
        
        注意：声光超时由 _get_effective_level() 处理，
        超时后会返回 LEVEL_OFF，不会进入此方法。
        """
        # 闪灯
        cycle = self.TRIGGERED_FLASH_ON + self.TRIGGERED_FLASH_OFF
        should_on = (elapsed % cycle) < self.TRIGGERED_FLASH_ON
        if should_on != self._light_on:
            await self._set_spotlight(should_on)
        
        # 警报
        await self._maybe_siren(elapsed, self.TRIGGERED_SIREN_INTERVAL, self.TRIGGERED_SIREN_DURATION)
    
    async def _maybe_siren(self, elapsed: float, interval: float, duration: float):
        """根据时间间隔触发警报"""
        if interval <= 0:
            return
        
        elapsed_int = int(elapsed)
        
        # 首次（刚进入该级别）
        if elapsed < 0.5 and self._last_siren_time == 0:
            self._last_siren_time = -1
            await self._trigger_siren(duration)
            return
        
        # 周期性
        if elapsed_int > 0 and elapsed_int % interval == 0 and elapsed_int != self._last_siren_time:
            self._last_siren_time = elapsed_int
            await self._trigger_siren(duration)
    
    async def _set_spotlight(self, on: bool):
        """设置灯光状态"""
        if on == self._light_on:
            return
        
        self._light_on = on
        logger.info(f"{self._log_prefix} 💡 {'ON' if on else 'OFF'}")
        
        if self._on_spotlight:
            try:
                await self._on_spotlight(on)
            except Exception as e:
                logger.error(f"{self._log_prefix} 灯光控制失败: {e}")
    
    async def _trigger_siren(self, duration: float):
        """触发警报"""
        logger.info(f"{self._log_prefix} 🔔 警报 {duration}s")
        
        if self._on_siren:
            try:
                await self._on_siren(duration)
            except Exception as e:
                logger.error(f"{self._log_prefix} 警报控制失败: {e}")
