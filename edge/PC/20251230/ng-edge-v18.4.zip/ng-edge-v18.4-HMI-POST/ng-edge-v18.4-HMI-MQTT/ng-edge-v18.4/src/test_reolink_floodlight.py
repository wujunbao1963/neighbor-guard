#!/usr/bin/env python3
"""
测试 Reolink Floodlight API

用法:
    python test_reolink_floodlight.py <ip> <user> <password> [command]

命令:
    info        - 查看所有灯光设置
    flash_on    - 尝试开启持续闪烁
    flash_off   - 关闭闪烁
    raw         - 查看原始 API 响应
"""

import asyncio
import sys
import json


async def main():
    if len(sys.argv) < 4:
        print(__doc__)
        return
    
    ip, user, password = sys.argv[1:4]
    command = sys.argv[4] if len(sys.argv) > 4 else "info"
    
    print(f"[TEST] 连接 {ip}...")
    
    from reolink_aio.api import Host
    host = Host(ip, user, password)
    
    try:
        await host.get_host_data()
        model = host.camera_model(0)
        print(f"[TEST] ✅ 已连接: {model}")
        
        if command == "info":
            print(f"\n=== 基本灯光设置 ===")
            print(f"  whiteled_state: {host.whiteled_state(0)}")
            print(f"  whiteled_mode: {host.whiteled_mode(0)}")
            print(f"  whiteled_mode_list: {host.whiteled_mode_list(0)}")
            print(f"  whiteled_brightness: {host.whiteled_brightness(0)}")
            
            print(f"\n=== 完整 whiteled_settings ===")
            settings = host.whiteled_settings(0)
            print(json.dumps(settings, indent=2, default=str))
            
            # 查看所有可能的 floodlight 属性
            print(f"\n=== 所有 whiteled/light 相关属性 ===")
            for attr in dir(host):
                if 'light' in attr.lower() or 'led' in attr.lower() or 'flood' in attr.lower():
                    try:
                        val = getattr(host, attr)
                        if callable(val):
                            try:
                                result = val(0)
                                print(f"  {attr}(0): {result}")
                            except:
                                pass
                        else:
                            print(f"  {attr}: {val}")
                    except:
                        pass
        
        elif command == "raw":
            # 直接发送原始 API 命令
            print(f"\n=== 原始 API 查询 ===")
            
            # 尝试获取各种设置
            commands = [
                "GetWhiteLed",
                "GetAlarm", 
                "GetAudioAlarm",
                "GetAbility",
            ]
            
            for cmd in commands:
                print(f"\n--- {cmd} ---")
                try:
                    body = [{"cmd": cmd, "action": 0, "param": {"channel": 0}}]
                    result = await host.send(body, expected_content_type="json")
                    print(json.dumps(result, indent=2, default=str))
                except Exception as e:
                    print(f"  失败: {e}")
        
        elif command == "flash_on":
            print(f"\n[TEST] 尝试开启持续闪烁...")
            
            # 方法1: 尝试设置 whiteled 的特殊模式
            print("尝试方法1: set_whiteled with different modes...")
            
            # 查看当前设置
            settings = host.whiteled_settings(0)
            print(f"当前设置: {json.dumps(settings, indent=2)}")
            
            # 尝试设置闪烁模式 - 根据 Floodlight 文档，可能有 "Continuous Flashing" 选项
            # 在 Light Alert 设置中
            try:
                # 尝试直接发送 SetWhiteLed 命令
                body = [{
                    "cmd": "SetWhiteLed",
                    "param": {
                        "WhiteLed": {
                            "channel": 0,
                            "state": 1,
                            "bright": 100,
                            "mode": 1,  # 尝试不同的 mode 值
                        }
                    }
                }]
                result = await host.send(body, expected_content_type="json")
                print(f"SetWhiteLed mode=1 结果: {result}")
            except Exception as e:
                print(f"SetWhiteLed 失败: {e}")
            
            # 尝试 AudioAlarm (可能触发闪烁)
            try:
                await host.set_audio_alarm(0, True)
                print("AudioAlarm ON")
            except Exception as e:
                print(f"AudioAlarm 失败: {e}")
        
        elif command == "flash_off":
            print(f"\n[TEST] 关闭闪烁...")
            await host.set_whiteled(0, state=False)
            try:
                await host.set_audio_alarm(0, False)
            except:
                pass
            print("[TEST] ✅ 已关闭")
        
        else:
            print(f"[ERROR] 未知命令: {command}")
    
    except Exception as e:
        print(f"[ERROR] 失败: {e}")
        import traceback
        traceback.print_exc()
    
    finally:
        await host.logout()


if __name__ == "__main__":
    asyncio.run(main())
