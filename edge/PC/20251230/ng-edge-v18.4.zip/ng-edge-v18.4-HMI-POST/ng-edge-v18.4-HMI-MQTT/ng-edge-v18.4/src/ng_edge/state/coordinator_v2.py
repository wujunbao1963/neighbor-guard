"""
Security Coordinator Wrapper (v2.2)

将现有 SecurityCoordinator (v5) 包装为 v2.2 架构兼容版本。

功能：
1. 接收 SignalEnvelope 输入
2. 输出双维度状态 (ThreatState + WorkflowState)
3. 集成 JudgeAvailabilityTracker
4. 记录 TransitionRecord
"""

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Optional, Callable, List, Dict, Any
import uuid

from ng_edge.core.signal import SignalEnvelope, CameraRole, Hardness
from ng_edge.state.states import (
    ThreatState,
    WorkflowState,
    IncidentState,
    TransitionRecord,
    ReasonCode,
    alarm_state_to_threat,
)
from ng_edge.state.judge_tracker import JudgeAvailabilityTracker, JudgeConfig

# 导入现有状态机
from ng_edge.services.state_machine_v5 import (
    SecurityCoordinator,
    Signal as LegacySignal,
    SignalType as LegacySignalType,
    ZoneType as LegacyZoneType,
    HouseMode,
    UserMode,
    AlarmState,
    TransitionResult,
)


# =============================================================================
# Signal 转换
# =============================================================================

# SignalEnvelope.signal_kind → LegacySignalType
SIGNAL_KIND_TO_LEGACY = {
    "door_open": LegacySignalType.DOOR_OPEN,
    "door_close": LegacySignalType.DOOR_CLOSE,
    "motion_pir": LegacySignalType.MOTION_ACTIVE,
    "glass_break": LegacySignalType.GLASS_BREAK,
    "person_detected": LegacySignalType.PERSON_DETECTED,
    "vehicle_detected": LegacySignalType.VEHICLE_DETECTED,
}

# zone_id → LegacyZoneType
ZONE_TO_LEGACY = {
    "exterior": LegacyZoneType.EXTERIOR,
    "entry_exit": LegacyZoneType.ENTRY_EXIT,
    "interior": LegacyZoneType.INTERIOR,
    "perimeter": LegacyZoneType.PERIMETER,
}


def envelope_to_legacy_signal(envelope: SignalEnvelope) -> Optional[LegacySignal]:
    """
    将 SignalEnvelope 转换为 Legacy Signal
    """
    signal_type = SIGNAL_KIND_TO_LEGACY.get(envelope.signal_kind)
    if not signal_type:
        return None
    
    zone_type = ZONE_TO_LEGACY.get(envelope.zone_id, LegacyZoneType.EXTERIOR)
    
    return LegacySignal(
        entry_point_id=envelope.entrypoint_id or "_global",
        zone_type=zone_type,
        signal_type=signal_type,
        from_inside=envelope.attributes.get("from_inside", False),
        confidence=envelope.confidence,
        timestamp=envelope.timestamp,
        signal_id=envelope.signal_id,
    )


# =============================================================================
# 结果包装
# =============================================================================

@dataclass
class ProcessResult:
    """
    处理结果 (v2.2 格式)
    """
    success: bool
    
    # 事件标识
    incident_id: str
    entry_point_id: str
    
    # 双维度状态
    threat_state: ThreatState
    workflow_state: WorkflowState
    
    # 转换信息
    threat_changed: bool = False
    workflow_changed: bool = False
    from_threat: Optional[ThreatState] = None
    to_threat: Optional[ThreatState] = None
    
    # 原因
    reason_code: str = ""
    message: str = ""
    
    # Judge 状态
    judge_available: bool = True
    judge_capped: bool = False  # PRE 是否被 Judge 离线限制
    
    # 原始结果（兼容）
    legacy_result: Optional[TransitionResult] = None


# =============================================================================
# 包装器
# =============================================================================

class SecurityCoordinatorV2:
    """
    Security Coordinator v2.2 包装器
    
    使用方式:
        coord = SecurityCoordinatorV2(
            house_mode=HouseMode.AWAY,
            user_mode=UserMode.QUIET,
        )
        
        # 配置 Judge
        coord.register_judge("cam_front", "ep_front")
        
        # 处理信号
        result = coord.process_envelope(envelope)
        
        # 检查状态
        print(result.threat_state, result.workflow_state)
    """
    
    def __init__(
        self,
        house_mode: HouseMode = HouseMode.DISARMED,
        user_mode: UserMode = UserMode.QUIET,
        entry_delay_sec: int = 30,
        judge_config: Optional[JudgeConfig] = None,
        on_transition: Optional[Callable[[ProcessResult], None]] = None,
    ):
        # 底层 v5 协调器
        self._coordinator = SecurityCoordinator(
            house_mode=house_mode,
            user_mode=user_mode,
            entry_delay_sec=entry_delay_sec,
            on_global_state_change=self._on_legacy_state_change,
        )
        
        # Judge 跟踪器
        self._judge_tracker = JudgeAvailabilityTracker(judge_config)
        self._judge_tracker.on_state_change = self._on_judge_state_change
        
        # 事件跟踪
        self._incidents: Dict[str, IncidentState] = {}
        self._entry_to_incident: Dict[str, str] = {}  # entry_point_id → incident_id
        
        # 转换历史
        self._transitions: List[TransitionRecord] = []
        
        # 回调
        self.on_transition = on_transition
        
        # 统计
        self.stats = {
            "signals_processed": 0,
            "soft_signals": 0,
            "hard_signals": 0,
            "judge_capped": 0,
            "transitions": 0,
        }
    
    # =========================================================================
    # 配置
    # =========================================================================
    
    def register_entry_point(self, entry_point_id: str, name: str = "", entry_delay_sec: int = None):
        """注册入口点"""
        self._coordinator.register_entry_point(entry_point_id, name, entry_delay_sec)
    
    def register_judge(self, camera_id: str, entry_point_id: Optional[str] = None):
        """注册 Judge 摄像头"""
        self._judge_tracker.register_judge(camera_id, entry_point_id)
    
    def set_modes(self, house_mode: HouseMode, user_mode: UserMode):
        """设置模式"""
        self._coordinator.set_modes(house_mode, user_mode)
    
    @property
    def house_mode(self) -> HouseMode:
        return self._coordinator.house_mode
    
    @property
    def user_mode(self) -> UserMode:
        return self._coordinator.user_mode
    
    # =========================================================================
    # Judge 管理
    # =========================================================================
    
    def record_judge_heartbeat(self, camera_id: str):
        """记录 Judge 心跳"""
        self._judge_tracker.record_heartbeat(camera_id)
    
    def record_judge_failure(self, camera_id: str):
        """记录 Judge 失败"""
        self._judge_tracker.record_failure(camera_id)
    
    def check_judge_timeouts(self) -> List[str]:
        """检查 Judge 超时"""
        return self._judge_tracker.check_timeouts()
    
    def is_judge_available(self, camera_id: str = None) -> bool:
        """检查 Judge 是否可用"""
        if camera_id:
            return self._judge_tracker.is_available(camera_id)
        return self._judge_tracker.is_any_available()
    
    # =========================================================================
    # 核心处理
    # =========================================================================
    
    def process_envelope(self, envelope: SignalEnvelope) -> ProcessResult:
        """
        处理 SignalEnvelope
        
        这是主要入口点
        """
        self.stats["signals_processed"] += 1
        
        if envelope.is_hard():
            self.stats["hard_signals"] += 1
        else:
            self.stats["soft_signals"] += 1
        
        # 检查 Judge 限制
        judge_available = self._check_judge_for_signal(envelope)
        judge_capped = False
        
        # 如果是来自摄像头的 soft 信号且 Judge 不可用，限制 PRE 升级
        if envelope.is_soft() and envelope.source_type.value == "camera":
            if not judge_available:
                judge_capped = True
                self.stats["judge_capped"] += 1
                # 不直接返回，仍然处理但限制结果
        
        # 转换为 legacy signal
        legacy_signal = envelope_to_legacy_signal(envelope)
        if not legacy_signal:
            return ProcessResult(
                success=False,
                incident_id="",
                entry_point_id=envelope.entrypoint_id or "_global",
                threat_state=ThreatState.NONE,
                workflow_state=WorkflowState.IDLE,
                reason_code="unsupported_signal",
                message=f"Unsupported signal kind: {envelope.signal_kind}",
                judge_available=judge_available,
            )
        
        # 获取处理前状态
        entry_point_id = legacy_signal.entry_point_id
        ep = self._coordinator.get_entry_point(entry_point_id)
        before_state = ep.state if ep else AlarmState.QUIET
        before_threat = alarm_state_to_threat(before_state)
        
        # 处理信号
        legacy_result = self._coordinator.process(legacy_signal)
        
        # 获取处理后状态
        ep = self._coordinator.get_entry_point(entry_point_id)
        after_state = ep.state if ep else AlarmState.QUIET
        after_threat = alarm_state_to_threat(after_state)
        
        # 应用 Judge 限制
        if judge_capped and after_threat in {ThreatState.PRE_L2, ThreatState.PRE_L3}:
            # 限制到 PRE_L1
            after_threat = ThreatState.PRE_L1
        
        # 确定 WorkflowState
        workflow_state = self._determine_workflow_state(after_threat, legacy_result)
        
        # 获取或创建 incident
        incident_id = self._get_or_create_incident(entry_point_id, after_threat, workflow_state)
        
        # 记录转换
        threat_changed = before_threat != after_threat
        if threat_changed:
            self._record_transition(
                incident_id=incident_id,
                dimension="threat",
                from_state=before_threat.value,
                to_state=after_threat.value,
                signal_id=envelope.signal_id,
                reason_code=self._infer_reason_code(envelope, legacy_result),
            )
        
        # 构建结果
        result = ProcessResult(
            success=legacy_result.success,
            incident_id=incident_id,
            entry_point_id=entry_point_id,
            threat_state=after_threat,
            workflow_state=workflow_state,
            threat_changed=threat_changed,
            from_threat=before_threat if threat_changed else None,
            to_threat=after_threat if threat_changed else None,
            reason_code=self._infer_reason_code(envelope, legacy_result),
            message=legacy_result.message or "",
            judge_available=judge_available,
            judge_capped=judge_capped,
            legacy_result=legacy_result,
        )
        
        # 触发回调
        if self.on_transition and threat_changed:
            self.on_transition(result)
        
        return result
    
    def process_legacy(self, signal: LegacySignal) -> ProcessResult:
        """
        处理 Legacy Signal（兼容接口）
        """
        # 转换为 envelope
        envelope = SignalEnvelope(
            signal_id=signal.signal_id,
            device_id=f"legacy_{signal.entry_point_id}",
            zone_id=signal.zone_type.value,
            entrypoint_id=signal.entry_point_id,
            signal_kind=signal.signal_type.value,
            confidence=signal.confidence,
            timestamp=signal.timestamp,
            attributes={"from_inside": signal.from_inside},
        )
        return self.process_envelope(envelope)
    
    # =========================================================================
    # 用户操作
    # =========================================================================
    
    def cancel(self, entry_point_id: str = "_global") -> ProcessResult:
        """取消 PRE/PENDING"""
        before_state = self._get_threat_state(entry_point_id)
        
        legacy_result = self._coordinator.cancel(entry_point_id)
        
        after_state = self._get_threat_state(entry_point_id)
        incident_id = self._entry_to_incident.get(entry_point_id, "")
        
        if before_state != after_state:
            self._record_transition(
                incident_id=incident_id,
                dimension="threat",
                from_state=before_state.value,
                to_state=after_state.value,
                reason_code=ReasonCode.USER_CANCEL.value,
            )
        
        return ProcessResult(
            success=legacy_result.success,
            incident_id=incident_id,
            entry_point_id=entry_point_id,
            threat_state=after_state,
            workflow_state=WorkflowState.IDLE if after_state == ThreatState.NONE else WorkflowState.RESOLVED,
            threat_changed=before_state != after_state,
            from_threat=before_state,
            to_threat=after_state,
            reason_code=ReasonCode.USER_CANCEL.value,
            legacy_result=legacy_result,
            judge_available=self.is_judge_available(),
        )
    
    def resolve(self, entry_point_id: str = "_global") -> ProcessResult:
        """解除 TRIGGERED"""
        before_state = self._get_threat_state(entry_point_id)
        
        legacy_result = self._coordinator.resolve(entry_point_id)
        
        after_state = self._get_threat_state(entry_point_id)
        incident_id = self._entry_to_incident.get(entry_point_id, "")
        
        if before_state != after_state:
            self._record_transition(
                incident_id=incident_id,
                dimension="threat",
                from_state=before_state.value,
                to_state=after_state.value,
                reason_code=ReasonCode.USER_RESOLVE.value,
            )
        
        return ProcessResult(
            success=legacy_result.success,
            incident_id=incident_id,
            entry_point_id=entry_point_id,
            threat_state=after_state,
            workflow_state=WorkflowState.RESOLVED if legacy_result.success else WorkflowState.ESCALATED,
            threat_changed=before_state != after_state,
            from_threat=before_state,
            to_threat=after_state,
            reason_code=ReasonCode.USER_RESOLVE.value,
            legacy_result=legacy_result,
            judge_available=self.is_judge_available(),
        )
    
    def trigger_entry_delay_expired(self, entry_point_id: str) -> ProcessResult:
        """入口延迟超时"""
        before_state = self._get_threat_state(entry_point_id)
        
        ep = self._coordinator.get_entry_point(entry_point_id)
        if not ep:
            return ProcessResult(
                success=False,
                incident_id="",
                entry_point_id=entry_point_id,
                threat_state=ThreatState.NONE,
                workflow_state=WorkflowState.IDLE,
                reason_code="entry_point_not_found",
                judge_available=self.is_judge_available(),
            )
        
        legacy_result = ep.trigger_entry_delay_expired()
        
        after_state = self._get_threat_state(entry_point_id)
        incident_id = self._entry_to_incident.get(entry_point_id, "")
        
        if before_state != after_state:
            self._record_transition(
                incident_id=incident_id,
                dimension="threat",
                from_state=before_state.value,
                to_state=after_state.value,
                reason_code=ReasonCode.ENTRY_DELAY_EXPIRED.value,
            )
        
        return ProcessResult(
            success=legacy_result.success,
            incident_id=incident_id,
            entry_point_id=entry_point_id,
            threat_state=after_state,
            workflow_state=WorkflowState.ESCALATED if after_state == ThreatState.TRIGGERED else WorkflowState.NOTIFIED,
            threat_changed=before_state != after_state,
            from_threat=before_state,
            to_threat=after_state,
            reason_code=ReasonCode.ENTRY_DELAY_EXPIRED.value,
            legacy_result=legacy_result,
            judge_available=self.is_judge_available(),
        )
    
    # =========================================================================
    # 状态查询
    # =========================================================================
    
    def get_threat_state(self, entry_point_id: str) -> ThreatState:
        """获取威胁状态"""
        return self._get_threat_state(entry_point_id)
    
    def get_incident(self, incident_id: str) -> Optional[IncidentState]:
        """获取事件状态"""
        return self._incidents.get(incident_id)
    
    def get_transitions(self, incident_id: str = None) -> List[TransitionRecord]:
        """获取转换历史"""
        if incident_id:
            return [t for t in self._transitions if t.incident_id == incident_id]
        return self._transitions.copy()
    
    def get_stats(self) -> Dict[str, Any]:
        """获取统计信息"""
        return {
            **self.stats,
            "active_incidents": sum(1 for i in self._incidents.values() if i.is_active()),
            "total_incidents": len(self._incidents),
            "judge_stats": self._judge_tracker.get_stats(),
        }
    
    # =========================================================================
    # 内部方法
    # =========================================================================
    
    def _get_threat_state(self, entry_point_id: str) -> ThreatState:
        """获取入口点的威胁状态"""
        ep = self._coordinator.get_entry_point(entry_point_id)
        if not ep:
            return ThreatState.NONE
        return alarm_state_to_threat(ep.state)
    
    def _check_judge_for_signal(self, envelope: SignalEnvelope) -> bool:
        """检查信号对应的 Judge 是否可用"""
        if envelope.camera_role == CameraRole.JUDGE:
            return self._judge_tracker.is_available(envelope.device_id)
        # 非摄像头信号，检查是否有任何 Judge 可用
        return self._judge_tracker.is_any_available()
    
    def _determine_workflow_state(self, threat: ThreatState, result: TransitionResult) -> WorkflowState:
        """根据威胁状态确定工作流状态"""
        if threat == ThreatState.NONE:
            return WorkflowState.IDLE
        elif threat in {ThreatState.PRE_L1}:
            return WorkflowState.IDLE
        elif threat in {ThreatState.PRE_L2, ThreatState.PRE_L3}:
            return WorkflowState.NOTIFIED
        elif threat == ThreatState.PENDING:
            return WorkflowState.NOTIFIED
        elif threat == ThreatState.TRIGGERED:
            return WorkflowState.ESCALATED
        return WorkflowState.IDLE
    
    def _get_or_create_incident(self, entry_point_id: str, threat: ThreatState, workflow: WorkflowState) -> str:
        """获取或创建事件"""
        # 检查现有事件
        incident_id = self._entry_to_incident.get(entry_point_id)
        if incident_id and incident_id in self._incidents:
            incident = self._incidents[incident_id]
            # 更新状态
            incident.threat_state = threat
            incident.workflow_state = workflow
            incident.last_transition_at = datetime.now(timezone.utc)
            return incident_id
        
        # 创建新事件
        incident_id = f"inc_{uuid.uuid4().hex[:8]}"
        incident = IncidentState(
            incident_id=incident_id,
            threat_state=threat,
            workflow_state=workflow,
            entrypoint_id=entry_point_id,
            judge_available=self.is_judge_available(),
        )
        self._incidents[incident_id] = incident
        self._entry_to_incident[entry_point_id] = incident_id
        
        return incident_id
    
    def _record_transition(
        self,
        incident_id: str,
        dimension: str,
        from_state: str,
        to_state: str,
        signal_id: str = "",
        reason_code: str = "",
    ):
        """记录状态转换"""
        record = TransitionRecord(
            record_id=f"tr_{uuid.uuid4().hex[:8]}",
            timestamp=datetime.now(timezone.utc),
            incident_id=incident_id,
            dimension=dimension,
            from_state=from_state,
            to_state=to_state,
            reason_code=reason_code,
            trigger_signal_ids=[signal_id] if signal_id else [],
        )
        self._transitions.append(record)
        self.stats["transitions"] += 1
        
        # 更新 incident
        if incident_id in self._incidents:
            self._incidents[incident_id].transitions.append(record)
    
    def _infer_reason_code(self, envelope: SignalEnvelope, result: TransitionResult) -> str:
        """推断原因码"""
        kind = envelope.signal_kind
        if kind == "door_open":
            return ReasonCode.SIGNAL_DOOR_OPEN.value
        elif kind == "glass_break":
            return ReasonCode.SIGNAL_GLASS_BREAK.value
        elif kind == "motion_pir":
            return ReasonCode.SIGNAL_MOTION.value
        elif kind == "person_detected":
            return ReasonCode.SIGNAL_PERSON.value
        return "signal_other"
    
    def _on_legacy_state_change(self, entry_point_id: str, result: TransitionResult):
        """Legacy 状态变化回调"""
        # 这个回调由底层触发，我们在 process_envelope 中已经处理了
        pass
    
    def _on_judge_state_change(self, camera_id: str, old_state, new_state):
        """Judge 状态变化回调"""
        # 记录 Judge 状态变化
        entry_point_id = self._judge_tracker.get_entrypoint(camera_id) or "_global"
        incident_id = self._entry_to_incident.get(entry_point_id, "")
        
        reason_code = ReasonCode.JUDGE_OFFLINE.value if new_state.value == "degraded" else ReasonCode.JUDGE_ONLINE.value
        
        self._record_transition(
            incident_id=incident_id or f"judge_{camera_id}",
            dimension="judge_availability",
            from_state=old_state.value,
            to_state=new_state.value,
            reason_code=reason_code,
        )
