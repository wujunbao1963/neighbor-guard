#!/usr/bin/env python3
"""
NG Edge - Cloud Sync Service

Background service for edge-to-cloud synchronization:
- Heartbeat every 30 seconds
- Topology sync every 5 minutes  
- Event forwarding when events are generated

Usage:
    python run_cloud_sync.py --server http://10.0.0.136:3000 --circle <circle_id>

The device key is read from /var/lib/ng-edge/device_key

Press Ctrl+C to stop.
"""

import asyncio
import argparse
import sys
import signal
import uuid
from pathlib import Path
from datetime import datetime, timezone

# Add parent to path for imports
sys.path.insert(0, str(Path(__file__).parent))

from ng_edge.cloud import CloudConfig, CloudSyncService


# Sample topology for testing
def get_sample_topology() -> dict:
    """Return sample topology data."""
    return {
        "version": 1,
        "zones": [
            {"zoneId": "00000000-0000-0000-0000-000000000001", "zoneName": "Front Yard", "zoneType": "EXTERIOR"},
            {"zoneId": "00000000-0000-0000-0000-000000000002", "zoneName": "Entry", "zoneType": "ENTRY"},
            {"zoneId": "00000000-0000-0000-0000-000000000003", "zoneName": "Living Room", "zoneType": "INTERIOR"},
        ],
        "entryPoints": [
            {
                "entryPointId": "00000000-0000-0000-0000-000000000010",
                "name": "Front Door",
                "zone": {"zoneId": "00000000-0000-0000-0000-000000000002"},
                "kind": "DOOR",
            },
        ],
        "nodes": [
            {
                "nodeId": "00000000-0000-0000-0000-000000000020",
                "nodeType": "CAMERA",
                "name": "Front Camera",
                "zone": {"zoneId": "00000000-0000-0000-0000-000000000001"},
                "source": "camera_ai",
                "sourceRef": "cam_front",
            },
            {
                "nodeId": "00000000-0000-0000-0000-000000000021",
                "nodeType": "SENSOR",
                "name": "Front Door Contact",
                "zone": {"zoneId": "00000000-0000-0000-0000-000000000002"},
                "source": "door_contact",
                "sourceRef": "sensor.front_door",
            },
            {
                "nodeId": "00000000-0000-0000-0000-000000000022",
                "nodeType": "SENSOR",
                "name": "Living Room PIR",
                "zone": {"zoneId": "00000000-0000-0000-0000-000000000003"},
                "source": "pir",
                "sourceRef": "sensor.living_room_pir",
            },
        ],
    }


def create_test_event() -> dict:
    """Create a test event."""
    return {
        "eventId": str(uuid.uuid4()),
        "occurredAt": datetime.now(timezone.utc).isoformat(),
        "eventType": "motion_detected",
        "severity": "LOW",
        "notificationLevel": "NORMAL",
        "status": "OPEN",
        "title": f"Test motion detected at {datetime.now().strftime('%H:%M:%S')}",
        "description": "Periodic test event from sync demo",
        "explainSummary": {
            "ruleId": "TEST_MOTION",
            "keySignals": [{"code": "pir.motion", "source": "pir", "sourceRef": "test_sensor"}],
            "mode": "HOME",
        },
    }


async def main():
    parser = argparse.ArgumentParser(description="NG Edge Cloud Sync Service")
    parser.add_argument(
        "--server", "-s",
        default="http://10.0.0.136:3000",
        help="Server URL (default: http://10.0.0.136:3000)",
    )
    parser.add_argument(
        "--circle", "-c",
        required=True,
        help="Circle ID to send events to",
    )
    parser.add_argument(
        "--config-dir",
        default="./config",
        help="Config directory for credentials cache",
    )
    parser.add_argument(
        "--device-key-path",
        default="/var/lib/ng-edge/device_key",
        help="Path to device key file (default: /var/lib/ng-edge/device_key)",
    )
    parser.add_argument(
        "--heartbeat",
        type=int,
        default=30,
        help="Heartbeat interval in seconds (default: 30)",
    )
    parser.add_argument(
        "--topo-interval",
        type=int,
        default=300,
        help="Topology sync interval in seconds (default: 300)",
    )
    parser.add_argument(
        "--send-events",
        action="store_true",
        help="Send test events every 60 seconds",
    )
    
    args = parser.parse_args()
    
    print("=" * 60)
    print("NG Edge - Cloud Sync Service")
    print("=" * 60)
    print(f"Server URL:  {args.server}")
    print(f"Circle ID:   {args.circle}")
    print(f"Config Dir:  {args.config_dir}")
    print(f"Device Key:  {args.device_key_path}")
    print(f"Heartbeat:   every {args.heartbeat}s")
    print(f"Topo Sync:   every {args.topo_interval}s")
    print(f"Send Events: {args.send_events}")
    print("=" * 60)
    
    # Load config
    config = CloudConfig(
        server_url=args.server,
        config_dir=args.config_dir,
        system_device_key_path=args.device_key_path,
    )
    
    # Try to load credentials (from cache or system device key)
    if not config.load_or_create_credentials(circle_id=args.circle):
        print("\n✗ ERROR: No device credentials available!")
        print(f"  Checked: {config.credentials_path}")
        print(f"  Checked: {args.device_key_path}")
        return 1
    
    print(f"\nDevice ID:  {config.credentials.device_id}")
    print(f"Device Key: {config.credentials.device_key[:30]}...")
    print(f"Circle ID:  {config.credentials.circle_id}")
    
    # Create sync service
    sync = CloudSyncService(
        config=config,
        heartbeat_interval_sec=args.heartbeat,
        topo_sync_interval_sec=args.topo_interval,
    )
    
    # Set topology provider
    sync.set_topology_provider(get_sample_topology)
    
    # Set callbacks
    def on_heartbeat(ok: bool):
        status = "✓" if ok else "✗"
        print(f"[{datetime.now().strftime('%H:%M:%S')}] Heartbeat: {status}")
    
    def on_connection_lost():
        print(f"\n[{datetime.now().strftime('%H:%M:%S')}] ⚠ CONNECTION LOST")
    
    def on_connection_restored():
        print(f"\n[{datetime.now().strftime('%H:%M:%S')}] ✓ CONNECTION RESTORED")
    
    sync.on_heartbeat(on_heartbeat)
    sync.on_connection_lost(on_connection_lost)
    sync.on_connection_restored(on_connection_restored)
    
    # Handle Ctrl+C
    stop_event = asyncio.Event()
    
    def signal_handler():
        print("\n\nReceived stop signal...")
        stop_event.set()
    
    loop = asyncio.get_event_loop()
    for sig in (signal.SIGINT, signal.SIGTERM):
        loop.add_signal_handler(sig, signal_handler)
    
    # Start sync service
    await sync.start()
    
    print("\nSync service running. Press Ctrl+C to stop.\n")
    
    # Event sending loop (optional)
    event_task = None
    if args.send_events:
        async def send_events_loop():
            while not stop_event.is_set():
                await asyncio.sleep(60)  # Send event every 60 seconds
                if not stop_event.is_set():
                    event = create_test_event()
                    print(f"\n[{datetime.now().strftime('%H:%M:%S')}] Sending test event...")
                    await sync.forward_event(event)
        
        event_task = asyncio.create_task(send_events_loop())
    
    # Wait for stop signal
    await stop_event.wait()
    
    # Cancel event task if running
    if event_task:
        event_task.cancel()
        try:
            await event_task
        except asyncio.CancelledError:
            pass
    
    # Stop sync service
    await sync.stop()
    
    # Print final stats
    print("\n" + "=" * 60)
    print("Final Statistics")
    print("=" * 60)
    status = sync.get_status()
    print(f"Heartbeat: {status['heartbeat']['success_count']} success, {status['heartbeat']['failure_count']} failed")
    print(f"Topo Sync: {status['topo_sync']['success_count']} success, {status['topo_sync']['failure_count']} failed")
    print(f"Events: {status['events']['forwarded']} forwarded, {status['events']['failed']} failed, {status['events']['queued']} queued")
    
    return 0


if __name__ == "__main__":
    exit_code = asyncio.run(main())
    sys.exit(exit_code)
