#!/usr/bin/env python3
"""
验证 edge_runtime._get_zone_and_level 与 test_zone_detection.py 一致
"""

import sys
sys.path.insert(0, 'src')

from dataclasses import dataclass

@dataclass
class MockCamCfg:
    """模拟 CameraDeviceConfig"""
    door_threshold: float = 0.69
    yard_threshold: float = 0.0

def get_zone_test_script(bbox_xyxy, frame_height, door_y_px=400):
    """测试脚本的逻辑 - bbox 是 (x1, y1, x2, y2)"""
    x1, y1, x2, y2 = bbox_xyxy
    if y2 >= door_y_px:
        return "door", 2
    else:
        return "yard", 1

def get_zone_edge_runtime(bbox_xywh, frame_height, door_threshold=0.69):
    """edge_runtime 的逻辑 - bbox 是 (x, y, w, h)"""
    x, y, w, h = bbox_xywh
    y2 = y + h  # 转换为脚的位置
    
    door_y = int(frame_height * door_threshold)
    
    if y2 >= door_y:
        return "door", 2
    else:
        return "yard", 1

def test_consistency():
    """测试两种实现是否一致"""
    frame_height = 576
    door_y_px = 400  # 576 * 0.69 ≈ 397
    door_threshold = 0.69
    
    print(f"frame_height = {frame_height}")
    print(f"door_y_px = {door_y_px}")
    print(f"door_threshold = {door_threshold} → door_y = {int(frame_height * door_threshold)}")
    print()
    
    # 测试用例：(x1, y1, x2, y2) 和对应的 (x, y, w, h)
    test_cases = [
        # (xyxy, xywh, description)
        ((100, 100, 200, 350), (100, 100, 100, 250), "y2=350 < 400 → yard L1"),
        ((100, 100, 200, 400), (100, 100, 100, 300), "y2=400 = 400 → door L2"),
        ((100, 100, 200, 450), (100, 100, 100, 350), "y2=450 > 400 → door L2"),
        ((100, 50, 200, 500), (100, 50, 100, 450), "y2=500 > 400 → door L2"),
        ((100, 200, 200, 380), (100, 200, 100, 180), "y2=380 < 400 → yard L1"),
    ]
    
    print("=" * 70)
    print("测试 bbox (xyxy) vs (xywh) 转换一致性")
    print("=" * 70)
    
    all_passed = True
    for xyxy, xywh, desc in test_cases:
        # 验证 xywh 和 xyxy 对应
        x, y, w, h = xywh
        x1, y1, x2, y2 = xyxy
        assert x == x1 and y == y1, f"x,y 不匹配: {xywh} vs {xyxy}"
        assert x + w == x2 and y + h == y2, f"转换不匹配: x+w={x+w}, y+h={y+h} vs x2={x2}, y2={y2}"
        
        zone1, level1 = get_zone_test_script(xyxy, frame_height, door_y_px)
        zone2, level2 = get_zone_edge_runtime(xywh, frame_height, door_threshold)
        
        match = (zone1 == zone2 and level1 == level2)
        status = "✅" if match else "❌"
        
        print(f"{status} xyxy={xyxy} xywh={xywh}")
        print(f"   test_script: {zone1} L{level1}")
        print(f"   edge_runtime: {zone2} L{level2}")
        print(f"   {desc}")
        print()
        
        if not match:
            all_passed = False
    
    print("=" * 70)
    if all_passed:
        print("✅ 所有测试通过！分区逻辑一致")
    else:
        print("❌ 有测试失败！")
    print("=" * 70)
    
    return all_passed

def test_real_yolo_detector():
    """测试 yolo_detector 实际返回的 bbox 格式"""
    print()
    print("=" * 70)
    print("验证 yolo_detector 的 bbox 格式")
    print("=" * 70)
    
    try:
        from ng_edge.hardware.yolo_detector import YOLODetector, Detection
        print("✅ yolo_detector 导入成功")
        
        # 检查 Detection 的 bbox 定义
        import inspect
        source = inspect.getsource(Detection)
        if "bbox: Tuple[int, int, int, int]  # (x, y, w, h)" in source:
            print("✅ Detection.bbox 格式是 (x, y, w, h)")
        else:
            print("⚠️ 无法确认 Detection.bbox 格式，请检查源码")
            
    except ImportError as e:
        print(f"⚠️ 无法导入 yolo_detector: {e}")
        print("   这不影响逻辑测试，只是无法验证实际格式")

if __name__ == "__main__":
    test_consistency()
    test_real_yolo_detector()
