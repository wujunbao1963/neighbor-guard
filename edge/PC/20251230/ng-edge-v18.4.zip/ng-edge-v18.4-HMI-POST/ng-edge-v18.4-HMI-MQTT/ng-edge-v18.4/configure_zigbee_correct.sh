#!/bin/bash
# Zigbee传感器正确配置脚本
# 理解了完整的报警流程后的正确配置

echo "========================================="
echo "Zigbee传感器配置脚本 (正确版本)"
echo "========================================="
echo ""
echo "架构理解："
echo "  - Back Door: ENTRY_EXIT zone → 需要Entry Point → PENDING → TRIGGERED"
echo "  - Family Room: PERIMETER zone → 无需Entry Point → 直接TRIGGERED"
echo ""

BASE_URL="http://localhost:8000/api"

# ==========================================
# Step 1: 创建Zones
# ==========================================
echo "Step 1: 创建Zones..."
echo ""

# Zone 1: Back Door (ENTRY_EXIT) - 需要Entry Point
echo "  [1/2] 创建 zone_back_door (ENTRY_EXIT)..."
curl -s -X POST "$BASE_URL/zones" \
  -H "Content-Type: application/json" \
  -d '{
    "zone_id": "zone_back_door",
    "name": "Back Door",
    "zone_type": "ENTRY_EXIT",
    "location_type": "indoor",
    "entry_point_ids": [],
    "adjacent_zone_ids": [],
    "is_bypass_home": false,
    "is_bypass_night_occupied": false,
    "capability_tier": "E"
  }' | jq -r '.zone_id // "ERROR"'

# Zone 2: Family Room (PERIMETER) - 不需要Entry Point
echo "  [2/2] 创建 zone_family_room (PERIMETER)..."
curl -s -X POST "$BASE_URL/zones" \
  -H "Content-Type: application/json" \
  -d '{
    "zone_id": "zone_family_room",
    "name": "Family Room",
    "zone_type": "PERIMETER",
    "location_type": "indoor",
    "entry_point_ids": [],
    "adjacent_zone_ids": [],
    "is_bypass_home": true,
    "is_bypass_night_occupied": true,
    "capability_tier": "E"
  }' | jq -r '.zone_id // "ERROR"'

echo ""

# ==========================================
# Step 2: 创建Entry Point (仅Back Door需要)
# ==========================================
echo "Step 2: 创建Entry Point (仅ENTRY_EXIT需要)..."
echo ""

echo "  创建 ep_back_door (AWAY=30s, NIGHT=15s, HOME=30s)..."
curl -s -X POST "$BASE_URL/entry-points" \
  -H "Content-Type: application/json" \
  -d '{
    "entry_point_id": "ep_back_door",
    "name": "Back Door Entry",
    "zone_id": "zone_back_door",
    "entry_delay_away_sec": 30,
    "entry_delay_night_sec": 15,
    "entry_delay_home_sec": 30,
    "is_primary_entry": false,
    "sensor_ids": ["zigbee_back_door_001"]
  }' | jq -r '.entry_point_id // "ERROR"'

echo ""

# ==========================================
# Step 3: 更新Zone关联Entry Point
# ==========================================
echo "Step 3: 关联Zone和Entry Point..."
echo ""

echo "  zone_back_door ← ep_back_door..."
curl -s -X PATCH "$BASE_URL/zones/zone_back_door" \
  -H "Content-Type: application/json" \
  -d '{
    "entry_point_ids": ["ep_back_door"]
  }' | jq -r '.zone_id // "ERROR"'

echo ""

# ==========================================
# Step 4: 创建Sensors (不指定entry_point_id)
# ==========================================
echo "Step 4: 创建Sensors..."
echo ""

# Sensor只绑定到Zone，entry_point_id由Signal携带
echo "  [1/2] 创建 zigbee_back_door_001 (door_contact)..."
curl -s -X POST "$BASE_URL/sensors" \
  -H "Content-Type: application/json" \
  -d '{
    "sensor_id": "zigbee_back_door_001",
    "sensor_type": "door_contact",
    "zone_id": "zone_back_door",
    "name": "Back Door Contact"
  }' | jq -r '.sensor_id // "ERROR"'

echo "  [2/2] 创建 zigbee_family_room_001 (motion_pir)..."
curl -s -X POST "$BASE_URL/sensors" \
  -H "Content-Type: application/json" \
  -d '{
    "sensor_id": "zigbee_family_room_001",
    "sensor_type": "motion_pir",
    "zone_id": "zone_family_room",
    "name": "Family Room Motion"
  }' | jq -r '.sensor_id // "ERROR"'

echo ""

# ==========================================
# Step 5: 初始化Pipeline Topology
# ==========================================
echo "Step 5: 重新初始化Pipeline..."
echo ""

echo "  调用 rebuild_topology..."
curl -s -X POST "$BASE_URL/pipeline/rebuild-topology" | jq -r '.status // "ERROR"'

echo ""

# ==========================================
# 验证配置
# ==========================================
echo "========================================="
echo "配置完成！验证结果..."
echo "========================================="
echo ""

echo "📊 Zones:"
ZONE_COUNT=$(curl -s "$BASE_URL/zones" | jq '.zones | length')
echo "  总数: $ZONE_COUNT"
curl -s "$BASE_URL/zones" | jq -r '.zones[] | "  - \(.zone_id): \(.zone_type) (\(.entry_point_ids | length) entry points)"'

echo ""
echo "🚪 Entry Points:"
EP_COUNT=$(curl -s "$BASE_URL/entry-points" | jq '.entry_points | length')
echo "  总数: $EP_COUNT"
curl -s "$BASE_URL/entry-points" | jq -r '.entry_points[] | "  - \(.entry_point_id): zone=\(.zone_id), AWAY=\(.entry_delay_away_sec)s"'

echo ""
echo "📡 Sensors:"
SENSOR_COUNT=$(curl -s "$BASE_URL/sensors" | jq '.sensors | length')
echo "  总数: $SENSOR_COUNT"
curl -s "$BASE_URL/sensors" | jq -r '.sensors[] | "  - \(.sensor_id): \(.sensor_type) → \(.zone_id)"'

echo ""
echo "⚙️  Pipeline状态:"
curl -s "$BASE_URL/pipeline/status" | jq '{
  alarm_state,
  mode: .house_mode,
  zones: (.topology.zones // {} | length),
  entry_points: (.topology.entry_points // {} | length)
}'

echo ""
echo "🔌 Zigbee集成状态:"
curl -s "$BASE_URL/zigbee/status" | jq '{
  pipeline_enabled,
  zigbee_active: .active,
  mqtt_connected: .connected,
  device_count
}'

echo ""
echo "========================================="
echo "✅ 配置完成！"
echo "========================================="
echo ""

# 检查pipeline_enabled
PIPELINE_ENABLED=$(curl -s "$BASE_URL/zigbee/status" | jq -r '.pipeline_enabled')

if [ "$PIPELINE_ENABLED" = "true" ]; then
    echo "🎉 Pipeline集成成功！"
    echo ""
    echo "📋 下一步测试："
    echo ""
    echo "1. 设置AWAY模式:"
    echo "   curl -X POST $BASE_URL/set-mode -H 'Content-Type: application/json' -d '{\"mode\":\"AWAY\"}'"
    echo ""
    echo "2. 触发Back Door Contact（物理打开门）"
    echo "   预期: ARMED → PENDING (30秒entry delay)"
    echo ""
    echo "3. 检查状态:"
    echo "   curl $BASE_URL/pipeline/status | jq"
    echo "   预期输出: alarm_state = \"PENDING\""
    echo ""
    echo "4. 等待30秒或触发Family Room Motion"
    echo "   预期: PENDING → TRIGGERED"
    echo ""
else
    echo "⚠️  Pipeline未连接"
    echo "可能原因:"
    echo "  1. Pipeline未初始化 - 尝试: curl -X POST $BASE_URL/config/load-standard"
    echo "  2. manager.state未设置 - 检查NG Edge日志"
    echo "  3. Zigbee API代码未更新 - 确认使用了新版本zigbee_api.py"
fi

echo ""
