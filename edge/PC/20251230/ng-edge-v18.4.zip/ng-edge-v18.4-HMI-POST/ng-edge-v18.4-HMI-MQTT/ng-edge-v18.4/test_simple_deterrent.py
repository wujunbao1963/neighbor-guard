#!/usr/bin/env python3
"""
验证：永不取消的单循环 + 去抖

核心思想：
1. 检测层只设置 desired_level，不控制循环
2. 循环永远运行，每 tick 检查 desired_level
3. 去抖逻辑在循环内部

测试场景：
1. L0/L1 快速抖动 - 灯不应频繁开关
2. L1/L2 快速抖动 - 级别不应频繁切换
3. 人离开后重新进入 - 应该正确恢复
4. L2 最短持续 5 秒
"""

import asyncio
import time
import logging

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s.%(msecs)03d [%(levelname)s] %(message)s',
    datefmt='%H:%M:%S'
)
logger = logging.getLogger(__name__)


class SimpleDeterrentSystem:
    """
    简化的威慑系统 - 单循环 + 去抖
    """
    
    # 去抖配置
    DEBOUNCE_UP = 0.5      # 升级去抖（秒）
    DEBOUNCE_DOWN = 2.0    # 降级去抖（秒）
    MIN_HOLD_L2 = 5.0      # L2 最短持续
    MIN_HOLD_L1 = 3.0      # L1 最短持续
    
    # 效果参数（默认无延迟，由客户配置）
    L1_SIREN_INTERVAL = 5
    L1_SIREN_DELAY = 0          # L1 警报延迟（默认立即）
    L2_START_DELAY = 0          # L2 缓冲时间（默认立即）
    L2_SIREN_DELAY = 0          # L2 警报延迟（默认立即）
    L2_FLASH_ON = 2
    L2_FLASH_OFF = 2
    L2_SIREN_INTERVAL = 3
    
    def __init__(self):
        # 多传感器报告：sensor_id → (level, timestamp)
        self._sensor_reports: dict = {}
        self.SENSOR_TIMEOUT = 3.0  # 传感器无报告3秒视为离开
        
        # 期望状态（聚合后的最高级别）
        self._desired_level: int = 0  # 0=OFF, 1=L1, 2=L2
        
        # 当前确认状态
        self._confirmed_level: int = 0
        self._confirmed_time: float = 0
        
        # 待确认状态（去抖中）
        self._pending_level: int | None = None
        self._pending_time: float = 0
        self._pending_debounce: float = 0  # 锁定的去抖时间
        
        # 设备状态
        self._light_on: bool = False
        self._last_siren_time: float = 0
        
        # 控制
        self.running: bool = False
        self._task: asyncio.Task | None = None
        
        # 统计
        self.light_on_count = 0
        self.light_off_count = 0
        self.siren_count = 0
        self.level_changes: list = []
    
    def start(self):
        """启动（只调用一次）"""
        if self.running:
            return
        self.running = True
        self._task = asyncio.create_task(self._run_loop())
        logger.info("[SYSTEM] 启动")
    
    def stop(self):
        """停止"""
        self.running = False
        if self._task:
            self._task.cancel()
        logger.info("[SYSTEM] 停止")
    
    def report_sensor(self, sensor_id: str, level: int):
        """
        传感器报告检测结果（高频调用）
        
        多个传感器独立报告，系统取最高级别
        """
        self._sensor_reports[sensor_id] = (level, time.time())
    
    def set_desired(self, level: int, source: str = ""):
        """
        直接设置期望级别（简化接口，用于单传感器或测试）
        """
        self.report_sensor(source or "default", level)
    
    def _aggregate_sensors(self) -> int:
        """聚合所有传感器，取最高级别"""
        now = time.time()
        max_level = 0
        expired = []
        
        for sensor_id, (level, ts) in self._sensor_reports.items():
            if now - ts < self.SENSOR_TIMEOUT:
                max_level = max(max_level, level)
            else:
                expired.append(sensor_id)
        
        # 清理超时的传感器
        for sensor_id in expired:
            del self._sensor_reports[sensor_id]
            logger.debug(f"[SENSOR] {sensor_id} 超时移除")
        
        return max_level
    
    async def _run_loop(self):
        """主循环 - 永不取消"""
        logger.info("[LOOP] 循环启动")
        
        try:
            while self.running:
                now = time.time()
                
                # 聚合多传感器结果
                self._desired_level = self._aggregate_sensors()
                
                # 1. 处理去抖
                self._process_debounce(now)
                
                # 2. 执行当前级别的效果
                await self._execute_effect(now)
                
                await asyncio.sleep(0.5)
                
        except asyncio.CancelledError:
            logger.info("[LOOP] 循环取消")
        finally:
            await self._shutdown()
    
    def _process_debounce(self, now: float):
        """去抖处理"""
        desired = self._desired_level
        confirmed = self._confirmed_level
        
        # 相同级别，取消待确认
        if desired == confirmed:
            if self._pending_level is not None:
                logger.info(f"[DEBOUNCE] 取消待确认 L{self._pending_level}，保持 L{confirmed}")
                self._pending_level = None
            return
        
        # 新的待确认（级别变化）
        if self._pending_level != desired:
            # 计算并锁定去抖时间
            elapsed = now - self._confirmed_time
            
            # 检查是否在缓冲期内（还没触发警报）
            in_buffer = (confirmed == 2 and elapsed < self.L2_START_DELAY)
            
            if desired > confirmed:
                # 升级
                debounce = self.DEBOUNCE_UP
            else:
                # 降级
                if in_buffer:
                    # 缓冲期内降级：使用标准去抖，不受最短持续限制
                    debounce = self.DEBOUNCE_DOWN
                    logger.info(f"[DEBOUNCE] 缓冲期内降级")
                elif confirmed == 2 and elapsed < self.MIN_HOLD_L2:
                    debounce = self.MIN_HOLD_L2 - elapsed
                elif confirmed == 1 and elapsed < self.MIN_HOLD_L1:
                    debounce = self.MIN_HOLD_L1 - elapsed
                else:
                    debounce = self.DEBOUNCE_DOWN
            
            self._pending_level = desired
            self._pending_time = now
            self._pending_debounce = debounce  # 锁定！
            logger.info(f"[DEBOUNCE] 待确认: L{confirmed} → L{desired} (去抖 {debounce:.1f}s)")
        
        # 检查是否可以确认（使用锁定的去抖时间）
        if self._pending_level is not None:
            if now - self._pending_time >= self._pending_debounce:
                self._confirm_level(self._pending_level, now)
    
    def _confirm_level(self, level: int, now: float):
        """确认级别切换"""
        old = self._confirmed_level
        self._confirmed_level = level
        self._confirmed_time = now
        self._pending_level = None
        self._last_siren_time = 0  # 重置警报计时
        
        self.level_changes.append((now, old, level))
        logger.warning(f"[CONFIRM] L{old} → L{level}")
    
    async def _execute_effect(self, now: float):
        """执行当前级别的效果"""
        level = self._confirmed_level
        elapsed = now - self._confirmed_time
        
        if level == 0:
            # OFF - 关灯
            if self._light_on:
                await self._light_off_action()
        
        elif level == 1:
            # L1 - 常亮 + 延迟后慢滴
            if not self._light_on:
                await self._light_on_action()
            
            # 警报（延迟后才开始）
            if elapsed >= self.L1_SIREN_DELAY:
                siren_elapsed = elapsed - self.L1_SIREN_DELAY
                await self._maybe_siren(siren_elapsed, self.L1_SIREN_INTERVAL, 1)
        
        elif level == 2:
            # L2 - 有缓冲期
            if elapsed < self.L2_START_DELAY:
                # 缓冲期：灯灭
                if self._light_on:
                    await self._light_off_action()
                return
            
            # 缓冲结束后的 elapsed
            effect_elapsed = elapsed - self.L2_START_DELAY
            
            # 闪灯（缓冲结束后立即开始）
            cycle = self.L2_FLASH_ON + self.L2_FLASH_OFF
            should_on = (effect_elapsed % cycle) < self.L2_FLASH_ON
            
            if should_on != self._light_on:
                if should_on:
                    await self._light_on_action()
                else:
                    await self._light_off_action()
            
            # 警报（闪灯后再延迟）
            if effect_elapsed >= self.L2_SIREN_DELAY:
                siren_elapsed = effect_elapsed - self.L2_SIREN_DELAY
                await self._maybe_siren(siren_elapsed, self.L2_SIREN_INTERVAL, 2)
    
    async def _maybe_siren(self, elapsed: float, interval: int, duration: int):
        """可能触发警报"""
        elapsed_int = int(elapsed)
        
        # 首次进入
        if elapsed < 1.0 and self._last_siren_time == 0:
            self._last_siren_time = -1
            await self._siren_action(duration)
            return
        
        # 周期触发
        if elapsed_int > 0 and elapsed_int % interval == 0 and elapsed_int != self._last_siren_time:
            self._last_siren_time = elapsed_int
            await self._siren_action(duration)
    
    async def _light_on_action(self):
        self._light_on = True
        self.light_on_count += 1
        logger.info(f"[DEVICE] 💡 ON (count={self.light_on_count})")
    
    async def _light_off_action(self):
        self._light_on = False
        self.light_off_count += 1
        logger.info(f"[DEVICE] 💡 OFF (count={self.light_off_count})")
    
    async def _siren_action(self, duration: int):
        self.siren_count += 1
        logger.info(f"[DEVICE] 🔔 警报 {duration}s (count={self.siren_count})")
    
    async def _shutdown(self):
        if self._light_on:
            await self._light_off_action()
        logger.info("[DEVICE] 关闭")


# ============================================================
# 测试用例
# ============================================================

async def test_l0_l1_jitter():
    """测试1: L0/L1 快速抖动"""
    print("\n" + "="*60)
    print("测试1: L0/L1 快速抖动（每0.3秒切换，共10次）")
    print("预期: 灯只开1次（因为2秒去抖）")
    print("="*60)
    
    s = SimpleDeterrentSystem()
    s.start()
    
    # 快速抖动
    for i in range(10):
        level = 1 if i % 2 == 0 else 0
        s.set_desired(level, f"抖动{i}")
        await asyncio.sleep(0.3)
    
    await asyncio.sleep(3)
    s.stop()
    await asyncio.sleep(0.5)
    
    print(f"\n结果: light_on={s.light_on_count} level_changes={len(s.level_changes)}")
    
    if s.light_on_count <= 1:
        print("✅ 通过")
        return True
    else:
        print("❌ 失败")
        return False


async def test_l1_l2_jitter():
    """测试2: L1/L2 快速抖动"""
    print("\n" + "="*60)
    print("测试2: L1/L2 快速抖动")
    print("预期: 先确认 L1，抖动不会频繁切换")
    print("="*60)
    
    s = SimpleDeterrentSystem()
    s.start()
    
    # 先稳定在 L1
    s.set_desired(1, "进入L1")
    await asyncio.sleep(1)
    
    # 快速 L1/L2 抖动
    for i in range(10):
        level = 2 if i % 2 == 0 else 1
        s.set_desired(level, f"抖动{i}")
        await asyncio.sleep(0.3)
    
    await asyncio.sleep(2)
    s.stop()
    await asyncio.sleep(0.5)
    
    print(f"\n结果: level_changes={s.level_changes}")
    
    # 应该只有 0→1，可能有 1→2（如果最后停在2）
    if len(s.level_changes) <= 2:
        print("✅ 通过")
        return True
    else:
        print("❌ 失败：切换太频繁")
        return False


async def test_person_leave_return():
    """测试3: 人离开又回来"""
    print("\n" + "="*60)
    print("测试3: L1 → 人消失0.5秒 → 人回来")
    print("预期: 灯保持亮（去抖取消关灯）")
    print("="*60)
    
    s = SimpleDeterrentSystem()
    s.start()
    
    # 进入 L1
    s.set_desired(1, "进入")
    await asyncio.sleep(1)
    
    # 人消失
    s.set_desired(0, "消失")
    await asyncio.sleep(0.5)  # 小于去抖时间
    
    # 人回来
    s.set_desired(1, "回来")
    await asyncio.sleep(1)
    
    light_still_on = s._light_on
    off_count = s.light_off_count
    
    s.stop()
    await asyncio.sleep(0.5)
    
    print(f"\n结果: light_on={light_still_on} off_count={off_count}")
    
    if light_still_on and off_count == 0:
        print("✅ 通过：短暂消失不关灯")
        return True
    else:
        print("❌ 失败")
        return False


async def test_l2_min_hold():
    """测试4: L2 最短持续 5 秒"""
    print("\n" + "="*60)
    print("测试4: L2 最短持续（无延迟配置）")
    print("预期: 确认后尝试关闭，受最短持续限制")
    print("="*60)
    
    s = SimpleDeterrentSystem()
    s.start()
    
    # 直接进入 L2
    s.set_desired(2, "进入L2")
    await asyncio.sleep(1)  # 等确认
    
    # 确认后立即尝试关闭
    t0 = time.time()
    s.set_desired(0, "关闭")
    
    # 等待
    while s._confirmed_level != 0 and time.time() - t0 < 10:
        await asyncio.sleep(0.5)
    
    duration = time.time() - t0
    
    s.stop()
    await asyncio.sleep(0.5)
    
    print(f"\n结果: 从尝试关闭到实际关闭 {duration:.1f}s")
    
    # 应该受最短持续限制（约4-5秒）
    if duration >= 3.5:
        print("✅ 通过：最短持续有效")
        return True
    else:
        print("❌ 失败：降级太快")
        return False


async def test_rapid_same_level():
    """测试5: 快速重复同级别信号"""
    print("\n" + "="*60)
    print("测试5: 快速重复 L1 信号（模拟每帧检测）")
    print("预期: 灯只开1次")
    print("="*60)
    
    s = SimpleDeterrentSystem()
    s.start()
    
    # 快速连续 L1
    for i in range(50):
        s.set_desired(1, f"帧{i}")
        await asyncio.sleep(0.05)
    
    await asyncio.sleep(2)
    
    on_count = s.light_on_count
    light_on = s._light_on
    
    s.stop()
    await asyncio.sleep(0.5)
    
    print(f"\n结果: light_on_count={on_count} light_on={light_on}")
    
    if on_count == 1 and light_on:
        print("✅ 通过")
        return True
    else:
        print("❌ 失败")
        return False


async def test_l1_l2_l1_sequence():
    """测试6: L1 → L2 → L1 序列"""
    print("\n" + "="*60)
    print("测试6: L1 → L2 → L1 正常序列")
    print("="*60)
    
    s = SimpleDeterrentSystem()
    s.start()
    
    # L1（持续报告）
    for _ in range(4):
        s.set_desired(1, "L1")
        await asyncio.sleep(0.5)
    print(f"L1: confirmed={s._confirmed_level} light={s._light_on}")
    
    # L2（持续报告，超过最短持续）
    for _ in range(14):  # 7秒
        s.set_desired(2, "L2")
        await asyncio.sleep(0.5)
    print(f"L2: confirmed={s._confirmed_level} light={s._light_on}")
    
    # 回 L1（持续报告，需要超过去抖时间2秒）
    for _ in range(10):  # 5秒
        s.set_desired(1, "回L1")
        await asyncio.sleep(0.5)
    print(f"回L1: confirmed={s._confirmed_level} light={s._light_on}")
    
    s.stop()
    await asyncio.sleep(0.5)
    
    print(f"\n级别变化: {s.level_changes}")
    
    # 应该有 0→1, 1→2, 2→1
    if len(s.level_changes) == 3 and s._confirmed_level == 1:
        print("✅ 通过")
        return True
    else:
        print("❌ 失败")
        return False


async def test_l2_buffer():
    """测试7: L2 基本流程（默认无延迟）"""
    print("\n" + "="*60)
    print("测试7: L2 基本流程（默认无延迟）")
    print("="*60)
    
    s = SimpleDeterrentSystem()
    s.start()
    
    # 直接进入 L2
    s.set_desired(2, "进入L2")
    await asyncio.sleep(1)  # 等确认
    
    # 无延迟时，应该立即有灯和警报
    light = s._light_on
    siren = s.siren_count
    print(f"确认后(1s): light={light} siren={siren}")
    
    s.stop()
    await asyncio.sleep(0.5)
    
    # 无延迟配置：应该有灯和警报
    if siren > 0:
        print("✅ 通过：无延迟配置正常")
        return True
    else:
        print("❌ 失败")
        return False


async def test_l2_buffer_cancel():
    """测试8: L2 快速降级"""
    print("\n" + "="*60)
    print("测试8: L2 降级（人离开）")
    print("="*60)
    
    s = SimpleDeterrentSystem()
    s.start()
    
    # 进入 L2（持续报告）
    for _ in range(3):
        s.set_desired(2, "进入L2")
        await asyncio.sleep(0.5)
    
    confirmed = s._confirmed_level
    print(f"确认L2: confirmed={confirmed}")
    
    # 人离开（停止报告，等传感器超时+最短持续）
    await asyncio.sleep(8)  # 超时3秒 + 最短持续5秒
    
    final_level = s._confirmed_level
    print(f"人离开后: level={final_level}")
    
    s.stop()
    await asyncio.sleep(0.5)
    
    # 验证正确降级到 L0
    if confirmed == 2 and final_level == 0:
        print("✅ 通过：降级正常")
        return True
    else:
        print("❌ 失败")
        return False


async def test_multi_sensor():
    """测试9: 多传感器聚合"""
    print("\n" + "="*60)
    print("测试9: 多传感器聚合（取最高级别）")
    print("="*60)
    
    s = SimpleDeterrentSystem()
    s.start()
    
    # 场景1：两个传感器同时报告不同级别
    for _ in range(3):
        s.report_sensor("cam_back", 1)   # 后院 L1
        s.report_sensor("cam_front", 2)  # 前门 L2
        await asyncio.sleep(0.5)
    
    level1 = s._confirmed_level  # 应该是2
    print(f"cam_back=L1, cam_front=L2 → confirmed={level1}")
    
    # 场景2：高级别传感器离开，低级别继续报告
    for _ in range(10):  # 5秒，超过最短持续
        s.report_sensor("cam_back", 1)   # 后院继续 L1
        # cam_front 不再报告
        await asyncio.sleep(0.5)
    
    level2 = s._confirmed_level  # 应该是1
    print(f"cam_front停止后 → confirmed={level2}")
    
    # 场景3：所有传感器都离开
    await asyncio.sleep(6)  # 等超时+去抖
    
    level3 = s._confirmed_level  # 应该是0
    print(f"全部停止后 → confirmed={level3}")
    
    s.stop()
    await asyncio.sleep(0.5)
    
    # 验证
    if level1 == 2 and level2 == 1 and level3 == 0:
        print("✅ 通过：多传感器聚合正确")
        return True
    else:
        print(f"❌ 失败：期望 2,1,0 得到 {level1},{level2},{level3}")
        return False


async def test_multi_sensor_rapid():
    """测试10: 多传感器快速交替"""
    print("\n" + "="*60)
    print("测试10: 多传感器快速交替（不应混乱）")
    print("="*60)
    
    s = SimpleDeterrentSystem()
    s.start()
    
    # 模拟两个摄像头交替报告
    for i in range(20):
        if i % 2 == 0:
            s.report_sensor("cam_A", 2)  # A 报告 L2
            s.report_sensor("cam_B", 1)  # B 报告 L1
        else:
            s.report_sensor("cam_A", 1)  # A 报告 L1
            s.report_sensor("cam_B", 2)  # B 报告 L2
        await asyncio.sleep(0.1)
    
    await asyncio.sleep(1)
    
    # 结果应该是 L2（因为总有一个是 L2）
    level = s._desired_level
    confirmed = s._confirmed_level
    
    print(f"交替后: desired={level} confirmed={confirmed}")
    
    s.stop()
    await asyncio.sleep(0.5)
    
    # 应该稳定在 L2
    if level == 2 and confirmed == 2:
        print("✅ 通过：快速交替不混乱")
        return True
    else:
        print("❌ 失败")
        return False


async def main():
    results = []
    
    results.append(("L0/L1抖动", await test_l0_l1_jitter()))
    results.append(("L1/L2抖动", await test_l1_l2_jitter()))
    results.append(("人离开又回来", await test_person_leave_return()))
    results.append(("L2最短持续", await test_l2_min_hold()))
    results.append(("快速重复信号", await test_rapid_same_level()))
    results.append(("L1→L2→L1序列", await test_l1_l2_l1_sequence()))
    results.append(("L2缓冲期", await test_l2_buffer()))
    results.append(("L2缓冲期取消", await test_l2_buffer_cancel()))
    results.append(("多传感器聚合", await test_multi_sensor()))
    results.append(("多传感器快速交替", await test_multi_sensor_rapid()))
    
    print("\n" + "="*60)
    print("测试汇总")
    print("="*60)
    for name, passed in results:
        status = "✅" if passed else "❌"
        print(f"  {status} {name}")
    
    return all(p for _, p in results)


if __name__ == "__main__":
    asyncio.run(main())
