"""
Tests for Core Signal Definitions
"""

import pytest
from datetime import datetime, timezone

from ng_edge.core.signal import (
    SignalEnvelope,
    SourceType,
    Hardness,
    CameraRole,
    ContextGateType,
    get_signal_hardness,
)


class TestHardnessClassification:
    """信号硬度分类测试"""
    
    def test_sensor_signals_are_hard(self):
        """传感器信号应该是 HARD"""
        assert get_signal_hardness("door_open") == Hardness.HARD
        assert get_signal_hardness("door_close") == Hardness.HARD
        assert get_signal_hardness("glass_break") == Hardness.HARD
    
    def test_camera_signals_are_soft(self):
        """摄像头信号应该是 SOFT"""
        assert get_signal_hardness("person_detected") == Hardness.SOFT
        assert get_signal_hardness("vehicle_detected") == Hardness.SOFT
    
    def test_unknown_signals_default_to_soft(self):
        """未知信号默认为 SOFT"""
        assert get_signal_hardness("unknown_signal") == Hardness.SOFT


class TestSignalEnvelopeBasic:
    """SignalEnvelope 基础测试"""
    
    def test_create_minimal_signal(self):
        """测试创建最小信号"""
        signal = SignalEnvelope(
            device_id="sensor_001",
            zone_id="zone_front",
            signal_kind="door_open",
        )
        
        assert signal.device_id == "sensor_001"
        assert signal.zone_id == "zone_front"
        assert signal.signal_kind == "door_open"
        assert signal.hardness == Hardness.HARD
        assert signal.signal_id.startswith("sig_")
    
    def test_signal_id_uniqueness(self):
        """测试信号 ID 唯一性"""
        signal1 = SignalEnvelope(signal_kind="door_open")
        signal2 = SignalEnvelope(signal_kind="door_open")
        
        assert signal1.signal_id != signal2.signal_id
    
    def test_is_hard_is_soft(self):
        """测试 is_hard/is_soft 方法"""
        hard_signal = SignalEnvelope(signal_kind="door_open")
        soft_signal = SignalEnvelope(signal_kind="person_detected")
        
        assert hard_signal.is_hard()
        assert soft_signal.is_soft()


class TestSignalFactoryMethods:
    """信号工厂方法测试"""
    
    def test_from_zigbee(self):
        """测试从 Zigbee 创建信号"""
        signal = SignalEnvelope.from_zigbee(
            device_id="0xb40e060fffe290c7",
            friendly_name="Back Door Contact",
            signal_kind="door_open",
            zone_id="entry_exit",
            entrypoint_id="ep_back_door",
        )
        
        assert signal.source_type == SourceType.SENSOR
        assert signal.device_id == "0xb40e060fffe290c7"
        assert signal.hardness == Hardness.HARD
        assert signal.confidence == 1.0
    
    def test_from_camera(self):
        """测试从摄像头创建信号"""
        signal = SignalEnvelope.from_camera(
            device_id="cam_front",
            signal_kind="person_detected",
            zone_id="exterior",
            camera_role=CameraRole.JUDGE,
            confidence=0.92,
        )
        
        assert signal.source_type == SourceType.CAMERA
        assert signal.hardness == Hardness.SOFT
        assert signal.camera_role == CameraRole.JUDGE
        assert signal.confidence == 0.92
    
    def test_context_gate(self):
        """测试上下文门控信号"""
        signal = SignalEnvelope.context_gate(
            gate_type=ContextGateType.YARD_CONFIRMED,
            zone_id="zone_front",
            source_device="cam_front",
            ttl_sec=120,
        )
        
        assert signal.source_type == SourceType.CONTEXT
        assert signal.signal_kind == "context_gate"
        assert signal.attributes["ttl_sec"] == 120


class TestSignalSerialization:
    """信号序列化测试"""
    
    def test_to_dict_and_back(self):
        """测试序列化往返"""
        original = SignalEnvelope.from_zigbee(
            device_id="sensor_001",
            friendly_name="Test",
            signal_kind="door_open",
            zone_id="entry_exit",
        )
        
        data = original.to_dict()
        restored = SignalEnvelope.from_dict(data)
        
        assert restored.device_id == original.device_id
        assert restored.signal_kind == original.signal_kind
        assert restored.hardness == original.hardness
