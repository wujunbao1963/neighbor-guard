"""
Tests for Signal Correlator
"""

import pytest
from datetime import datetime, timezone, timedelta

from ng_edge.core.signal import SignalEnvelope, Hardness
from ng_edge.correlation.correlator import (
    SignalCorrelator,
    CorrelatorConfig,
    Lease,
    IncidentCandidate,
)


def make_door_signal(
    zone_id: str = "entry_exit",
    entrypoint_id: str = "ep_front",
    signal_id: str = None,
) -> SignalEnvelope:
    """创建门信号"""
    signal = SignalEnvelope.from_zigbee(
        device_id="sensor_001",
        friendly_name="Door Contact",
        signal_kind="door_open",
        zone_id=zone_id,
        entrypoint_id=entrypoint_id,
    )
    if signal_id:
        signal.signal_id = signal_id
    return signal


def make_person_signal(
    zone_id: str = "exterior",
    entrypoint_id: str = None,
    signal_id: str = None,
) -> SignalEnvelope:
    """创建人员检测信号"""
    from ng_edge.core.signal import CameraRole
    signal = SignalEnvelope.from_camera(
        device_id="cam_front",
        signal_kind="person_detected",
        zone_id=zone_id,
        camera_role=CameraRole.JUDGE,
        entrypoint_id=entrypoint_id,
    )
    if signal_id:
        signal.signal_id = signal_id
    return signal


class TestLease:
    """Lease 测试"""
    
    def test_lease_equality(self):
        """测试 Lease 相等性"""
        lease1 = Lease(zone_id="zone_front", entrypoint_id="ep_front")
        lease2 = Lease(zone_id="zone_front", entrypoint_id="ep_front")
        lease3 = Lease(zone_id="zone_front", entrypoint_id="ep_back")
        
        assert lease1 == lease2
        assert lease1 != lease3
    
    def test_lease_hash(self):
        """测试 Lease 可哈希"""
        lease1 = Lease(zone_id="zone_front", entrypoint_id="ep_front")
        lease2 = Lease(zone_id="zone_front", entrypoint_id="ep_front")
        
        d = {lease1: "test"}
        assert d[lease2] == "test"
    
    def test_lease_matches(self):
        """测试 Lease 匹配"""
        lease = Lease(zone_id="entry_exit", entrypoint_id="ep_front")
        
        signal1 = make_door_signal(zone_id="entry_exit", entrypoint_id="ep_front")
        signal2 = make_door_signal(zone_id="entry_exit", entrypoint_id="ep_back")
        signal3 = make_door_signal(zone_id="interior", entrypoint_id="ep_front")
        
        assert lease.matches(signal1)
        assert not lease.matches(signal2)
        assert not lease.matches(signal3)


class TestIncidentCandidate:
    """IncidentCandidate 测试"""
    
    def test_add_signal(self):
        """测试添加信号"""
        candidate = IncidentCandidate(
            candidate_id="cand_001",
            lease=Lease(zone_id="entry_exit"),
        )
        
        hard_signal = make_door_signal()
        soft_signal = make_person_signal()
        
        candidate.add_signal(hard_signal)
        candidate.add_signal(soft_signal)
        
        assert candidate.signal_count() == 2
        assert len(candidate.hard_signals) == 1
        assert len(candidate.soft_signals) == 1
    
    def test_has_hard_signal(self):
        """测试是否有 Hard 信号"""
        candidate = IncidentCandidate(
            candidate_id="cand_001",
            lease=Lease(zone_id="entry_exit"),
        )
        
        assert not candidate.has_hard_signal()
        
        candidate.add_signal(make_door_signal())
        
        assert candidate.has_hard_signal()
    
    def test_deduplication(self):
        """测试信号去重"""
        candidate = IncidentCandidate(
            candidate_id="cand_001",
            lease=Lease(zone_id="entry_exit"),
        )
        
        signal = make_door_signal(signal_id="sig_001")
        
        candidate.add_signal(signal)
        candidate.add_signal(signal)  # 重复添加
        
        assert candidate.signal_count() == 1


class TestSignalCorrelator:
    """SignalCorrelator 测试"""
    
    def test_create_correlator(self):
        """测试创建关联器"""
        correlator = SignalCorrelator()
        
        assert correlator.config.pre_aggregation_window_sec == 60
    
    def test_correlate_first_signal(self):
        """测试关联第一个信号"""
        correlator = SignalCorrelator()
        
        signal = make_door_signal()
        candidate = correlator.correlate(signal)
        
        assert candidate is not None
        assert candidate.signal_count() == 1
        assert correlator.stats["candidates_created"] == 1
    
    def test_correlate_same_lease(self):
        """测试同一 Lease 的信号关联到同一候选"""
        correlator = SignalCorrelator()
        
        signal1 = make_door_signal(entrypoint_id="ep_front")
        signal2 = make_person_signal(zone_id="entry_exit", entrypoint_id="ep_front")
        
        candidate1 = correlator.correlate(signal1)
        candidate2 = correlator.correlate(signal2)
        
        assert candidate1.candidate_id == candidate2.candidate_id
        assert candidate1.signal_count() == 2
    
    def test_correlate_different_lease(self):
        """测试不同 Lease 的信号创建不同候选"""
        correlator = SignalCorrelator()
        
        signal1 = make_door_signal(entrypoint_id="ep_front")
        signal2 = make_door_signal(entrypoint_id="ep_back")
        
        candidate1 = correlator.correlate(signal1)
        candidate2 = correlator.correlate(signal2)
        
        assert candidate1.candidate_id != candidate2.candidate_id
        assert correlator.stats["candidates_created"] == 2
    
    def test_signal_deduplication(self):
        """测试信号去重"""
        correlator = SignalCorrelator()
        
        signal = make_door_signal(signal_id="sig_001")
        
        candidate1 = correlator.correlate(signal)
        candidate2 = correlator.correlate(signal)  # 重复信号
        
        assert candidate1.candidate_id == candidate2.candidate_id
        assert correlator.stats["signals_deduplicated"] == 1
    
    def test_time_window_respected(self):
        """测试时间窗口"""
        config = CorrelatorConfig(pre_aggregation_window_sec=60)
        correlator = SignalCorrelator(config)
        
        signal1 = make_door_signal(signal_id="sig_001")
        candidate1 = correlator.correlate(signal1)
        
        # 模拟信号超过时间窗口
        signal2 = make_door_signal(signal_id="sig_002")
        signal2.ingest_ts = datetime.now(timezone.utc) + timedelta(seconds=120)
        
        # 手动更新 candidate 的 last_signal_at 为旧时间
        candidate1.last_signal_at = datetime.now(timezone.utc) - timedelta(seconds=120)
        
        candidate2 = correlator.correlate(signal2)
        
        # 应该创建新候选（因为超过窗口）
        assert candidate1.candidate_id != candidate2.candidate_id


class TestCorrelatorOperations:
    """关联器操作测试"""
    
    def test_get_candidate(self):
        """测试获取候选"""
        correlator = SignalCorrelator()
        
        signal = make_door_signal()
        candidate = correlator.correlate(signal)
        
        retrieved = correlator.get_candidate(candidate.candidate_id)
        
        assert retrieved is not None
        assert retrieved.candidate_id == candidate.candidate_id
    
    def test_get_candidate_by_lease(self):
        """测试通过 Lease 获取候选"""
        correlator = SignalCorrelator()
        
        signal = make_door_signal(zone_id="entry_exit", entrypoint_id="ep_front")
        correlator.correlate(signal)
        
        lease = Lease(zone_id="entry_exit", entrypoint_id="ep_front")
        candidate = correlator.get_candidate_by_lease(lease)
        
        assert candidate is not None
    
    def test_get_active_candidates(self):
        """测试获取活跃候选"""
        correlator = SignalCorrelator()
        
        correlator.correlate(make_door_signal(entrypoint_id="ep_front"))
        correlator.correlate(make_door_signal(entrypoint_id="ep_back"))
        
        active = correlator.get_active_candidates()
        
        assert len(active) == 2
    
    def test_get_active_candidates_by_zone(self):
        """测试按 zone 获取活跃候选"""
        correlator = SignalCorrelator()
        
        correlator.correlate(make_door_signal(zone_id="entry_exit"))
        correlator.correlate(make_person_signal(zone_id="exterior"))
        
        entry_candidates = correlator.get_active_candidates("entry_exit")
        
        assert len(entry_candidates) == 1
    
    def test_promote_to_incident(self):
        """测试提升为 Incident"""
        correlator = SignalCorrelator()
        
        signal = make_door_signal()
        candidate = correlator.correlate(signal)
        
        correlator.promote_to_incident(candidate.candidate_id, "inc_001")
        
        assert candidate.promoted_to_incident
        assert candidate.incident_id == "inc_001"
    
    def test_close_candidate(self):
        """测试关闭候选"""
        correlator = SignalCorrelator()
        
        signal = make_door_signal()
        candidate = correlator.correlate(signal)
        
        correlator.close_candidate(candidate.candidate_id, "test")
        
        assert not candidate.is_active
        assert correlator.stats["candidates_closed"] == 1
    
    def test_cleanup_inactive(self):
        """测试清理不活跃候选"""
        correlator = SignalCorrelator()
        
        signal = make_door_signal()
        candidate = correlator.correlate(signal)
        
        # 设置为旧时间
        candidate.last_signal_at = datetime.now(timezone.utc) - timedelta(seconds=600)
        
        closed = correlator.cleanup_inactive(max_age_sec=300)
        
        assert len(closed) == 1
        assert not candidate.is_active


class TestCorrelatorCallbacks:
    """回调测试"""
    
    def test_on_candidate_created(self):
        """测试创建回调"""
        correlator = SignalCorrelator()
        created = []
        correlator.on_candidate_created = lambda c: created.append(c)
        
        correlator.correlate(make_door_signal())
        
        assert len(created) == 1
    
    def test_on_candidate_updated(self):
        """测试更新回调"""
        correlator = SignalCorrelator()
        updated = []
        correlator.on_candidate_updated = lambda c: updated.append(c)
        
        correlator.correlate(make_door_signal(signal_id="sig_001"))
        correlator.correlate(make_door_signal(signal_id="sig_002"))  # 同一 lease
        
        assert len(updated) == 1
    
    def test_on_candidate_closed(self):
        """测试关闭回调"""
        correlator = SignalCorrelator()
        closed = []
        correlator.on_candidate_closed = lambda c: closed.append(c)
        
        signal = make_door_signal()
        candidate = correlator.correlate(signal)
        correlator.close_candidate(candidate.candidate_id)
        
        assert len(closed) == 1
