"""
Tests for State Definitions (v2.2)
"""

import pytest
from datetime import datetime, timezone

from ng_edge.state.states import (
    ThreatState,
    WorkflowState,
    WorkflowSubPhase,
    JudgeAvailabilityState,
    ReasonCode,
    IncidentState,
    TransitionRecord,
    is_valid_combination,
    alarm_state_to_threat,
    threat_to_alarm_state,
    VALID_STATE_COMBINATIONS,
)


class TestThreatState:
    """ThreatState 测试"""
    
    def test_threat_levels_order(self):
        """测试威胁级别顺序"""
        levels = [
            ThreatState.NONE,
            ThreatState.PRE_L1,
            ThreatState.PRE_L2,
            ThreatState.PRE_L3,
            ThreatState.PENDING,
            ThreatState.TRIGGERED,
        ]
        # 确保所有级别都定义了
        assert len(levels) == 6
    
    def test_threat_state_values(self):
        """测试状态值"""
        assert ThreatState.NONE.value == "none"
        assert ThreatState.PRE_L2.value == "pre_l2"
        assert ThreatState.TRIGGERED.value == "triggered"


class TestWorkflowState:
    """WorkflowState 测试"""
    
    def test_workflow_states_exist(self):
        """测试工作流状态存在"""
        assert WorkflowState.IDLE
        assert WorkflowState.NOTIFIED
        assert WorkflowState.VERIFYING
        assert WorkflowState.ESCALATED
        assert WorkflowState.RESOLVED
        assert WorkflowState.CLOSED


class TestValidCombinations:
    """状态组合验证测试"""
    
    def test_none_idle_valid(self):
        """NONE + IDLE 有效"""
        assert is_valid_combination(ThreatState.NONE, WorkflowState.IDLE)
    
    def test_none_closed_valid(self):
        """NONE + CLOSED 有效"""
        assert is_valid_combination(ThreatState.NONE, WorkflowState.CLOSED)
    
    def test_none_notified_invalid(self):
        """NONE + NOTIFIED 无效"""
        assert not is_valid_combination(ThreatState.NONE, WorkflowState.NOTIFIED)
    
    def test_pre_l1_idle_valid(self):
        """PRE_L1 + IDLE 有效"""
        assert is_valid_combination(ThreatState.PRE_L1, WorkflowState.IDLE)
    
    def test_pre_l1_notified_invalid(self):
        """PRE_L1 + NOTIFIED 无效（PRE_L1 太轻微不通知）"""
        assert not is_valid_combination(ThreatState.PRE_L1, WorkflowState.NOTIFIED)
    
    def test_pre_l2_notified_valid(self):
        """PRE_L2 + NOTIFIED 有效"""
        assert is_valid_combination(ThreatState.PRE_L2, WorkflowState.NOTIFIED)
    
    def test_pending_notified_valid(self):
        """PENDING + NOTIFIED 有效"""
        assert is_valid_combination(ThreatState.PENDING, WorkflowState.NOTIFIED)
    
    def test_triggered_escalated_valid(self):
        """TRIGGERED + ESCALATED 有效"""
        assert is_valid_combination(ThreatState.TRIGGERED, WorkflowState.ESCALATED)
    
    def test_pre_l2_escalated_invalid(self):
        """PRE_L2 + ESCALATED 无效（PRE 不能升级到 ESCALATED）"""
        assert not is_valid_combination(ThreatState.PRE_L2, WorkflowState.ESCALATED)


class TestIncidentState:
    """IncidentState 测试"""
    
    def test_create_incident(self):
        """测试创建事件"""
        incident = IncidentState(
            incident_id="inc_001",
            zone_id="zone_front",
            entrypoint_id="ep_front",
        )
        
        assert incident.incident_id == "inc_001"
        assert incident.threat_state == ThreatState.NONE
        assert incident.workflow_state == WorkflowState.IDLE
        assert incident.judge_available == True
    
    def test_is_active_none_idle(self):
        """NONE + IDLE 不活跃"""
        incident = IncidentState(incident_id="test")
        assert not incident.is_active()
    
    def test_is_active_pre_l2(self):
        """PRE_L2 活跃"""
        incident = IncidentState(
            incident_id="test",
            threat_state=ThreatState.PRE_L2,
        )
        assert incident.is_active()
    
    def test_is_active_triggered(self):
        """TRIGGERED 活跃"""
        incident = IncidentState(
            incident_id="test",
            threat_state=ThreatState.TRIGGERED,
            workflow_state=WorkflowState.ESCALATED,
        )
        assert incident.is_active()
    
    def test_is_valid_default(self):
        """默认状态有效"""
        incident = IncidentState(incident_id="test")
        assert incident.is_valid()
    
    def test_is_valid_triggered_escalated(self):
        """TRIGGERED + ESCALATED 有效"""
        incident = IncidentState(
            incident_id="test",
            threat_state=ThreatState.TRIGGERED,
            workflow_state=WorkflowState.ESCALATED,
        )
        assert incident.is_valid()
    
    def test_can_escalate_pre_when_judge_available(self):
        """Judge 可用时可以升级 PRE"""
        incident = IncidentState(
            incident_id="test",
            threat_state=ThreatState.PRE_L1,
            judge_available=True,
        )
        assert incident.can_escalate_pre()
    
    def test_cannot_escalate_pre_when_judge_degraded(self):
        """Judge 降级时不能升级 PRE"""
        incident = IncidentState(
            incident_id="test",
            threat_state=ThreatState.PRE_L1,
            judge_available=False,
        )
        assert not incident.can_escalate_pre()
    
    def test_cannot_escalate_pre_when_already_l3(self):
        """已经是 PRE_L3 时不能再升级"""
        incident = IncidentState(
            incident_id="test",
            threat_state=ThreatState.PRE_L3,
            judge_available=True,
        )
        assert not incident.can_escalate_pre()


class TestCompatibilityMapping:
    """兼容性映射测试"""
    
    def test_alarm_quiet_to_none(self):
        """quiet → NONE"""
        from ng_edge.services.state_machine_v5 import AlarmState
        result = alarm_state_to_threat(AlarmState.QUIET)
        assert result == ThreatState.NONE
    
    def test_alarm_attention_to_pre_l1(self):
        """attention → PRE_L1"""
        from ng_edge.services.state_machine_v5 import AlarmState
        result = alarm_state_to_threat(AlarmState.ATTENTION)
        assert result == ThreatState.PRE_L1
    
    def test_alarm_pre_to_pre_l2(self):
        """pre → PRE_L2"""
        from ng_edge.services.state_machine_v5 import AlarmState
        result = alarm_state_to_threat(AlarmState.PRE)
        assert result == ThreatState.PRE_L2
    
    def test_alarm_pending_to_pending(self):
        """pending → PENDING"""
        from ng_edge.services.state_machine_v5 import AlarmState
        result = alarm_state_to_threat(AlarmState.PENDING)
        assert result == ThreatState.PENDING
    
    def test_alarm_triggered_to_triggered(self):
        """triggered → TRIGGERED"""
        from ng_edge.services.state_machine_v5 import AlarmState
        result = alarm_state_to_threat(AlarmState.TRIGGERED)
        assert result == ThreatState.TRIGGERED
    
    def test_threat_none_to_quiet(self):
        """NONE → quiet"""
        result = threat_to_alarm_state(ThreatState.NONE)
        assert result == "quiet"
    
    def test_threat_pre_l2_to_pre(self):
        """PRE_L2 → pre"""
        result = threat_to_alarm_state(ThreatState.PRE_L2)
        assert result == "pre"
    
    def test_threat_pre_l3_to_pre(self):
        """PRE_L3 → pre (v5 没有 L3)"""
        result = threat_to_alarm_state(ThreatState.PRE_L3)
        assert result == "pre"


class TestReasonCode:
    """ReasonCode 测试"""
    
    def test_signal_codes(self):
        """测试信号原因码"""
        assert ReasonCode.SIGNAL_DOOR_OPEN.value == "signal_door_open"
        assert ReasonCode.SIGNAL_GLASS_BREAK.value == "signal_glass_break"
    
    def test_decay_codes(self):
        """测试衰减原因码"""
        assert ReasonCode.DECAY_SILENCE_L3.value == "decay_silence_l3"
    
    def test_user_codes(self):
        """测试用户操作原因码"""
        assert ReasonCode.USER_CANCEL.value == "user_cancel"
        assert ReasonCode.USER_RESOLVE.value == "user_resolve"


class TestTransitionRecord:
    """TransitionRecord 测试"""
    
    def test_create_record(self):
        """测试创建转换记录"""
        record = TransitionRecord(
            record_id="tr_001",
            timestamp=datetime.now(timezone.utc),
            incident_id="inc_001",
            dimension="threat",
            from_state="none",
            to_state="pre_l2",
            reason_code="signal_person",
        )
        
        assert record.record_id == "tr_001"
        assert record.dimension == "threat"
        assert record.from_state == "none"
        assert record.to_state == "pre_l2"
