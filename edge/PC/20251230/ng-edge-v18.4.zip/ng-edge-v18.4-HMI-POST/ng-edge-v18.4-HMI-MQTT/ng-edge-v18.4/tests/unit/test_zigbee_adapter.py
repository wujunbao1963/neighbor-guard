"""
Tests for Zigbee Signal Adapter
"""

import pytest
from unittest.mock import Mock, MagicMock

from ng_edge.core.signal import SignalEnvelope, Hardness, SourceType
from ng_edge.core.zigbee_adapter import (
    convert_zigbee_signal,
    ZigbeeSignalAdapter,
    create_envelope_handler,
    SIGNAL_KIND_MAP,
)


class TestConvertZigbeeSignal:
    """测试信号转换函数"""
    
    def test_convert_door_open(self):
        """测试转换 DOOR_OPEN"""
        sensor_info = {
            "sensor_id": "sensor_back_door",
            "ieee_address": "0xb40e060fffe290c7",
            "friendly_name": "Back Door Contact",
            "sensor_type": "contact",
            "entry_point_id": "ep_back_door",
            "zone_type": "entry_exit",
        }
        signal_data = {
            "contact": False,
            "battery": 100,
            "linkquality": 150,
        }
        
        envelope = convert_zigbee_signal(sensor_info, "DOOR_OPEN", signal_data)
        
        assert envelope is not None
        assert envelope.signal_kind == "door_open"
        assert envelope.hardness == Hardness.HARD
        assert envelope.device_id == "0xb40e060fffe290c7"
        assert envelope.entrypoint_id == "ep_back_door"
        assert envelope.zone_id == "entry_exit"
        assert envelope.source_type == SourceType.SENSOR
        assert envelope.attributes["battery"] == 100
    
    def test_convert_door_close(self):
        """测试转换 DOOR_CLOSE"""
        sensor_info = {
            "sensor_id": "sensor_back_door",
            "ieee_address": "0xabc123",
            "friendly_name": "Back Door",
            "entry_point_id": "ep_back",
            "zone_type": "entry_exit",
        }
        signal_data = {"contact": True, "battery": 95}
        
        envelope = convert_zigbee_signal(sensor_info, "DOOR_CLOSE", signal_data)
        
        assert envelope is not None
        assert envelope.signal_kind == "door_close"
        assert envelope.hardness == Hardness.HARD
    
    def test_convert_motion_active(self):
        """测试转换 MOTION_ACTIVE"""
        sensor_info = {
            "sensor_id": "sensor_motion_1",
            "ieee_address": "0x54ef4410014105aa",
            "friendly_name": "Living Room Motion",
            "sensor_type": "motion",
            "entry_point_id": "ep_living",
            "zone_type": "interior",
        }
        signal_data = {
            "occupancy": True,
            "illuminance": 25,
            "battery": 80,
        }
        
        envelope = convert_zigbee_signal(sensor_info, "MOTION_ACTIVE", signal_data)
        
        assert envelope is not None
        assert envelope.signal_kind == "motion_pir"
        assert envelope.hardness == Hardness.HARD
        assert envelope.zone_id == "interior"
    
    def test_convert_glass_break(self):
        """测试转换 GLASS_BREAK"""
        sensor_info = {
            "sensor_id": "sensor_glass_1",
            "ieee_address": "0xdef456",
            "friendly_name": "Window Glass",
            "sensor_type": "glass_break",
            "zone_type": "perimeter",
        }
        signal_data = {"vibration": True}
        
        envelope = convert_zigbee_signal(sensor_info, "GLASS_BREAK", signal_data)
        
        assert envelope is not None
        assert envelope.signal_kind == "glass_break"
        assert envelope.hardness == Hardness.HARD
    
    def test_convert_unknown_signal_returns_none(self):
        """测试未知信号类型返回 None"""
        sensor_info = {"sensor_id": "test"}
        signal_data = {}
        
        envelope = convert_zigbee_signal(sensor_info, "UNKNOWN_TYPE", signal_data)
        
        assert envelope is None
    
    def test_convert_preserves_raw_payload(self):
        """测试保留原始 payload"""
        sensor_info = {
            "sensor_id": "test",
            "ieee_address": "0x123",
            "friendly_name": "Test",
            "zone_type": "exterior",
        }
        signal_data = {"contact": False, "battery": 100, "custom": "value"}
        
        envelope = convert_zigbee_signal(sensor_info, "DOOR_OPEN", signal_data)
        
        assert envelope.attributes["raw_payload"] == signal_data


class TestZigbeeSignalAdapter:
    """测试 Zigbee 信号适配器"""
    
    def test_adapter_converts_signals(self):
        """测试适配器转换信号"""
        # Mock router
        router = Mock()
        router.on_signal_callback = None
        router.get_stats = Mock(return_value={})
        
        # 创建适配器
        adapter = ZigbeeSignalAdapter(router)
        
        # 记录收到的 envelope
        received = []
        adapter.on_signal_envelope = lambda e: received.append(e)
        
        # 模拟信号
        sensor_info = {
            "sensor_id": "test",
            "ieee_address": "0x123",
            "friendly_name": "Test",
            "entry_point_id": "ep_test",
            "zone_type": "entry_exit",
        }
        
        # 触发回调
        router.on_signal_callback(sensor_info, "DOOR_OPEN", {"contact": False})
        
        assert len(received) == 1
        assert received[0].signal_kind == "door_open"
        assert adapter.stats["signals_converted"] == 1
    
    def test_adapter_preserves_original_callback(self):
        """测试适配器保留原有回调"""
        router = Mock()
        original_called = []
        router.on_signal_callback = lambda *args: original_called.append(args)
        router.get_stats = Mock(return_value={})
        
        adapter = ZigbeeSignalAdapter(router)
        
        sensor_info = {"sensor_id": "test", "ieee_address": "0x1", "friendly_name": "T", "zone_type": "x"}
        router.on_signal_callback(sensor_info, "DOOR_OPEN", {})
        
        # 原有回调也被调用
        assert len(original_called) == 1
    
    def test_adapter_handles_conversion_error(self):
        """测试适配器处理转换错误"""
        router = Mock()
        router.on_signal_callback = None
        router.get_stats = Mock(return_value={})
        
        adapter = ZigbeeSignalAdapter(router)
        
        # 触发无效信号
        router.on_signal_callback({}, "UNKNOWN", {})
        
        # 不应崩溃，统计应更新
        assert adapter.stats["signals_received"] == 1
        assert adapter.stats["signals_converted"] == 0


class TestCreateEnvelopeHandler:
    """测试工厂函数"""
    
    def test_creates_working_handler(self):
        """测试创建可用的处理器"""
        received = []
        handler = create_envelope_handler(lambda e: received.append(e))
        
        sensor_info = {
            "sensor_id": "test",
            "ieee_address": "0x123",
            "friendly_name": "Test",
            "zone_type": "entry_exit",
        }
        
        handler(sensor_info, "DOOR_OPEN", {"contact": False})
        
        assert len(received) == 1
        assert received[0].signal_kind == "door_open"
    
    def test_handler_ignores_unknown_signals(self):
        """测试处理器忽略未知信号"""
        received = []
        handler = create_envelope_handler(lambda e: received.append(e))
        
        handler({"sensor_id": "x"}, "UNKNOWN", {})
        
        assert len(received) == 0


class TestSignalKindMap:
    """测试信号类型映射"""
    
    def test_all_mappings_exist(self):
        """测试所有必要的映射存在"""
        assert "DOOR_OPEN" in SIGNAL_KIND_MAP
        assert "DOOR_CLOSE" in SIGNAL_KIND_MAP
        assert "MOTION_ACTIVE" in SIGNAL_KIND_MAP
        assert "GLASS_BREAK" in SIGNAL_KIND_MAP
    
    def test_mappings_are_lowercase(self):
        """测试映射值为小写"""
        for old, new in SIGNAL_KIND_MAP.items():
            assert new == new.lower()
