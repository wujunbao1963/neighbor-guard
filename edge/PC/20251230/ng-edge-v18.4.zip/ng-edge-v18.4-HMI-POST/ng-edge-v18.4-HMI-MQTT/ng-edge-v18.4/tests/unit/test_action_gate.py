"""
Tests for Action Gate
"""

import pytest
from datetime import datetime, timezone, timedelta

from ng_edge.state.states import ThreatState, WorkflowState
from ng_edge.action.gate import (
    ActionGate,
    ActionGateConfig,
    ActionType,
    GateDecision,
    GateResult,
    SirenPolicy,
    SirenPolicyConfig,
    SirenState,
)


class TestActionGateBasic:
    """Action Gate 基础测试"""
    
    def test_create_gate(self):
        """测试创建 Gate"""
        gate = ActionGate()
        assert gate.config is not None
    
    def test_custom_config(self):
        """测试自定义配置"""
        config = ActionGateConfig(
            pre_l1_actions={ActionType.SNAPSHOT},
        )
        gate = ActionGate(config)
        
        assert ActionType.SNAPSHOT in gate.config.pre_l1_actions


class TestActionGateDecisions:
    """权限决策测试"""
    
    def test_allow_in_correct_state(self):
        """测试正确状态下允许"""
        gate = ActionGate()
        
        result = gate.check(
            action=ActionType.SIREN_ACTIVATE,
            threat_state=ThreatState.TRIGGERED,
        )
        
        assert result.decision == GateDecision.ALLOW
    
    def test_deny_in_wrong_state(self):
        """测试错误状态下拒绝"""
        gate = ActionGate()
        
        result = gate.check(
            action=ActionType.SIREN_ACTIVATE,
            threat_state=ThreatState.PRE_L1,
        )
        
        assert result.decision == GateDecision.DENY
    
    def test_always_allowed(self):
        """测试始终允许的动作"""
        gate = ActionGate()
        
        # DISARM 在任何状态都允许
        result = gate.check(
            action=ActionType.DISARM_SYSTEM,
            threat_state=ThreatState.NONE,
        )
        
        assert result.decision == GateDecision.ALLOW
        assert result.reason == "always_allowed"
    
    def test_override(self):
        """测试强制覆盖"""
        gate = ActionGate()
        
        result = gate.check(
            action=ActionType.SIREN_ACTIVATE,
            threat_state=ThreatState.NONE,
            override=True,
        )
        
        assert result.decision == GateDecision.ALLOW
        assert result.reason == "override"


class TestActionGateMatrix:
    """权限矩阵测试"""
    
    def test_pre_l1_actions(self):
        """测试 PRE_L1 允许的动作"""
        gate = ActionGate()
        
        allowed = gate.get_allowed_actions(ThreatState.PRE_L1)
        
        assert ActionType.LIGHT_FLASH in allowed
        assert ActionType.SNAPSHOT in allowed
        assert ActionType.SIREN_ACTIVATE not in allowed
    
    def test_pre_l2_actions(self):
        """测试 PRE_L2 允许的动作"""
        gate = ActionGate()
        
        allowed = gate.get_allowed_actions(ThreatState.PRE_L2)
        
        assert ActionType.CHIME in allowed
        assert ActionType.PUSH_NOTIFICATION in allowed
    
    def test_triggered_actions(self):
        """测试 TRIGGERED 允许的动作"""
        gate = ActionGate()
        
        allowed = gate.get_allowed_actions(ThreatState.TRIGGERED)
        
        assert ActionType.SIREN_ACTIVATE in allowed
        assert ActionType.SMS_ALERT in allowed
        assert ActionType.REQUEST_DISPATCH in allowed
    
    def test_none_state_minimal(self):
        """测试 NONE 状态动作最少"""
        gate = ActionGate()
        
        allowed = gate.get_allowed_actions(ThreatState.NONE)
        
        # 只有 always_allowed
        assert ActionType.DISARM_SYSTEM in allowed
        assert ActionType.SIREN_ACTIVATE not in allowed


class TestActionGateConfirmation:
    """确认要求测试"""
    
    def test_dispatch_requires_confirmation(self):
        """测试派遣需要确认"""
        gate = ActionGate()
        
        result = gate.check(
            action=ActionType.REQUEST_DISPATCH,
            threat_state=ThreatState.TRIGGERED,
        )
        
        assert result.decision == GateDecision.ALLOW
        assert result.requires_confirmation


class TestActionGateBatch:
    """批量检查测试"""
    
    def test_check_batch(self):
        """测试批量检查"""
        gate = ActionGate()
        
        actions = [
            ActionType.SIREN_ACTIVATE,
            ActionType.PUSH_NOTIFICATION,
            ActionType.SNAPSHOT,
        ]
        
        results = gate.check_batch(actions, ThreatState.TRIGGERED)
        
        assert len(results) == 3
        assert all(r.decision == GateDecision.ALLOW for r in results.values())


class TestActionGateStats:
    """统计测试"""
    
    def test_stats_counting(self):
        """测试统计计数"""
        gate = ActionGate()
        
        gate.check(ActionType.SIREN_ACTIVATE, ThreatState.TRIGGERED)  # allow
        gate.check(ActionType.SIREN_ACTIVATE, ThreatState.NONE)       # deny
        
        stats = gate.get_stats()
        
        assert stats["checks"] == 2
        assert stats["allowed"] == 1
        assert stats["denied"] == 1


class TestActionGateCallback:
    """回调测试"""
    
    def test_on_decision_callback(self):
        """测试决策回调"""
        gate = ActionGate()
        decisions = []
        gate.on_decision = lambda r: decisions.append(r)
        
        gate.check(ActionType.SIREN_ACTIVATE, ThreatState.TRIGGERED)
        
        assert len(decisions) == 1
        assert decisions[0].action == ActionType.SIREN_ACTIVATE


# =============================================================================
# Siren Policy Tests
# =============================================================================

class TestSirenPolicyBasic:
    """Siren Policy 基础测试"""
    
    def test_create_policy(self):
        """测试创建策略"""
        policy = SirenPolicy()
        
        assert policy.status.state == SirenState.OFF
        assert not policy.is_active
    
    def test_custom_config(self):
        """测试自定义配置"""
        config = SirenPolicyConfig(siren_delay_sec=60)
        policy = SirenPolicy(config)
        
        assert policy.config.siren_delay_sec == 60


class TestSirenPolicyActivation:
    """警报激活测试"""
    
    def test_request_activation(self):
        """测试请求激活（进入延迟）"""
        policy = SirenPolicy()
        
        status = policy.request_activation("test")
        
        assert status.state == SirenState.PENDING
        assert status.reason == "test"
    
    def test_immediate_activate(self):
        """测试立即激活"""
        policy = SirenPolicy()
        
        status = policy.activate("emergency")
        
        assert status.state == SirenState.ACTIVE
        assert policy.is_active
    
    def test_deactivate(self):
        """测试停止"""
        policy = SirenPolicy()
        policy.activate()
        
        status = policy.deactivate("user_cancel")
        
        assert status.state == SirenState.OFF
        assert not policy.is_active


class TestSirenPolicyTiming:
    """警报计时测试"""
    
    def test_pending_not_expired_immediately(self):
        """测试延迟未立即过期"""
        policy = SirenPolicy()
        policy.request_activation()
        
        assert not policy.check_pending_expired()
    
    def test_pending_expired_after_delay(self):
        """测试延迟过期"""
        config = SirenPolicyConfig(siren_delay_sec=30)
        policy = SirenPolicy(config)
        policy.request_activation()
        
        # 模拟时间过去
        policy._status.activated_at = datetime.now(timezone.utc) - timedelta(seconds=60)
        
        assert policy.check_pending_expired()
    
    def test_get_remaining_delay(self):
        """测试获取剩余延迟"""
        config = SirenPolicyConfig(siren_delay_sec=30)
        policy = SirenPolicy(config)
        policy.request_activation()
        
        remaining = policy.get_remaining_delay()
        
        assert 25 < remaining <= 30  # 允许一点误差
    
    def test_duration_expired(self):
        """测试持续时间过期"""
        policy = SirenPolicy()
        policy.activate()
        
        # 模拟时间过去
        policy._status.deactivate_at = datetime.now(timezone.utc) - timedelta(seconds=10)
        
        assert policy.check_duration_expired()


class TestSirenPolicyCallback:
    """警报回调测试"""
    
    def test_state_change_callback(self):
        """测试状态变化回调"""
        policy = SirenPolicy()
        changes = []
        policy.on_state_change = lambda old, new: changes.append((old, new))
        
        policy.request_activation()
        policy.activate()
        policy.deactivate()
        
        assert len(changes) == 3
        assert changes[0] == (SirenState.OFF, SirenState.PENDING)
        assert changes[1] == (SirenState.PENDING, SirenState.ACTIVE)
        assert changes[2] == (SirenState.ACTIVE, SirenState.OFF)
