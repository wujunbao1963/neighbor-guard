#!/usr/bin/env python3
"""
Tamper Detection 单元测试 (PRD §8.1)

测试 Zigbee 物理防拆检测
"""

import pytest
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "..", "src"))

from ng_edge.runtime.edge_runtime import EdgeRuntime, get_default_config


class TestZigbeeTamperDetection:
    """Zigbee 物理防拆检测测试"""
    
    def test_detect_tamper_from_payload(self):
        """测试从 Zigbee payload 检测 tamper"""
        config = get_default_config()
        runtime = EdgeRuntime(config)
        
        # 正常状态 - 没有 tamper
        payload_normal = {"contact": True, "tamper": False, "battery": 100}
        signal = runtime._detect_zigbee_signal_kind(payload_normal, "contact")
        assert signal == "door_close"
        
        # Tamper 触发
        payload_tamper = {"contact": True, "tamper": True, "battery": 100}
        signal = runtime._detect_zigbee_signal_kind(payload_tamper, "contact")
        assert signal == "tamper_s"
    
    def test_tamper_priority_over_contact(self):
        """测试 tamper 优先于 contact 状态"""
        config = get_default_config()
        runtime = EdgeRuntime(config)
        
        # 即使门是开的，tamper 也优先
        payload = {"contact": False, "tamper": True, "battery": 100}
        signal = runtime._detect_zigbee_signal_kind(payload, "contact")
        assert signal == "tamper_s"
    
    def test_tamper_with_motion_sensor(self):
        """测试 motion 传感器的 tamper"""
        config = get_default_config()
        runtime = EdgeRuntime(config)
        
        payload = {"occupancy": True, "tamper": True, "battery": 85}
        signal = runtime._detect_zigbee_signal_kind(payload, "motion")
        assert signal == "tamper_s"
    
    def test_no_false_positive_tamper(self):
        """测试没有误报 tamper"""
        config = get_default_config()
        runtime = EdgeRuntime(config)
        
        # tamper=False 不应该触发
        payload = {"contact": False, "tamper": False}
        signal = runtime._detect_zigbee_signal_kind(payload, "contact")
        assert signal == "door_open"
        
        # 没有 tamper 字段也不应该触发
        payload = {"contact": True}
        signal = runtime._detect_zigbee_signal_kind(payload, "contact")
        assert signal == "door_close"


class TestTamperCallback:
    """Tamper 回调测试"""
    
    def test_tamper_callback_exists(self):
        """测试 on_tamper_detected 回调存在"""
        config = get_default_config()
        runtime = EdgeRuntime(config)
        
        assert hasattr(runtime, "on_tamper_detected")
        assert runtime.on_tamper_detected is None  # 默认为 None
        
        # 可以设置回调
        tamper_events = []
        def on_tamper(device_id, ep_id, tamper_type):
            tamper_events.append((device_id, ep_id, tamper_type))
        
        runtime.on_tamper_detected = on_tamper
        assert runtime.on_tamper_detected is not None


class TestTamperTypes:
    """Tamper 类型测试"""
    
    def test_tamper_types_defined(self):
        """测试 Tamper 类型定义正确"""
        # 这些是代码中使用的 tamper_type 值
        expected_types = [
            "zigbee_physical",         # Zigbee 传感器被撬开
            "camera_offline",          # 摄像头离线 >= 90s
            "camera_blackout",         # 摄像头黑屏
            "camera_brightness_drop",  # 摄像头亮度骤降
        ]
        
        # 验证类型字符串格式
        for t in expected_types:
            assert isinstance(t, str)
            assert "_" in t or t.isalpha()  # 下划线分隔或纯字母


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
