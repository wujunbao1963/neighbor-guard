#!/usr/bin/env python3
"""
威慑逻辑模拟测试 - 不需要硬件

验证：
1. L1: 只开灯常亮，无声音
2. L2: 闪灯（5秒亮/5秒灭），无声音
3. TRIGGERED: 闪灯 + 连续警报

运行：
    python tests/test_deterrent_logic.py
"""

import asyncio
import time


class MockDeterrent:
    """模拟威慑控制器"""
    
    # 配置
    PRE_L1_SIREN_INTERVAL = 30   # L1: 每30秒警报
    PRE_L1_SIREN_DURATION = 1    # L1: 警报1秒
    PRE_L2_FLASH_ON = 5          # L2: 亮灯时间
    PRE_L2_FLASH_OFF = 5         # L2: 灭灯时间
    PRE_L2_SIREN_INTERVAL = 10   # L2: 每10秒警报
    PRE_L2_SIREN_DURATION = 2    # L2: 警报2秒
    TRIGGERED_FLASH = 4          # TRIGGERED: 闪灯间隔
    TRIGGERED_SIREN = 3          # TRIGGERED: 警报间隔
    TRIGGERED_SIREN_DURATION = 3 # TRIGGERED: 警报持续时间
    MAX_DURATION = 180
    
    def __init__(self):
        self._deterrent_active = False
        self._deterrent_level = None
        self._deterrent_task = None
        
        # 模拟状态
        self.light_state = False
        self.siren_state = False
        
        # 日志
        self.log = []
        
    def _log(self, msg: str):
        elapsed = getattr(self, '_start_time', 0)
        if elapsed:
            elapsed = time.time() - elapsed
        self.log.append(f"[{elapsed:6.2f}s] {msg}")
        print(self.log[-1])
    
    def start_deterrent(self, level: str):
        """启动威慑"""
        if self._deterrent_level == level and self._deterrent_active:
            self._log(f"⚠️ {level} 已在运行，跳过")
            return
        
        # 停止之前的
        if self._deterrent_active:
            self._log(f"切换 {self._deterrent_level} → {level}")
            self._deterrent_active = False
            if self._deterrent_task:
                self._deterrent_task.cancel()
        
        self._deterrent_active = True
        self._deterrent_level = level
        self._start_time = time.time()
        
        self._log(f"🚨 启动 {level} 威慑")
        
        # 启动任务
        self._deterrent_task = asyncio.create_task(self._deterrent_loop(level))
    
    def stop_deterrent(self):
        """停止威慑"""
        if not self._deterrent_active:
            return
        
        self._log(f"🛑 停止威慑")
        self._deterrent_active = False
        self._deterrent_level = None
        
        if self._deterrent_task:
            self._deterrent_task.cancel()
            self._deterrent_task = None
        
        # 关灯关声
        asyncio.create_task(self._set_light(False))
        asyncio.create_task(self._set_siren(False))
    
    async def _deterrent_loop(self, level: str):
        """威慑循环"""
        last_siren_time = -999
        
        try:
            if level == "L1":
                # L1: 常亮 + 每30秒警报
                self._log(f"💡 L1: 常亮灯 + 每{self.PRE_L1_SIREN_INTERVAL}s警报")
                asyncio.create_task(self._set_light(True))
                
                # 立即触发第一次警报（不等待）
                asyncio.create_task(self._trigger_siren(self.PRE_L1_SIREN_DURATION))
                last_siren_time = 0
                
                while self._deterrent_active:
                    elapsed = time.time() - self._start_time
                    elapsed_int = int(elapsed)
                    
                    # 警报逻辑
                    if elapsed_int % self.PRE_L1_SIREN_INTERVAL == 0 and elapsed_int != last_siren_time and elapsed_int > 0:
                        last_siren_time = elapsed_int
                        asyncio.create_task(self._trigger_siren(self.PRE_L1_SIREN_DURATION))
                    
                    await asyncio.sleep(1)
                    
            elif level == "L2":
                # L2: 闪灯 + 每10秒警报
                self._log(f"💡 L2: 闪灯 (亮{self.PRE_L2_FLASH_ON}s/灭{self.PRE_L2_FLASH_OFF}s) + 每{self.PRE_L2_SIREN_INTERVAL}s警报")
                
                # 立即触发第一次警报（不等待）
                asyncio.create_task(self._trigger_siren(self.PRE_L2_SIREN_DURATION))
                last_siren_time = 0
                light_on = False
                
                while self._deterrent_active:
                    elapsed = time.time() - self._start_time
                    elapsed_int = int(elapsed)
                    
                    # 闪灯逻辑：亮5秒/灭5秒周期
                    cycle_time = self.PRE_L2_FLASH_ON + self.PRE_L2_FLASH_OFF
                    pos_in_cycle = elapsed % cycle_time
                    should_be_on = pos_in_cycle < self.PRE_L2_FLASH_ON
                    
                    # 状态变化时才调用
                    if should_be_on != light_on:
                        light_on = should_be_on
                        asyncio.create_task(self._set_light(light_on))
                        self._log(f"💡 {'ON' if light_on else 'OFF'}")
                    
                    # 警报逻辑
                    if elapsed_int % self.PRE_L2_SIREN_INTERVAL == 0 and elapsed_int != last_siren_time and elapsed_int > 0:
                        last_siren_time = elapsed_int
                        asyncio.create_task(self._trigger_siren(self.PRE_L2_SIREN_DURATION))
                    
                    await asyncio.sleep(0.5)
                    
            elif level == "TRIGGERED":
                # TRIGGERED: 闪灯 + 连续警报
                self._log(f"🚨 TRIGGERED: 闪灯({self.TRIGGERED_FLASH}s) + 警报({self.TRIGGERED_SIREN}s间隔)")
                
                light_on = True
                last_light_change = 0
                
                # 立即开灯和警报（不等待）
                asyncio.create_task(self._set_light(True))
                asyncio.create_task(self._trigger_siren(self.TRIGGERED_SIREN_DURATION))
                last_siren_time = 0
                
                while self._deterrent_active:
                    elapsed = time.time() - self._start_time
                    
                    # 超时检查
                    if elapsed >= self.MAX_DURATION:
                        self._log(f"⏱️ 威慑超时")
                        break
                    
                    # 闪灯逻辑
                    if elapsed - last_light_change >= self.TRIGGERED_FLASH:
                        light_on = not light_on
                        last_light_change = elapsed
                        asyncio.create_task(self._set_light(light_on))
                        self._log(f"💡 {'ON' if light_on else 'OFF'}")
                    
                    # 警报逻辑
                    elapsed_int = int(elapsed)
                    if elapsed_int % self.TRIGGERED_SIREN == 0 and elapsed_int != last_siren_time and elapsed_int > 0:
                        last_siren_time = elapsed_int
                        asyncio.create_task(self._trigger_siren(self.TRIGGERED_SIREN_DURATION))
                    
                    await asyncio.sleep(0.5)
                    
        except asyncio.CancelledError:
            self._log("威慑循环已取消")
        finally:
            self._deterrent_active = False
    
    async def _set_light(self, state: bool):
        """设置灯光（模拟 API 延迟）"""
        # 模拟 API 延迟 50ms
        await asyncio.sleep(0.05)
        self.light_state = state
    
    async def _set_siren(self, state: bool):
        """设置警报"""
        await asyncio.sleep(0.05)
        self.siren_state = state
    
    async def _trigger_siren(self, duration: int):
        """触发警报（带持续时间）"""
        self._log(f"🔔 警报 (duration={duration}s)")
        await asyncio.sleep(0.05)


async def test_l1():
    """测试 L1: 常亮灯 + 每30秒警报"""
    print("\n" + "="*60)
    print("测试 L1: 常亮灯 + 每30秒警报")
    print("="*60)
    
    d = MockDeterrent()
    d.PRE_L1_SIREN_INTERVAL = 5  # 测试用缩短到5秒
    d.start_deterrent("L1")
    
    await asyncio.sleep(6)
    
    d.stop_deterrent()
    await asyncio.sleep(0.2)
    
    # 验证
    assert d.light_state == False, "停止后灯应该关闭"
    siren_count = len([l for l in d.log if "🔔" in l])
    assert siren_count >= 2, f"L1 应该有至少 2 次警报，实际 {siren_count}"
    
    print(f"\n统计: 警报={siren_count}")
    print("✅ L1 测试通过: 灯常亮 + 有警报")


async def test_l2():
    """测试 L2: 闪灯 + 每10秒警报"""
    print("\n" + "="*60)
    print("测试 L2: 闪灯 + 每10秒警报")
    print("="*60)
    
    d = MockDeterrent()
    d.PRE_L2_SIREN_INTERVAL = 5  # 测试用缩短到5秒
    d.start_deterrent("L2")
    
    # 等待一个完整周期
    await asyncio.sleep(12)
    
    d.stop_deterrent()
    await asyncio.sleep(0.2)
    
    # 验证：应该有至少 2 次 ON 和 1 次 OFF，以及警报
    on_count = len([l for l in d.log if "💡 ON" in l])
    off_count = len([l for l in d.log if "💡 OFF" in l])
    siren_count = len([l for l in d.log if "🔔" in l])
    
    print(f"\n统计: ON={on_count}, OFF={off_count}, 警报={siren_count}")
    
    assert on_count >= 2, f"L2 应该至少有 2 次 ON，实际 {on_count}"
    assert off_count >= 1, f"L2 应该至少有 1 次 OFF，实际 {off_count}"
    assert siren_count >= 2, f"L2 应该有至少 2 次警报，实际 {siren_count}"
    
    print("✅ L2 测试通过: 正确闪灯 + 有警报")


async def test_triggered():
    """测试 TRIGGERED: 闪灯 + 连续警报"""
    print("\n" + "="*60)
    print("测试 TRIGGERED: 闪灯 + 连续警报")
    print("="*60)
    
    d = MockDeterrent()
    d.start_deterrent("TRIGGERED")
    
    # 等待 10 秒
    await asyncio.sleep(10)
    
    d.stop_deterrent()
    await asyncio.sleep(0.2)
    
    # 验证
    light_changes = len([l for l in d.log if "💡 ON" in l or "💡 OFF" in l])
    siren_count = len([l for l in d.log if "🔔" in l])
    
    print(f"\n统计: 灯光切换={light_changes}, 警报={siren_count}")
    
    assert light_changes >= 2, f"TRIGGERED 应该有灯光切换，实际 {light_changes}"
    assert siren_count >= 3, f"TRIGGERED 应该有多次警报，实际 {siren_count}"
    
    print("✅ TRIGGERED 测试通过: 闪灯 + 连续警报")


async def test_level_switch():
    """测试级别切换: L1 → L2 → TRIGGERED"""
    print("\n" + "="*60)
    print("测试级别切换: L1 → L2 → TRIGGERED")
    print("="*60)
    
    d = MockDeterrent()
    
    print("\n1. 启动 L1")
    d.start_deterrent("L1")
    await asyncio.sleep(2)
    
    print("\n2. 切换到 L2")
    d.start_deterrent("L2")
    await asyncio.sleep(3)
    
    print("\n3. 切换到 TRIGGERED")
    d.start_deterrent("TRIGGERED")
    await asyncio.sleep(4)
    
    d.stop_deterrent()
    await asyncio.sleep(0.2)
    
    # 验证有切换日志（检查所有日志）
    all_logs = "\n".join(d.log)
    assert "切换" in all_logs or ("L1" in all_logs and "L2" in all_logs and "TRIGGERED" in all_logs), "应该有级别切换"
    
    print("\n✅ 级别切换测试通过")


async def test_level_upgrade_downgrade():
    """测试升降级: L1 → L2 → L1 → L2"""
    print("\n" + "="*60)
    print("测试升降级: L1 → L2 → L1 → L2")
    print("="*60)
    
    d = MockDeterrent()
    d.PRE_L2_SIREN_INTERVAL = 5  # 缩短测试时间
    
    print("\n1. 启动 L1 (常亮)")
    d.start_deterrent("L1")
    await asyncio.sleep(2)
    assert d.light_state == True, "L1 应该开灯"
    
    print("\n2. 升级到 L2 (闪灯)")
    d.start_deterrent("L2")
    await asyncio.sleep(3)
    
    print("\n3. 降级回 L1 (常亮)")
    d.start_deterrent("L1")
    await asyncio.sleep(2)
    
    print("\n4. 再升级到 L2")
    d.start_deterrent("L2")
    await asyncio.sleep(3)
    
    d.stop_deterrent()
    await asyncio.sleep(0.2)
    
    # 验证切换次数
    switch_count = len([l for l in d.log if "切换" in l])
    l1_count = len([l for l in d.log if "启动 L1" in l])
    l2_count = len([l for l in d.log if "启动 L2" in l])
    
    print(f"\n统计: 切换={switch_count}, L1启动={l1_count}, L2启动={l2_count}")
    
    assert l1_count >= 2, f"L1 应该启动至少 2 次，实际 {l1_count}"
    assert l2_count >= 2, f"L2 应该启动至少 2 次，实际 {l2_count}"
    
    print("✅ 升降级测试通过")


async def test_same_level_no_restart():
    """测试同级别不重复启动"""
    print("\n" + "="*60)
    print("测试同级别不重复启动")
    print("="*60)
    
    d = MockDeterrent()
    
    d.start_deterrent("L1")
    await asyncio.sleep(1)
    
    # 再次启动 L1
    d.start_deterrent("L1")
    await asyncio.sleep(1)
    
    d.stop_deterrent()
    await asyncio.sleep(0.2)
    
    # 验证只有一次启动
    start_logs = [l for l in d.log if "启动 L1" in l]
    skip_logs = [l for l in d.log if "已在运行" in l]
    
    assert len(start_logs) == 1, f"应该只有 1 次启动，实际 {len(start_logs)}"
    assert len(skip_logs) == 1, f"应该有 1 次跳过，实际 {len(skip_logs)}"
    
    print("\n✅ 同级别不重复启动测试通过")


async def main():
    print("="*60)
    print("威慑逻辑模拟测试")
    print("="*60)
    
    await test_l1()
    await test_l2()
    await test_triggered()
    await test_level_switch()
    await test_level_upgrade_downgrade()
    await test_same_level_no_restart()
    
    print("\n" + "="*60)
    print("✅ 所有测试通过!")
    print("="*60)


if __name__ == "__main__":
    asyncio.run(main())
