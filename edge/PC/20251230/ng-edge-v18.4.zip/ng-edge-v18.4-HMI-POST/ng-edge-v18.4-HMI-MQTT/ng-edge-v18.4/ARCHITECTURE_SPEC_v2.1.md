# NeighborGuard Edge Architecture Spec v2.1

> **Scope**: Edge-only design. Collaboration/circle workflows deferred.
> **Status**: Architecture-Frozen for Implementation
> **Changes from v2**: Added Sub-Phase, Rule Registry, Replay Contract, Edge/Cloud Contract

---

## 0. Design Principles

| # | Principle | Implication |
|---|-----------|-------------|
| P1 | **Signal ≠ Decision** | All detectors emit signals only. Only Incident State Machine may change state or execute actions. |
| P2 | **Single Incident per Lease** | For `(home, zone, entrypoint)`, at most one active incident within time window. |
| P3 | **Soft vs Hard Isolation** | Camera PRE (soft) cannot directly trigger PENDING/TRIGGERED unless explicitly allowed by policy. |
| P4 | **Edge Survivability** | Under resource pressure: sample/drop soft signals, never drop hard triggers. |
| P5 | **Idempotency Everywhere** | All processing must be idempotent on `signal_id`. At-least-once delivery assumed. |
| P6 | **Deterministic Replay** | Given same inputs, system must produce identical outputs. Enables testing and debugging. |
| P7 | **Rule Evolvability** | Transition rules can be updated without code deployment. |

---

## 1. Signal Layer

### 1.1 Signal Envelope (Unified)

All signals MUST conform to this envelope:

```
SignalEnvelope {
    # Identity
    signal_id: str              # Globally unique, idempotency key
    source_type: camera | sensor | health
    device_id: str
    
    # Spatial
    zone_id: str
    entrypoint_id: str?         # Optional but recommended
    
    # Classification
    signal_kind: str            # person_detected, door_open, glass_break, tamper, etc.
    hardness: soft | hard       # Determines processing priority
    level: PRE_L1 | PRE_L2 | PRE_L3 | null  # For soft signals
    confidence: float           # 0.0 - 1.0
    
    # Temporal
    timestamp: datetime         # Device-reported time
    ingest_ts: datetime         # Edge-received time (authoritative for ordering)
    
    # Payload
    attributes: {               # Signal-specific data
        bbox?, track_id?, direction?, contact_state?, battery?, etc.
    }
    evidence_hints: {           # Pointers, not content
        snapshot_key?, clip_pointer?, ring_buffer_offset?
    }
}
```

### 1.2 Hardness Classification (Fixed)

| Signal Kind | Hardness | Notes |
|-------------|----------|-------|
| person_detected | soft | Camera AI |
| vehicle_detected | soft | Camera AI |
| loitering | soft | Camera AI |
| motion_camera | soft | Camera motion |
| door_open | **hard** | Contact sensor |
| door_close | **hard** | Contact sensor |
| glass_break | **hard** | Acoustic/vibration sensor |
| motion_pir | **hard** | PIR sensor |
| tamper_s | soft | Suspected tamper (single source) |
| tamper_c | **hard** | Confirmed tamper (corroborated) |
| offline | soft | Device health |
| battery_low | soft | Device health |

### 1.3 Delivery Semantics

- Signal ingestion is **at-least-once**
- Downstream processing MUST be idempotent on `signal_id`
- Late/duplicate signals MAY append to incident but MUST NOT cause re-transition
- Hard signals MUST NOT be dropped under any circumstances

### 1.4 Time Policy

| Use Case | Timestamp | Rationale |
|----------|-----------|-----------|
| Ordering & Correlation | `ingest_ts` | Device clocks may drift |
| Evidence & Audit | Both | Full traceability |
| User Display | `timestamp` | Device-reported time |

---

## 2. Correlation Layer

### 2.1 Responsibilities (Allowed)

- Merge signals into IncidentCandidate
- Deduplicate by `signal_id`
- Group by `leaseKey`
- Attribute to zone/entrypoint/track
- Compute scoring hints (non-binding)

### 2.2 Non-Responsibilities (Forbidden)

| ❌ Forbidden | Reason |
|--------------|--------|
| Change ThreatState | Only State Machine |
| Change WorkflowState | Only State Machine |
| Emit notifications | Only Action Executor |
| Control siren/lights | Only Action Executor |
| Upload evidence | Only Evidence Manager |
| Call external services | Edge isolation |

### 2.3 Lease & Window Model

```
leaseKey = (home_id, zone_id, entrypoint_id)
```

| Window | Default | Purpose |
|--------|---------|---------|
| PRE aggregation | 30-90s | Group soft signals |
| Hard association | 10-30s | Correlate hard with soft |
| Incident active | 3-10min | Append vs new incident |

### 2.4 IncidentCandidate Structure

```
IncidentCandidate {
    candidate_id: str
    lease_key: str
    
    # Temporal
    window_start: datetime
    window_end: datetime
    last_signal_at: datetime
    
    # Signals
    signals: Signal[]           # All signals
    soft_count: int
    hard_count: int
    
    # Hints (non-binding)
    threat_hint: ThreatLevel
    confidence: float
    evidence_hints: str[]
    
    # Attribution
    zone_id: str
    entrypoint_id: str?
    track_ids: str[]            # For camera continuity
}
```

### 2.5 Split & Merge Rules

**SPLIT** incident when:
- `door_close` + silence > `split_silence_threshold` (default 60s)
- Track exits zone + silence > `track_decay_window` (default 30s)
- Explicit user action (resolve/close)

**MERGE** signals when:
- Same `leaseKey` + within `incident_active_window`
- Continuous track spans adjacent zones (driveway → front door)
- Same device + ROI continuity indicates single actor

**NEVER MERGE**:
- Signals from different `entrypoint_id` (unless track continuity proven)
- Signals separated by > `incident_active_window`

---

## 3. Incident State Machine

### 3.1 Orthogonal State Dimensions

```
┌─────────────────────────────────────────────────────────────┐
│  ThreatState (signal-driven, monotonic with decay)          │
│  NONE → PRE_L1 → PRE_L2 → PRE_L3 → PENDING → TRIGGERED     │
└─────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────┐
│  WorkflowState (action/user-driven)                         │
│  IDLE → NOTIFIED → VERIFYING → ESCALATED → RESOLVED → CLOSED│
└─────────────────────────────────────────────────────────────┘
```

**Key Rule**: ThreatState and WorkflowState are independent. PRE advancement does not force Workflow advancement.

### 3.2 Valid State Combinations

| ThreatState | Valid WorkflowStates |
|-------------|---------------------|
| NONE | IDLE, CLOSED |
| PRE_L1 | IDLE |
| PRE_L2 | IDLE, NOTIFIED |
| PRE_L3 | IDLE, NOTIFIED, VERIFYING |
| PENDING | NOTIFIED, VERIFYING |
| TRIGGERED | NOTIFIED, VERIFYING, ESCALATED, RESOLVED |

Invalid combinations MUST raise `InvalidStateError` and be logged.

### 3.3 Workflow Sub-Phases (NEW)

WorkflowState `ESCALATED` has sub-phases for finer control:

```
WorkflowSubPhase (for ESCALATED only) {
    SIREN_ACTIVE        # Siren currently sounding
    SIREN_TIMEOUT       # Siren auto-stopped after max duration
    AWAITING_RESPONSE   # Waiting for user/collaborator response
    DISPATCH_REQUESTED  # Emergency dispatch requested
    DISPATCH_CONFIRMED  # Dispatch acknowledged by provider
    DISPATCH_CANCELLED  # User cancelled dispatch
}
```

**Sub-Phase Transitions**:

```
ESCALATED entry → SIREN_ACTIVE (if siren enabled)
                → AWAITING_RESPONSE (if siren disabled)

SIREN_ACTIVE --[timeout]--> SIREN_TIMEOUT → AWAITING_RESPONSE
SIREN_ACTIVE --[user_silence]--> AWAITING_RESPONSE

AWAITING_RESPONSE --[user_dispatch]--> DISPATCH_REQUESTED
AWAITING_RESPONSE --[user_resolve]--> (exit to RESOLVED)

DISPATCH_REQUESTED --[provider_ack]--> DISPATCH_CONFIRMED
DISPATCH_REQUESTED --[user_cancel]--> DISPATCH_CANCELLED → AWAITING_RESPONSE
```

**Sub-Phase Data**:

```
EscalatedPhaseData {
    sub_phase: WorkflowSubPhase
    siren_started_at: datetime?
    siren_stopped_at: datetime?
    siren_stop_reason: timeout | user_silence | resolved
    dispatch_requested_at: datetime?
    dispatch_provider: str?
    dispatch_reference: str?
}
```

### 3.4 Threat Transition Rules

```
# Soft signals: max PRE_L3
soft_signal → max(current, hint) capped at PRE_L3

# Hard signals: can reach PENDING/TRIGGERED
door_open (entry_exit zone) → PENDING
door_open (interior zone) → TRIGGERED
glass_break → TRIGGERED
tamper_c → TRIGGERED (policy-gated)
motion_pir (armed_away) → TRIGGERED

# Mode-dependent (see §4)
```

### 3.5 Threat Decay Rules

PRE states decay after silence:

| From | To | Silence Window | Reason Code |
|------|----|----------------|-------------|
| PRE_L3 | PRE_L2 | 120s | DECAY_SILENCE_L3 |
| PRE_L2 | PRE_L1 | 180s | DECAY_SILENCE_L2 |
| PRE_L1 | NONE | 300s | DECAY_SILENCE_L1 |

Decay MUST emit TransitionRecord with `reason_code`.

PENDING/TRIGGERED do NOT auto-decay (require explicit action).

### 3.6 PENDING Cancellation Rules

| Condition | Result | Reason Code |
|-----------|--------|-------------|
| door_close within 3s of door_open | Cancel PENDING → NONE | QUICK_OPEN_CLOSE |
| Valid PIN entered on keypad | Cancel PENDING → NONE | USER_DISARM_PIN |
| User confirms "It's me" in app | Cancel PENDING → RESOLVED | USER_CONFIRM_SELF |
| Entry delay timeout | Escalate → TRIGGERED | ENTRY_DELAY_EXPIRED |

Cancellation NOT allowed for:
- `glass_break` triggered incidents
- `tamper_c` triggered incidents
- Already TRIGGERED state

### 3.7 Rule Registry (NEW)

All transition rules are defined in a registry that supports hot-reload and canary deployment.

```
RuleRegistry {
    # Rule storage
    rules: Map<rule_id, TransitionRule>
    
    # Version control
    version: str
    loaded_at: datetime
    source: file | remote | embedded
    
    # Canary deployment
    canary_enabled: bool
    canary_percentage: float        # 0.0 - 1.0
    canary_rules: Map<rule_id, TransitionRule>
    canary_selector: (incident) -> bool  # Deterministic selection
    
    # Methods
    reload(): RuleLoadResult
    get_rule(rule_id, incident): TransitionRule
    evaluate(incident, signal): TransitionResult
}

TransitionRule {
    rule_id: str                    # Unique identifier
    version: str                    # Rule version
    priority: int                   # Higher = evaluated first
    
    # Conditions
    conditions: {
        signal_kinds: str[]         # Matching signal types
        threat_states: ThreatState[] # Current state must be in list
        arming_states: str[]        # Mode conditions
        zone_types: str[]           # Zone conditions
        custom_predicate: str?      # Expression for complex logic
    }
    
    # Action
    action: {
        new_threat: ThreatState?
        new_workflow: WorkflowState?
        reason_code: str
    }
    
    # Metadata
    enabled: bool
    created_at: datetime
    description: str
}
```

**Rule Evaluation Order**:
1. Sort rules by priority (descending)
2. For each rule, check if conditions match
3. First matching rule wins
4. If canary enabled and incident selected, use canary rules instead

**Hot Reload**:
```
POST /api/rules/reload
  → validates new rules
  → atomic swap
  → emits RuleReloadEvent
```

**Canary Selection** (deterministic):
```python
def is_canary(incident_id: str, percentage: float) -> bool:
    # Hash-based selection ensures same incident always gets same result
    hash_value = hash(incident_id) % 100
    return hash_value < (percentage * 100)
```

### 3.8 Transition Recording (Mandatory)

Every state change MUST emit:

```
TransitionRecord {
    record_id: str
    timestamp: datetime
    incident_id: str
    
    dimension: "threat" | "workflow" | "sub_phase"
    from_state: str
    to_state: str
    
    rule_id: str                # Which rule triggered
    rule_version: str           # Rule version used
    is_canary: bool             # Was canary rule used?
    reason_code: str            # Human-readable reason
    
    trigger_signal_ids: str[]   # Max 10, most recent
    trigger_signal_summary: {   # Key fields only
        signal_kind, device_id, confidence
    }
    
    context: {
        arming_state, house_mode, zone_id, entrypoint_id
    }
}
```

---

## 4. Mode Policy

### 4.1 Mode Inputs

```
ModeContext {
    arming_state: disarmed | armed_stay | armed_away
    house_mode: home | away | night | vacation
    entry_delay_sec: int        # Default 30
    exit_delay_sec: int         # Default 60
    bypass_zones: str[]         # Zones to ignore
}
```

### 4.2 Threat Transition Matrix

| Arming State | Signal Kind | Zone Type | → ThreatState |
|--------------|-------------|-----------|---------------|
| **disarmed** | any | any | NONE (log only) |
| **armed_stay** | door_open | entry_exit | PENDING |
| **armed_stay** | door_open | interior | NONE |
| **armed_stay** | motion_pir | interior | NONE |
| **armed_stay** | motion_pir | perimeter | PRE_L2 |
| **armed_stay** | glass_break | any | TRIGGERED |
| **armed_away** | door_open | entry_exit | PENDING |
| **armed_away** | door_open | interior | TRIGGERED |
| **armed_away** | motion_pir | any | TRIGGERED |
| **armed_away** | glass_break | any | TRIGGERED |

### 4.3 Bypass Handling

- Signals from `bypass_zones` are logged but do not advance ThreatState
- Bypass status MUST be recorded in TransitionRecord

---

## 5. Action Gate

### 5.1 Action Permission Matrix

| ThreatState | Permitted Actions |
|-------------|-------------------|
| NONE | (none) |
| PRE_L1 | log, cache_evidence_pointer |
| PRE_L2 | log, cache_evidence_pointer, notify_light, spotlight_on, live_view_hint |
| PRE_L3 | log, cache_evidence_pointer, notify_strong, spotlight_on, live_view_hint, pull_minimal_clip, beep_warning |
| PENDING | log, notify_urgent, spotlight_on, keypad_countdown, prepare_siren, pull_evidence_packet |
| TRIGGERED | log, notify_alarm, siren_on, spotlight_on, pull_full_evidence, collaboration_alert, dispatch_ready |

### 5.2 Sub-Phase Action Permissions (NEW)

| Sub-Phase | Additional Actions |
|-----------|-------------------|
| SIREN_ACTIVE | siren_off (user), siren_timeout (system) |
| AWAITING_RESPONSE | request_dispatch, resolve, escalate_collaborator |
| DISPATCH_REQUESTED | cancel_dispatch, dispatch_update |
| DISPATCH_CONFIRMED | (read-only until resolved) |

### 5.3 PRE Notification Suppression

When ThreatState reaches PENDING or TRIGGERED:
- PRE-level notifications (`notify_light`, `notify_strong`) are **suppressed**
- PRE signals continue to append to incident (for evidence)
- Only PENDING/TRIGGERED notifications are sent

### 5.4 Action Authorization Check

```
def is_authorized(threat: ThreatState, workflow: WorkflowState, 
                  sub_phase: SubPhase?, action: str) -> bool:
    base_allowed = action in ACTION_PERMISSIONS[threat]
    phase_allowed = sub_phase is None or action in SUBPHASE_PERMISSIONS[sub_phase]
    return base_allowed and phase_allowed
```

Unauthorized action attempts MUST be logged with `reason=UNAUTHORIZED`.

---

## 6. Action Execution Contract

### 6.1 Action Definition

```
ActionSpec {
    action_id: str              # Idempotency key
    action_type: str            # siren_on, notify_alarm, etc.
    target_device: str?         # Device ID if applicable
    
    # Execution control
    preconditions: Condition[]  # Must all pass
    retry_policy: {
        max_attempts: int       # Default 3
        backoff_ms: int         # Default 1000
    }
    cooldown_sec: int           # Min time between executions
    timeout_sec: int            # Execution timeout
    
    # Failure handling
    fallback_action: str?       # Alternative if fails
    failure_blocks_state: bool  # Default false
}
```

### 6.2 Execution Rules

- Action failures MUST NOT block state progression (unless `failure_blocks_state=true`)
- Failed actions emit `ActionFailureRecord` with error details
- Cooldown prevents spam (e.g., siren cannot retrigger within 5s)

### 6.3 Standard Action Specs

| Action | Cooldown | Timeout | Retry | Fallback |
|--------|----------|---------|-------|----------|
| siren_on | 5s | 10s | 3 | spotlight_on |
| siren_off | 1s | 5s | 3 | (none) |
| spotlight_on | 1s | 5s | 3 | (none) |
| notify_alarm | 0s | 30s | 5 | (none) |
| pull_evidence_packet | 60s | 120s | 2 | pull_minimal_clip |
| request_dispatch | 0s | 60s | 3 | notify_alarm |

---

## 7. Evidence Policy

### 7.1 Evidence Levels

| ThreatState | Evidence Mode | Retention |
|-------------|---------------|-----------|
| PRE_L1/L2 | Ring buffer pointers only | 1 hour |
| PRE_L3 | Snapshots + short clips (low bitrate) | 24 hours |
| PENDING | Prepare packet (pre-buffer 30s) | 7 days |
| TRIGGERED | Full packet (multi-camera, ±120s) | 30 days |

### 7.2 Evidence Packet Contents (TRIGGERED)

```
EvidencePacket {
    incident_id: str
    
    # Video
    clips: [{
        camera_id, start_ts, end_ts, resolution, url
    }]
    pre_buffer_sec: 60
    post_buffer_sec: 120
    
    # Signals
    signal_sequence: Signal[]   # All signals in incident
    
    # Health
    device_heartbeats: [{
        device_id, last_seen, battery, connectivity
    }]
    
    # Metadata
    created_at: datetime
    total_size_bytes: int
}
```

### 7.3 Privacy & Storage

- Evidence defaults to **local-only** on Edge
- Cloud upload requires explicit user consent or TRIGGERED state
- PRE evidence auto-expires; TRIGGERED evidence requires manual deletion

---

## 8. Noise Control & Backpressure

### 8.1 Signal Sampling (Soft Only)

Under resource pressure:
- PRE_L1 signals: sample 1-in-N (N configurable)
- PRE_L2/L3 signals: sample 1-in-2 max
- Hard signals: **NEVER sample or drop**

### 8.2 Notification Cooldowns

| ThreatState | Cooldown | Notes |
|-------------|----------|-------|
| PRE_L1 | 600s (10min) | Or skip entirely |
| PRE_L2 | 300s (5min) | |
| PRE_L3 | 60s (1min) | |
| PENDING | 0s | Always notify |
| TRIGGERED | 0s | Always notify |

### 8.3 Sensor Debounce

| Signal Kind | Debounce Window |
|-------------|-----------------|
| door_open/close | 5s |
| motion_pir | 15s |
| glass_break | 0s (never debounce) |

Debounced signals are **counted** but do not trigger re-transition.

### 8.4 Backpressure Response

When Edge resources critical:
1. Increase soft signal sampling rate
2. Reduce PRE evidence retention
3. Downshift PRE_L3 → PRE_L2 processing
4. **Never** affect hard signal processing

---

## 9. Health & Reliability Signals

### 9.1 Health Signal Types

| Signal | Source | Typical Interval |
|--------|--------|------------------|
| camera_heartbeat | Camera | 30s |
| rtsp_availability | Edge monitor | 10s |
| battery_level | Sensor | 1h |
| connectivity | Edge monitor | 60s |
| device_offline | Edge monitor | On change |

### 9.2 Health → Threat Policy

**Default**: Health degradation affects available actions, NOT threat level.

| Health Signal | Effect |
|---------------|--------|
| camera_offline | Disable live_view for that camera |
| low_battery | Log warning, no threat change |
| connectivity_loss | Queue notifications for retry |

**Exception - Tamper-C**:

Tamper-C is **computed by Correlation**, not a raw signal:

```
tamper_c = (
    dual_camera_offline >= 90s
    AND (door_open OR glass_break) within 10s
) OR (
    single_camera_offline
    AND second_camera_detects_obstruction
)
```

Tamper-C MAY escalate to TRIGGERED (policy-gated, default OFF).

### 9.3 Tamper-C Policy

```
TamperCPolicy {
    enabled: bool               # Default false
    require_hard_correlation: bool  # Default true
    escalate_to: TRIGGERED | PRE_L3  # Default PRE_L3
    reason_code: "TAMPER_C_ESCALATION"
}
```

---

## 10. Metrics & Observability

### 10.1 Required Metrics

| Metric | Type | Labels |
|--------|------|--------|
| `signal_ingested_total` | Counter | source_type, signal_kind, hardness |
| `signal_dropped_total` | Counter | source_type, reason |
| `incident_created_total` | Counter | zone_id |
| `incident_by_threat` | Gauge | threat_state |
| `incident_by_subphase` | Gauge | sub_phase |
| `transition_total` | Counter | dimension, from_state, to_state, rule_id |
| `transition_canary_total` | Counter | rule_id, is_canary |
| `action_executed_total` | Counter | action_type, success |
| `action_latency_ms` | Histogram | action_type |
| `signal_to_notify_latency_ms` | Histogram | threat_state |
| `rule_evaluation_ms` | Histogram | rule_id |

### 10.2 Alerting Thresholds

| Condition | Alert |
|-----------|-------|
| Hard signal drop | CRITICAL |
| Action failure rate > 10% | WARNING |
| Signal-to-notify latency > 5s | WARNING |
| Incident backlog > 100 | WARNING |
| Rule evaluation > 100ms | WARNING |
| Canary error rate > baseline | WARNING |

---

## 11. Incident Replay Contract (NEW)

### 11.1 Purpose

The Replay Contract enables:
- Reproducing production incidents for debugging
- Regression testing rule changes
- Stress testing with synthetic data
- Compliance auditing

### 11.2 Replay Input

```
ReplayInput {
    # Scenario identification
    replay_id: str
    description: str?
    
    # Signal sequence (ordered by ingest_ts)
    signals: Signal[]
    
    # Initial state
    initial_state: {
        mode_context: ModeContext
        active_incidents: Incident[]  # Usually empty
        device_states: DeviceState[]
    }
    
    # Configuration snapshot
    config: Config
    rules: RuleRegistry             # Specific rule version
    
    # Time control
    time_mode: realtime | accelerated | instant
    acceleration_factor: float?     # For accelerated mode
}
```

### 11.3 Replay Output

```
ReplayOutput {
    replay_id: str
    
    # Results
    incidents: Incident[]           # Final incident states
    transitions: TransitionRecord[] # All state changes
    actions_authorized: Action[]    # Actions that would execute
    actions_executed: Action[]      # Actions actually executed (if live mode)
    
    # Metrics
    signals_processed: int
    signals_deduplicated: int
    incidents_created: int
    incidents_merged: int
    total_transitions: int
    
    # Timing
    replay_started_at: datetime
    replay_completed_at: datetime
    simulated_duration: duration
    wall_clock_duration: duration
    
    # Validation
    errors: ReplayError[]
    warnings: ReplayWarning[]
}
```

### 11.4 Replay Constraints (MUST enforce)

| Constraint | Description |
|------------|-------------|
| **Deterministic** | Same input MUST produce identical output |
| **Side-effect-free** | No real notifications, siren, uploads (unless live mode) |
| **Time-isolated** | Uses simulated clock, not system clock |
| **Config-frozen** | Rules and config cannot change during replay |

### 11.5 Replay Modes

| Mode | Actions Executed | Real Time | Use Case |
|------|------------------|-----------|----------|
| `dry_run` | None | No | Testing, debugging |
| `shadow` | Logged only | No | Canary validation |
| `live` | Yes | Yes | Production replay |

### 11.6 Replay API

```
# Start replay
POST /api/replay
Body: ReplayInput
Response: { replay_id, status: "running" }

# Get status
GET /api/replay/{replay_id}
Response: { status: "running" | "completed" | "failed", progress: float }

# Get results
GET /api/replay/{replay_id}/results
Response: ReplayOutput

# Compare two replays (for regression testing)
POST /api/replay/compare
Body: { replay_id_a, replay_id_b }
Response: ReplayDiff
```

### 11.7 Replay Diff (for regression testing)

```
ReplayDiff {
    replay_id_a: str
    replay_id_b: str
    
    # Differences
    incident_diffs: [{
        incident_id: str
        field: str
        value_a: any
        value_b: any
    }]
    
    transition_diffs: [{
        index: int
        diff_type: "added" | "removed" | "changed"
        transition_a: TransitionRecord?
        transition_b: TransitionRecord?
    }]
    
    action_diffs: [{
        action_id: str
        diff_type: "added" | "removed" | "changed"
        action_a: Action?
        action_b: Action?
    }]
    
    # Summary
    is_identical: bool
    diff_count: int
    severity: "none" | "minor" | "major" | "critical"
}
```

### 11.8 Test Case Format

```yaml
# test_cases/door_breach_away_mode.yaml
name: "Door breach in away mode"
description: "Front door opens while armed away, no disarm within 30s"

input:
  initial_state:
    mode_context:
      arming_state: armed_away
      house_mode: away
      entry_delay_sec: 30
  
  signals:
    - signal_id: "sig_001"
      signal_kind: door_open
      hardness: hard
      zone_id: "front_door"
      entrypoint_id: "ep_front"
      ingest_ts: "2024-01-01T10:00:00Z"
    
    # No disarm signal - timeout should trigger
    - signal_id: "sig_002"
      signal_kind: _timeout
      timeout_type: entry_delay
      ingest_ts: "2024-01-01T10:00:30Z"

expected:
  incidents:
    - threat_state: TRIGGERED
      workflow_state: NOTIFIED
      
  transitions:
    - from_state: NONE
      to_state: PENDING
      reason_code: DOOR_OPEN_ENTRY_EXIT
      
    - from_state: PENDING
      to_state: TRIGGERED
      reason_code: ENTRY_DELAY_EXPIRED
  
  actions_authorized:
    - notify_urgent
    - notify_alarm
    - siren_on
```

---

## 12. Edge / Cloud Contract (NEW)

### 12.1 Overview

Edge and Cloud communicate through well-defined contracts. Edge is authoritative for security decisions; Cloud provides persistence, analytics, and user interface.

```
┌─────────────────┐                    ┌─────────────────┐
│                 │  Event Report      │                 │
│                 │ ─────────────────► │                 │
│                 │  Evidence Upload   │                 │
│      EDGE       │ ─────────────────► │     CLOUD       │
│                 │                    │                 │
│                 │  Config Push       │                 │
│                 │ ◄───────────────── │                 │
│                 │  Remote Command    │                 │
│                 │ ◄───────────────── │                 │
└─────────────────┘                    └─────────────────┘
```

### 12.2 Edge → Cloud: Event Report

```
EventReport {
    # Identity
    report_id: str
    edge_id: str
    home_id: str
    
    # Incident summary
    incident_id: str
    threat_state: ThreatState
    workflow_state: WorkflowState
    sub_phase: WorkflowSubPhase?
    
    # Timeline
    incident_started_at: datetime
    last_transition_at: datetime
    reported_at: datetime
    
    # Signals summary (not full signals)
    signal_count: int
    hard_signal_count: int
    signal_kinds: str[]
    
    # Location
    zone_id: str
    entrypoint_id: str?
    
    # Evidence availability
    evidence_available: bool
    evidence_size_bytes: int?
    
    # Transitions summary
    transition_count: int
    key_transitions: TransitionRecord[]  # Max 5 most important
}
```

**Delivery**:
```
POST /api/v1/events
Headers:
  X-Edge-ID: {edge_id}
  X-Idempotency-Key: {report_id}
  Authorization: Bearer {token}
Body: EventReport

Response:
  200 OK: { received: true, event_id: str }
  409 Conflict: { duplicate: true }  # Idempotency
  
Retry: Exponential backoff, max 5 attempts
Queue: Store-and-forward if offline
```

### 12.3 Edge → Cloud: Evidence Upload

```
EvidenceUploadRequest {
    incident_id: str
    evidence_type: "packet" | "clip" | "snapshot"
    
    # For chunked upload
    chunk_index: int
    total_chunks: int
    chunk_data: bytes
    chunk_hash: str             # SHA-256
    
    # Metadata
    total_size_bytes: int
    content_type: str
    created_at: datetime
}
```

**Delivery**:
```
# Initiate upload
POST /api/v1/evidence/upload/init
Body: { incident_id, evidence_type, total_size_bytes, total_chunks }
Response: { upload_id, chunk_urls: str[] }

# Upload chunks (direct to storage)
PUT {chunk_url}
Body: chunk_data
Headers: X-Chunk-Hash: {hash}

# Complete upload
POST /api/v1/evidence/upload/complete
Body: { upload_id, chunk_hashes: str[] }
Response: { evidence_id, url }
```

**Rules**:
- Evidence upload only for PENDING/TRIGGERED incidents
- PRE evidence stays local unless user explicitly requests
- Chunked upload for reliability
- Resume capability for interrupted uploads

### 12.4 Cloud → Edge: Config Push

```
ConfigUpdate {
    update_id: str
    timestamp: datetime
    
    # What changed
    changes: [{
        path: str               # e.g., "correlation.incident_active_window_sec"
        old_value: any
        new_value: any
    }]
    
    # Full config (optional, for full sync)
    full_config: Config?
    
    # Rule updates
    rule_updates: [{
        rule_id: str
        action: "add" | "update" | "delete"
        rule: TransitionRule?
    }]
    
    # Acknowledgment requirement
    require_ack: bool
    ack_timeout_sec: int
}
```

**Delivery**:
```
# Option A: Webhook (Edge exposes endpoint)
POST https://{edge_address}/api/config/update
Body: ConfigUpdate
Response: { ack: true, applied_at: datetime }

# Option B: Polling (Edge pulls)
GET /api/v1/config/updates?since={last_update_id}
Response: { updates: ConfigUpdate[] }

# Option C: WebSocket (persistent connection)
WS /api/v1/edge/ws
Message: { type: "config_update", payload: ConfigUpdate }
```

**Rules**:
- Config changes are atomic (all or nothing)
- Edge validates config before applying
- Invalid config is rejected with error details
- Acknowledgment confirms successful apply

### 12.5 Cloud → Edge: Remote Command

```
RemoteCommand {
    command_id: str
    timestamp: datetime
    
    # Command type
    command_type: "disarm" | "arm_stay" | "arm_away" | 
                  "siren_off" | "panic" | "refresh_config"
    
    # Parameters
    params: {
        pin: str?               # For disarm
        zone_id: str?           # For zone-specific commands
        incident_id: str?       # For incident-specific commands
    }
    
    # Authorization
    user_id: str
    auth_method: "pin" | "biometric" | "trusted_device"
    
    # Execution control
    expires_at: datetime        # Command expires if not executed
    require_ack: bool
}
```

**Delivery**:
```
# Via WebSocket (preferred for low latency)
WS /api/v1/edge/ws
Message: { type: "command", payload: RemoteCommand }
Response: { type: "command_ack", command_id, status, result }

# Via webhook (fallback)
POST https://{edge_address}/api/command
Body: RemoteCommand
Response: { status: "executed" | "rejected", result }
```

**Security Rules**:
- All commands require valid authentication
- `disarm` requires PIN or biometric
- Commands have expiration (default 60s)
- Edge validates auth independently (not just trust Cloud)
- Failed auth attempts are logged and rate-limited

### 12.6 Offline Behavior

| Scenario | Edge Behavior | Sync on Reconnect |
|----------|---------------|-------------------|
| Cloud unreachable | Continue all local operations | Queue EventReports |
| Event queue full | Drop oldest PRE events, keep TRIGGERED | Sync TRIGGERED first |
| Config push missed | Use last known config | Pull latest config |
| Command while offline | Not received | Command expires |

### 12.7 Edge/Cloud Contract Versioning

```
ContractVersion {
    edge_version: str           # e.g., "2.1.0"
    cloud_version: str          # e.g., "2.1.0"
    
    # Compatibility
    min_compatible_edge: str    # Minimum Edge version Cloud supports
    min_compatible_cloud: str   # Minimum Cloud version Edge supports
    
    # Feature flags
    features: {
        chunked_upload: bool
        websocket_commands: bool
        rule_hot_reload: bool
    }
}
```

Negotiation on connection:
```
# Edge sends capabilities
{ edge_version: "2.1.0", features: [...] }

# Cloud responds with negotiated contract
{ contract_version: "2.1", features_enabled: [...] }
```

---

## 13. Configuration Defaults

```yaml
correlation:
  pre_aggregation_window_sec: 60
  hard_association_window_sec: 30
  incident_active_window_sec: 300
  split_silence_threshold_sec: 60
  track_decay_window_sec: 30

state_machine:
  entry_delay_sec: 30
  exit_delay_sec: 60
  quick_open_close_window_sec: 3
  
  decay:
    pre_l3_silence_sec: 120
    pre_l2_silence_sec: 180
    pre_l1_silence_sec: 300
  
  sub_phase:
    siren_max_duration_sec: 180
    dispatch_timeout_sec: 300

rules:
  registry_source: file         # file | remote | embedded
  registry_path: /etc/ng-edge/rules.yaml
  canary_enabled: false
  canary_percentage: 0.0
  hot_reload_enabled: true
  reload_check_interval_sec: 60

action:
  siren_max_duration_sec: 180
  siren_cooldown_sec: 5
  notify_retry_max: 5

evidence:
  pre_retention_hours: 24
  triggered_retention_days: 30
  pre_buffer_sec: 60
  post_buffer_sec: 120

noise:
  pre_l1_notify_cooldown_sec: 600
  pre_l2_notify_cooldown_sec: 300
  pre_l3_notify_cooldown_sec: 60
  door_debounce_sec: 5
  motion_debounce_sec: 15

health:
  camera_heartbeat_interval_sec: 30
  offline_threshold_sec: 90
  tamper_c_enabled: false
  tamper_c_escalate_to: PRE_L3

backpressure:
  soft_sample_rate_normal: 1.0
  soft_sample_rate_pressure: 0.5
  hard_sample_rate: 1.0         # Never change

replay:
  enabled: true
  max_concurrent: 3
  result_retention_hours: 24

cloud:
  event_report_endpoint: https://api.neighborguard.com/v1/events
  evidence_upload_endpoint: https://api.neighborguard.com/v1/evidence
  config_poll_interval_sec: 300
  websocket_enabled: true
  websocket_endpoint: wss://api.neighborguard.com/v1/edge/ws
  offline_queue_max_size: 1000
```

---

## 14. Explicit Deferrals

The following are **intentionally deferred** to later specs:

| Topic | Reason | Hook Preserved |
|-------|--------|----------------|
| Collaboration / circle workflows | Multi-party complexity | `collaboration_hint` field |
| Cross-house correlation | Privacy & scale | `home_id` in all records |
| Cloud-side learning | Requires data pipeline | Metrics emission |
| PTZ camera presets | Hardware-specific | `device_capabilities` |
| Voice announcements | UX design pending | `announcement_hint` field |
| Geofencing auto-arm | Mobile app dependency | `arming_trigger` field |

---

## 15. Implementation Checklist

| # | Component | Status | Notes |
|---|-----------|--------|-------|
| 1 | Signal Envelope validation | ⬜ | Schema enforcement |
| 2 | Correlation Layer | ⬜ | Pure logic, testable |
| 3 | Lease Manager | ⬜ | Zone-level isolation |
| 4 | State Machine (dual dimension) | ⬜ | Refactor from v5 |
| 5 | Sub-Phase handling | ⬜ | ESCALATED sub-states |
| 6 | Rule Registry | ⬜ | Hot-reload support |
| 7 | Transition Recording | ⬜ | Every state change |
| 8 | Action Gate | ⬜ | Permission matrix |
| 9 | Action Executor | ⬜ | With retry/cooldown |
| 10 | Evidence Manager | ⬜ | Level-based policy |
| 11 | Noise Policy | ⬜ | Debounce + cooldown |
| 12 | Health Monitor | ⬜ | Including Tamper-C |
| 13 | Replay Engine | ⬜ | Deterministic replay |
| 14 | Replay API | ⬜ | REST endpoints |
| 15 | Cloud Client | ⬜ | Event report, evidence |
| 16 | Command Handler | ⬜ | Remote commands |
| 17 | Metrics emission | ⬜ | Prometheus format |
| 18 | Config loader | ⬜ | YAML with defaults |

---

## 16. Migration Path from v18.x

| Current Component | Target Component | Change Type |
|-------------------|------------------|-------------|
| `state_machine_v5.py` | `incident_state_machine.py` | Refactor (dual dimension + sub-phase) |
| (none) | `rule_registry.py` | New |
| `zigbee_signal_router.py` | `signal_layer/sensor_source.py` | Rename + envelope |
| `camera_signal_source.py` | `signal_layer/camera_source.py` | Rename + envelope |
| (none) | `correlation/correlator.py` | New |
| (none) | `correlation/lease_manager.py` | New |
| `manager.py._trigger_*` | `action/action_gate.py` | Extract |
| `manager.py._trigger_*` | `action/action_executor.py` | Extract |
| (none) | `evidence/evidence_manager.py` | New |
| (none) | `health/health_monitor.py` | New |
| (none) | `noise/noise_policy.py` | New |
| (none) | `replay/replay_engine.py` | New |
| (none) | `cloud/cloud_client.py` | New |
| (none) | `cloud/command_handler.py` | New |

---

*End of Architecture Spec v2.1*
