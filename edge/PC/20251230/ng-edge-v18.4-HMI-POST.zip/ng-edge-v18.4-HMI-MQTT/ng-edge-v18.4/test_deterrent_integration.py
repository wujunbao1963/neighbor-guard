#!/usr/bin/env python3
"""
测试 DeterrentSystem 与 EdgeRuntime 的集成

验证所有威慑触发路径：
1. PRE 检测 (report_sensor)
2. TRIGGERED (set_triggered)
3. 撤防 (force_stop)
4. Entry Delay 超时 (_activate_alarm)
"""

import asyncio
import sys
sys.path.insert(0, 'src')

from ng_edge.runtime.deterrent_system import DeterrentSystem
from ng_edge.runtime.edge_runtime import EdgeRuntime, EdgeRuntimeConfig
from ng_edge.services.state_machine_v5 import HouseMode, UserMode


# Mock 回调
spotlight_calls = []
siren_calls = []


async def mock_spotlight(on: bool):
    spotlight_calls.append(("spotlight", on))
    print(f"  💡 Spotlight: {'ON' if on else 'OFF'}")


async def mock_siren(duration: float):
    siren_calls.append(("siren", duration))
    print(f"  🔔 Siren: {duration}s")


async def test_deterrent_system_standalone():
    """测试1: DeterrentSystem 独立测试"""
    print("\n" + "="*60)
    print("测试1: DeterrentSystem 独立测试")
    print("="*60)
    
    spotlight_calls.clear()
    siren_calls.clear()
    
    system = DeterrentSystem(
        on_spotlight=mock_spotlight,
        on_siren=mock_siren,
    )
    
    await system.start()
    
    # 模拟摄像头检测 L2
    print("\n[1] 报告 L2 检测...")
    system.report_sensor("cam_front", 2)
    await asyncio.sleep(1.5)  # 等待去抖确认
    
    state = system.get_state()
    print(f"  状态: confirmed={state['confirmed']}")
    
    # 模拟人离开
    print("\n[2] 报告人离开...")
    system.report_sensor("cam_front", 0)
    await asyncio.sleep(4)  # 等待超时 + 去抖
    
    state = system.get_state()
    print(f"  状态: confirmed={state['confirmed']}")
    
    # 测试 TRIGGERED
    print("\n[3] 设置 TRIGGERED...")
    system.set_triggered(True)
    await asyncio.sleep(1.5)
    
    state = system.get_state()
    print(f"  状态: confirmed={state['confirmed']}")
    
    # 测试 force_stop
    print("\n[4] 强制停止...")
    system.force_stop()
    await asyncio.sleep(1)
    
    state = system.get_state()
    print(f"  状态: confirmed={state['confirmed']}")
    
    await system.stop()
    
    # 验证
    has_spotlight = any(c[0] == "spotlight" for c in spotlight_calls)
    has_siren = any(c[0] == "siren" for c in siren_calls)
    
    print(f"\n结果: spotlight调用={len([c for c in spotlight_calls if c[1]])} siren调用={len(siren_calls)}")
    
    if has_spotlight and has_siren:
        print("✅ 通过")
        return True
    else:
        print("❌ 失败")
        return False


async def test_edge_runtime_deterrent_methods():
    """测试2: EdgeRuntime 威慑方法存在性测试"""
    print("\n" + "="*60)
    print("测试2: EdgeRuntime 威慑方法存在性测试")
    print("="*60)
    
    config = EdgeRuntimeConfig(
        cameras={},  # 无摄像头
        zigbee_devices={},  # 无 Zigbee
        house_mode=HouseMode.AWAY,
    )
    
    runtime = EdgeRuntime(config)
    
    # 检查 deterrent_system 存在
    has_deterrent_system = hasattr(runtime, 'deterrent_system')
    print(f"  has deterrent_system: {has_deterrent_system}")
    
    # 检查关键方法
    has_report_sensor = hasattr(runtime.deterrent_system, 'report_sensor')
    has_set_triggered = hasattr(runtime.deterrent_system, 'set_triggered')
    has_force_stop = hasattr(runtime.deterrent_system, 'force_stop')
    has_start = hasattr(runtime.deterrent_system, 'start')
    has_stop = hasattr(runtime.deterrent_system, 'stop')
    
    print(f"  has report_sensor: {has_report_sensor}")
    print(f"  has set_triggered: {has_set_triggered}")
    print(f"  has force_stop: {has_force_stop}")
    print(f"  has start: {has_start}")
    print(f"  has stop: {has_stop}")
    
    # 检查旧方法不存在
    no_old_start = not hasattr(runtime, '_start_deterrent')
    no_old_stop = not hasattr(runtime, '_stop_deterrent')
    no_old_loop = not hasattr(runtime, '_deterrent_loop')
    no_old_active = not hasattr(runtime, '_deterrent_active')
    
    print(f"  no _start_deterrent: {no_old_start}")
    print(f"  no _stop_deterrent: {no_old_stop}")
    print(f"  no _deterrent_loop: {no_old_loop}")
    print(f"  no _deterrent_active: {no_old_active}")
    
    all_ok = all([
        has_deterrent_system,
        has_report_sensor,
        has_set_triggered,
        has_force_stop,
        has_start,
        has_stop,
        no_old_start,
        no_old_stop,
        no_old_loop,
        no_old_active,
    ])
    
    if all_ok:
        print("✅ 通过")
        return True
    else:
        print("❌ 失败")
        return False


async def test_edge_runtime_activate_alarm():
    """测试3: EdgeRuntime._activate_alarm 测试"""
    print("\n" + "="*60)
    print("测试3: EdgeRuntime._activate_alarm 测试")
    print("="*60)
    
    config = EdgeRuntimeConfig(
        cameras={},
        zigbee_devices={},
        house_mode=HouseMode.AWAY,
    )
    
    runtime = EdgeRuntime(config)
    
    # 替换回调为 mock
    runtime.deterrent_system._on_spotlight = mock_spotlight
    runtime.deterrent_system._on_siren = mock_siren
    
    spotlight_calls.clear()
    siren_calls.clear()
    
    # 启动威慑系统
    await runtime.deterrent_system.start()
    
    # 调用 _activate_alarm（模拟 Entry Delay 超时）
    print("\n[1] 调用 _activate_alarm()...")
    try:
        await runtime._activate_alarm()
        print("  方法调用成功")
        
        await asyncio.sleep(1.5)  # 等待效果执行
        
        state = runtime.deterrent_system.get_state()
        print(f"  状态: confirmed={state['confirmed']}")
        
        success = True
    except AttributeError as e:
        print(f"  ❌ AttributeError: {e}")
        success = False
    except Exception as e:
        print(f"  ❌ 异常: {e}")
        success = False
    
    await runtime.deterrent_system.stop()
    
    if success:
        print("✅ 通过")
        return True
    else:
        print("❌ 失败")
        return False


async def test_edge_runtime_disarm():
    """测试4: EdgeRuntime.disarm 测试"""
    print("\n" + "="*60)
    print("测试4: EdgeRuntime.disarm 测试")
    print("="*60)
    
    config = EdgeRuntimeConfig(
        cameras={},
        zigbee_devices={},
        house_mode=HouseMode.AWAY,
    )
    
    runtime = EdgeRuntime(config)
    runtime.deterrent_system._on_spotlight = mock_spotlight
    runtime.deterrent_system._on_siren = mock_siren
    
    await runtime.deterrent_system.start()
    
    # 先触发 TRIGGERED
    print("\n[1] 设置 TRIGGERED...")
    runtime.deterrent_system.set_triggered(True)
    await asyncio.sleep(1.5)
    
    state = runtime.deterrent_system.get_state()
    print(f"  状态: confirmed={state['confirmed']}")
    
    # 调用 disarm
    print("\n[2] 调用 disarm()...")
    try:
        runtime.disarm()
        print("  方法调用成功")
        
        await asyncio.sleep(1)
        
        state = runtime.deterrent_system.get_state()
        print(f"  状态: confirmed={state['confirmed']}")
        
        success = state['confirmed'] == 0
    except AttributeError as e:
        print(f"  ❌ AttributeError: {e}")
        success = False
    except Exception as e:
        print(f"  ❌ 异常: {e}")
        success = False
    
    await runtime.deterrent_system.stop()
    
    if success:
        print("✅ 通过")
        return True
    else:
        print("❌ 失败")
        return False


async def test_multi_sensor_aggregation():
    """测试5: 多传感器聚合测试"""
    print("\n" + "="*60)
    print("测试5: 多传感器聚合测试")
    print("="*60)
    
    config = EdgeRuntimeConfig(
        cameras={},
        zigbee_devices={},
        house_mode=HouseMode.AWAY,
    )
    
    runtime = EdgeRuntime(config)
    runtime.deterrent_system._on_spotlight = mock_spotlight
    runtime.deterrent_system._on_siren = mock_siren
    
    await runtime.deterrent_system.start()
    
    # 两个摄像头同时报告
    print("\n[1] cam_front=L2, cam_back=L1...")
    for _ in range(3):
        runtime.deterrent_system.report_sensor("cam_front", 2)
        runtime.deterrent_system.report_sensor("cam_back", 1)
        await asyncio.sleep(0.5)
    
    state = runtime.deterrent_system.get_state()
    level1 = state['confirmed']
    print(f"  聚合结果: confirmed={level1} (应为2)")
    
    # cam_front 停止报告
    print("\n[2] cam_front 停止，cam_back 继续...")
    for _ in range(10):
        runtime.deterrent_system.report_sensor("cam_back", 1)
        await asyncio.sleep(0.5)
    
    state = runtime.deterrent_system.get_state()
    level2 = state['confirmed']
    print(f"  聚合结果: confirmed={level2} (应为1)")
    
    await runtime.deterrent_system.stop()
    
    if level1 == 2 and level2 == 1:
        print("✅ 通过")
        return True
    else:
        print("❌ 失败")
        return False


async def test_triggered_persistence():
    """测试6: TRIGGERED 持续性（不会因传感器超时结束）"""
    print("\n" + "="*60)
    print("测试6: TRIGGERED 持续性测试")
    print("="*60)
    
    spotlight_calls.clear()
    siren_calls.clear()
    
    system = DeterrentSystem(
        on_spotlight=mock_spotlight,
        on_siren=mock_siren,
    )
    
    await system.start()
    
    # 设置 TRIGGERED
    print("\n[1] 设置 TRIGGERED...")
    system.set_triggered(True)
    await asyncio.sleep(1.5)
    
    state = system.get_state()
    print(f"  triggered_active={state['triggered_active']} confirmed={state['confirmed']}")
    
    # 等待超过传感器超时（3秒），TRIGGERED 应该仍然保持
    print("\n[2] 等待 5 秒（超过传感器超时）...")
    await asyncio.sleep(5)
    
    state = system.get_state()
    still_triggered = state['triggered_active']
    confirmed_level = state['confirmed']
    siren_count = len([c for c in siren_calls if c[0] == 'siren'])
    
    print(f"  triggered_active={still_triggered} confirmed={confirmed_level} siren_count={siren_count}")
    
    # 清理
    system.force_stop()
    await asyncio.sleep(0.5)
    
    state = system.get_state()
    print(f"\n[3] force_stop 后: triggered_active={state['triggered_active']} confirmed={state['confirmed']}")
    
    await system.stop()
    
    # 验证：TRIGGERED 应该持续，警报应该多次触发
    if still_triggered and confirmed_level == 10 and siren_count >= 2:
        print("✅ 通过：TRIGGERED 持续不结束")
        return True
    else:
        print("❌ 失败")
        return False


async def test_triggered_siren_timeout():
    """测试7: TRIGGERED 声光超时（只停输出，状态保持）"""
    print("\n" + "="*60)
    print("测试7: TRIGGERED 声光超时测试")
    print("="*60)
    
    spotlight_calls.clear()
    siren_calls.clear()
    
    system = DeterrentSystem(
        on_spotlight=mock_spotlight,
        on_siren=mock_siren,
    )
    # 设置短超时便于测试
    system.TRIGGERED_MAX_DURATION = 3
    
    await system.start()
    
    # 设置 TRIGGERED
    print("\n[1] 设置 TRIGGERED...")
    system.set_triggered(True)
    await asyncio.sleep(1.5)
    
    state = system.get_state()
    print(f"  triggered_active={state['triggered_active']} siren_timed_out={state['siren_timed_out']}")
    
    # 等待声光超时
    print("\n[2] 等待声光超时（3秒）...")
    await asyncio.sleep(3)
    
    state = system.get_state()
    triggered_active = state['triggered_active']
    siren_timed_out = state['siren_timed_out']
    confirmed_level = state['confirmed']
    
    print(f"  triggered_active={triggered_active} siren_timed_out={siren_timed_out} confirmed={confirmed_level}")
    
    # 验证：状态仍是 TRIGGERED，但声光超时
    # confirmed 应该变成 OFF（因为 _get_effective_level 返回 OFF）
    if triggered_active and siren_timed_out and confirmed_level == 0:
        print("✅ 通过：声光停止但 TRIGGERED 状态保持")
        result = True
    else:
        print("❌ 失败")
        result = False
    
    system.force_stop()
    await system.stop()
    
    return result


async def test_triggered_only_ends_by_force_stop():
    """测试8: TRIGGERED 只能通过 force_stop 或 set_triggered(False) 结束"""
    print("\n" + "="*60)
    print("测试8: TRIGGERED 结束条件测试")
    print("="*60)
    
    system = DeterrentSystem(
        on_spotlight=mock_spotlight,
        on_siren=mock_siren,
    )
    
    await system.start()
    
    # 设置 TRIGGERED
    print("\n[1] 设置 TRIGGERED...")
    system.set_triggered(True)
    await asyncio.sleep(1)
    
    # 尝试通过传感器报告 L0 来结束（应该无效）
    print("\n[2] 尝试通过传感器报告 L0（应该无效）...")
    for _ in range(5):
        system.report_sensor("cam_test", 0)
        await asyncio.sleep(0.5)
    
    state = system.get_state()
    still_triggered_1 = state['triggered_active']
    print(f"  传感器报告后: triggered_active={still_triggered_1}")
    
    # 使用 set_triggered(False) 结束
    print("\n[3] 使用 set_triggered(False)...")
    system.set_triggered(False)
    await asyncio.sleep(1)
    
    state = system.get_state()
    triggered_after_false = state['triggered_active']
    print(f"  set_triggered(False) 后: triggered_active={triggered_after_false}")
    
    # 再次激活，然后用 force_stop
    print("\n[4] 再次激活，然后 force_stop...")
    system.set_triggered(True)
    await asyncio.sleep(1)
    system.force_stop()
    await asyncio.sleep(0.5)
    
    state = system.get_state()
    triggered_after_force = state['triggered_active']
    print(f"  force_stop 后: triggered_active={triggered_after_force}")
    
    await system.stop()
    
    # 验证
    if still_triggered_1 and not triggered_after_false and not triggered_after_force:
        print("✅ 通过：TRIGGERED 只能通过正确方式结束")
        return True
    else:
        print("❌ 失败")
        return False


async def main():
    results = []
    
    results.append(("DeterrentSystem独立", await test_deterrent_system_standalone()))
    results.append(("EdgeRuntime方法存在", await test_edge_runtime_deterrent_methods()))
    results.append(("_activate_alarm", await test_edge_runtime_activate_alarm()))
    results.append(("disarm", await test_edge_runtime_disarm()))
    results.append(("多传感器聚合", await test_multi_sensor_aggregation()))
    results.append(("TRIGGERED持续性", await test_triggered_persistence()))
    results.append(("TRIGGERED声光超时", await test_triggered_siren_timeout()))
    results.append(("TRIGGERED结束条件", await test_triggered_only_ends_by_force_stop()))
    
    print("\n" + "="*60)
    print("测试汇总")
    print("="*60)
    for name, passed in results:
        status = "✅" if passed else "❌"
        print(f"  {status} {name}")
    
    all_passed = all(p for _, p in results)
    print(f"\n总计: {sum(1 for _, p in results if p)}/{len(results)} 通过")
    
    return all_passed


if __name__ == "__main__":
    success = asyncio.run(main())
    sys.exit(0 if success else 1)
