#!/usr/bin/env python3
"""
威慑系统仿真测试界面

启动：python3 test_deterrent_web.py
访问：http://localhost:8765

按钮：OFF / L1 / L2 / TRIGGERED
输出：💡 灯状态 / 🔔 警报状态
"""

import asyncio
import json
import time
import logging
from aiohttp import web

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s.%(msecs)03d [%(levelname)s] %(message)s',
    datefmt='%H:%M:%S'
)
logger = logging.getLogger(__name__)


# ============================================================
# 威慑系统（与 test_simple_deterrent.py 相同逻辑）
# ============================================================

class DeterrentSystem:
    """威慑系统 - 单循环 + 去抖"""
    
    # 去抖配置
    DEBOUNCE_UP = 0.5
    DEBOUNCE_DOWN = 2.0
    MIN_HOLD_L2 = 5.0
    MIN_HOLD_L1 = 3.0
    
    # 效果参数（默认无延迟，由客户配置）
    PATTERNS = {
        0: {"light": "off", "siren_interval": 0},
        1: {"light": "steady", "start_delay": 0, "siren_interval": 30, "siren_duration": 1},
        2: {"light": "flash", "start_delay": 0, "flash_on": 5, "flash_off": 5, "siren_interval": 10, "siren_duration": 2},
        3: {"light": "flash", "start_delay": 0, "flash_on": 3, "flash_off": 3, "siren_interval": 5, "siren_duration": 2},
        10: {"light": "flash", "start_delay": 0, "flash_on": 1, "flash_off": 1, "siren_interval": 3, "siren_duration": 3},  # TRIGGERED
    }
    
    def __init__(self, on_state_change=None):
        self._desired_level = 0
        self._confirmed_level = 0
        self._confirmed_time = 0
        self._pending_level = None
        self._pending_time = 0
        self._pending_debounce = 0
        
        self._light_on = False
        self._siren_on = False
        self._last_siren_time = 0
        self._siren_end_time = 0
        
        self.running = False
        self._task = None
        self._on_state_change = on_state_change
    
    def start(self):
        if self.running:
            return
        self.running = True
        self._task = asyncio.create_task(self._run_loop())
        logger.info("[SYSTEM] 启动")
    
    def stop(self):
        self.running = False
        if self._task:
            self._task.cancel()
        logger.info("[SYSTEM] 停止")
    
    def set_desired(self, level: int):
        """设置期望级别"""
        if level != self._desired_level:
            logger.info(f"[INPUT] 设置 L{level}")
        self._desired_level = level
    
    def get_state(self):
        """获取当前状态"""
        level = self._confirmed_level
        pattern = self.PATTERNS.get(level, self.PATTERNS[0])
        start_delay = pattern.get("start_delay", 0)
        elapsed = time.time() - self._confirmed_time if self._confirmed_time > 0 else 0
        
        buffer_remaining = None
        if start_delay > 0 and elapsed < start_delay:
            buffer_remaining = int(start_delay - elapsed)
        
        return {
            "desired": self._desired_level,
            "confirmed": self._confirmed_level,
            "pending": self._pending_level,
            "light": self._light_on,
            "siren": self._siren_on,
            "buffer": buffer_remaining,  # 缓冲剩余秒数，None 表示不在缓冲期
        }
    
    async def _run_loop(self):
        """主循环"""
        try:
            while self.running:
                now = time.time()
                self._process_debounce(now)
                await self._execute_effect(now)
                self._notify_state()
                await asyncio.sleep(0.2)
        except asyncio.CancelledError:
            pass
        finally:
            self._light_on = False
            self._siren_on = False
            self._notify_state()
    
    def _process_debounce(self, now: float):
        """去抖处理"""
        desired = self._desired_level
        confirmed = self._confirmed_level
        
        if desired == confirmed:
            if self._pending_level is not None:
                logger.info(f"[DEBOUNCE] 取消待确认 L{self._pending_level}")
                self._pending_level = None
            return
        
        if self._pending_level != desired:
            elapsed = now - self._confirmed_time
            if desired > confirmed:
                debounce = self.DEBOUNCE_UP
            else:
                if confirmed == 2 and elapsed < self.MIN_HOLD_L2:
                    debounce = self.MIN_HOLD_L2 - elapsed
                elif confirmed == 1 and elapsed < self.MIN_HOLD_L1:
                    debounce = self.MIN_HOLD_L1 - elapsed
                else:
                    debounce = self.DEBOUNCE_DOWN
            
            self._pending_level = desired
            self._pending_time = now
            self._pending_debounce = debounce
            logger.info(f"[DEBOUNCE] L{confirmed} → L{desired} (去抖 {debounce:.1f}s)")
        
        if self._pending_level is not None:
            if now - self._pending_time >= self._pending_debounce:
                self._confirm_level(self._pending_level, now)
    
    def _confirm_level(self, level: int, now: float):
        """确认级别"""
        old = self._confirmed_level
        self._confirmed_level = level
        self._confirmed_time = now
        self._pending_level = None
        self._last_siren_time = 0
        logger.warning(f"[CONFIRM] L{old} → L{level}")
    
    async def _execute_effect(self, now: float):
        """执行效果"""
        level = self._confirmed_level
        pattern = self.PATTERNS.get(level, self.PATTERNS[0])
        elapsed = now - self._confirmed_time
        
        # 缓冲延时检查
        start_delay = pattern.get("start_delay", 0)
        if elapsed < start_delay:
            # 缓冲期：灯灭，不警报，但显示倒计时
            remaining = start_delay - elapsed
            if int(remaining) != getattr(self, '_last_countdown', -1):
                self._last_countdown = int(remaining)
                logger.info(f"[BUFFER] L{level} 缓冲中... {int(remaining)}s")
            
            # 确保灯灭
            if self._light_on:
                self._light_on = False
                logger.info("[DEVICE] 💡 OFF (缓冲期)")
            return
        
        # 缓冲结束后的实际 elapsed
        effect_elapsed = elapsed - start_delay
        
        # 灯光
        if pattern["light"] == "off":
            desired_light = False
        elif pattern["light"] == "steady":
            desired_light = True
        else:  # flash
            cycle = pattern["flash_on"] + pattern["flash_off"]
            desired_light = (effect_elapsed % cycle) < pattern["flash_on"]
        
        if desired_light != self._light_on:
            self._light_on = desired_light
            logger.info(f"[DEVICE] 💡 {'ON' if desired_light else 'OFF'}")
        
        # 警报
        if now < self._siren_end_time:
            if not self._siren_on:
                self._siren_on = True
        else:
            if self._siren_on:
                self._siren_on = False
        
        interval = pattern.get("siren_interval", 0)
        if interval > 0:
            effect_elapsed_int = int(effect_elapsed)
            # 首次（缓冲结束后）
            if effect_elapsed < 0.5 and self._last_siren_time == 0:
                self._last_siren_time = -1
                self._trigger_siren(pattern.get("siren_duration", 1), now)
            # 周期
            elif effect_elapsed_int > 0 and effect_elapsed_int % interval == 0 and effect_elapsed_int != self._last_siren_time:
                self._last_siren_time = effect_elapsed_int
                self._trigger_siren(pattern.get("siren_duration", 1), now)
    
    def _trigger_siren(self, duration: float, now: float):
        """触发警报"""
        self._siren_end_time = now + duration
        self._siren_on = True
        logger.info(f"[DEVICE] 🔔 警报 {duration}s")
    
    def _notify_state(self):
        """通知状态变化"""
        if self._on_state_change:
            self._on_state_change(self.get_state())


# ============================================================
# Web 服务
# ============================================================

HTML = '''<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>威慑系统仿真</title>
    <style>
        * { box-sizing: border-box; }
        body { 
            font-family: -apple-system, BlinkMacSystemFont, sans-serif;
            background: #1a1a2e; 
            color: #eee;
            margin: 0;
            padding: 20px;
            min-height: 100vh;
        }
        h1 { text-align: center; color: #fff; margin-bottom: 30px; }
        
        .container {
            max-width: 600px;
            margin: 0 auto;
        }
        
        .panel {
            background: #16213e;
            border-radius: 16px;
            padding: 24px;
            margin-bottom: 20px;
        }
        
        .panel-title {
            font-size: 14px;
            color: #888;
            text-transform: uppercase;
            margin-bottom: 16px;
        }
        
        .buttons {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 12px;
        }
        
        button {
            padding: 20px 16px;
            font-size: 18px;
            font-weight: 600;
            border: none;
            border-radius: 12px;
            cursor: pointer;
            transition: all 0.2s;
        }
        
        button:hover { transform: translateY(-2px); }
        button:active { transform: translateY(0); }
        
        .btn-off { background: #4a4a4a; color: #fff; }
        .btn-l1 { background: #f39c12; color: #000; }
        .btn-l2 { background: #e74c3c; color: #fff; }
        .btn-triggered { background: #9b59b6; color: #fff; }
        
        .btn-off.active { box-shadow: 0 0 20px #4a4a4a; }
        .btn-l1.active { box-shadow: 0 0 20px #f39c12; }
        .btn-l2.active { box-shadow: 0 0 20px #e74c3c; }
        .btn-triggered.active { box-shadow: 0 0 20px #9b59b6; }
        
        .outputs {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }
        
        .output {
            text-align: center;
            padding: 40px 20px;
            border-radius: 16px;
            background: #0f0f23;
        }
        
        .output-icon {
            font-size: 64px;
            margin-bottom: 12px;
            transition: all 0.2s;
        }
        
        .output-label {
            font-size: 14px;
            color: #888;
        }
        
        .output.on .output-icon {
            filter: drop-shadow(0 0 20px currentColor);
        }
        
        .light-icon { color: #333; }
        .light-icon.on { color: #f1c40f; }
        
        .siren-icon { color: #333; }
        .siren-icon.on { color: #e74c3c; animation: pulse 0.5s infinite; }
        
        @keyframes pulse {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.1); }
        }
        
        .status {
            display: flex;
            justify-content: space-between;
            padding: 12px 0;
            border-top: 1px solid #333;
            margin-top: 16px;
        }
        
        .status-item {
            text-align: center;
        }
        
        .status-value {
            font-size: 24px;
            font-weight: 600;
        }
        
        .status-label {
            font-size: 12px;
            color: #666;
        }
        
        .log {
            background: #0f0f23;
            border-radius: 8px;
            padding: 12px;
            height: 200px;
            overflow-y: auto;
            font-family: monospace;
            font-size: 12px;
            line-height: 1.6;
        }
        
        .log-entry { color: #888; }
        .log-entry.confirm { color: #2ecc71; }
        .log-entry.debounce { color: #f39c12; }
        .log-entry.device { color: #3498db; }
    </style>
</head>
<body>
    <div class="container">
        <h1>🎛️ 威慑系统仿真</h1>
        
        <div class="panel">
            <div class="panel-title">控制</div>
            <div class="buttons">
                <button class="btn-off active" onclick="setLevel(0)">OFF</button>
                <button class="btn-l1" onclick="setLevel(1)">L1</button>
                <button class="btn-l2" onclick="setLevel(2)">L2</button>
                <button class="btn-triggered" onclick="setLevel(10)">TRIGGERED</button>
            </div>
            
            <div class="status">
                <div class="status-item">
                    <div class="status-value" id="desired">0</div>
                    <div class="status-label">期望</div>
                </div>
                <div class="status-item">
                    <div class="status-value" id="pending">-</div>
                    <div class="status-label">待确认</div>
                </div>
                <div class="status-item">
                    <div class="status-value" id="confirmed">0</div>
                    <div class="status-label">当前</div>
                </div>
                <div class="status-item">
                    <div class="status-value" id="buffer">-</div>
                    <div class="status-label">缓冲</div>
                </div>
            </div>
        </div>
        
        <div class="panel">
            <div class="panel-title">输出</div>
            <div class="outputs">
                <div class="output" id="light-output">
                    <div class="output-icon light-icon" id="light-icon">💡</div>
                    <div class="output-label">灯光</div>
                </div>
                <div class="output" id="siren-output">
                    <div class="output-icon siren-icon" id="siren-icon">🔔</div>
                    <div class="output-label">警报</div>
                </div>
            </div>
        </div>
        
        <div class="panel">
            <div class="panel-title">日志</div>
            <div class="log" id="log"></div>
        </div>
    </div>
    
    <script>
        let ws;
        let currentDesired = 0;
        
        function connect() {
            ws = new WebSocket('ws://' + location.host + '/ws');
            
            ws.onopen = () => {
                addLog('已连接', 'confirm');
            };
            
            ws.onmessage = (e) => {
                const data = JSON.parse(e.data);
                updateUI(data);
            };
            
            ws.onclose = () => {
                addLog('断开连接，3秒后重连...', 'debounce');
                setTimeout(connect, 3000);
            };
        }
        
        function setLevel(level) {
            currentDesired = level;
            if (ws && ws.readyState === WebSocket.OPEN) {
                ws.send(JSON.stringify({level: level}));
            }
            
            // 更新按钮状态
            document.querySelectorAll('button').forEach(btn => btn.classList.remove('active'));
            const btnMap = {0: 'btn-off', 1: 'btn-l1', 2: 'btn-l2', 10: 'btn-triggered'};
            document.querySelector('.' + btnMap[level]).classList.add('active');
        }
        
        function updateUI(state) {
            // 状态
            document.getElementById('desired').textContent = state.desired;
            document.getElementById('pending').textContent = state.pending !== null ? state.pending : '-';
            document.getElementById('confirmed').textContent = state.confirmed;
            document.getElementById('buffer').textContent = state.buffer !== null ? state.buffer + 's' : '-';
            
            // 缓冲期高亮
            const bufferEl = document.getElementById('buffer');
            if (state.buffer !== null) {
                bufferEl.style.color = '#f39c12';
            } else {
                bufferEl.style.color = '';
            }
            
            // 灯光
            const lightIcon = document.getElementById('light-icon');
            const lightOutput = document.getElementById('light-output');
            if (state.light) {
                lightIcon.classList.add('on');
                lightOutput.classList.add('on');
            } else {
                lightIcon.classList.remove('on');
                lightOutput.classList.remove('on');
            }
            
            // 警报
            const sirenIcon = document.getElementById('siren-icon');
            const sirenOutput = document.getElementById('siren-output');
            if (state.siren) {
                sirenIcon.classList.add('on');
                sirenOutput.classList.add('on');
            } else {
                sirenIcon.classList.remove('on');
                sirenOutput.classList.remove('on');
            }
        }
        
        function addLog(msg, type = '') {
            const log = document.getElementById('log');
            const time = new Date().toLocaleTimeString();
            const entry = document.createElement('div');
            entry.className = 'log-entry ' + type;
            entry.textContent = time + ' ' + msg;
            log.appendChild(entry);
            log.scrollTop = log.scrollHeight;
            
            // 限制日志数量
            while (log.children.length > 100) {
                log.removeChild(log.firstChild);
            }
        }
        
        // 键盘快捷键
        document.addEventListener('keydown', (e) => {
            if (e.key === '0') setLevel(0);
            if (e.key === '1') setLevel(1);
            if (e.key === '2') setLevel(2);
            if (e.key === 't' || e.key === 'T') setLevel(10);
        });
        
        connect();
    </script>
</body>
</html>
'''

# 全局状态
clients = set()
system = None


async def handle_index(request):
    return web.Response(text=HTML, content_type='text/html')


async def handle_websocket(request):
    ws = web.WebSocketResponse()
    await ws.prepare(request)
    clients.add(ws)
    
    try:
        # 发送当前状态
        if system:
            await ws.send_json(system.get_state())
        
        async for msg in ws:
            if msg.type == web.WSMsgType.TEXT:
                data = json.loads(msg.data)
                if 'level' in data:
                    system.set_desired(data['level'])
    finally:
        clients.discard(ws)
    
    return ws


def broadcast_state(state):
    """广播状态到所有客户端"""
    for ws in list(clients):
        if not ws.closed:
            asyncio.create_task(ws.send_json(state))


async def start_background_tasks(app):
    global system
    system = DeterrentSystem(on_state_change=broadcast_state)
    system.start()


async def cleanup_background_tasks(app):
    if system:
        system.stop()


def main():
    app = web.Application()
    app.router.add_get('/', handle_index)
    app.router.add_get('/ws', handle_websocket)
    
    app.on_startup.append(start_background_tasks)
    app.on_cleanup.append(cleanup_background_tasks)
    
    print("\n" + "="*50)
    print("威慑系统仿真测试")
    print("="*50)
    print("\n访问: http://localhost:8765")
    print("\n快捷键: 0=OFF, 1=L1, 2=L2, T=TRIGGERED")
    print("\n按 Ctrl+C 停止\n")
    
    web.run_app(app, host='0.0.0.0', port=8765, print=None)


if __name__ == '__main__':
    main()
