#!/usr/bin/env python3
"""
测试 Reolink 灯光控制的实际响应时间

用法:
    python3 test_light_timing.py <ip> <user> <password>
    
测试内容:
    1. 开灯时间
    2. 关灯时间
    3. 连续开关的间隔
"""

import asyncio
import sys
import time

async def main():
    if len(sys.argv) < 4:
        print("用法: python3 test_light_timing.py <ip> <user> <password>")
        sys.exit(1)
    
    ip, user, password = sys.argv[1], sys.argv[2], sys.argv[3]
    
    try:
        from reolink_aio.api import Host
    except ImportError:
        print("请安装: pip install reolink-aio")
        sys.exit(1)
    
    print(f"连接 {ip}...")
    host = Host(ip, user, password)
    await host.get_host_data()
    print(f"已连接: {host.camera_name}")
    
    print("\n" + "="*60)
    print("测试 1: 开灯时间")
    print("="*60)
    
    # 先确保灯是关的
    await host.set_whiteled(0, state=False)
    await asyncio.sleep(1)
    
    start = time.time()
    await host.set_whiteled(0, state=True)
    elapsed = time.time() - start
    print(f"开灯耗时: {elapsed:.2f}s")
    
    await asyncio.sleep(2)
    
    print("\n" +