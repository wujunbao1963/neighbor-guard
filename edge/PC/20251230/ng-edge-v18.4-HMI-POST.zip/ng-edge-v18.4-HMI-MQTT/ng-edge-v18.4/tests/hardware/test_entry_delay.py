#!/usr/bin/env python3
"""
Entry Delay + TRIGGERED 测试 (Ring Keypad 撤防)

测试流程：
1. 打开门 → PENDING
2. 倒计时 (可配置)
3. 用 Ring Keypad 输入 PIN + DISARM 撤防
4. 或超时 → TRIGGERED

使用方式：
    # 10 秒延迟测试
    python tests/hardware/test_entry_delay.py --delay 10
    
    # 只用 Zigbee + Keypad (不启动摄像头)
    python tests/hardware/test_entry_delay.py --delay 10 --no-cameras
    
    # 指定 PIN
    python tests/hardware/test_entry_delay.py --pin 1234
"""

import asyncio
import sys
import os

# 添加项目路径
script_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.dirname(os.path.dirname(script_dir))
sys.path.insert(0, os.path.join(project_root, 'src'))

from ng_edge.runtime.edge_runtime import EdgeRuntime, EdgeRuntimeConfig, get_default_config
from ng_edge.state.states import ThreatState


class EntryDelayTester:
    """Entry Delay 测试器 (Ring Keypad 撤防)"""
    
    def __init__(self, delay_sec: int = 10, use_cameras: bool = False, pin: str = "1234",
                 keypad_ws_url: str = "ws://localhost:3000", keypad_node_id: int = 2):
        self.delay_sec = delay_sec
        
        # 获取配置
        config = get_default_config()
        config.entry_delay_sec = delay_sec
        config.valid_pins = [pin]
        config.keypad_ws_url = keypad_ws_url
        config.keypad_node_id = keypad_node_id
        
        if not use_cameras:
            config.cameras = {}
        
        self.runtime = EdgeRuntime(config)
        
        # 设置回调
        self.runtime.on_entry_delay_tick = self._on_tick
        self.runtime.on_triggered = self._on_triggered
        self.runtime.on_keypad_disarm = self._on_disarm
        
        self.triggered = False
        self.disarmed = False
    
    def _on_tick(self, entry_point_id: str, remaining: int):
        """倒计时回调"""
        bar_len = 30
        filled = int((self.delay_sec - remaining) / self.delay_sec * bar_len)
        bar = "█" * filled + "░" * (bar_len - filled)
        print(f"\r⏱️  [{entry_point_id}] [{bar}] {remaining:2d}s  ", end="", flush=True)
    
    def _on_triggered(self, entry_point_id: str, incident_id: str):
        """TRIGGERED 回调"""
        self.triggered = True
        print()
        print()
        print("🚨" * 30)
        print(f"🚨 ALARM TRIGGERED!")
        print(f"🚨 Entry Point: {entry_point_id}")
        print(f"🚨 Incident: {incident_id}")
        print("🚨" * 30)
        print()
    
    def _on_disarm(self):
        """Keypad 撤防回调"""
        self.disarmed = True
        print()
        print()
        print("🔓" * 30)
        print("🔓 DISARMED via Keypad!")
        print("🔓" * 30)
        print()
    
    async def run(self):
        """运行测试"""
        print("=" * 70)
        print("Entry Delay + TRIGGERED 测试 (Ring Keypad)")
        print("=" * 70)
        print()
        print(f"Entry Delay: {self.delay_sec} 秒")
        print(f"Keypad: {self.runtime.config.keypad_ws_url}")
        print(f"Node ID: {self.runtime.config.keypad_node_id}")
        print(f"有效 PIN: {self.runtime.config.valid_pins}")
        print()
        print("测试步骤:")
        print("  1. 打开门传感器 → PENDING")
        print(f"  2. 等待 {self.delay_sec}s 倒计时")
        print("  3. 在 Keypad 上输入 PIN + DISARM 撤防")
        print("  4. 或超时 → TRIGGERED 🚨")
        print()
        print("按 Ctrl+C 退出")
        print("=" * 70)
        print()
        
        try:
            await self.runtime.start()
        except KeyboardInterrupt:
            print("\n用户中断")
        finally:
            await self.runtime.stop()
            
            print()
            if self.disarmed:
                print("✅ Keypad 撤防测试成功!")
            elif self.triggered:
                print("✅ TRIGGERED 测试成功!")
            else:
                print("ℹ️ 测试结束")


async def main():
    import argparse
    
    parser = argparse.ArgumentParser(description="Entry Delay + TRIGGERED 测试 (Ring Keypad)")
    parser.add_argument("--delay", type=int, default=10, help="Entry Delay 秒数 (默认 10)")
    parser.add_argument("--cameras", action="store_true", help="启用摄像头")
    parser.add_argument("--no-cameras", dest="cameras", action="store_false")
    parser.add_argument("--pin", default="1234", help="有效 PIN (默认 1234)")
    parser.add_argument("--keypad-url", default="ws://localhost:3000", help="Z-Wave JS WebSocket URL")
    parser.add_argument("--keypad-node", type=int, default=2, help="Keypad Node ID")
    parser.set_defaults(cameras=True)  # 默认启用摄像头以支持声光
    
    args = parser.parse_args()
    
    tester = EntryDelayTester(
        delay_sec=args.delay,
        use_cameras=args.cameras,
        pin=args.pin,
        keypad_ws_url=args.keypad_url,
        keypad_node_id=args.keypad_node,
    )
    
    await tester.run()


if __name__ == "__main__":
    asyncio.run(main())
