#!/usr/bin/env python3
"""
EdgeRuntime 集成测试

同时运行 Zigbee + Camera，验证完整信号流。

使用方式：
    python tests/hardware/test_edge_runtime.py
    python tests/hardware/test_edge_runtime.py --duration 60
    python tests/hardware/test_edge_runtime.py --no-cameras  # 只测 Zigbee
"""

import asyncio
import sys
import os

# 添加项目路径
script_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.dirname(os.path.dirname(script_dir))
sys.path.insert(0, os.path.join(project_root, 'src'))

from ng_edge.runtime.edge_runtime import EdgeRuntime, get_default_config


async def main():
    import argparse
    
    parser = argparse.ArgumentParser(description="EdgeRuntime 集成测试")
    parser.add_argument("--duration", type=int, default=None, help="运行时长（秒）")
    parser.add_argument("--no-cameras", action="store_true", help="不启动摄像头")
    parser.add_argument("--no-zigbee", action="store_true", help="不启动 Zigbee")
    args = parser.parse_args()
    
    print("=" * 70)
    print("EdgeRuntime 集成测试")
    print("=" * 70)
    print()
    print("这个测试将同时运行：")
    if not args.no_zigbee:
        print("  ✓ Zigbee 传感器监听 (MQTT)")
    if not args.no_cameras:
        print("  ✓ 摄像头 YOLO 检测 (RTSP)")
    print()
    print("测试场景：")
    print("  1. 在摄像头前走动 → person_detected → PRE_L2")
    print("  2. 打开门传感器 → door_open → PENDING")
    print("  3. 组合: person + door → 状态叠加")
    print()
    print("按 Ctrl+C 退出")
    print("=" * 70)
    print()
    
    config = get_default_config()
    
    if args.no_cameras:
        config.cameras = {}
        print("[INFO] 摄像头已禁用")
    if args.no_zigbee:
        config.zigbee_devices = {}
        print("[INFO] Zigbee 已禁用")
    
    runtime = EdgeRuntime(config)
    
    try:
        if args.duration:
            print(f"[INFO] 运行 {args.duration} 秒后自动停止")
            task = asyncio.create_task(runtime.start())
            await asyncio.sleep(args.duration)
            runtime.running = False
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass
            await runtime.stop()
        else:
            await runtime.start()
    except KeyboardInterrupt:
        print("\n用户中断")
        await runtime.stop()


if __name__ == "__main__":
    asyncio.run(main())
