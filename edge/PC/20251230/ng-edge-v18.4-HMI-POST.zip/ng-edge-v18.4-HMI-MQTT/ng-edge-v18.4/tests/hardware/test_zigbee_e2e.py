#!/usr/bin/env python3
"""
Zigbee 端到端硬件验证脚本

测试流程：
1. 连接 MQTT (Zigbee2MQTT)
2. 监听真实 Zigbee 传感器信号
3. 通过 ZigbeeSignalAdapter 转换为 SignalEnvelope
4. 发送到 SecurityCoordinatorV2 处理
5. 显示状态变化

使用方式：
    python tests/hardware/test_zigbee_e2e.py

测试步骤：
    1. 运行脚本
    2. 打开/关闭门传感器
    3. 触发运动传感器
    4. 观察控制台输出
"""

import asyncio
import json
import sys
from datetime import datetime, timezone
from typing import Optional

# 添加项目路径 (自动检测)
import os
script_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.dirname(os.path.dirname(script_dir))
sys.path.insert(0, os.path.join(project_root, 'src'))

from ng_edge.core.signal import SignalEnvelope
from ng_edge.core.zigbee_adapter import convert_zigbee_signal, SIGNAL_KIND_MAP
from ng_edge.state.coordinator_v2 import SecurityCoordinatorV2, ProcessResult
from ng_edge.state.states import ThreatState, WorkflowState
from ng_edge.services.state_machine_v5 import HouseMode, UserMode

# MQTT 配置
MQTT_HOST = "localhost"
MQTT_PORT = 1883
ZIGBEE_TOPIC = "zigbee2mqtt/+"


class ZigbeeE2ETest:
    """Zigbee 端到端测试"""
    
    def __init__(self):
        # 创建协调器 - AWAY 模式
        self.coordinator = SecurityCoordinatorV2(
            house_mode=HouseMode.AWAY,
            user_mode=UserMode.QUIET,
            entry_delay_sec=30,
        )
        
        # 注册入口点
        self.coordinator.register_entry_point("ep_back", "Back Door", entry_delay_sec=30)
        self.coordinator.register_entry_point("ep_front", "Front Door", entry_delay_sec=30)
        
        # 设备 → 入口点映射 (根据 Zigbee2MQTT friendly_name)
        self.device_mapping = {
            # 后门
            "Back Door Contact": {
                "entrypoint_id": "ep_back",
                "zone_id": "entry_exit",
                "device_type": "contact",
            },
            "Back Door Motion": {
                "entrypoint_id": "ep_back",
                "zone_id": "entry_exit",
                "device_type": "motion",
            },
            # 前门
            "Front Door Contact": {
                "entrypoint_id": "ep_front",
                "zone_id": "entry_exit",
                "device_type": "contact",
            },
            "Front Door Motion": {
                "entrypoint_id": "ep_front",
                "zone_id": "entry_exit",
                "device_type": "motion",
            },
        }
        
        # 统计
        self.stats = {
            "mqtt_messages": 0,
            "signals_processed": 0,
            "state_changes": 0,
        }
        
        # 设置回调
        self.coordinator.on_transition = self._on_transition
        
        self.mqtt_client = None
    
    async def start(self):
        """启动测试"""
        print("=" * 60)
        print("Zigbee E2E 硬件验证测试")
        print("=" * 60)
        print(f"模式: {self.coordinator.house_mode.value}")
        print(f"入口点: {list(self.device_mapping.keys())}")
        print()
        print("等待 Zigbee 传感器信号...")
        print("- 打开/关闭门传感器测试 door_open/door_close")
        print("- 走动测试 motion 传感器")
        print("- Ctrl+C 退出")
        print("-" * 60)
        
        try:
            import aiomqtt
        except ImportError:
            print("\n[ERROR] 需要安装 aiomqtt: pip install aiomqtt")
            return
        
        try:
            async with aiomqtt.Client(MQTT_HOST, MQTT_PORT) as client:
                self.mqtt_client = client
                await client.subscribe("zigbee2mqtt/#")
                
                print(f"[MQTT] 已连接 {MQTT_HOST}:{MQTT_PORT}")
                print(f"[MQTT] 订阅 zigbee2mqtt/#")
                print()
                
                async for message in client.messages:
                    await self._handle_mqtt_message(message)
                    
        except Exception as e:
            print(f"[ERROR] MQTT 连接失败: {e}")
            print("确保 Zigbee2MQTT 正在运行")
    
    async def _handle_mqtt_message(self, message):
        """处理 MQTT 消息"""
        topic = str(message.topic)
        
        # 跳过 bridge 消息
        if "bridge" in topic:
            return
        
        # 解析设备名称
        parts = topic.split("/")
        if len(parts) < 2:
            return
        
        device_name = parts[1]
        
        # 解析 payload
        try:
            payload = json.loads(message.payload.decode())
        except:
            return
        
        self.stats["mqtt_messages"] += 1
        
        # 显示原始消息
        self._log_mqtt(device_name, payload)
        
        # 转换并处理
        await self._process_zigbee_signal(device_name, payload)
    
    async def _process_zigbee_signal(self, device_name: str, payload: dict):
        """处理 Zigbee 信号"""
        # 查找设备映射
        mapping = self.device_mapping.get(device_name)
        
        if not mapping:
            # 尝试模糊匹配
            for key, m in self.device_mapping.items():
                if key in device_name or device_name in key:
                    mapping = m
                    break
        
        if not mapping:
            # 未知设备，尝试自动检测类型
            mapping = self._auto_detect_mapping(device_name, payload)
        
        # 确定信号类型
        signal_kind = self._detect_signal_kind(payload, mapping.get("device_type", ""))
        
        if not signal_kind:
            return
        
        # 创建 SignalEnvelope
        envelope = SignalEnvelope.from_zigbee(
            device_id=device_name,
            friendly_name=device_name,
            signal_kind=signal_kind,
            zone_id=mapping.get("zone_id", "entry_exit"),
            entrypoint_id=mapping.get("entrypoint_id", "ep_back"),
            battery=payload.get("battery"),
            linkquality=payload.get("linkquality"),
            raw_payload=payload,
        )
        
        self._log_envelope(envelope)
        
        # 发送到协调器
        result = self.coordinator.process_envelope(envelope)
        self.stats["signals_processed"] += 1
        
        self._log_result(result)
    
    def _detect_signal_kind(self, payload: dict, device_type: str) -> Optional[str]:
        """检测信号类型"""
        # 门窗传感器
        if "contact" in payload:
            return "door_open" if payload["contact"] == False else "door_close"
        
        # 运动传感器
        if "occupancy" in payload:
            if payload["occupancy"]:
                return "motion_pir"
            return None  # 运动结束不触发
        
        # 也支持 motion 字段
        if "motion" in payload:
            if payload["motion"]:
                return "motion_pir"
            return None
        
        return None
    
    def _auto_detect_mapping(self, device_name: str, payload: dict) -> dict:
        """自动检测设备映射"""
        device_type = ""
        
        if "contact" in payload:
            device_type = "contact"
        elif "occupancy" in payload or "motion" in payload:
            device_type = "motion"
        
        return {
            "entrypoint_id": "ep_back",  # 默认后门
            "zone_id": "entry_exit",
            "device_type": device_type,
        }
    
    def _on_transition(self, result: ProcessResult):
        """状态转换回调"""
        self.stats["state_changes"] += 1
        
        print()
        print("!" * 60)
        print(f"[STATE CHANGE] {result.from_threat} → {result.to_threat}")
        print(f"  Entry Point: {result.entry_point_id}")
        print(f"  Incident: {result.incident_id}")
        print(f"  Reason: {result.reason_code}")
        print("!" * 60)
        print()
    
    def _log_mqtt(self, device_name: str, payload: dict):
        """记录 MQTT 消息"""
        ts = datetime.now().strftime("%H:%M:%S.%f")[:-3]
        
        # 提取关键字段
        key_fields = {}
        for k in ["contact", "occupancy", "motion", "battery", "linkquality"]:
            if k in payload:
                key_fields[k] = payload[k]
        
        print(f"[{ts}] MQTT < {device_name}: {key_fields}")
    
    def _log_envelope(self, envelope: SignalEnvelope):
        """记录 SignalEnvelope"""
        ts = datetime.now().strftime("%H:%M:%S.%f")[:-3]
        
        print(f"[{ts}] ENVELOPE: kind={envelope.signal_kind}, "
              f"ep={envelope.entrypoint_id}, "
              f"hardness={envelope.hardness.value}")
    
    def _log_result(self, result: ProcessResult):
        """记录处理结果"""
        ts = datetime.now().strftime("%H:%M:%S.%f")[:-3]
        
        status = "✓" if result.success else "✗"
        changed = "CHANGED" if result.threat_changed else "unchanged"
        
        print(f"[{ts}] RESULT {status}: threat={result.threat_state.value}, "
              f"workflow={result.workflow_state.value}, {changed}")
        
        if result.judge_capped:
            print(f"[{ts}] WARNING: PRE capped due to Judge offline")


async def main():
    test = ZigbeeE2ETest()
    
    try:
        await test.start()
    except KeyboardInterrupt:
        print()
        print("-" * 60)
        print("测试结束")
        print(f"统计: {test.stats}")
        print("-" * 60)


if __name__ == "__main__":
    asyncio.run(main())
