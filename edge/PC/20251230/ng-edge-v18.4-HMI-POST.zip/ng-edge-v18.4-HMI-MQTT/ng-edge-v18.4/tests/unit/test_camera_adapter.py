"""
Tests for Camera Signal Adapter
"""

import pytest
from datetime import datetime, timezone
from unittest.mock import Mock
from dataclasses import dataclass
from enum import Enum

from ng_edge.core.signal import SignalEnvelope, Hardness, CameraRole, PreLevel
from ng_edge.core.camera_adapter import (
    convert_camera_signal,
    CameraSignalAdapter,
    CameraRoleConfig,
)


# Mock Signal class (模拟 domain.models.Signal)
class MockSignalType(Enum):
    PERSON_DETECTED = "person_detected"
    VEHICLE_DETECTED = "vehicle_detected"


@dataclass
class MockSignal:
    """模拟 domain.models.Signal"""
    signal_id: str
    timestamp: datetime
    sensor_id: str
    sensor_type: str
    signal_type: MockSignalType
    zone_id: str
    entry_point_id: str
    confidence: float
    raw_payload: dict
    is_processed: bool = False
    is_filtered: bool = False


def make_mock_signal(
    sensor_id: str = "cam_front",
    confidence: float = 0.85,
    zone_id: str = "exterior",
    signal_type: MockSignalType = MockSignalType.PERSON_DETECTED,
) -> MockSignal:
    """创建测试用 Mock Signal"""
    return MockSignal(
        signal_id=f"sig_test_{sensor_id}",
        timestamp=datetime.now(timezone.utc),
        sensor_id=sensor_id,
        sensor_type="camera",
        signal_type=signal_type,
        zone_id=zone_id,
        entry_point_id=None,
        confidence=confidence,
        raw_payload={
            "detection_count": 1,
            "best_detection": {
                "class": "person",
                "confidence": confidence,
                "bbox": [100, 200, 50, 100],
            },
            "camera": {
                "name": "Front Camera",
                "resolution": "1920x1080",
            }
        }
    )


class TestConvertCameraSignal:
    """测试信号转换函数"""
    
    def test_convert_person_detected(self):
        """测试转换人员检测信号"""
        signal = make_mock_signal(confidence=0.9)
        
        envelope = convert_camera_signal(signal, CameraRole.JUDGE)
        
        assert envelope is not None
        assert envelope.signal_kind == "person_detected"
        assert envelope.hardness == Hardness.SOFT
        assert envelope.camera_role == CameraRole.JUDGE
        assert envelope.confidence == 0.9
        assert envelope.level == PreLevel.L2  # 高置信度
    
    def test_convert_with_witness_role(self):
        """测试 Witness 角色"""
        signal = make_mock_signal()
        
        envelope = convert_camera_signal(signal, CameraRole.WITNESS)
        
        assert envelope.camera_role == CameraRole.WITNESS
        assert not envelope.is_from_judge()
    
    def test_convert_with_entrypoint(self):
        """测试关联入口点"""
        signal = make_mock_signal()
        
        envelope = convert_camera_signal(signal, CameraRole.JUDGE, "ep_front")
        
        assert envelope.entrypoint_id == "ep_front"
    
    def test_pre_level_high_confidence(self):
        """测试高置信度 → L2"""
        signal = make_mock_signal(confidence=0.90)
        envelope = convert_camera_signal(signal, CameraRole.JUDGE)
        
        assert envelope.level == PreLevel.L2
    
    def test_pre_level_medium_confidence(self):
        """测试中等置信度 → L1"""
        signal = make_mock_signal(confidence=0.75)
        envelope = convert_camera_signal(signal, CameraRole.JUDGE)
        
        assert envelope.level == PreLevel.L1
    
    def test_pre_level_low_confidence(self):
        """测试低置信度 → None"""
        signal = make_mock_signal(confidence=0.60)
        envelope = convert_camera_signal(signal, CameraRole.JUDGE)
        
        assert envelope.level is None
    
    def test_preserves_bbox(self):
        """测试保留检测框"""
        signal = make_mock_signal()
        envelope = convert_camera_signal(signal, CameraRole.JUDGE)
        
        assert "bbox" in envelope.attributes
        assert envelope.attributes["bbox"] == (100, 200, 50, 100)


class TestCameraSignalAdapter:
    """测试 Camera 信号适配器"""
    
    def test_configure_camera(self):
        """测试配置摄像头"""
        adapter = CameraSignalAdapter()
        
        adapter.configure_camera("cam_front", CameraRole.JUDGE, "ep_front")
        adapter.configure_camera("cam_blink", CameraRole.WITNESS)
        
        assert adapter.get_camera_config("cam_front").role == CameraRole.JUDGE
        assert adapter.get_camera_config("cam_blink").role == CameraRole.WITNESS
        assert adapter.get_camera_config("unknown") is None
    
    def test_convert_configured_camera(self):
        """测试转换已配置的摄像头信号"""
        adapter = CameraSignalAdapter()
        adapter.configure_camera("cam_front", CameraRole.JUDGE, "ep_front")
        
        signal = make_mock_signal(sensor_id="cam_front")
        envelope = adapter.convert(signal)
        
        assert envelope.camera_role == CameraRole.JUDGE
        assert envelope.entrypoint_id == "ep_front"
    
    def test_convert_unconfigured_camera_defaults_to_judge(self):
        """测试未配置的摄像头默认为 JUDGE"""
        adapter = CameraSignalAdapter()
        
        signal = make_mock_signal(sensor_id="unknown_cam")
        envelope = adapter.convert(signal)
        
        assert envelope.camera_role == CameraRole.JUDGE
        assert adapter.stats["unknown_cameras"] == 1
    
    def test_stats(self):
        """测试统计信息"""
        adapter = CameraSignalAdapter()
        adapter.configure_camera("cam1", CameraRole.JUDGE)
        adapter.configure_camera("cam2", CameraRole.WITNESS)
        
        signal1 = make_mock_signal(sensor_id="cam1")
        signal2 = make_mock_signal(sensor_id="cam2")
        
        adapter.convert(signal1)
        adapter.convert(signal2)
        
        stats = adapter.get_stats()
        assert stats["signals_received"] == 2
        assert stats["signals_converted"] == 2
        assert stats["judge_cameras"] == 1
        assert stats["witness_cameras"] == 1


class TestCameraRoleConfig:
    """测试角色配置"""
    
    def test_default_role_is_judge(self):
        """测试默认角色是 JUDGE"""
        config = CameraRoleConfig(camera_id="test")
        assert config.role == CameraRole.JUDGE
    
    def test_witness_role(self):
        """测试 WITNESS 角色"""
        config = CameraRoleConfig(camera_id="test", role=CameraRole.WITNESS)
        assert config.role == CameraRole.WITNESS
