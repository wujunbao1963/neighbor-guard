"""
Tests for Evidence Policy
"""

import pytest

from ng_edge.state.states import ThreatState
from ng_edge.action.evidence import (
    EvidencePolicy,
    EvidencePolicyConfig,
    EvidenceType,
    EvidenceStatus,
    EvidencePriority,
    EvidenceRequest,
)


class TestEvidencePolicyBasic:
    """基础测试"""
    
    def test_create_policy(self):
        """测试创建策略"""
        policy = EvidencePolicy()
        assert policy.config is not None
    
    def test_custom_config(self):
        """测试自定义配置"""
        config = EvidencePolicyConfig(
            collect_on_pre_l1=True,
            triggered_clip_duration_sec=120,
        )
        policy = EvidencePolicy(config)
        
        assert policy.config.collect_on_pre_l1
        assert policy.config.triggered_clip_duration_sec == 120


class TestEvidenceCollection:
    """证据收集测试"""
    
    def test_no_collect_on_none(self):
        """测试 NONE 状态不收集"""
        policy = EvidencePolicy()
        
        requests = policy.on_state_change(
            incident_id="inc_001",
            new_threat=ThreatState.NONE,
            devices=["cam_front"],
        )
        
        assert len(requests) == 0
    
    def test_no_collect_on_pre_l1_default(self):
        """测试默认 PRE_L1 不收集"""
        policy = EvidencePolicy()
        
        requests = policy.on_state_change(
            incident_id="inc_001",
            new_threat=ThreatState.PRE_L1,
            devices=["cam_front"],
        )
        
        assert len(requests) == 0
    
    def test_collect_on_pre_l2(self):
        """测试 PRE_L2 收集 snapshot"""
        policy = EvidencePolicy()
        
        requests = policy.on_state_change(
            incident_id="inc_001",
            new_threat=ThreatState.PRE_L2,
            devices=["cam_front"],
        )
        
        assert len(requests) == 1
        assert requests[0].evidence_type == EvidenceType.SNAPSHOT
    
    def test_collect_on_triggered(self):
        """测试 TRIGGERED 收集多种证据"""
        policy = EvidencePolicy()
        
        requests = policy.on_state_change(
            incident_id="inc_001",
            new_threat=ThreatState.TRIGGERED,
            devices=["cam_front"],
        )
        
        types = {r.evidence_type for r in requests}
        
        assert EvidenceType.SNAPSHOT in types
        assert EvidenceType.VIDEO_CLIP in types
    
    def test_collect_from_multiple_devices(self):
        """测试多设备收集"""
        policy = EvidencePolicy()
        
        requests = policy.on_state_change(
            incident_id="inc_001",
            new_threat=ThreatState.PRE_L2,
            devices=["cam_front", "cam_back", "cam_side"],
        )
        
        # 每个设备一个 snapshot
        assert len(requests) == 3
        assert all(r.evidence_type == EvidenceType.SNAPSHOT for r in requests)


class TestEvidencePriority:
    """优先级测试"""
    
    def test_triggered_is_critical(self):
        """测试 TRIGGERED 优先级为 CRITICAL"""
        policy = EvidencePolicy()
        
        requests = policy.on_state_change(
            incident_id="inc_001",
            new_threat=ThreatState.TRIGGERED,
            devices=["cam_front"],
        )
        
        assert all(r.priority == EvidencePriority.CRITICAL for r in requests)
    
    def test_pending_is_high(self):
        """测试 PENDING 优先级为 HIGH"""
        policy = EvidencePolicy()
        
        requests = policy.on_state_change(
            incident_id="inc_001",
            new_threat=ThreatState.PENDING,
            devices=["cam_front"],
        )
        
        assert all(r.priority == EvidencePriority.HIGH for r in requests)
    
    def test_pre_is_low(self):
        """测试 PRE 优先级为 LOW"""
        policy = EvidencePolicy()
        
        requests = policy.on_state_change(
            incident_id="inc_001",
            new_threat=ThreatState.PRE_L2,
            devices=["cam_front"],
        )
        
        assert all(r.priority == EvidencePriority.LOW for r in requests)


class TestEvidenceClipDuration:
    """视频片段时长测试"""
    
    def test_pre_clip_duration(self):
        """测试 PRE 阶段片段时长"""
        policy = EvidencePolicy()
        
        duration = policy.get_clip_duration(ThreatState.PRE_L2)
        
        assert duration == policy.config.pre_clip_duration_sec
    
    def test_triggered_clip_duration(self):
        """测试 TRIGGERED 片段时长"""
        policy = EvidencePolicy()
        
        duration = policy.get_clip_duration(ThreatState.TRIGGERED)
        
        assert duration == policy.config.triggered_clip_duration_sec


class TestEvidenceStatusUpdate:
    """状态更新测试"""
    
    def test_update_to_local(self):
        """测试更新为本地完成"""
        policy = EvidencePolicy()
        
        requests = policy.on_state_change(
            incident_id="inc_001",
            new_threat=ThreatState.PRE_L2,
            devices=["cam_front"],
        )
        
        request = requests[0]
        
        policy.update_status(
            request_id=request.request_id,
            status=EvidenceStatus.LOCAL,
            local_path="/tmp/snapshot_001.jpg",
            file_size=102400,
        )
        
        assert request.status == EvidenceStatus.LOCAL
        assert request.local_path == "/tmp/snapshot_001.jpg"
        assert request.file_size_bytes == 102400
    
    def test_update_to_uploaded(self):
        """测试更新为已上传"""
        policy = EvidencePolicy()
        
        requests = policy.on_state_change(
            incident_id="inc_001",
            new_threat=ThreatState.PRE_L2,
            devices=["cam_front"],
        )
        
        request = requests[0]
        
        policy.update_status(
            request_id=request.request_id,
            status=EvidenceStatus.UPLOADED,
            cloud_url="https://storage.example.com/snapshot_001.jpg",
        )
        
        assert request.status == EvidenceStatus.UPLOADED
        assert policy.stats["requests_completed"] == 1
    
    def test_update_to_failed(self):
        """测试更新为失败"""
        policy = EvidencePolicy()
        
        requests = policy.on_state_change(
            incident_id="inc_001",
            new_threat=ThreatState.PRE_L2,
            devices=["cam_front"],
        )
        
        request = requests[0]
        
        policy.update_status(
            request_id=request.request_id,
            status=EvidenceStatus.FAILED,
        )
        
        assert request.status == EvidenceStatus.FAILED
        assert policy.stats["requests_failed"] == 1


class TestEvidenceRetrieval:
    """证据检索测试"""
    
    def test_get_pending_requests(self):
        """测试获取待处理请求"""
        policy = EvidencePolicy()
        
        policy.on_state_change(
            incident_id="inc_001",
            new_threat=ThreatState.PRE_L2,
            devices=["cam_front"],
        )
        
        pending = policy.get_pending_requests()
        
        assert len(pending) == 1
    
    def test_get_pending_by_incident(self):
        """测试按事件获取待处理请求"""
        policy = EvidencePolicy()
        
        policy.on_state_change(
            incident_id="inc_001",
            new_threat=ThreatState.PRE_L2,
            devices=["cam_front"],
        )
        policy.on_state_change(
            incident_id="inc_002",
            new_threat=ThreatState.PRE_L2,
            devices=["cam_back"],
        )
        
        pending = policy.get_pending_requests("inc_001")
        
        assert len(pending) == 1
        assert pending[0].incident_id == "inc_001"
    
    def test_get_requests_by_incident_includes_completed(self):
        """测试获取事件请求包括已完成"""
        policy = EvidencePolicy()
        
        requests = policy.on_state_change(
            incident_id="inc_001",
            new_threat=ThreatState.PRE_L2,
            devices=["cam_front"],
        )
        
        # 完成一个
        policy.update_status(
            request_id=requests[0].request_id,
            status=EvidenceStatus.UPLOADED,
        )
        
        all_requests = policy.get_requests_by_incident("inc_001")
        
        assert len(all_requests) == 1
        assert all_requests[0].status == EvidenceStatus.UPLOADED


class TestEvidenceUploadPolicy:
    """上传策略测试"""
    
    def test_should_upload_on_triggered(self):
        """测试 TRIGGERED 时应该上传"""
        policy = EvidencePolicy()
        
        assert policy.should_upload(ThreatState.TRIGGERED)
    
    def test_should_not_upload_on_pre(self):
        """测试 PRE 时不应该上传"""
        policy = EvidencePolicy()
        
        assert not policy.should_upload(ThreatState.PRE_L2)


class TestEvidenceCallbacks:
    """回调测试"""
    
    def test_on_request_created(self):
        """测试创建回调"""
        policy = EvidencePolicy()
        created = []
        policy.on_request_created = lambda r: created.append(r)
        
        policy.on_state_change(
            incident_id="inc_001",
            new_threat=ThreatState.PRE_L2,
            devices=["cam_front"],
        )
        
        assert len(created) == 1
    
    def test_on_request_completed(self):
        """测试完成回调"""
        policy = EvidencePolicy()
        completed = []
        policy.on_request_completed = lambda r: completed.append(r)
        
        requests = policy.on_state_change(
            incident_id="inc_001",
            new_threat=ThreatState.PRE_L2,
            devices=["cam_front"],
        )
        
        policy.update_status(
            request_id=requests[0].request_id,
            status=EvidenceStatus.UPLOADED,
        )
        
        assert len(completed) == 1


class TestEvidenceStats:
    """统计测试"""
    
    def test_stats_tracking(self):
        """测试统计跟踪"""
        policy = EvidencePolicy()
        
        requests = policy.on_state_change(
            incident_id="inc_001",
            new_threat=ThreatState.PRE_L2,
            devices=["cam_front"],
        )
        
        policy.update_status(
            request_id=requests[0].request_id,
            status=EvidenceStatus.UPLOADED,
        )
        
        stats = policy.get_stats()
        
        assert stats["requests_created"] == 1
        assert stats["requests_completed"] == 1
        assert stats["snapshots_collected"] == 1
