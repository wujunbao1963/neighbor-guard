#!/usr/bin/env python3
"""
置信度阈值测试 - 找到 L1 区域最佳参数

用法：
    # 实时测试，对比多个阈值
    python3 test_conf_threshold.py --rtsp 'rtsp://admin:XXX@10.0.0.155:554/h264Preview_01_sub'
    
    # 指定测试的阈值范围
    python3 test_conf_threshold.py --rtsp 'rtsp://...' --conf-list 0.3,0.4,0.5,0.6
    
    # 使用不同模型
    python3 test_conf_threshold.py --rtsp 'rtsp://...' --model yolo11s.pt

输出：
    - 实时显示每个阈值的检测情况
    - 统计 L1/L2 区域的检测率
    - 帮助找到远距离检测的最佳阈值
"""

import argparse
import cv2
import time
from datetime import datetime
from collections import defaultdict
from ultralytics import YOLO


class ConfThresholdTester:
    def __init__(self, model_path: str, door_y: int = 400):
        print(f"[YOLO] 加载模型: {model_path}")
        self.model = YOLO(model_path)
        print("[YOLO] 模型已加载")
        self.door_y = door_y
        
        # 统计数据
        self.stats = defaultdict(lambda: {
            'L1': {'detections': 0, 'total_conf': 0.0, 'min_conf': 1.0, 'max_conf': 0.0},
            'L2': {'detections': 0, 'total_conf': 0.0, 'min_conf': 1.0, 'max_conf': 0.0},
        })
        self.frame_count = 0
    
    def detect_all_confs(self, frame, conf_list: list) -> dict:
        """
        用最低阈值检测一次，然后按不同阈值过滤结果
        这样可以公平对比不同阈值
        """
        min_conf = min(conf_list)
        results = self.model(frame, verbose=False, conf=min_conf)
        
        # 收集所有 person 检测
        all_detections = []
        for r in results:
            for box in r.boxes:
                cls_id = int(box.cls[0])
                if self.model.names[cls_id] == "person":
                    conf = float(box.conf[0])
                    bbox = [int(v) for v in box.xyxy[0].tolist()]
                    x1, y1, x2, y2 = bbox
                    
                    # 分区判断
                    level = 2 if y2 >= self.door_y else 1
                    zone = "L2" if level == 2 else "L1"
                    
                    all_detections.append({
                        'bbox': bbox,
                        'conf': conf,
                        'y2': y2,
                        'zone': zone,
                        'level': level,
                    })
        
        # 按不同阈值过滤
        results_by_conf = {}
        for conf_thresh in conf_list:
            filtered = [d for d in all_detections if d['conf'] >= conf_thresh]
            results_by_conf[conf_thresh] = filtered
            
            # 更新统计
            for det in filtered:
                zone = det['zone']
                self.stats[conf_thresh][zone]['detections'] += 1
                self.stats[conf_thresh][zone]['total_conf'] += det['conf']
                self.stats[conf_thresh][zone]['min_conf'] = min(
                    self.stats[conf_thresh][zone]['min_conf'], det['conf'])
                self.stats[conf_thresh][zone]['max_conf'] = max(
                    self.stats[conf_thresh][zone]['max_conf'], det['conf'])
        
        return results_by_conf, all_detections
    
    def run_test(self, rtsp_url: str, conf_list: list, duration: int = 60):
        """运行测试"""
        print(f"\n[RTSP] 连接: {rtsp_url}")
        cap = cv2.VideoCapture(rtsp_url)
        if not cap.isOpened():
            print("[ERROR] 无法连接 RTSP")
            return
        
        w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        print(f"[INFO] 分辨率: {w}x{h}")
        print(f"[INFO] door_y = {self.door_y} (y2 >= {self.door_y} → L2)")
        print(f"[INFO] 测试阈值: {conf_list}")
        print(f"[INFO] 测试时长: {duration} 秒")
        print(f"[INFO] 按 'q' 提前退出, 's' 打印当前统计")
        print()
        
        # 打开日志文件
        log_file = open("conf_threshold_test.txt", "w")
        log_file.write(f"=== 置信度阈值测试 ===\n")
        log_file.write(f"时间: {datetime.now()}\n")
        log_file.write(f"分辨率: {w}x{h}, door_y: {self.door_y}\n")
        log_file.write(f"测试阈值: {conf_list}\n")
        log_file.write(f"{'='*80}\n\n")
        
        start_time = time.time()
        self.frame_count = 0
        last_print_time = start_time
        
        try:
            while time.time() - start_time < duration:
                ret, frame = cap.read()
                if not ret:
                    continue
                
                self.frame_count += 1
                if self.frame_count % 5 != 0:  # 每 5 帧处理一次
                    continue
                
                # 检测
                results_by_conf, all_dets = self.detect_all_confs(frame, conf_list)
                
                # 实时输出（每秒一次）
                now = time.time()
                if now - last_print_time >= 1.0:
                    last_print_time = now
                    elapsed = now - start_time
                    
                    # 构建输出行
                    time_str = datetime.now().strftime("%H:%M:%S")
                    
                    if all_dets:
                        # 有检测，显示详情
                        for det in all_dets:
                            line = f"[{time_str}] y2={det['y2']:3d} conf={det['conf']:.2f} → {det['zone']}"
                            
                            # 显示哪些阈值能检测到
                            detected_by = [f"{c}" for c in conf_list if det['conf'] >= c]
                            line += f"  (detected by: {', '.join(detected_by)})"
                            
                            print(line)
                            log_file.write(line + "\n")
                    else:
                        # 无检测
                        line = f"[{time_str}] -- no detection --"
                        print(line)
                        log_file.write(line + "\n")
                    
                    log_file.flush()
                
                # 可视化（可选）
                vis_frame = frame.copy()
                cv2.line(vis_frame, (0, self.door_y), (w, self.door_y), (0, 0, 255), 2)
                cv2.putText(vis_frame, f"door_y={self.door_y} (L2 above)", (10, self.door_y - 10),
                           cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 0, 255), 2)
                
                # 绘制检测框
                for det in all_dets:
                    x1, y1, x2, y2 = det['bbox']
                    color = (0, 0, 255) if det['zone'] == 'L2' else (0, 255, 255)
                    cv2.rectangle(vis_frame, (x1, y1), (x2, y2), color, 2)
                    label = f"{det['zone']} conf={det['conf']:.2f}"
                    cv2.putText(vis_frame, label, (x1, y1-5), 
                               cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 2)
                
                # 显示统计
                y_pos = 30
                for conf_thresh in conf_list:
                    l1 = self.stats[conf_thresh]['L1']['detections']
                    l2 = self.stats[conf_thresh]['L2']['detections']
                    cv2.putText(vis_frame, f"conf>={conf_thresh}: L1={l1} L2={l2}",
                               (10, y_pos), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255,255,255), 1)
                    y_pos += 20
                
                cv2.imshow("Conf Threshold Test (q=quit, s=stats)", vis_frame)
                
                key = cv2.waitKey(1) & 0xFF
                if key == ord('q'):
                    break
                elif key == ord('s'):
                    self.print_stats()
        
        except KeyboardInterrupt:
            print("\n[INFO] 手动停止")
        
        finally:
            cap.release()
            cv2.destroyAllWindows()
            
            # 打印最终统计
            self.print_stats()
            
            # 写入日志
            log_file.write("\n" + "="*80 + "\n")
            log_file.write(self.get_stats_text())
            log_file.close()
            print("\n[INFO] 日志已保存到 conf_threshold_test.txt")
    
    def print_stats(self):
        """打印统计结果"""
        print("\n" + self.get_stats_text())
    
    def get_stats_text(self) -> str:
        """生成统计文本"""
        lines = []
        lines.append("=" * 80)
        lines.append("统计结果")
        lines.append("=" * 80)
        lines.append(f"总帧数: {self.frame_count}, 处理帧数: {self.frame_count // 5}")
        lines.append("")
        
        # 表头
        lines.append(f"{'阈值':<8} | {'L1检测':<10} | {'L2检测':<10} | {'L1平均conf':<12} | {'L2平均conf':<12}")
        lines.append("-" * 70)
        
        for conf_thresh in sorted(self.stats.keys()):
            l1 = self.stats[conf_thresh]['L1']
            l2 = self.stats[conf_thresh]['L2']
            
            l1_avg = l1['total_conf'] / l1['detections'] if l1['detections'] > 0 else 0
            l2_avg = l2['total_conf'] / l2['detections'] if l2['detections'] > 0 else 0
            
            lines.append(f"{conf_thresh:<8} | {l1['detections']:<10} | {l2['detections']:<10} | {l1_avg:<12.3f} | {l2_avg:<12.3f}")
        
        lines.append("")
        lines.append("详细统计:")
        for conf_thresh in sorted(self.stats.keys()):
            l1 = self.stats[conf_thresh]['L1']
            l2 = self.stats[conf_thresh]['L2']
            lines.append(f"\nconf >= {conf_thresh}:")
            if l1['detections'] > 0:
                lines.append(f"  L1: {l1['detections']} 次, conf range [{l1['min_conf']:.2f}, {l1['max_conf']:.2f}]")
            else:
                lines.append(f"  L1: 0 次")
            if l2['detections'] > 0:
                lines.append(f"  L2: {l2['detections']} 次, conf range [{l2['min_conf']:.2f}, {l2['max_conf']:.2f}]")
            else:
                lines.append(f"  L2: 0 次")
        
        lines.append("")
        lines.append("=" * 80)
        
        # 建议
        lines.append("\n建议:")
        
        # 找到 L1 检测最多的阈值
        best_l1_thresh = None
        best_l1_count = 0
        for conf_thresh in self.stats:
            l1_count = self.stats[conf_thresh]['L1']['detections']
            if l1_count > best_l1_count:
                best_l1_count = l1_count
                best_l1_thresh = conf_thresh
        
        if best_l1_thresh:
            lines.append(f"  - L1 区域最佳阈值: {best_l1_thresh} ({best_l1_count} 次检测)")
        
        # 检查 L2 是否稳定
        l2_counts = [self.stats[c]['L2']['detections'] for c in self.stats]
        if l2_counts and max(l2_counts) > 0:
            l2_variance = max(l2_counts) - min(l2_counts)
            lines.append(f"  - L2 区域检测差异: {l2_variance} (各阈值间)")
        
        return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser(description="置信度阈值测试")
    parser.add_argument("--rtsp", required=True, help="RTSP URL")
    parser.add_argument("--door-y", type=int, default=400, help="door 分界线 (默认 400)")
    parser.add_argument("--model", default="yolo11n.pt", help="YOLO 模型")
    parser.add_argument("--duration", type=int, default=60, help="测试时长(秒)")
    parser.add_argument("--conf-list", default="0.25,0.30,0.35,0.40,0.45,0.50",
                       help="逗号分隔的阈值列表")
    args = parser.parse_args()
    
    # 解析阈值列表
    conf_list = [float(c.strip()) for c in args.conf_list.split(",")]
    
    tester = ConfThresholdTester(args.model, args.door_y)
    tester.run_test(args.rtsp, conf_list, args.duration)


if __name__ == "__main__":
    main()
