"""
NG Edge Cloud Integration

Handles communication with NeighborGuard Cloud Server:
- Device registration (pairing)
- Event ingest
- Evidence upload
"""

from .config import CloudConfig, DeviceCredentials
from .client import CloudClient

__all__ = [
    "CloudConfig",
    "DeviceCredentials", 
    "CloudClient",
]
