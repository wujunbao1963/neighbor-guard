#!/usr/bin/env python3
"""
威慑系统独立测试 - 模拟 L0/L1/L2/无人 混合信号

测试场景：
1. 连续 L1 信号 - 灯应该常亮
2. L1 → L2 切换 - 应该立即切换到闪灯
3. L2 → L1 切换 - 应该切换回常亮
4. L1 → L0 - L0 不触发威慑，但不停止现有威慑
5. L1 → 无人 - 超时后停止威慑
6. 信号停止 - 应该关灯

用法：
    python3 test_deterrent.py
"""

import asyncio
import time
import logging

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s.%(msecs)03d [%(levelname)s] %(message)s',
    datefmt='%H:%M:%S'
)
logger = logging.getLogger(__name__)


class MockDeterrentSystem:
    """模拟威慑系统（与 edge_runtime 相同的逻辑）"""
    
    # 威慑参数
    PRE_L1_SIREN_INTERVAL = 5  # 测试用，缩短为5秒
    PRE_L1_SIREN_DURATION = 1
    PRE_L2_FLASH_ON = 2        # 测试用，缩短周期
    PRE_L2_FLASH_OFF = 2
    PRE_L2_SIREN_INTERVAL = 3
    PRE_L2_SIREN_DURATION = 1
    
    def __init__(self):
        self._deterrent_active = False
        self._deterrent_level = None
        self._deterrent_task = None
        self._deterrent_generation = 0  # 防止竞争条件
        self.running = True
        
        # 统计
        self.light_on_count = 0
        self.light_off_count = 0
        self.siren_count = 0
        self.light_state = False
    
    def _start_deterrent(self, level: str):
        """启动威慑"""
        # 同级别不重复启动
        if self._deterrent_level == level and self._deterrent_active:
            logger.debug(f"[DETERRENT] 同级别 {level}，跳过")
            return
        
        # 递增 generation
        self._deterrent_generation += 1
        new_gen = self._deterrent_generation
        
        # 级别变化：先停止任务
        if self._deterrent_active:
            old_level = self._deterrent_level
            logger.info(f"[DETERRENT] 取消 {old_level} → 准备启动 {level} (gen={new_gen})")
            self._deterrent_active = False
            if self._deterrent_task:
                self._deterrent_task.cancel()
                self._deterrent_task = None
        
        self._deterrent_active = True
        self._deterrent_level = level
        
        # 启动威慑任务
        self._deterrent_task = asyncio.create_task(self._deterrent_loop(level))
        logger.warning(f"[DETERRENT] 🚨 启动 {level} 威慑 (gen={new_gen})")
    
    def _stop_deterrent(self, reason: str = "unknown"):
        """停止威慑"""
        if not self._deterrent_active and self._deterrent_level is None:
            return
        
        logger.info(f"[DETERRENT] 停止威慑 level={self._deterrent_level} reason={reason}")
        self._deterrent_generation += 1  # 让旧任务的循环条件失效
        self._deterrent_active = False
        self._deterrent_level = None
        
        if self._deterrent_task:
            self._deterrent_task.cancel()
            self._deterrent_task = None
        
        # 关闭所有声光
        asyncio.create_task(self._deactivate_alarm())
    
    async def _deterrent_loop(self, level: str):
        """威慑循环"""
        start_time = time.time()
        last_siren_time = -999
        my_generation = self._deterrent_generation  # 记录启动时的代数
        
        try:
            if level == "L1":
                logger.warning(f"[DETERRENT] 💡 L1: 常亮灯 + 每{self.PRE_L1_SIREN_INTERVAL}s警报 (gen={my_generation})")
                await self._spotlight_on()
                
                # 立即触发第一次警报
                await self._trigger_siren(self.PRE_L1_SIREN_DURATION)
                last_siren_time = 0
                
                # 使用 generation 检查
                while my_generation == self._deterrent_generation and self.running:
                    elapsed = time.time() - start_time
                    elapsed_int = int(elapsed)
                    
                    # 警报逻辑
                    if elapsed_int % self.PRE_L1_SIREN_INTERVAL == 0 and elapsed_int != last_siren_time and elapsed_int > 0:
                        last_siren_time = elapsed_int
                        await self._trigger_siren(self.PRE_L1_SIREN_DURATION)
                    
                    await asyncio.sleep(0.5)
                    
            elif level in ("L2", "L3"):
                logger.warning(f"[DETERRENT] 💡 {level}: 闪灯 + 每{self.PRE_L2_SIREN_INTERVAL}s警报 (gen={my_generation})")
                
                await self._trigger_siren(self.PRE_L2_SIREN_DURATION)
                last_siren_time = 0
                light_on = False
                
                # 使用 generation 检查
                while my_generation == self._deterrent_generation and self.running:
                    elapsed = time.time() - start_time
                    elapsed_int = int(elapsed)
                    
                    # 闪灯逻辑
                    cycle_time = self.PRE_L2_FLASH_ON + self.PRE_L2_FLASH_OFF
                    pos_in_cycle = elapsed % cycle_time
                    should_be_on = pos_in_cycle < self.PRE_L2_FLASH_ON
                    
                    if should_be_on != light_on:
                        light_on = should_be_on
                        if light_on:
                            await self._spotlight_on()
                        else:
                            await self._spotlight_off()
                    
                    # 警报逻辑
                    if elapsed_int % self.PRE_L2_SIREN_INTERVAL == 0 and elapsed_int != last_siren_time and elapsed_int > 0:
                        last_siren_time = elapsed_int
                        await self._trigger_siren(self.PRE_L2_SIREN_DURATION)
                    
                    await asyncio.sleep(0.2)
        
        except asyncio.CancelledError:
            logger.info(f"[DETERRENT] {level} 威慑循环已取消")
        except Exception as e:
            logger.error(f"[DETERRENT] {level} 威慑循环异常: {e}")
        finally:
            # 注意：不修改 _deterrent_active，避免竞争条件！
            if self._deterrent_level is None:
                await self._spotlight_off()
    
    async def _spotlight_on(self):
        self.light_on_count += 1
        self.light_state = True
        logger.info(f"[LIGHT] 💡 ON (count={self.light_on_count})")
    
    async def _spotlight_off(self):
        self.light_off_count += 1
        self.light_state = False
        logger.info(f"[LIGHT] 💡 OFF (count={self.light_off_count})")
    
    async def _trigger_siren(self, duration):
        self.siren_count += 1
        logger.info(f"[SIREN] 🔔 警报 {duration}s (count={self.siren_count})")
    
    async def _deactivate_alarm(self):
        logger.info("[DETERRENT] 关闭声光")
        await self._spotlight_off()


async def test_continuous_l1():
    """测试1: 连续 L1 信号，灯应该保持常亮"""
    print("\n" + "="*60)
    print("测试1: 连续 L1 信号")
    print("="*60)
    
    system = MockDeterrentSystem()
    
    # 模拟连续 L1 检测（每 0.2 秒一次，共 3 秒）
    for i in range(15):
        system._start_deterrent("L1")
        await asyncio.sleep(0.2)
    
    # 等待一下看警报
    await asyncio.sleep(2)
    
    system._stop_deterrent(reason="test_end")
    await asyncio.sleep(0.5)
    
    print(f"\n结果: light_on={system.light_on_count} light_off={system.light_off_count} siren={system.siren_count}")
    print(f"预期: light_on=1 (常亮) light_off=1 (停止时) siren>=1")
    
    if system.light_on_count == 1:
        print("✅ 通过：灯只开了一次（常亮）")
        return True
    else:
        print(f"❌ 失败：灯开了 {system.light_on_count} 次（应该只开一次）")
        return False


async def test_l1_to_l2_switch():
    """测试2: L1 → L2 切换"""
    print("\n" + "="*60)
    print("测试2: L1 → L2 切换")
    print("="*60)
    
    system = MockDeterrentSystem()
    
    # L1 运行 2 秒
    system._start_deterrent("L1")
    await asyncio.sleep(2)
    
    print("\n--- 切换到 L2 ---\n")
    
    # 切换到 L2
    system._start_deterrent("L2")
    await asyncio.sleep(3)
    
    system._stop_deterrent(reason="test_end")
    await asyncio.sleep(0.5)
    
    print(f"\n结果: light_on={system.light_on_count} light_off={system.light_off_count} siren={system.siren_count}")
    print(f"预期: light_on>=2 (L1常亮 + L2闪灯) light_off>=1 siren>=2")
    
    # L2 应该有闪灯
    if system.light_on_count >= 2 and system.light_off_count >= 1:
        print("✅ 通过：L2 闪灯正常")
        return True
    else:
        print("❌ 失败：L2 闪灯异常")
        return False


async def test_l1_to_l0():
    """测试3: L1 → L0（L0 不触发威慑，但不应该停止现有威慑）"""
    print("\n" + "="*60)
    print("测试3: L1 → L0（L0 信号不影响现有威慑）")
    print("="*60)
    
    system = MockDeterrentSystem()
    
    # L1 启动
    system._start_deterrent("L1")
    await asyncio.sleep(1)
    
    print("\n--- 发送 L0 信号（不应该影响威慑）---\n")
    
    # L0 不调用 _start_deterrent，因为代码里 L0 被忽略
    # 这里模拟：L0 不做任何操作
    # system._start_deterrent("L0")  # 不调用！
    
    await asyncio.sleep(2)
    
    # 检查威慑是否还在运行
    is_active = system._deterrent_active
    level = system._deterrent_level
    light = system.light_state
    
    print(f"威慑状态: active={is_active} level={level} light={light}")
    
    system._stop_deterrent(reason="test_end")
    await asyncio.sleep(0.5)
    
    if is_active and level == "L1" and light:
        print("✅ 通过：L0 信号不影响现有 L1 威慑")
        return True
    else:
        print("❌ 失败：L0 信号错误地停止了威慑")
        return False


async def test_l1_to_no_person():
    """测试4: L1 → 无人（超时后停止威慑）"""
    print("\n" + "="*60)
    print("测试4: L1 → 无人（模拟 PERSON LEAVE 超时）")
    print("="*60)
    
    system = MockDeterrentSystem()
    
    # L1 启动
    system._start_deterrent("L1")
    await asyncio.sleep(1)
    
    print("\n--- 模拟无人检测，触发超时停止 ---\n")
    
    # 模拟 PERSON LEAVE 超时
    system._stop_deterrent(reason="person_leave_timeout")
    await asyncio.sleep(0.5)
    
    # 检查威慑是否已停止
    is_active = system._deterrent_active
    level = system._deterrent_level
    light = system.light_state
    
    print(f"威慑状态: active={is_active} level={level} light={light}")
    
    if not is_active and level is None and not light:
        print("✅ 通过：无人后威慑正确停止")
        return True
    else:
        print("❌ 失败：无人后威慑未正确停止")
        return False


async def test_rapid_same_level():
    """测试5: 快速重复同级别信号（模拟连续检测）"""
    print("\n" + "="*60)
    print("测试5: 快速重复 L1 信号（竞争条件测试）")
    print("="*60)
    
    system = MockDeterrentSystem()
    
    # 快速连续发送 L1（模拟每帧检测）
    for i in range(50):
        system._start_deterrent("L1")
        await asyncio.sleep(0.05)  # 50ms 间隔，模拟 20fps
    
    # 检查灯是否还亮着
    await asyncio.sleep(1)
    
    print(f"\n灯状态: {'亮' if system.light_state else '灭'}")
    print(f"_deterrent_active: {system._deterrent_active}")
    print(f"_deterrent_level: {system._deterrent_level}")
    
    is_ok = system.light_state and system._deterrent_active
    
    system._stop_deterrent(reason="test_end")
    await asyncio.sleep(0.5)
    
    if is_ok:
        print("✅ 通过：快速重复信号后威慑仍在运行")
        return True
    else:
        print("❌ 失败：快速重复信号导致威慑停止")
        return False


async def test_mixed_signals():
    """测试6: 混合信号 L1 L1 L2 L2 L1 L1"""
    print("\n" + "="*60)
    print("测试6: 混合信号序列")
    print("="*60)
    
    system = MockDeterrentSystem()
    
    signals = ["L1", "L1", "L1", "L2", "L2", "L2", "L1", "L1", "L1"]
    
    for sig in signals:
        logger.info(f">>> 发送信号: {sig}")
        system._start_deterrent(sig)
        await asyncio.sleep(0.5)
    
    # 继续运行看警报
    await asyncio.sleep(3)
    
    system._stop_deterrent(reason="test_end")
    await asyncio.sleep(0.5)
    
    print(f"\n结果: light_on={system.light_on_count} light_off={system.light_off_count} siren={system.siren_count}")
    print("✅ 通过（检查日志确认切换正确）")
    return True


async def test_l1_noperson_l1():
    """测试7: L1 → 无人 → L1（重新进入）"""
    print("\n" + "="*60)
    print("测试7: L1 → 无人 → L1（重新进入）")
    print("="*60)
    
    system = MockDeterrentSystem()
    
    # 第一次 L1
    logger.info(">>> 第一次 L1 进入")
    system._start_deterrent("L1")
    await asyncio.sleep(1)
    
    # 无人
    logger.info(">>> 无人，超时停止")
    system._stop_deterrent(reason="person_leave_timeout")
    await asyncio.sleep(1)
    
    # 第二次 L1
    logger.info(">>> 第二次 L1 进入")
    system._start_deterrent("L1")
    await asyncio.sleep(2)
    
    # 检查
    is_active = system._deterrent_active
    level = system._deterrent_level
    
    system._stop_deterrent(reason="test_end")
    await asyncio.sleep(0.5)
    
    print(f"\n结果: light_on={system.light_on_count} siren={system.siren_count}")
    print(f"预期: light_on=2 (两次进入) siren=2 (两次警报)")
    
    if system.light_on_count == 2:
        print("✅ 通过：重新进入后威慑正确启动")
        return True
    else:
        print("❌ 失败：重新进入后威慑异常")
        return False


async def main():
    results = []
    
    results.append(("连续L1", await test_continuous_l1()))
    results.append(("L1→L2切换", await test_l1_to_l2_switch()))
    results.append(("L1→L0", await test_l1_to_l0()))
    results.append(("L1→无人", await test_l1_to_no_person()))
    results.append(("快速重复", await test_rapid_same_level()))
    results.append(("混合信号", await test_mixed_signals()))
    results.append(("L1→无人→L1", await test_l1_noperson_l1()))
    
    print("\n" + "="*60)
    print("测试汇总")
    print("="*60)
    for name, passed in results:
        status = "✅" if passed else "❌"
        print(f"  {status} {name}")


if __name__ == "__main__":
    asyncio.run(main())
