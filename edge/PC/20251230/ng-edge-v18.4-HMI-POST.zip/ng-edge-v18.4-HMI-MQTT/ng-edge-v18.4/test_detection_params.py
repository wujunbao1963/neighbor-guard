#!/usr/bin/env python3
"""
检测参数测试脚本

测试不同置信度阈值下的检测效果，帮助找到最佳参数。

用法:
    PYTHONPATH=src python3 test_detection_params.py --ip 192.168.1.100 --user admin --pass password
    PYTHONPATH=src python3 test_detection_params.py --ip 192.168.1.100 --user admin --pass password --conf 0.3
    PYTHONPATH=src python3 test_detection_params.py --ip 192.168.1.100 --user admin --pass password --duration 60
"""

import argparse
import time
import sys
from collections import defaultdict
from datetime import datetime

# 禁用输出缓冲
import functools
print = functools.partial(print, flush=True)

# 添加 src 到路径
sys.path.insert(0, 'src')

print("正在加载模块...")

try:
    from ng_edge.hardware.yolo_detector import YOLODetector
    from ng_edge.hardware.reolink_ultrawide import ReolinkUltrawideClient, CameraConfig, StreamType
    print("✅ 模块加载成功")
except ImportError as e:
    print(f"导入错误: {e}")
    print("请确保在 ng-edge-v18.4 目录下运行：")
    print("  cd ng-edge-v18.4")
    print("  PYTHONPATH=src python3 test_detection_params.py ...")
    sys.exit(1)


def test_detection(ip: str, username: str, password: str, 
                   conf_threshold: float = 0.5,
                   duration: int = 30,
                   door_threshold: float = 0.69,
                   verbose: bool = False):
    """
    测试检测效果
    
    Args:
        ip: 摄像头 IP
        username: 用户名
        password: 密码
        conf_threshold: 置信度阈值
        duration: 测试时长（秒）
        door_threshold: door 区域阈值
        verbose: 详细输出
    """
    print(f"\n{'='*60}")
    print(f"检测参数测试")
    print(f"{'='*60}")
    print(f"摄像头: {ip}")
    print(f"置信度阈值: {conf_threshold}")
    print(f"Door 阈值: {door_threshold}")
    print(f"测试时长: {duration}s")
    print(f"{'='*60}\n")
    
    # 连接摄像头
    config = CameraConfig(
        name="test_cam",
        ip=ip,
        username=username,
        password=password,
        stream_type=StreamType.SUB,
        use_tcp=True,
    )
    
    camera = ReolinkUltrawideClient(config)
    if not camera.connect():
        print("❌ 无法连接摄像头")
        return
    
    print(f"✅ 摄像头已连接 ({camera.actual_width}x{camera.actual_height})")
    frame_height = camera.actual_height or 576
    door_y = int(frame_height * door_threshold)
    print(f"   door_y = {door_y} (frame_height * {door_threshold})")
    
    # 初始化检测器
    try:
        detector = YOLODetector(
            model_name="yolo11n.pt",
            conf_threshold=conf_threshold,
            target_classes=["person"],
        )
        print(f"✅ YOLO 检测器已加载 (conf={conf_threshold})")
    except Exception as e:
        print(f"❌ YOLO 加载失败: {e}")
        camera.disconnect()
        return
    
    # 统计
    stats = {
        'total_frames': 0,
        'detected_frames': 0,
        'detections': [],  # [(timestamp, conf, y2, zone)]
        'zone_counts': defaultdict(int),
        'conf_histogram': defaultdict(int),  # 置信度分布
        'missed_frames': 0,  # 连续无检测帧数
        'max_missed': 0,
    }
    
    start_time = time.time()
    last_detection_time = start_time
    current_missed = 0
    
    print(f"\n开始测试 ({duration}s)...\n")
    print("时间       | 检测 | 置信度 | Y2  | 分区 | 备注")
    print("-" * 60)
    
    try:
        while time.time() - start_time < duration:
            ret, frame = camera.read_frame()
            if not ret or frame is None:
                time.sleep(0.1)
                continue
            
            stats['total_frames'] += 1
            
            # 检测
            detections, _ = detector.detect(frame, visualize=False)
            persons = [d for d in detections if d.class_name == "person"]
            
            now = time.time()
            timestamp = datetime.now().strftime("%H:%M:%S")
            
            if persons:
                stats['detected_frames'] += 1
                current_missed = 0
                last_detection_time = now
                
                for det in persons:
                    x, y, w, h = det.bbox
                    y2 = y + h
                    conf = det.confidence
                    
                    # 判断分区
                    if y2 >= door_y:
                        zone = "door"
                    else:
                        zone = "yard"
                    
                    stats['detections'].append((now, conf, y2, zone))
                    stats['zone_counts'][zone] += 1
                    
                    # 置信度分布（0.1 为步长）
                    conf_bucket = int(conf * 10) / 10
                    stats['conf_histogram'][conf_bucket] += 1
                    
                    if verbose or conf < 0.6:  # 低置信度时显示
                        note = "⚠️ 低置信度" if conf < 0.5 else ""
                        print(f"{timestamp} | ✓    | {conf:.2f}   | {y2:3d} | {zone:4s} | {note}")
            else:
                current_missed += 1
                stats['missed_frames'] += 1
                stats['max_missed'] = max(stats['max_missed'], current_missed)
                
                # 如果之前有检测，现在突然没有
                if now - last_detection_time > 1.0 and current_missed == 1:
                    print(f"{timestamp} | ✗    | -      | -   | -    | 检测丢失")
            
            time.sleep(0.1)  # 约 10 FPS
            
    except KeyboardInterrupt:
        print("\n\n[中断]")
    
    camera.disconnect()
    
    # 输出统计
    elapsed = time.time() - start_time
    print(f"\n{'='*60}")
    print("测试结果")
    print(f"{'='*60}")
    print(f"测试时长: {elapsed:.1f}s")
    print(f"总帧数: {stats['total_frames']}")
    print(f"检测帧数: {stats['detected_frames']} ({100*stats['detected_frames']/max(1,stats['total_frames']):.1f}%)")
    print(f"检测次数: {len(stats['detections'])}")
    print(f"最长丢失: {stats['max_missed']} 帧 (~{stats['max_missed']*0.1:.1f}s)")
    
    print(f"\n分区分布:")
    for zone, count in sorted(stats['zone_counts'].items()):
        pct = 100 * count / max(1, len(stats['detections']))
        print(f"  {zone}: {count} ({pct:.1f}%)")
    
    print(f"\n置信度分布:")
    for conf, count in sorted(stats['conf_histogram'].items()):
        pct = 100 * count / max(1, len(stats['detections']))
        bar = "█" * int(pct / 5)
        print(f"  {conf:.1f}-{conf+0.1:.1f}: {count:4d} ({pct:5.1f}%) {bar}")
    
    if stats['detections']:
        confs = [d[1] for d in stats['detections']]
        print(f"\n置信度统计:")
        print(f"  最低: {min(confs):.2f}")
        print(f"  最高: {max(confs):.2f}")
        print(f"  平均: {sum(confs)/len(confs):.2f}")
        
        # 计算不同阈值下的保留率
        print(f"\n不同阈值的保留率:")
        for thresh in [0.3, 0.4, 0.5, 0.6, 0.7]:
            kept = sum(1 for c in confs if c >= thresh)
            pct = 100 * kept / len(confs)
            bar = "█" * int(pct / 5)
            print(f"  conf >= {thresh}: {pct:5.1f}% {bar}")
    
    print(f"\n{'='*60}")
    print("建议:")
    if stats['detected_frames'] / max(1, stats['total_frames']) < 0.5:
        print("  ⚠️ 检测率低于 50%，建议降低置信度阈值")
    if stats['max_missed'] > 30:
        print("  ⚠️ 最长丢失超过 3 秒，可能影响威慑效果")
    if stats['conf_histogram']:
        low_conf = sum(c for k, c in stats['conf_histogram'].items() if k < 0.5)
        if low_conf > 0:
            print(f"  ℹ️ 有 {low_conf} 次检测置信度 < 0.5，当前阈值可能过低")
    print(f"{'='*60}")


def main():
    parser = argparse.ArgumentParser(description="检测参数测试")
    parser.add_argument("--ip", required=True, help="摄像头 IP")
    parser.add_argument("--user", default="admin", help="用户名")
    parser.add_argument("--password", "--pass", dest="password", required=True, help="密码")
    parser.add_argument("--conf", type=float, default=0.5, help="置信度阈值 (默认 0.5)")
    parser.add_argument("--duration", type=int, default=30, help="测试时长秒 (默认 30)")
    parser.add_argument("--door-threshold", type=float, default=0.69, help="Door 阈值 (默认 0.69)")
    parser.add_argument("-v", "--verbose", action="store_true", help="详细输出")
    
    args = parser.parse_args()
    
    test_detection(
        ip=args.ip,
        username=args.user,
        password=args.password,
        conf_threshold=args.conf,
        duration=args.duration,
        door_threshold=args.door_threshold,
        verbose=args.verbose,
    )


if __name__ == "__main__":
    main()
