# NeighborGuard Edge Architecture Spec v2 (Final)

> **Scope**: Edge-only design. Collaboration/circle workflows deferred.
> **Status**: Architecture-Frozen for Implementation

---

## 0. Design Principles

| # | Principle | Implication |
|---|-----------|-------------|
| P1 | **Signal ≠ Decision** | All detectors emit signals only. Only Incident State Machine may change state or execute actions. |
| P2 | **Single Incident per Lease** | For `(home, zone, entrypoint)`, at most one active incident within time window. |
| P3 | **Soft vs Hard Isolation** | Camera PRE (soft) cannot directly trigger PENDING/TRIGGERED unless explicitly allowed by policy. |
| P4 | **Edge Survivability** | Under resource pressure: sample/drop soft signals, never drop hard triggers. |
| P5 | **Idempotency Everywhere** | All processing must be idempotent on `signal_id`. At-least-once delivery assumed. |

---

## 1. Signal Layer

### 1.1 Signal Envelope (Unified)

All signals MUST conform to this envelope:

```
SignalEnvelope {
    # Identity
    signal_id: str              # Globally unique, idempotency key
    source_type: camera | sensor | health
    device_id: str
    
    # Spatial
    zone_id: str
    entrypoint_id: str?         # Optional but recommended
    
    # Classification
    signal_kind: str            # person_detected, door_open, glass_break, tamper, etc.
    hardness: soft | hard       # Determines processing priority
    level: PRE_L1 | PRE_L2 | PRE_L3 | null  # For soft signals
    confidence: float           # 0.0 - 1.0
    
    # Temporal
    timestamp: datetime         # Device-reported time
    ingest_ts: datetime         # Edge-received time (authoritative for ordering)
    
    # Payload
    attributes: {               # Signal-specific data
        bbox?, track_id?, direction?, contact_state?, battery?, etc.
    }
    evidence_hints: {           # Pointers, not content
        snapshot_key?, clip_pointer?, ring_buffer_offset?
    }
}
```

### 1.2 Hardness Classification (Fixed)

| Signal Kind | Hardness | Notes |
|-------------|----------|-------|
| person_detected | soft | Camera AI |
| vehicle_detected | soft | Camera AI |
| loitering | soft | Camera AI |
| motion_camera | soft | Camera motion |
| door_open | **hard** | Contact sensor |
| door_close | **hard** | Contact sensor |
| glass_break | **hard** | Acoustic/vibration sensor |
| motion_pir | **hard** | PIR sensor |
| tamper_s | soft | Suspected tamper (single source) |
| tamper_c | **hard** | Confirmed tamper (corroborated) |
| offline | soft | Device health |
| battery_low | soft | Device health |

### 1.3 Delivery Semantics

- Signal ingestion is **at-least-once**
- Downstream processing MUST be idempotent on `signal_id`
- Late/duplicate signals MAY append to incident but MUST NOT cause re-transition
- Hard signals MUST NOT be dropped under any circumstances

### 1.4 Time Policy

| Use Case | Timestamp | Rationale |
|----------|-----------|-----------|
| Ordering & Correlation | `ingest_ts` | Device clocks may drift |
| Evidence & Audit | Both | Full traceability |
| User Display | `timestamp` | Device-reported time |

---

## 2. Correlation Layer

### 2.1 Responsibilities (Allowed)

- Merge signals into IncidentCandidate
- Deduplicate by `signal_id`
- Group by `leaseKey`
- Attribute to zone/entrypoint/track
- Compute scoring hints (non-binding)

### 2.2 Non-Responsibilities (Forbidden)

| ❌ Forbidden | Reason |
|--------------|--------|
| Change ThreatState | Only State Machine |
| Change WorkflowState | Only State Machine |
| Emit notifications | Only Action Executor |
| Control siren/lights | Only Action Executor |
| Upload evidence | Only Evidence Manager |
| Call external services | Edge isolation |

### 2.3 Lease & Window Model

```
leaseKey = (home_id, zone_id, entrypoint_id)
```

| Window | Default | Purpose |
|--------|---------|---------|
| PRE aggregation | 30-90s | Group soft signals |
| Hard association | 10-30s | Correlate hard with soft |
| Incident active | 3-10min | Append vs new incident |

### 2.4 IncidentCandidate Structure

```
IncidentCandidate {
    candidate_id: str
    lease_key: str
    
    # Temporal
    window_start: datetime
    window_end: datetime
    last_signal_at: datetime
    
    # Signals
    signals: Signal[]           # All signals
    soft_count: int
    hard_count: int
    
    # Hints (non-binding)
    threat_hint: ThreatLevel
    confidence: float
    evidence_hints: str[]
    
    # Attribution
    zone_id: str
    entrypoint_id: str?
    track_ids: str[]            # For camera continuity
}
```

### 2.5 Split & Merge Rules

**SPLIT** incident when:
- `door_close` + silence > `split_silence_threshold` (default 60s)
- Track exits zone + silence > `track_decay_window` (default 30s)
- Explicit user action (resolve/close)

**MERGE** signals when:
- Same `leaseKey` + within `incident_active_window`
- Continuous track spans adjacent zones (driveway → front door)
- Same device + ROI continuity indicates single actor

**NEVER MERGE**:
- Signals from different `entrypoint_id` (unless track continuity proven)
- Signals separated by > `incident_active_window`

---

## 3. Incident State Machine

### 3.1 Orthogonal State Dimensions

```
┌─────────────────────────────────────────────────────────────┐
│  ThreatState (signal-driven, monotonic with decay)          │
│  NONE → PRE_L1 → PRE_L2 → PRE_L3 → PENDING → TRIGGERED     │
└─────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────┐
│  WorkflowState (action/user-driven)                         │
│  IDLE → NOTIFIED → VERIFYING → ESCALATED → RESOLVED → CLOSED│
└─────────────────────────────────────────────────────────────┘
```

**Key Rule**: ThreatState and WorkflowState are independent. PRE advancement does not force Workflow advancement.

### 3.2 Valid State Combinations

| ThreatState | Valid WorkflowStates |
|-------------|---------------------|
| NONE | IDLE, CLOSED |
| PRE_L1 | IDLE |
| PRE_L2 | IDLE, NOTIFIED |
| PRE_L3 | IDLE, NOTIFIED, VERIFYING |
| PENDING | NOTIFIED, VERIFYING |
| TRIGGERED | NOTIFIED, VERIFYING, ESCALATED, RESOLVED |

Invalid combinations MUST raise `InvalidStateError` and be logged.

### 3.3 Threat Transition Rules

```
# Soft signals: max PRE_L3
soft_signal → max(current, hint) capped at PRE_L3

# Hard signals: can reach PENDING/TRIGGERED
door_open (entry_exit zone) → PENDING
door_open (interior zone) → TRIGGERED
glass_break → TRIGGERED
tamper_c → TRIGGERED (policy-gated)
motion_pir (armed_away) → TRIGGERED

# Mode-dependent (see §4)
```

### 3.4 Threat Decay Rules

PRE states decay after silence:

| From | To | Silence Window | Reason Code |
|------|----|----------------|-------------|
| PRE_L3 | PRE_L2 | 120s | DECAY_SILENCE_L3 |
| PRE_L2 | PRE_L1 | 180s | DECAY_SILENCE_L2 |
| PRE_L1 | NONE | 300s | DECAY_SILENCE_L1 |

Decay MUST emit TransitionRecord with `reason_code`.

PENDING/TRIGGERED do NOT auto-decay (require explicit action).

### 3.5 PENDING Cancellation Rules

| Condition | Result | Reason Code |
|-----------|--------|-------------|
| door_close within 3s of door_open | Cancel PENDING → NONE | QUICK_OPEN_CLOSE |
| Valid PIN entered on keypad | Cancel PENDING → NONE | USER_DISARM_PIN |
| User confirms "It's me" in app | Cancel PENDING → RESOLVED | USER_CONFIRM_SELF |
| Entry delay timeout | Escalate → TRIGGERED | ENTRY_DELAY_EXPIRED |

Cancellation NOT allowed for:
- `glass_break` triggered incidents
- `tamper_c` triggered incidents
- Already TRIGGERED state

### 3.6 Transition Recording (Mandatory)

Every state change MUST emit:

```
TransitionRecord {
    record_id: str
    timestamp: datetime
    incident_id: str
    
    dimension: "threat" | "workflow"
    from_state: str
    to_state: str
    
    rule_id: str                # Which rule triggered
    reason_code: str            # Human-readable reason
    
    trigger_signal_ids: str[]   # Max 10, most recent
    trigger_signal_summary: {   # Key fields only
        signal_kind, device_id, confidence
    }
    
    context: {
        arming_state, house_mode, zone_id, entrypoint_id
    }
}
```

---

## 4. Mode Policy

### 4.1 Mode Inputs

```
ModeContext {
    arming_state: disarmed | armed_stay | armed_away
    house_mode: home | away | night | vacation
    entry_delay_sec: int        # Default 30
    exit_delay_sec: int         # Default 60
    bypass_zones: str[]         # Zones to ignore
}
```

### 4.2 Threat Transition Matrix

| Arming State | Signal Kind | Zone Type | → ThreatState |
|--------------|-------------|-----------|---------------|
| **disarmed** | any | any | NONE (log only) |
| **armed_stay** | door_open | entry_exit | PENDING |
| **armed_stay** | door_open | interior | NONE |
| **armed_stay** | motion_pir | interior | NONE |
| **armed_stay** | motion_pir | perimeter | PRE_L2 |
| **armed_stay** | glass_break | any | TRIGGERED |
| **armed_away** | door_open | entry_exit | PENDING |
| **armed_away** | door_open | interior | TRIGGERED |
| **armed_away** | motion_pir | any | TRIGGERED |
| **armed_away** | glass_break | any | TRIGGERED |

### 4.3 Bypass Handling

- Signals from `bypass_zones` are logged but do not advance ThreatState
- Bypass status MUST be recorded in TransitionRecord

---

## 5. Action Gate

### 5.1 Action Permission Matrix

| ThreatState | Permitted Actions |
|-------------|-------------------|
| NONE | (none) |
| PRE_L1 | log, cache_evidence_pointer |
| PRE_L2 | log, cache_evidence_pointer, notify_light, spotlight_on, live_view_hint |
| PRE_L3 | log, cache_evidence_pointer, notify_strong, spotlight_on, live_view_hint, pull_minimal_clip, beep_warning |
| PENDING | log, notify_urgent, spotlight_on, keypad_countdown, prepare_siren, pull_evidence_packet |
| TRIGGERED | log, notify_alarm, siren_on, spotlight_on, pull_full_evidence, collaboration_alert, dispatch_ready |

### 5.2 PRE Notification Suppression

When ThreatState reaches PENDING or TRIGGERED:
- PRE-level notifications (`notify_light`, `notify_strong`) are **suppressed**
- PRE signals continue to append to incident (for evidence)
- Only PENDING/TRIGGERED notifications are sent

### 5.3 Action Authorization Check

```
def is_authorized(threat: ThreatState, action: str) -> bool:
    return action in ACTION_PERMISSIONS[threat]
```

Unauthorized action attempts MUST be logged with `reason=UNAUTHORIZED`.

---

## 6. Action Execution Contract

### 6.1 Action Definition

```
ActionSpec {
    action_id: str              # Idempotency key
    action_type: str            # siren_on, notify_alarm, etc.
    target_device: str?         # Device ID if applicable
    
    # Execution control
    preconditions: Condition[]  # Must all pass
    retry_policy: {
        max_attempts: int       # Default 3
        backoff_ms: int         # Default 1000
    }
    cooldown_sec: int           # Min time between executions
    timeout_sec: int            # Execution timeout
    
    # Failure handling
    fallback_action: str?       # Alternative if fails
    failure_blocks_state: bool  # Default false
}
```

### 6.2 Execution Rules

- Action failures MUST NOT block state progression (unless `failure_blocks_state=true`)
- Failed actions emit `ActionFailureRecord` with error details
- Cooldown prevents spam (e.g., siren cannot retrigger within 5s)

### 6.3 Standard Action Specs

| Action | Cooldown | Timeout | Retry | Fallback |
|--------|----------|---------|-------|----------|
| siren_on | 5s | 10s | 3 | spotlight_on |
| spotlight_on | 1s | 5s | 3 | (none) |
| notify_alarm | 0s | 30s | 5 | (none) |
| pull_evidence_packet | 60s | 120s | 2 | pull_minimal_clip |

---

## 7. Evidence Policy

### 7.1 Evidence Levels

| ThreatState | Evidence Mode | Retention |
|-------------|---------------|-----------|
| PRE_L1/L2 | Ring buffer pointers only | 1 hour |
| PRE_L3 | Snapshots + short clips (low bitrate) | 24 hours |
| PENDING | Prepare packet (pre-buffer 30s) | 7 days |
| TRIGGERED | Full packet (multi-camera, ±120s) | 30 days |

### 7.2 Evidence Packet Contents (TRIGGERED)

```
EvidencePacket {
    incident_id: str
    
    # Video
    clips: [{
        camera_id, start_ts, end_ts, resolution, url
    }]
    pre_buffer_sec: 60
    post_buffer_sec: 120
    
    # Signals
    signal_sequence: Signal[]   # All signals in incident
    
    # Health
    device_heartbeats: [{
        device_id, last_seen, battery, connectivity
    }]
    
    # Metadata
    created_at: datetime
    total_size_bytes: int
}
```

### 7.3 Privacy & Storage

- Evidence defaults to **local-only** on Edge
- Cloud upload requires explicit user consent or TRIGGERED state
- PRE evidence auto-expires; TRIGGERED evidence requires manual deletion

---

## 8. Noise Control & Backpressure

### 8.1 Signal Sampling (Soft Only)

Under resource pressure:
- PRE_L1 signals: sample 1-in-N (N configurable)
- PRE_L2/L3 signals: sample 1-in-2 max
- Hard signals: **NEVER sample or drop**

### 8.2 Notification Cooldowns

| ThreatState | Cooldown | Notes |
|-------------|----------|-------|
| PRE_L1 | 600s (10min) | Or skip entirely |
| PRE_L2 | 300s (5min) | |
| PRE_L3 | 60s (1min) | |
| PENDING | 0s | Always notify |
| TRIGGERED | 0s | Always notify |

### 8.3 Sensor Debounce

| Signal Kind | Debounce Window |
|-------------|-----------------|
| door_open/close | 5s |
| motion_pir | 15s |
| glass_break | 0s (never debounce) |

Debounced signals are **counted** but do not trigger re-transition.

### 8.4 Backpressure Response

When Edge resources critical:
1. Increase soft signal sampling rate
2. Reduce PRE evidence retention
3. Downshift PRE_L3 → PRE_L2 processing
4. **Never** affect hard signal processing

---

## 9. Health & Reliability Signals

### 9.1 Health Signal Types

| Signal | Source | Typical Interval |
|--------|--------|------------------|
| camera_heartbeat | Camera | 30s |
| rtsp_availability | Edge monitor | 10s |
| battery_level | Sensor | 1h |
| connectivity | Edge monitor | 60s |
| device_offline | Edge monitor | On change |

### 9.2 Health → Threat Policy

**Default**: Health degradation affects available actions, NOT threat level.

| Health Signal | Effect |
|---------------|--------|
| camera_offline | Disable live_view for that camera |
| low_battery | Log warning, no threat change |
| connectivity_loss | Queue notifications for retry |

**Exception - Tamper-C**:

Tamper-C is **computed by Correlation**, not a raw signal:

```
tamper_c = (
    dual_camera_offline >= 90s
    AND (door_open OR glass_break) within 10s
) OR (
    single_camera_offline
    AND second_camera_detects_obstruction
)
```

Tamper-C MAY escalate to TRIGGERED (policy-gated, default OFF).

### 9.3 Tamper-C Policy

```
TamperCPolicy {
    enabled: bool               # Default false
    require_hard_correlation: bool  # Default true
    escalate_to: TRIGGERED | PRE_L3  # Default PRE_L3
    reason_code: "TAMPER_C_ESCALATION"
}
```

---

## 10. Metrics & Observability

### 10.1 Required Metrics

| Metric | Type | Labels |
|--------|------|--------|
| `signal_ingested_total` | Counter | source_type, signal_kind, hardness |
| `signal_dropped_total` | Counter | source_type, reason |
| `incident_created_total` | Counter | zone_id |
| `incident_by_threat` | Gauge | threat_state |
| `transition_total` | Counter | dimension, from_state, to_state, rule_id |
| `action_executed_total` | Counter | action_type, success |
| `action_latency_ms` | Histogram | action_type |
| `signal_to_notify_latency_ms` | Histogram | threat_state |

### 10.2 Alerting Thresholds

| Condition | Alert |
|-----------|-------|
| Hard signal drop | CRITICAL |
| Action failure rate > 10% | WARNING |
| Signal-to-notify latency > 5s | WARNING |
| Incident backlog > 100 | WARNING |

---

## 11. Configuration Defaults

```yaml
correlation:
  pre_aggregation_window_sec: 60
  hard_association_window_sec: 30
  incident_active_window_sec: 300
  split_silence_threshold_sec: 60
  track_decay_window_sec: 30

state_machine:
  entry_delay_sec: 30
  exit_delay_sec: 60
  quick_open_close_window_sec: 3
  
  decay:
    pre_l3_silence_sec: 120
    pre_l2_silence_sec: 180
    pre_l1_silence_sec: 300

action:
  siren_max_duration_sec: 180
  siren_cooldown_sec: 5
  notify_retry_max: 5

evidence:
  pre_retention_hours: 24
  triggered_retention_days: 30
  pre_buffer_sec: 60
  post_buffer_sec: 120

noise:
  pre_l1_notify_cooldown_sec: 600
  pre_l2_notify_cooldown_sec: 300
  pre_l3_notify_cooldown_sec: 60
  door_debounce_sec: 5
  motion_debounce_sec: 15

health:
  camera_heartbeat_interval_sec: 30
  offline_threshold_sec: 90
  tamper_c_enabled: false
  tamper_c_escalate_to: PRE_L3

backpressure:
  soft_sample_rate_normal: 1.0
  soft_sample_rate_pressure: 0.5
  hard_sample_rate: 1.0  # Never change
```

---

## 12. Explicit Deferrals

The following are **intentionally deferred** to later specs:

| Topic | Reason |
|-------|--------|
| Collaboration / circle workflows | Multi-party complexity |
| Cross-house correlation | Privacy & scale concerns |
| Cloud-side learning | Requires data pipeline |
| PTZ camera presets | Hardware-specific |
| Voice announcements | UX design pending |

Edge preserves hooks for future integration:
- `reason_code` in all records
- `evidence_packet` boundaries
- `collaboration_hint` field in IncidentCandidate

---

## 13. Implementation Checklist

| # | Component | Status | Notes |
|---|-----------|--------|-------|
| 1 | Signal Envelope validation | ⬜ | Schema enforcement |
| 2 | Correlation Layer | ⬜ | Pure logic, testable |
| 3 | Lease Manager | ⬜ | Zone-level isolation |
| 4 | State Machine (dual dimension) | ⬜ | Refactor from v5 |
| 5 | Transition Recording | ⬜ | Every state change |
| 6 | Action Gate | ⬜ | Permission matrix |
| 7 | Action Executor | ⬜ | With retry/cooldown |
| 8 | Evidence Manager | ⬜ | Level-based policy |
| 9 | Noise Policy | ⬜ | Debounce + cooldown |
| 10 | Health Monitor | ⬜ | Including Tamper-C |
| 11 | Metrics emission | ⬜ | Prometheus format |
| 12 | Config loader | ⬜ | YAML with defaults |

---

## 14. Migration Path from v18.x

| Current Component | Target Component | Change Type |
|-------------------|------------------|-------------|
| `state_machine_v5.py` | `incident_state_machine.py` | Refactor (dual dimension) |
| `zigbee_signal_router.py` | `signal_layer/sensor_source.py` | Rename + envelope |
| `camera_signal_source.py` | `signal_layer/camera_source.py` | Rename + envelope |
| (none) | `correlation/correlator.py` | New |
| (none) | `correlation/lease_manager.py` | New |
| `manager.py._trigger_*` | `action/action_gate.py` | Extract |
| `manager.py._trigger_*` | `action/action_executor.py` | Extract |
| (none) | `evidence/evidence_manager.py` | New |
| (none) | `health/health_monitor.py` | New |
| (none) | `noise/noise_policy.py` | New |

---

*End of Architecture Spec v2 Final*
