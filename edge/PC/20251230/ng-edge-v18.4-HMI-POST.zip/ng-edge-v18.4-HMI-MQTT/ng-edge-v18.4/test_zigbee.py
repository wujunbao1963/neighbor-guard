#!/usr/bin/env python3
"""
测试Zigbee MQTT集成
"""
import sys
import time

# 添加路径
sys.path.insert(0, 'src')

from ng_edge.hardware.zigbee_mqtt_client import ZigbeeMQTTClient, ZigbeeDevice
from ng_edge.domain.models import Signal


def on_signal_received(signal: Signal):
    """Signal回调函数"""
    print(f"\n{'='*60}")
    print(f"📡 收到Signal:")
    print(f"  Type: {signal.signal_type.value}")
    print(f"  Sensor ID: {signal.sensor_id}")
    print(f"  Sensor Type: {signal.sensor_type}")
    print(f"  Zone ID: {signal.zone_id}")
    print(f"  Confidence: {signal.confidence:.2f}")
    print(f"  Battery: {signal.raw_payload.get('battery')}%")
    print(f"  Link Quality: {signal.raw_payload.get('linkquality')}")
    print(f"{'='*60}\n")


def main():
    print("🔌 Zigbee MQTT 测试")
    print("-" * 60)
    
    # 创建客户端
    client = ZigbeeMQTTClient(
        mqtt_host="localhost",
        mqtt_port=1883,
        base_topic="zigbee2mqtt",
        on_signal=on_signal_received
    )
    
    # 添加设备 - 注意添加了 sensor_type 参数
    client.add_device(ZigbeeDevice(
        friendly_name="Back Door Contact",
        sensor_id="zigbee_back_door_001",
        sensor_type="zigbee_contact",
        zone_id="zone_back_door",
        device_type="contact"
    ))
    
    client.add_device(ZigbeeDevice(
        friendly_name="Family Room Motion",
        sensor_id="zigbee_family_room_001",
        sensor_type="zigbee_motion",
        zone_id="zone_family_room",
        device_type="motion"
    ))
    
    # 连接
    if not client.connect():
        print("❌ 连接失败")
        return
    
    print("\n✅ 已连接到MQTT broker")
    print("📱 请触发传感器:")
    print("  - 打开/关闭 Back Door")
    print("  - 在 Family Room Motion 前挥手")
    print("\n按 Ctrl+C 停止测试\n")
    
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\n\n⏹️  停止测试")
        client.disconnect()


if __name__ == "__main__":
    main()
