#!/usr/bin/env python3
"""
Step 4: 检查 Camera Detection Service 状态

通过 API 检查服务状态

用法:
    python test_service_step4.py
"""

import requests
import json
import time

BASE_URL = "http://localhost:8000"

def main():
    print("=" * 60)
    print("Step 4: 检查 Camera Detection Service 状态")
    print("=" * 60)
    
    # 1. 检查服务状态
    print("\n[1] 检查服务状态...")
    try:
        resp = requests.get(f"{BASE_URL}/api/camera-detection/status")
        data = resp.json()
        print(f"  状态: {json.dumps(data, indent=2, ensure_ascii=False)}")
    except Exception as e:
        print(f"  ❌ 失败: {e}")
        return
    
    # 2. 检查 house_mode
    print("\n[2] 检查 house_mode...")
    house_mode = data.get("house_mode", "unknown")
    print(f"  house_mode: {house_mode}")
    
    if house_mode == "disarmed":
        print("  ⚠️ 当前是 DISARMED 模式，威慑不会触发！")
        print("  请切换到 away 模式:")
        print("    curl -X POST 'http://localhost:8000/api/pipeline/mode?mode=away'")
    
    # 3. 检查摄像头
    print("\n[3] 检查摄像头...")
    cameras = data.get("cameras", {})
    if not cameras:
        print("  ⚠️ 没有摄像头！")
    else:
        for name, info in cameras.items():
            print(f"  {name}:")
            print(f"    person_active: {info.get('person_active')}")
            print(f"    current_level: {info.get('current_level')}")
            print(f"    current_zone: {info.get('current_zone')}")
    
    # 4. 实时监控
    print("\n[4] 实时监控 (15秒)...")
    print("  请在摄像头前走动...")
    print("-" * 60)
    
    for i in range(15):
        try:
            resp = requests.get(f"{BASE_URL}/api/camera-detection/status")
            data = resp.json()
            cameras = data.get("cameras", {})
            
            status_parts = []
            for name, info in cameras.items():
                level = info.get('current_level', 0)
                zone = info.get('current_zone', '')
                active = info.get('person_active', False)
                
                if active:
                    status_parts.append(f"{name}: 👤 L{level} ({zone})")
                else:
                    status_parts.append(f"{name}: ✓")
            
            print(f"  [{i+1}s] {' | '.join(status_parts)}")
            
        except Exception as e:
            print(f"  [{i+1}s] 错误: {e}")
        
        time.sleep(1)
    
    print("-" * 60)
    print("\n" + "=" * 60)
    print("测试完成")
    print("=" * 60)


if __name__ == "__main__":
    main()
