#!/usr/bin/env python3
"""
Zigbee MQTT消息调试工具

监听所有MQTT消息，查看设备实际发送什么数据
"""

import json
import time
import paho.mqtt.client as mqtt


def debug_mqtt_messages(device_friendly_name: str, duration_sec: int = 10):
    """
    监听指定设备的MQTT消息
    
    Args:
        device_friendly_name: 设备友好名称，例如 "Front Door Contact"
        duration_sec: 监听时长（秒）
    """
    
    messages_received = []
    
    def on_connect(client, userdata, flags, rc):
        if rc == 0:
            print(f"✅ 已连接到MQTT broker")
            
            # 订阅该设备的所有topic
            topic = f"zigbee2mqtt/{device_friendly_name}"
            client.subscribe(f"{topic}/#")
            print(f"📡 订阅: {topic}/#")
            
            # 也订阅不带后缀的
            client.subscribe(topic)
            print(f"📡 订阅: {topic}")
            
        else:
            print(f"❌ 连接失败: {rc}")
    
    def on_message(client, userdata, msg):
        try:
            payload_str = msg.payload.decode()
            
            print(f"\n📨 收到消息:")
            print(f"  Topic: {msg.topic}")
            print(f"  Payload: {payload_str}")
            
            try:
                payload_json = json.loads(payload_str)
                print(f"  JSON: {json.dumps(payload_json, indent=4, ensure_ascii=False)}")
            except:
                pass
            
            messages_received.append({
                "topic": msg.topic,
                "payload": payload_str,
                "timestamp": time.time()
            })
            
        except Exception as e:
            print(f"❌ 处理消息错误: {e}")
    
    client = mqtt.Client(client_id="ng_edge_debugger")
    client.on_connect = on_connect
    client.on_message = on_message
    
    try:
        print(f"连接到 localhost:1883...")
        client.connect("localhost", 1883, 60)
        
        print(f"\n监听 {duration_sec} 秒...")
        print("请触发设备（例如打开/关闭门）观察消息\n")
        print("=" * 70)
        
        # 启动循环
        client.loop_start()
        
        # 等待指定时间
        time.sleep(duration_sec)
        
        # 停止
        client.loop_stop()
        client.disconnect()
        
        print("\n" + "=" * 70)
        print(f"\n总共收到 {len(messages_received)} 条消息")
        
        if not messages_received:
            print("\n⚠️  没有收到任何消息")
            print("\n可能的原因：")
            print("  1. 设备名称不对（检查Zigbee2MQTT中的Friendly Name）")
            print("  2. 设备没有主动发送状态更新")
            print("  3. 需要手动触发设备（打开/关闭门磁）")
        
    except Exception as e:
        print(f"❌ 错误: {e}")


def list_and_monitor():
    """列出设备并选择一个进行监听"""
    from zigbee_verifier_v2 import list_zigbee_devices
    
    print("=" * 70)
    print("  MQTT消息调试工具")
    print("=" * 70)
    
    # 获取设备列表
    print("\n正在获取设备列表...")
    result = list_zigbee_devices()
    
    if not result["success"]:
        print(f"\n❌ 获取设备列表失败: {result['error']}")
        return
    
    devices = result["devices"]
    
    if not devices:
        print("\n⚠️  没有找到任何Zigbee设备")
        return
    
    # 显示设备列表
    print(f"\n找到 {len(devices)} 个Zigbee设备:\n")
    
    for i, device in enumerate(devices, 1):
        print(f"{i}. {device['friendly_name']}")
        print(f"   IEEE: {device['ieee_address']}")
        print(f"   型号: {device['model']}")
        print()
    
    # 用户选择
    print("请选择一个设备进行监听 (输入序号，0退出):")
    try:
        choice = int(input(">>> ").strip())
        
        if choice == 0:
            return
        
        if choice < 1 or choice > len(devices):
            print("❌ 无效的选择")
            return
        
        selected = devices[choice - 1]
        
        print(f"\n将监听设备: {selected['friendly_name']}")
        print(f"IEEE地址: {selected['ieee_address']}")
        
        # 监听该设备
        print("\n" + "=" * 70)
        debug_mqtt_messages(selected['friendly_name'], duration_sec=15)
        
    except ValueError:
        print("❌ 请输入数字")
    except KeyboardInterrupt:
        print("\n\n取消")


if __name__ == "__main__":
    list_and_monitor()
