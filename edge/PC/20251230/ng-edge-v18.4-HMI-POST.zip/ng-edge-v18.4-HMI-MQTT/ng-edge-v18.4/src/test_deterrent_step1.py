#!/usr/bin/env python3
"""
Step 1: 测试 Reolink 威慑控制

直接测试 spotlight 和 siren 是否工作

用法:
    python test_deterrent_step1.py 10.0.0.155 admin YOUR_PASSWORD
"""

import asyncio
import sys


async def test_spotlight(ip: str, user: str, password: str):
    """测试 Spotlight"""
    print(f"\n[Step 1] 测试 Spotlight...")
    
    from reolink_aio.api import Host
    host = Host(ip, user, password)
    
    try:
        await host.get_host_data()
        model = host.camera_model(0)
        print(f"  ✅ 已连接: {model}")
        
        # 开灯
        print(f"  💡 开灯...")
        await host.set_whiteled(0, state=True)
        print(f"  ✅ 灯已开，等待 2 秒...")
        await asyncio.sleep(2)
        
        # 关灯
        print(f"  💡 关灯...")
        await host.set_whiteled(0, state=False)
        print(f"  ✅ 灯已关")
        
        return True
    except Exception as e:
        print(f"  ❌ 失败: {e}")
        return False
    finally:
        await host.logout()


async def test_siren(ip: str, user: str, password: str):
    """测试 Siren (短促 beep)"""
    print(f"\n[Step 2] 测试 Siren (短促 beep)...")
    
    from reolink_aio.api import Host
    host = Host(ip, user, password)
    
    try:
        await host.get_host_data()
        
        # 短促 beep
        print(f"  🔊 Beep...")
        await host.set_siren(0, True)
        await asyncio.sleep(0.1)
        await host.set_siren(0, False)
        print(f"  ✅ Beep 完成")
        
        return True
    except Exception as e:
        print(f"  ❌ 失败: {e}")
        return False
    finally:
        await host.logout()


async def test_deterrent_loop(ip: str, user: str, password: str):
    """测试 L2 威慑循环 (5秒)"""
    print(f"\n[Step 3] 测试 L2 威慑循环 (5秒)...")
    
    from reolink_aio.api import Host
    host = Host(ip, user, password)
    
    try:
        await host.get_host_data()
        
        # 开灯
        await host.set_whiteled(0, state=True)
        print(f"  💡 灯已开")
        
        # 循环 beep
        for i in range(5):
            print(f"  🔊 Beep #{i+1}")
            await host.set_siren(0, True)
            await asyncio.sleep(0.1)
            await host.set_siren(0, False)
            await asyncio.sleep(0.9)  # 1秒间隔
        
        # 关灯
        await host.set_whiteled(0, state=False)
        print(f"  💡 灯已关")
        print(f"  ✅ 威慑循环完成")
        
        return True
    except Exception as e:
        print(f"  ❌ 失败: {e}")
        return False
    finally:
        await host.logout()


async def main():
    if len(sys.argv) < 4:
        print("用法: python test_deterrent_step1.py <ip> <user> <password>")
        return
    
    ip, user, password = sys.argv[1:4]
    
    print("=" * 60)
    print("威慑功能测试")
    print("=" * 60)
    
    # Step 1: Spotlight
    result1 = await test_spotlight(ip, user, password)
    
    if not result1:
        print("\n❌ Spotlight 测试失败，停止")
        return
    
    await asyncio.sleep(1)
    
    # Step 2: Siren
    result2 = await test_siren(ip, user, password)
    
    if not result2:
        print("\n❌ Siren 测试失败，停止")
        return
    
    await asyncio.sleep(1)
    
    # Step 3: 威慑循环
    result3 = await test_deterrent_loop(ip, user, password)
    
    print("\n" + "=" * 60)
    if result1 and result2 and result3:
        print("✅ 所有测试通过！威慑功能正常")
    else:
        print("❌ 部分测试失败")
    print("=" * 60)


if __name__ == "__main__":
    asyncio.run(main())
