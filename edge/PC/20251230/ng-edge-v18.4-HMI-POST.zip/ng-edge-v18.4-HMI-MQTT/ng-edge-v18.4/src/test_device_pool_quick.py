#!/usr/bin/env python3
"""
设备池快速测试

测试设备池的基本功能:
1. 启动服务器
2. 添加测试设备
3. 绑定设备
4. 验证API工作
"""

import subprocess
import time
import requests
import sys
import os

os.chdir(os.path.dirname(os.path.abspath(__file__)))

BASE_URL = "http://localhost:8000"

def print_section(title):
    """打印分节标题"""
    print("\n" + "=" * 70)
    print(f"  {title}")
    print("=" * 70)

def start_server():
    """启动服务器"""
    print_section("步骤1: 启动服务器")
    
    subprocess.run(["pkill", "-f", "uvicorn.*ng_edge"], stderr=subprocess.DEVNULL)
    time.sleep(1)
    
    server_process = subprocess.Popen(
        ["uvicorn", "ng_edge.api.manager:app", "--host", "0.0.0.0", "--port", "8000"],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True
    )
    
    print("\n等待服务器启动...")
    for i in range(15):
        try:
            resp = requests.get(f"{BASE_URL}/api/devices/", timeout=1)
            if resp.status_code == 200:
                print(f"✅ 服务器已就绪")
                return server_process
        except:
            pass
        time.sleep(1)
    
    print("❌ 服务器启动超时")
    server_process.terminate()
    return None

def test_device_pool_api():
    """测试设备池API"""
    print_section("步骤2: 测试设备池API")
    
    # 1. 获取设备列表
    print("\n[1/6] 获取设备列表...")
    try:
        resp = requests.get(f"{BASE_URL}/api/devices/")
        if resp.status_code == 200:
            data = resp.json()
            print(f"✅ 设备总数: {data.get('total', 0)}")
        else:
            print(f"❌ 失败: {resp.status_code}")
            return False
    except Exception as e:
        print(f"❌ 错误: {e}")
        return False
    
    # 2. 添加测试摄像头
    print("\n[2/6] 添加测试摄像头...")
    try:
        resp = requests.post(f"{BASE_URL}/api/devices/discover/camera",
            json={
                "friendly_name": "Test Front Camera",
                "camera_ip": "10.0.0.156",
                "username": "admin",
                "password": "test123"
            }
        )
        if resp.status_code == 200:
            result = resp.json()
            camera_id = result.get('device_id')
            print(f"✅ 摄像头已添加: {camera_id}")
        else:
            print(f"❌ 失败: {resp.status_code}")
            return False
    except Exception as e:
        print(f"❌ 错误: {e}")
        return False
    
    time.sleep(0.5)
    
    # 3. 模拟Zigbee门磁发现
    print("\n[3/6] 模拟Zigbee门磁发现...")
    try:
        resp = requests.post(f"{BASE_URL}/api/devices/discover/zigbee",
            json={
                "friendly_name": "Test Front Door Contact",
                "ieee_address": "00:11:22:33:44:55:66:77",
                "model": "MCCGQ11LM",
                "device_type_hint": "contact"
            }
        )
        if resp.status_code == 200:
            result = resp.json()
            contact_id = result.get('device_id')
            print(f"✅ 门磁已发现: {contact_id}")
            print(f"   类型: {result.get('device_type')}")
        else:
            print(f"❌ 失败: {resp.status_code}")
            return False
    except Exception as e:
        print(f"❌ 错误: {e}")
        return False
    
    time.sleep(0.5)
    
    # 4. 模拟Zigbee Motion发现
    print("\n[4/6] 模拟Zigbee Motion发现...")
    try:
        resp = requests.post(f"{BASE_URL}/api/devices/discover/zigbee",
            json={
                "friendly_name": "Test Front Motion",
                "ieee_address": "00:11:22:33:44:55:66:88",
                "model": "RTCGQ11LM",
                "device_type_hint": "motion"
            }
        )
        if resp.status_code == 200:
            result = resp.json()
            motion_id = result.get('device_id')
            print(f"✅ Motion已发现: {motion_id}")
            print(f"   类型: {result.get('device_type')}")
        else:
            print(f"❌ 失败: {resp.status_code}")
            return False
    except Exception as e:
        print(f"❌ 错误: {e}")
        return False
    
    time.sleep(0.5)
    
    # 5. 查看未绑定设备
    print("\n[5/6] 查看未绑定设备...")
    try:
        resp = requests.get(f"{BASE_URL}/api/devices/unbound")
        if resp.status_code == 200:
            data = resp.json()
            devices = data.get('devices', [])
            print(f"✅ 未绑定设备: {len(devices)} 个")
            for device in devices:
                print(f"   - {device['friendly_name']} ({device['device_type']})")
        else:
            print(f"❌ 失败: {resp.status_code}")
            return False
    except Exception as e:
        print(f"❌ 错误: {e}")
        return False
    
    time.sleep(0.5)
    
    # 6. 绑定摄像头到前门
    print("\n[6/6] 绑定摄像头到前门拓扑...")
    try:
        resp = requests.post(f"{BASE_URL}/api/devices/{camera_id}/bind",
            json={
                "entry_point_id": "ep_front_door",
                "zone_id": "zone_front_yard"
            }
        )
        if resp.status_code == 200:
            result = resp.json()
            print(f"✅ 绑定成功!")
            print(f"   Sensor ID: {result.get('sensor_id')}")
            print(f"   Entry Point: {result.get('bound_to_entry_point')}")
            print(f"   Zone: {result.get('bound_to_zone')}")
        else:
            print(f"❌ 失败: {resp.status_code}")
            return False
    except Exception as e:
        print(f"❌ 错误: {e}")
        return False
    
    return True

def show_device_stats():
    """显示设备统计"""
    print_section("设备统计")
    
    try:
        resp = requests.get(f"{BASE_URL}/api/devices/stats/summary")
        if resp.status_code == 200:
            stats = resp.json()
            
            print(f"\n总设备数: {stats.get('total_devices', 0)}")
            
            print(f"\n按类型:")
            for dtype, count in stats.get('by_type', {}).items():
                print(f"  {dtype}: {count}")
            
            print(f"\n按状态:")
            for status, count in stats.get('by_status', {}).items():
                print(f"  {status}: {count}")
            
            print(f"\n未绑定: {stats.get('unbound_devices', 0)}")
            print(f"已绑定: {stats.get('bound_devices', 0)}")
        else:
            print(f"❌ 获取统计失败")
    except Exception as e:
        print(f"❌ 错误: {e}")

def show_all_devices():
    """显示所有设备"""
    print_section("所有设备")
    
    try:
        resp = requests.get(f"{BASE_URL}/api/devices/")
        if resp.status_code == 200:
            data = resp.json()
            devices = data.get('devices', [])
            
            print(f"\n共 {len(devices)} 个设备:\n")
            
            for device in devices:
                print(f"[{device['device_id']}]")
                print(f"  名称: {device['friendly_name']}")
                print(f"  类型: {device['device_type']}")
                print(f"  状态: {device['status']}")
                
                if device.get('ieee_address'):
                    print(f"  IEEE: {device['ieee_address']}")
                if device.get('camera_ip'):
                    print(f"  IP: {device['camera_ip']}")
                
                if device['status'] == 'bound':
                    print(f"  ✓ 已绑定:")
                    print(f"    Sensor: {device.get('sensor_id')}")
                    print(f"    Entry Point: {device.get('bound_to_entry_point')}")
                    print(f"    Zone: {device.get('bound_to_zone')}")
                
                print()
        else:
            print(f"❌ 获取设备失败")
    except Exception as e:
        print(f"❌ 错误: {e}")

def main():
    """主函数"""
    server_process = None
    
    try:
        print("\n" + "🔧" * 35)
        print("  设备池快速测试")
        print("🔧" * 35)
        
        # 1. 启动服务器
        server_process = start_server()
        if not server_process:
            return 1
        
        time.sleep(2)
        
        # 2. 测试设备池API
        if not test_device_pool_api():
            print("\n❌ 测试失败")
            return 1
        
        time.sleep(1)
        
        # 3. 显示统计
        show_device_stats()
        
        time.sleep(1)
        
        # 4. 显示所有设备
        show_all_devices()
        
        # 总结
        print_section("测试完成")
        print("\n✅ 设备池功能测试通过!")
        print("\n功能验证:")
        print("  ✓ 摄像头添加")
        print("  ✓ Zigbee自动发现")
        print("  ✓ 设备绑定")
        print("  ✓ 状态管理")
        print("  ✓ API响应")
        
        print("\n设备数据保存在:")
        print("  ./data/device_pool.json")
        
        print("\n服务器仍在运行...")
        print("你可以使用交互式工具:")
        print("  python3 test_device_pool.py")
        print("\n按Ctrl+C停止")
        
        # 保持运行
        try:
            server_process.wait()
        except KeyboardInterrupt:
            print("\n\n停止服务器...")
        
        return 0
        
    except KeyboardInterrupt:
        print("\n\n测试中断")
        return 1
        
    finally:
        if server_process:
            server_process.terminate()
            try:
                server_process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                server_process.kill()

if __name__ == "__main__":
    sys.exit(main())
