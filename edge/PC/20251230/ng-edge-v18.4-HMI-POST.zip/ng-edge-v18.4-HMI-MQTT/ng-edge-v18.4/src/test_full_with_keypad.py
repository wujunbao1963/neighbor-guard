#!/usr/bin/env python3
"""
完整拓扑测试 - 包含Keypad撤防功能

测试完整的报警和撤防流程:
1. 摄像头检测到人 → PRE
2. 门磁检测开门 → PENDING (30秒倒计时)
3. 用户有时间走到Keypad输入PIN撤防
4. 如果不撤防，30秒后自动TRIGGERED

修复的逻辑:
- PENDING期间Motion信号只记录，不触发报警
- 只有entry delay超时才TRIGGERED
- GLASS_BREAK例外，立即触发
"""

import subprocess
import time
import requests
import sys
import os

os.chdir(os.path.dirname(os.path.abspath(__file__)))

BASE_URL = "http://localhost:8000"
DEFAULT_PIN = "1234"

# 摄像头配置
CAMERA_IP = "10.0.0.155"
CAMERA_USERNAME = "admin"
CAMERA_PASSWORD = "Zafac05@a"

def print_section(title):
    """打印分节标题"""
    print("\n" + "=" * 70)
    print(f"  {title}")
    print("=" * 70)

def start_server():
    """启动服务器"""
    print_section("步骤1: 启动NG Edge服务器")
    
    subprocess.run(["pkill", "-f", "uvicorn.*ng_edge"], stderr=subprocess.DEVNULL)
    time.sleep(1)
    
    server_process = subprocess.Popen(
        ["uvicorn", "ng_edge.api.manager:app", "--host", "0.0.0.0", "--port", "8000"],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True
    )
    
    print("\n等待服务器启动...")
    for i in range(15):
        try:
            resp = requests.get(f"{BASE_URL}/api/pipeline/status", timeout=1)
            if resp.status_code == 200:
                print(f"✅ 服务器已就绪")
                return server_process
        except:
            pass
        time.sleep(1)
    
    print("❌ 服务器启动超时")
    server_process.terminate()
    return None

def load_config():
    """加载标准配置"""
    print_section("步骤2: 加载标准配置")
    
    try:
        resp = requests.post(f"{BASE_URL}/api/load-standard-config")
        if resp.status_code == 200:
            print("✅ 标准配置加载成功")
            return True
        else:
            print(f"❌ 配置加载失败: {resp.status_code}")
            return False
    except Exception as e:
        print(f"❌ 错误: {e}")
        return False

def start_camera():
    """启动摄像头"""
    print_section("步骤3: 启动摄像头")
    
    try:
        resp = requests.post(f"{BASE_URL}/api/camera/start",
            json={
                "sensor_id": "sensor_camera_backyard",
                "zone_id": "zone_backyard",
                "camera_ip": CAMERA_IP,
                "camera_username": CAMERA_USERNAME,
                "camera_password": CAMERA_PASSWORD,
                "detection_fps": 5.0,
                "confidence_threshold": 0.6
            }
        )
        
        if resp.status_code == 200:
            print("\n✅ 摄像头启动成功")
            return True
        else:
            print(f"\n⚠️  摄像头启动失败，继续测试")
            return False
    except Exception as e:
        print(f"\n⚠️  摄像头启动失败: {e}")
        return False

def start_zigbee():
    """启动Zigbee MQTT客户端"""
    print_section("步骤4: 启动Zigbee传感器")
    
    try:
        resp = requests.post(f"{BASE_URL}/api/zigbee/start",
            json={
                "mqtt_host": "localhost",
                "mqtt_port": 1883,
                "devices": [
                    {
                        "friendly_name": "Back Door Contact",
                        "sensor_id": "sensor_door_back",
                        "sensor_type": "door_contact",
                        "zone_id": "zone_back_door",
                        "device_type": "contact"
                    },
                    {
                        "friendly_name": "Family Room Motion",
                        "sensor_id": "sensor_pir_living",
                        "sensor_type": "motion_pir",
                        "zone_id": "zone_living_room",
                        "device_type": "motion"
                    }
                ]
            }
        )
        
        if resp.status_code == 200:
            print("\n✅ Zigbee客户端启动成功")
            return True
        else:
            print(f"\n❌ Zigbee启动失败")
            return False
    except Exception as e:
        print(f"\n❌ 错误: {e}")
        return False

def set_away_mode():
    """设置AWAY模式"""
    print_section("步骤5: 设置AWAY模式")
    
    try:
        resp = requests.post(f"{BASE_URL}/api/pipeline/mode", json={"mode": "away"})
        if resp.status_code == 200:
            print("✅ 已设置AWAY模式")
            return True
        else:
            print(f"❌ 设置模式失败: {resp.status_code}")
            return False
    except Exception as e:
        print(f"❌ 错误: {e}")
        return False

def test_keypad_disarm():
    """测试Keypad撤防"""
    print_section("Keypad撤防测试")
    
    print("\n📋 撤防测试场景:")
    print("  1. 系统进入PENDING状态")
    print("  2. 你有30秒时间输入PIN撤防")
    print("  3. 输入 'y' 模拟按Keypad撤防")
    print("  4. 输入 'n' 让系统自动超时触发报警")
    print()
    
    try:
        # 等待用户决定是否撤防
        user_input = input("是否模拟Keypad撤防? (y/n): ").strip().lower()
        
        if user_input == 'y':
            print("\n模拟Keypad撤防...")
            resp = requests.post(f"{BASE_URL}/api/disarm",
                json={"pin": DEFAULT_PIN})
            
            if resp.status_code == 200:
                print("✅ 撤防成功！")
                return True
            else:
                print(f"❌ 撤防失败: {resp.status_code}")
                return False
        else:
            print("\n⏰ 不撤防，等待entry delay超时...")
            return False
            
    except Exception as e:
        print(f"❌ 错误: {e}")
        return False

def monitor_system(duration=60):
    """监控系统状态"""
    print_section("步骤6: 监控系统")
    
    print("\n📋 测试指南:")
    print("  1️⃣  在摄像头前走动 → PERSON_DETECTED → PRE")
    print("  2️⃣  打开后门 → DOOR_OPEN → PENDING (30秒)")
    print("  3️⃣  在Family Room走动 → MOTION记录（不触发）")
    print("  4️⃣  30秒内决定是否输入PIN撤防")
    print()
    print(f"将监控 {duration} 秒...")
    print("按 Ctrl+C 随时停止")
    print()
    
    start_time = time.time()
    last_alarm_state = None
    last_ep_state = {}
    pending_started = False
    pending_notified = False
    
    try:
        while time.time() - start_time < duration:
            current_time = time.strftime("%H:%M:%S")
            
            try:
                resp = requests.get(f"{BASE_URL}/api/pipeline/status", timeout=1)
                status = resp.json()
                
                alarm = status.get('alarm_state', 'unknown')
                
                # 检查Alarm状态变化
                if alarm != last_alarm_state:
                    print(f"[{current_time}] 🚨 Alarm: {last_alarm_state} → {alarm}")
                    last_alarm_state = alarm
                    
                    # 进入PENDING状态
                    if alarm == 'pending' and not pending_started:
                        pending_started = True
                        print(f"[{current_time}] ⏰ Entry Delay开始！30秒倒计时...")
                        print(f"[{current_time}] 💡 提示: Motion信号会被记录但不触发报警")
                
                # 检查EntryPoint状态
                ep_states = status.get('entry_point_states', {})
                for ep_id, state in ep_states.items():
                    if state != last_ep_state.get(ep_id):
                        print(f"[{current_time}] 🚪 EntryPoint {ep_id}: {state}")
                        last_ep_state[ep_id] = state
                
                # 如果在PENDING状态，询问是否撤防
                if pending_started and not pending_notified:
                    # 等待10秒再询问（给用户反应时间）
                    if time.time() - start_time > 10:
                        pending_notified = True
                        print()
                        test_keypad_disarm()
                        print()
                
                # 检查新信号
                try:
                    camera_resp = requests.get(f"{BASE_URL}/api/camera/status", timeout=0.5)
                    zigbee_resp = requests.get(f"{BASE_URL}/api/zigbee/status", timeout=0.5)
                    
                    # 简单显示信号计数
                except:
                    pass
                
            except Exception as e:
                pass
            
            time.sleep(2)
        
        print(f"\n⏰ 监控时间结束")
        
    except KeyboardInterrupt:
        print("\n\n⚠️  用户停止监控")

def show_final_status():
    """显示最终状态"""
    print_section("最终状态报告")
    
    try:
        resp = requests.get(f"{BASE_URL}/api/pipeline/status")
        status = resp.json()
        
        print("\n系统状态:")
        print(f"  Mode: {status.get('mode')}")
        print(f"  Alarm: {status.get('alarm_state')}")
        
        ep_states = status.get('entry_point_states', {})
        if ep_states:
            print("\nEntry Point状态:")
            for ep_id, state in ep_states.items():
                print(f"  {ep_id}: {state}")
        
        # 摄像头状态
        try:
            camera_resp = requests.get(f"{BASE_URL}/api/camera/status")
            camera = camera_resp.json()
            
            if camera.get('active'):
                stats = camera.get('stats', {})
                print(f"\n摄像头: 总检测 {stats.get('signals_generated', 0)} 次")
        except:
            pass
        
        # Zigbee状态
        try:
            zigbee_resp = requests.get(f"{BASE_URL}/api/zigbee/status")
            zigbee = zigbee_resp.json()
            recent = zigbee.get('recent_signals', [])
            
            if recent:
                print(f"\nZigbee信号 (最近3条):")
                for i, sig in enumerate(recent[:3], 1):
                    print(f"  {i}. {sig.get('signal_type')} from {sig.get('sensor_id')}")
        except:
            pass
        
    except Exception as e:
        print(f"❌ 获取状态失败: {e}")

def main():
    """主函数"""
    server_process = None
    
    try:
        print("\n" + "🎯" * 35)
        print("  完整拓扑测试 - 包含Keypad撤防")
        print("🎯" * 35)
        print("\n🔧 修复的逻辑:")
        print("  - PENDING期间Motion只记录，不触发")
        print("  - 30秒倒计时后才TRIGGERED")
        print("  - 用户可以在倒计时期间撤防")
        
        # 启动服务器
        server_process = start_server()
        if not server_process:
            return 1
        
        time.sleep(2)
        
        # 加载配置
        if not load_config():
            return 1
        
        time.sleep(1)
        
        # 启动摄像头
        start_camera()
        time.sleep(2)
        
        # 启动Zigbee
        if not start_zigbee():
            print("\n⚠️  Zigbee启动失败，继续测试")
        
        time.sleep(2)
        
        # 设置AWAY模式
        if not set_away_mode():
            return 1
        
        time.sleep(1)
        
        # 监控系统
        monitor_system(duration=90)
        
        # 显示最终状态
        show_final_status()
        
        # 总结
        print_section("测试完成")
        print("\n✅ 测试的关键点:")
        print("   1. PRE状态: 摄像头检测到人")
        print("   2. PENDING状态: 门打开，30秒倒计时")
        print("   3. Motion信号: 在PENDING期间不触发报警")
        print("   4. Keypad撤防: 输入PIN可以取消报警")
        print("   5. 超时触发: 30秒后自动TRIGGERED")
        
        print("\n服务器仍在运行...")
        print("Web UI: http://localhost:8000")
        print("按Ctrl+C停止")
        
        try:
            server_process.wait()
        except KeyboardInterrupt:
            print("\n\n停止服务器...")
        
        return 0
        
    except KeyboardInterrupt:
        print("\n\n测试中断")
        return 1
        
    finally:
        if server_process:
            server_process.terminate()
            try:
                server_process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                server_process.kill()

if __name__ == "__main__":
    sys.exit(main())
