#!/usr/bin/env python3
"""
NG Edge - Cloud Sync Service (Server-Compatible)

Uses the actual server API endpoints:
- POST /api/edge/devices/:deviceKey/heartbeat
- POST /api/edge/devices/:deviceKey/topo
- POST /api/edge/events

Usage:
    python run_sync_v2.py --server http://10.0.0.136:3000

Device key is read from /var/lib/ng-edge/device_key
"""

import asyncio
import argparse
import json
import sys
import signal
import uuid
from pathlib import Path
from datetime import datetime, timezone
from typing import Optional, Dict, Any

try:
    import aiohttp
except ImportError:
    print("ERROR: aiohttp required. Install with: pip install aiohttp")
    sys.exit(1)


class EdgeSyncClient:
    """HTTP client for NG server edge API."""
    
    def __init__(self, server_url: str, device_key: str):
        self.server_url = server_url.rstrip('/')
        self.device_key = device_key
        self._session: Optional[aiohttp.ClientSession] = None
        
        # Stats
        self.heartbeat_success = 0
        self.heartbeat_failure = 0
        self.topo_success = 0
        self.topo_failure = 0
        self.event_success = 0
        self.event_failure = 0
    
    async def _get_session(self) -> aiohttp.ClientSession:
        if self._session is None or self._session.closed:
            timeout = aiohttp.ClientTimeout(total=10)
            self._session = aiohttp.ClientSession(timeout=timeout)
        return self._session
    
    async def close(self):
        if self._session and not self._session.closed:
            await self._session.close()
    
    def _auth_header(self) -> Dict[str, str]:
        return {
            "Authorization": f"Device {self.device_key}",
            "Content-Type": "application/json",
        }
    
    async def heartbeat(self, status: str = "ONLINE") -> tuple[bool, dict]:
        """
        POST /api/edge/devices/:deviceKey/heartbeat
        """
        url = f"{self.server_url}/api/edge/devices/{self.device_key}/heartbeat"
        session = await self._get_session()
        
        try:
            async with session.post(
                url,
                json={"status": status, "fwVersion": "1.1.0"},
                headers=self._auth_header(),
            ) as resp:
                data = await resp.json()
                if resp.status == 200 and data.get("success"):
                    self.heartbeat_success += 1
                    return True, data
                else:
                    self.heartbeat_failure += 1
                    return False, data
        except Exception as e:
            self.heartbeat_failure += 1
            return False, {"error": str(e)}
    
    async def send_topo(self, topo: dict) -> tuple[bool, dict]:
        """
        POST /api/edge/devices/:deviceKey/topo
        """
        url = f"{self.server_url}/api/edge/devices/{self.device_key}/topo"
        session = await self._get_session()
        
        print(f"[TOPO] Sending to: {url}")
        print(f"[TOPO] Payload: {json.dumps(topo, indent=2)[:500]}...")
        
        try:
            async with session.post(
                url,
                json=topo,
                headers=self._auth_header(),
            ) as resp:
                data = await resp.json()
                print(f"[TOPO] Response status: {resp.status}")
                print(f"[TOPO] Response body: {data}")
                if resp.status == 200 and data.get("success"):
                    self.topo_success += 1
                    return True, data
                else:
                    self.topo_failure += 1
                    return False, data
        except Exception as e:
            self.topo_failure += 1
            print(f"[TOPO] Exception: {e}")
            return False, {"error": str(e)}
    
    async def send_event(self, event: dict) -> tuple[bool, dict]:
        """
        POST /api/edge/events
        
        Required fields: eventType, title
        Optional: description, severity, zoneId, occurredAt
        """
        url = f"{self.server_url}/api/edge/events"
        session = await self._get_session()
        
        try:
            async with session.post(
                url,
                json=event,
                headers=self._auth_header(),
            ) as resp:
                data = await resp.json()
                if resp.status == 200 and data.get("success"):
                    self.event_success += 1
                    return True, data
                else:
                    self.event_failure += 1
                    return False, data
        except Exception as e:
            self.event_failure += 1
            return False, {"error": str(e)}
    
    async def check_health(self) -> tuple[bool, dict]:
        """Check server health."""
        url = f"{self.server_url}/health"
        session = await self._get_session()
        
        try:
            async with session.get(url) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    return data.get("ok", False), data
                return False, {"status": resp.status}
        except Exception as e:
            return False, {"error": str(e)}


def load_device_key(path: str = "/var/lib/ng-edge/device_key", key_arg: str = None) -> Optional[str]:
    """Load device key from argument or file."""
    # If passed as argument, use that
    if key_arg:
        print(f"[INIT] Device key from argument: {key_arg[:30]}...")
        return key_arg
    
    # Otherwise try to read from file
    try:
        key = Path(path).read_text().strip()
        if key:
            print(f"[INIT] Device key loaded: {key[:30]}...")
            return key
    except Exception as e:
        print(f"[ERROR] Failed to load device key from {path}: {e}")
        print(f"[HINT] Try: python3 run_sync_v2.py --device-key \"$(sudo cat {path})\"")
    return None


def get_sample_topo() -> dict:
    """Sample topology for testing."""
    return {
        "schemaVersion": "1.0",
        "zones": [
            {"id": "zone-1", "name": "Front Yard", "type": "EXTERIOR"},
            {"id": "zone-2", "name": "Entry", "type": "ENTRY"},
            {"id": "zone-3", "name": "Living Room", "type": "INTERIOR"},
        ],
        "sensors": [
            {"id": "sensor-1", "name": "Front Camera", "type": "camera", "zoneId": "zone-1"},
            {"id": "sensor-2", "name": "Front Door", "type": "door_contact", "zoneId": "zone-2"},
            {"id": "sensor-3", "name": "Living Room PIR", "type": "pir", "zoneId": "zone-3"},
        ],
    }


def create_test_event() -> dict:
    """Create a test event."""
    return {
        "eventType": "MOTION",
        "title": f"Test motion detected at {datetime.now().strftime('%H:%M:%S')}",
        "description": "Test event from edge sync service",
        "severity": "LOW",
        "occurredAt": datetime.now(timezone.utc).isoformat(),
    }


async def main():
    parser = argparse.ArgumentParser(description="NG Edge Sync Service v2")
    parser.add_argument("--server", "-s", default="http://10.0.0.136:3000", help="Server URL")
    parser.add_argument("--device-key", "-k", help="Device key (or reads from --device-key-path)")
    parser.add_argument("--device-key-path", default="/var/lib/ng-edge/device_key", help="Device key file")
    parser.add_argument("--heartbeat", type=int, default=30, help="Heartbeat interval (seconds)")
    parser.add_argument("--topo-interval", type=int, default=300, help="Topo sync interval (seconds)")
    parser.add_argument("--send-events", action="store_true", help="Send test events every 60s")
    
    args = parser.parse_args()
    
    print("=" * 60)
    print("NG Edge - Sync Service v2")
    print("=" * 60)
    print(f"Server:    {args.server}")
    print(f"Heartbeat: every {args.heartbeat}s")
    print(f"Topo:      every {args.topo_interval}s")
    print("=" * 60)
    
    # Load device key
    device_key = load_device_key(args.device_key_path, args.device_key)
    if not device_key:
        print("\n✗ ERROR: No device key found!")
        return 1
    
    # Create client
    client = EdgeSyncClient(args.server, device_key)
    
    # Check server health first
    print("\n[INIT] Checking server health...")
    ok, data = await client.check_health()
    if ok:
        print(f"[INIT] ✓ Server healthy: {data}")
    else:
        print(f"[INIT] ✗ Server not healthy: {data}")
        print("[INIT] Continuing anyway...")
    
    # Test heartbeat
    print("\n[INIT] Testing heartbeat...")
    ok, data = await client.heartbeat()
    if ok:
        print(f"[INIT] ✓ Heartbeat OK")
        device_info = data.get("data", {})
        print(f"[INIT]   Status: {device_info.get('effectiveStatus', 'UNKNOWN')}")
        print(f"[INIT]   Last seen: {device_info.get('lastSeenAt', 'never')}")
    else:
        print(f"[INIT] ✗ Heartbeat failed: {data}")
        if "DEVICE_NOT_FOUND" in str(data) or "设备未注册" in str(data):
            print("\n[ERROR] Device not registered on server!")
            print("        Register it first via the server API or UI.")
            await client.close()
            return 1
    
    # Handle Ctrl+C
    stop_event = asyncio.Event()
    
    def signal_handler():
        print("\n\nStopping...")
        stop_event.set()
    
    loop = asyncio.get_event_loop()
    for sig in (signal.SIGINT, signal.SIGTERM):
        loop.add_signal_handler(sig, signal_handler)
    
    print(f"\n[RUN] Sync service running. Press Ctrl+C to stop.\n")
    
    # Background tasks
    async def heartbeat_loop():
        while not stop_event.is_set():
            ok, data = await client.heartbeat()
            status = "✓" if ok else "✗"
            ts = datetime.now().strftime("%H:%M:%S")
            print(f"[{ts}] Heartbeat: {status}")
            if not ok:
                print(f"         Error: {data}")
            await asyncio.sleep(args.heartbeat)
    
    async def topo_loop():
        await asyncio.sleep(5)  # Initial delay (5 seconds)
        while not stop_event.is_set():
            print(f"\n[{datetime.now().strftime('%H:%M:%S')}] Starting topo sync...")
            topo = get_sample_topo()
            ok, data = await client.send_topo(topo)
            status = "✓" if ok else "✗"
            ts = datetime.now().strftime("%H:%M:%S")
            print(f"[{ts}] Topo sync result: {status}")
            if not ok:
                print(f"         Error: {data}")
            else:
                print(f"         Topo ID: {data.get('data', {}).get('id', 'unknown')}")
            await asyncio.sleep(args.topo_interval)
    
    async def event_loop():
        await asyncio.sleep(30)  # Initial delay
        while not stop_event.is_set():
            event = create_test_event()
            ok, data = await client.send_event(event)
            status = "✓" if ok else "✗"
            ts = datetime.now().strftime("%H:%M:%S")
            print(f"[{ts}] Event sent: {status}")
            if ok:
                print(f"         Event ID: {data.get('event', {}).get('id', 'unknown')}")
            else:
                print(f"         Error: {data}")
            await asyncio.sleep(60)
    
    # Start tasks
    tasks = [
        asyncio.create_task(heartbeat_loop()),
        asyncio.create_task(topo_loop()),
    ]
    
    if args.send_events:
        tasks.append(asyncio.create_task(event_loop()))
    
    # Wait for stop
    await stop_event.wait()
    
    # Cancel tasks
    for task in tasks:
        task.cancel()
        try:
            await task
        except asyncio.CancelledError:
            pass
    
    await client.close()
    
    # Stats
    print("\n" + "=" * 60)
    print("Statistics")
    print("=" * 60)
    print(f"Heartbeat: {client.heartbeat_success} success, {client.heartbeat_failure} failed")
    print(f"Topo:      {client.topo_success} success, {client.topo_failure} failed")
    print(f"Events:    {client.event_success} success, {client.event_failure} failed")
    
    return 0


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
