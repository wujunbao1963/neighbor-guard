#!/usr/bin/env python3
"""
Z-Wave JS WebSocket 连接测试

测试 WebSocket 连接是否可用
"""

import asyncio
import json
import sys

# 尝试不同的端口
PORTS_TO_TRY = [3000, 8091]

async def test_websocket(port):
    """测试 WebSocket 连接"""
    try:
        import websockets
    except ImportError:
        print("❌ websockets 未安装")
        print("   运行: pip install websockets --break-system-packages")
        return False
    
    url = f"ws://localhost:{port}"
    print(f"\n测试 {url} ...")
    
    try:
        async with websockets.connect(url, open_timeout=5) as ws:
            # 接收版本信息
            msg = await asyncio.wait_for(ws.recv(), timeout=5)
            data = json.loads(msg)
            
            print(f"✅ 连接成功!")
            print(f"   类型: {data.get('type', 'unknown')}")
            
            if 'maxSchemaVersion' in data:
                print(f"   Schema: {data.get('maxSchemaVersion')}")
            if 'driverVersion' in data:
                print(f"   Driver: {data.get('driverVersion')}")
            if 'serverVersion' in data:
                print(f"   Server: {data.get('serverVersion')}")
            
            return True
            
    except asyncio.TimeoutError:
        print(f"❌ 连接超时")
        return False
    except ConnectionRefusedError:
        print(f"❌ 连接被拒绝 (端口 {port} 未监听)")
        return False
    except Exception as e:
        print(f"❌ 连接失败: {e}")
        return False

async def main():
    print("=" * 60)
    print("  Z-Wave JS WebSocket 连接测试")
    print("=" * 60)
    
    success_port = None
    
    for port in PORTS_TO_TRY:
        if await test_websocket(port):
            success_port = port
            break
    
    print("\n" + "=" * 60)
    
    if success_port:
        print(f"✅ WebSocket 可用于端口 {success_port}")
        
        if success_port != 3000:
            print(f"\n⚠️  注意: 默认端口是 3000，但 {success_port} 可用")
            print(f"   如果需要修改配置，编辑 edge_runtime.py:")
            print(f'   keypad_ws_url="ws://localhost:{success_port}"')
    else:
        print("❌ 所有端口都连接失败")
        print("\n可能的原因:")
        print("  1. Z-Wave JS UI 未运行")
        print("  2. WebSocket 端口配置不同")
        print("  3. 防火墙阻止连接")
        print("\n检查 Z-Wave JS UI 设置:")
        print("  打开 http://localhost:8091")
        print("  Settings → Websocket Server → Port")

if __name__ == "__main__":
    asyncio.run(main())
