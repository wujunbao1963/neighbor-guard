#!/usr/bin/env python3
"""
测试 Reolink 灯光模式

用法:
    python test_reolink_whiteled.py <ip> <user> <password> [command]

命令:
    info        - 查看灯光设置和可用模式
    on          - 开灯（常亮）
    off         - 关灯
    auto        - 自动模式
    flash       - 闪烁模式（如果支持）
    mode:<n>    - 设置模式 n (0, 1, 2, ...)
"""

import asyncio
import sys


async def main():
    if len(sys.argv) < 4:
        print(__doc__)
        return
    
    ip, user, password = sys.argv[1:4]
    command = sys.argv[4] if len(sys.argv) > 4 else "info"
    
    print(f"[TEST] 连接 {ip}...")
    
    from reolink_aio.api import Host
    host = Host(ip, user, password)
    
    try:
        await host.get_host_data()
        model = host.camera_model(0)
        print(f"[TEST] ✅ 已连接: {model}")
        
        # 获取灯光信息
        print(f"\n=== 灯光设置 ===")
        print(f"  whiteled_state: {host.whiteled_state(0)}")
        print(f"  whiteled_mode: {host.whiteled_mode(0)}")
        print(f"  whiteled_mode_list: {host.whiteled_mode_list(0)}")
        print(f"  whiteled_brightness: {host.whiteled_brightness(0)}")
        print(f"  whiteled_settings: {host.whiteled_settings(0)}")
        
        # 事件相关设置
        print(f"\n=== 事件触发设置 ===")
        try:
            print(f"  whiteled_event_mode: {host.whiteled_event_mode(0)}")
            print(f"  whiteled_event_brightness: {host.whiteled_event_brightness(0)}")
            print(f"  whiteled_event_flash_time: {host.whiteled_event_flash_time(0)}")
            print(f"  whiteled_event_on_time: {host.whiteled_event_on_time(0)}")
        except Exception as e:
            print(f"  (事件设置不可用: {e})")
        
        if command == "info":
            print("\n完成。")
        
        elif command == "on":
            print(f"\n[TEST] 开灯（常亮）...")
            await host.set_whiteled(0, state=True, brightness=100)
            print(f"[TEST] ✅ 灯已开")
        
        elif command == "off":
            print(f"\n[TEST] 关灯...")
            await host.set_whiteled(0, state=False)
            print(f"[TEST] ✅ 灯已关")
        
        elif command == "auto":
            print(f"\n[TEST] 设置自动模式...")
            await host.set_whiteled(0, mode="auto")
            print(f"[TEST] ✅ 已设置自动模式")
        
        elif command == "flash":
            print(f"\n[TEST] 尝试闪烁模式...")
            # 尝试不同的方式
            modes = host.whiteled_mode_list(0) or []
            print(f"可用模式: {modes}")
            
            for mode_name in ["flash", "flashing", "strobe", "blink"]:
                if mode_name in [m.lower() for m in modes]:
                    print(f"找到模式: {mode_name}")
                    await host.set_whiteled(0, mode=mode_name)
                    print(f"[TEST] ✅ 已设置 {mode_name} 模式")
                    break
            else:
                print("[TEST] ⚠️ 未找到闪烁模式，尝试数字模式...")
                # 尝试数字模式
                for i in range(5):
                    try:
                        print(f"  尝试 mode={i}...")
                        await host.set_whiteled(0, state=True, mode=i)
                        await asyncio.sleep(2)
                        print(f"  mode={i} 成功，观察灯光...")
                        await asyncio.sleep(3)
                    except Exception as e:
                        print(f"  mode={i} 失败: {e}")
        
        elif command.startswith("mode:"):
            mode_val = command.split(":")[1]
            print(f"\n[TEST] 设置模式 {mode_val}...")
            try:
                mode_int = int(mode_val)
                await host.set_whiteled(0, state=True, mode=mode_int)
            except ValueError:
                await host.set_whiteled(0, mode=mode_val)
            print(f"[TEST] ✅ 已设置模式 {mode_val}")
        
        else:
            print(f"[ERROR] 未知命令: {command}")
    
    except Exception as e:
        print(f"[ERROR] 失败: {e}")
        import traceback
        traceback.print_exc()
    
    finally:
        await host.logout()


if __name__ == "__main__":
    asyncio.run(main())
