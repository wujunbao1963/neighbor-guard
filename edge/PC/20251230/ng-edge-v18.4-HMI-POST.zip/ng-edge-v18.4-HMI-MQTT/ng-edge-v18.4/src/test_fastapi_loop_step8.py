#!/usr/bin/env python3
"""
Step 8: 最小化测试 - 验证 FastAPI 事件循环

这个测试模拟 FastAPI 环境下的 asyncio.create_task 行为

用法:
    python test_fastapi_loop_step8.py 10.0.0.155 admin YOUR_PASSWORD
"""

import asyncio
import sys


class SimpleDeterrent:
    """简化的威慑控制器"""
    
    def __init__(self, ip: str, user: str, password: str):
        self.ip = ip
        self.user = user
        self.password = password
        self.active = False
        self._task = None
        self._host = None
    
    async def connect(self):
        from reolink_aio.api import Host
        self._host = Host(self.ip, self.user, self.password)
        await self._host.get_host_data()
        print(f"[Deterrent] 已连接: {self._host.camera_model(0)}")
    
    async def disconnect(self):
        if self._host:
            await self._host.logout()
    
    async def start(self):
        if self.active:
            return
        
        self.active = True
        self._task = asyncio.create_task(self._loop())
        print("[Deterrent] 已启动")
    
    async def stop(self):
        if not self.active:
            return
        
        print("[Deterrent] 停止中...")
        self.active = False
        
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                print("[Deterrent] 任务已取消")
            self._task = None
        
        # 确保关灯
        await self._host.set_whiteled(0, state=False)
        await self._host.set_siren(0, False)
        print("[Deterrent] 已停止")
    
    async def _loop(self):
        print("[Deterrent] 循环开始")
        beep_count = 0
        
        await self._host.set_whiteled(0, state=True)
        
        try:
            while self.active:
                await asyncio.sleep(1)
                
                if not self.active:
                    print("[Deterrent] 检测到 active=False，退出循环")
                    break
                
                beep_count += 1
                print(f"[Deterrent] Beep #{beep_count}")
                
                await self._host.set_siren(0, True)
                await asyncio.sleep(0.1)
                await self._host.set_siren(0, False)
        
        except asyncio.CancelledError:
            print("[Deterrent] 循环被取消")
            raise
        
        finally:
            print("[Deterrent] 循环结束，清理中...")
            await self._host.set_whiteled(0, state=False)
            await self._host.set_siren(0, False)
            print("[Deterrent] 清理完成")


async def simulate_fastapi_detection_loop(deterrent: SimpleDeterrent):
    """模拟 FastAPI 中的检测循环"""
    print("\n=== 模拟 FastAPI 检测循环 ===")
    
    # 模拟检测到人
    print("\n[模拟] 检测到人，启动威慑...")
    await deterrent.start()
    
    # 等待 5 秒
    for i in range(5):
        print(f"[模拟] 检测中... {i+1}s")
        await asyncio.sleep(1)
    
    # 模拟人离开
    print("\n[模拟] 人离开，停止威慑...")
    await deterrent.stop()
    
    # 等待 2 秒确认停止
    print("\n[模拟] 等待 2 秒确认...")
    await asyncio.sleep(2)
    
    print("\n[模拟] 测试完成")


async def main():
    if len(sys.argv) < 4:
        print("用法: python test_fastapi_loop_step8.py <ip> <user> <password>")
        return
    
    ip, user, password = sys.argv[1:4]
    
    print("=" * 60)
    print("Step 8: FastAPI 事件循环测试")
    print("=" * 60)
    
    deterrent = SimpleDeterrent(ip, user, password)
    
    try:
        await deterrent.connect()
        
        # 创建一个后台任务来运行检测循环（模拟 FastAPI 的 create_task）
        detection_task = asyncio.create_task(simulate_fastapi_detection_loop(deterrent))
        
        # 等待任务完成
        await detection_task
        
    finally:
        await deterrent.disconnect()
    
    print("\n" + "=" * 60)
    print("测试完成")
    print("=" * 60)


if __name__ == "__main__":
    asyncio.run(main())
