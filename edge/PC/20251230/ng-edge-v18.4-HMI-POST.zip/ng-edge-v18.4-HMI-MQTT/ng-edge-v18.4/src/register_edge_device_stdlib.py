#!/usr/bin/env python3
"""
NG Edge - Device Registration Helper (No external dependencies)

Uses only Python stdlib - no pip install needed!

Usage:
    # Read device key and pass as argument
    DEVICE_KEY=$(sudo cat /var/lib/ng-edge/device_key)
    python3 register_edge_device.py --server http://10.0.0.136:3001 --device-key "$DEVICE_KEY"
"""

import argparse
import json
import sys
from urllib.request import Request, urlopen
from urllib.error import URLError, HTTPError


def http_request(url: str, method: str = "GET", data: dict = None, headers: dict = None) -> tuple:
    """Make HTTP request using stdlib."""
    headers = headers or {}
    headers["Content-Type"] = "application/json"
    
    body = json.dumps(data).encode() if data else None
    
    req = Request(url, data=body, headers=headers, method=method)
    
    try:
        with urlopen(req, timeout=10) as resp:
            response_data = json.loads(resp.read().decode())
            return resp.status, response_data
    except HTTPError as e:
        try:
            response_data = json.loads(e.read().decode())
        except:
            response_data = {"error": str(e)}
        return e.code, response_data
    except URLError as e:
        return 0, {"error": str(e.reason)}
    except Exception as e:
        return 0, {"error": str(e)}


def main():
    parser = argparse.ArgumentParser(description="Register Edge Device (no dependencies)")
    parser.add_argument("--server", "-s", default="http://10.0.0.136:3001")
    parser.add_argument("--device-key", "-k", required=True, help="Device key (e.g., NGEDGE-xxx)")
    parser.add_argument("--email", "-e", default="edge-admin@test.com")
    parser.add_argument("--code", "-c", default="587585", help="Verification code")
    parser.add_argument("--circle-name", default="My Home")
    parser.add_argument("--device-name", default="UP Xtreme Edge")
    
    args = parser.parse_args()
    
    server = args.server.rstrip("/")
    device_key = args.device_key.strip()
    
    print("=" * 60)
    print("NG Edge - Device Registration")
    print("=" * 60)
    print(f"Server:     {server}")
    print(f"Email:      {args.email}")
    print(f"Device Key: {device_key}")
    print()
    
    # Step 1: Request code
    print("Step 1: Requesting verification code...")
    status, data = http_request(
        f"{server}/api/auth/request-code",
        method="POST",
        data={"email": args.email}
    )
    if status == 200 and data.get("success"):
        print(f"  ✓ Code requested (test mode uses {args.code})")
    else:
        print(f"  ✗ Failed: {data}")
        return 1
    
    # Step 2: Login
    print("\nStep 2: Logging in with code...")
    status, data = http_request(
        f"{server}/api/auth/login",
        method="POST",
        data={"email": args.email, "code": args.code}
    )
    if status != 200 or not data.get("accessToken"):
        print(f"  ✗ Login failed: {data}")
        return 1
    
    token = data["accessToken"]
    print(f"  ✓ Login successful")
    print(f"  Token: {token[:40]}...")
    
    auth_header = {"Authorization": f"Bearer {token}"}
    
    # Step 3: Get or create circle
    print("\nStep 3: Getting/creating circle...")
    status, data = http_request(
        f"{server}/api/circles",
        method="GET",
        headers=auth_header
    )
    
    circles = data.get("circles", []) if status == 200 else []
    
    if circles:
        circle = circles[0]
        print(f"  ✓ Using existing circle: {circle.get('name')} (ID: {circle.get('id')})")
    else:
        status, data = http_request(
            f"{server}/api/circles",
            method="POST",
            data={"name": args.circle_name},
            headers=auth_header
        )
        if status not in (200, 201):
            print(f"  ✗ Failed to create circle: {data}")
            return 1
        circle = data.get("circle") or data
        print(f"  ✓ Created circle: {circle.get('name')} (ID: {circle.get('id')})")
    
    circle_id = circle.get("id")
    
    # Step 4: Register device
    print("\nStep 4: Registering edge device...")
    status, data = http_request(
        f"{server}/api/edge/devices",
        method="POST",
        data={
            "circleId": circle_id,
            "deviceKey": device_key,
            "displayName": args.device_name,
        },
        headers=auth_header
    )
    
    if status == 200 and data.get("success"):
        device = data.get("data", {})
        print(f"  ✓ Device registered!")
        print(f"    Device ID: {device.get('id')}")
        print(f"    Circle ID: {device.get('circleId')}")
        print(f"    Status: {device.get('effectiveStatus', 'UNKNOWN')}")
    else:
        print(f"  ⚠ Response: {data}")
        # May already be registered, continue anyway
    
    # Step 5: Test heartbeat
    print("\nStep 5: Testing heartbeat...")
    device_auth = {"Authorization": f"Device {device_key}"}
    status, data = http_request(
        f"{server}/api/edge/devices/{device_key}/heartbeat",
        method="POST",
        data={"status": "ONLINE", "fwVersion": "1.1.0"},
        headers=device_auth
    )
    
    if status == 200 and data.get("success"):
        device = data.get("data", {})
        print(f"  ✓ Heartbeat successful!")
        print(f"    Status: {device.get('effectiveStatus')}")
        print(f"    Last Seen: {device.get('lastSeenAt')}")
    else:
        print(f"  ✗ Heartbeat failed: {data}")
        return 1
    
    # Summary
    print("\n" + "=" * 60)
    print("✓ REGISTRATION COMPLETE")
    print("=" * 60)
    print(f"Device Key: {device_key}")
    print(f"Circle ID:  {circle_id}")
    print()
    print("To run sync service, first install aiohttp:")
    print("  sudo pip3 install aiohttp --break-system-packages")
    print()
    print("Then run:")
    print(f"  sudo python3 run_sync_v2.py --server {server}")
    
    return 0


if __name__ == "__main__":
    sys.exit(main())
