"""
Camera Detection Service - NeighborGuard Edge

摄像头 YOLO 检测服务，实现 PRE L0/L1/L2 威慑 (PRD §3)

核心功能:
- RTSP 实时抓帧
- YOLO 人员检测
- 分区判断 (door/yard/street → PRE-L2/L1/L0)
- 独立威慑控制 (PRD §3: 不升级到 PENDING)

基于已验证的 yolo11_multi_camera.py 代码
"""

import asyncio
import logging
import threading
import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Callable, Any

import cv2

# 使用 print 而不是 logger，确保日志输出
def log_info(msg):
    print(msg)

def log_warning(msg):
    print(f"[WARN] {msg}")

def log_error(msg):
    print(f"[ERROR] {msg}")

def log_debug(msg):
    # 调试时可以取消注释
    # print(f"[DEBUG] {msg}")
    pass

logger = logging.getLogger(__name__)


# ============================================================
# 配置
# ============================================================

@dataclass
class CameraDetectionConfig:
    """摄像头检测配置"""
    name: str
    ip: str
    user: str
    password: str
    entry_point_id: str = ""  # 关联的入口点
    stream_path: str = "h264Preview_01_sub"
    zone_mode: str = "horizontal"  # horizontal (俯视) 或 vertical (水平视角)
    direction: str = "bottom_to_top"
    zones: Dict = None
    deterrent: Dict = None
    conf_threshold: float = 0.3
    
    def __post_init__(self):
        if self.zones is None:
            if self.zone_mode == "horizontal":
                self.zones = {
                    "door_threshold": 0.55,
                    "yard_threshold": 0.20,
                }
            else:
                self.zones = {
                    "door_threshold": 0.3,
                    "yard_threshold": 1.0,
                }
        
        if self.deterrent is None:
            self.deterrent = {
                "l1_interval": 5,
                "l1_flash": False,
                "l2_interval": 1,
                "l2_flash": True,
            }


# 预设配置
CAMERA_PRESETS = {
    "backdoor": {
        "stream_path": "h264Preview_01_sub",
        "zone_mode": "horizontal",
        "direction": "bottom_to_top",
        "zones": {"door_threshold": 0.55, "yard_threshold": 0.20},
        "deterrent": {"l1_interval": 5, "l1_flash": False, "l2_interval": 1, "l2_flash": True},
    },
    "frontdoor": {
        "stream_path": "h264Preview_01_sub",
        "zone_mode": "vertical",
        "direction": "left_to_right",
        "zones": {"door_threshold": 0.32, "yard_threshold": 1.0},
        "deterrent": {"l1_interval": 20, "l1_flash": False, "l2_interval": 5, "l2_flash": True},
    },
}


# ============================================================
# RTSP 实时抓帧
# ============================================================

class RTSPRealtimeCapture:
    """实时 RTSP 抓帧（独立线程读取）"""
    
    def __init__(self, rtsp_url: str, name: str = "camera"):
        self.rtsp_url = rtsp_url
        self.name = name
        self.cap = None
        self.frame = None
        self.frame_time = 0
        self.frame_count = 0
        self.running = False
        self.lock = threading.Lock()
        self.width = 0
        self.height = 0
        
        # 设置低延迟 FFmpeg 选项
        import os
        os.environ['OPENCV_FFMPEG_CAPTURE_OPTIONS'] = (
            'rtsp_transport;tcp|'
            'fflags;nobuffer+discardcorrupt|'
            'flags;low_delay|'
            'max_delay;500000|'
            'reorder_queue_size;0'
        )
    
    def start(self) -> bool:
        log_info(f"[{self.name}] 连接 RTSP...")
        self.cap = cv2.VideoCapture(self.rtsp_url, cv2.CAP_FFMPEG)
        
        # 设置最小缓冲
        self.cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
        
        if not self.cap.isOpened():
            log_error(f"[{self.name}] ❌ RTSP 连接失败")
            return False
        
        self.width = int(self.cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        self.height = int(self.cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        log_info(f"[{self.name}] ✅ RTSP 已连接 ({self.width}x{self.height})")
        
        self.running = True
        threading.Thread(target=self._read_loop, daemon=True).start()
        time.sleep(1)
        return True
    
    def _read_loop(self):
        """读取循环 - 清空缓冲区，始终获取最新帧"""
        consecutive_failures = 0
        
        while self.running:
            # 清空缓冲区：持续 grab 直到耗时变长
            skipped = 0
            while True:
                grab_start = time.time()
                grabbed = self.cap.grab()
                grab_time = time.time() - grab_start
                
                if not grabbed:
                    break
                
                skipped += 1
                
                # 如果 grab 耗时 > 40ms，说明缓冲区已空
                if grab_time > 0.04:
                    break
                
                # 安全限制
                if skipped > 500:
                    log_info(f"[{self.name}] ⚠️ 缓冲区超大，跳过 {skipped} 帧")
                    break
            
            # 解码最新帧
            ret, frame = self.cap.retrieve()
            
            if ret and frame is not None:
                with self.lock:
                    self.frame = frame
                    self.frame_time = time.time()
                    self.frame_count += 1
                consecutive_failures = 0
                
                # 调试日志已注释（v2.39）
                # if self.frame_count % 100 == 0 and skipped > 5:
                #     log_info(f"[{self.name}] 清空缓冲: 跳过 {skipped} 帧")
            else:
                consecutive_failures += 1
                if consecutive_failures > 30:
                    log_error(f"[{self.name}] 连续读取失败，尝试重连...")
                    self._reconnect()
                    consecutive_failures = 0
                time.sleep(0.01)
    
    def _reconnect(self):
        """重连 RTSP"""
        if self.cap:
            self.cap.release()
        time.sleep(1)
        self.cap = cv2.VideoCapture(self.rtsp_url, cv2.CAP_FFMPEG)
        self.cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
    
    def get_frame(self):
        with self.lock:
            if self.frame is None:
                return None, 0, 0
            return self.frame.copy(), self.frame_time, self.frame_count
    
    def stop(self):
        self.running = False
        if self.cap:
            self.cap.release()
        log_info(f"[{self.name}] RTSP 已断开")


# ============================================================
# Reolink 控制器
# ============================================================

class ReolinkController:
    """Reolink 摄像头控制"""
    
    def __init__(self, ip: str, user: str, password: str, name: str = "camera"):
        self.ip = ip
        self.user = user
        self.password = password
        self.name = name
        self._host = None
    
    async def connect(self):
        from reolink_aio.api import Host
        log_info(f"[{self.name}] 连接 Reolink API...")
        self._host = Host(self.ip, self.user, self.password)
        await self._host.get_host_data()
        model = self._host.camera_model(0)
        log_info(f"[{self.name}] ✅ 已连接: {model}")
    
    async def disconnect(self):
        if self._host:
            await self._host.logout()
            log_info(f"[{self.name}] Reolink 已断开")
    
    async def spotlight(self, on: bool):
        if self._host:
            try:
                await self._host.set_whiteled(0, state=on)
            except Exception as e:
                log_warning(f"[{self.name}] Spotlight 错误: {e}")
    
    async def siren(self, on: bool):
        if self._host:
            try:
                await self._host.set_siren(0, on)
            except Exception as e:
                log_warning(f"[{self.name}] Siren 错误: {e}")


# ============================================================
# 威慑控制器 (PRD §3: PRE-L0/L1/L2)
# ============================================================

class DeterrentController:
    """
    威慑控制器（每个摄像头独立）
    
    PRD §3.1:
    - PRE-L0: 静默记录
    - PRE-L1: 稳定灯光 + 可选静默通知
    - PRE-L2: 增强灯光 + 1Hz beep + 强通知
    
    PRD §3.2 约束:
    - 无警报 (siren)
    - 无派遣
    - 无强制用户操作
    """
    
    def __init__(self, reolink: ReolinkController, name: str = "camera", config: Dict = None):
        self.reolink = reolink
        self.name = name
        self.active = False
        self.level = 0
        self.house_mode = "away"
        self._task = None
        
        # 威慑参数
        config = config or {}
        self.l1_interval = config.get("l1_interval", 5)
        self.l1_flash = config.get("l1_flash", False)
        self.l2_interval = config.get("l2_interval", 1)
        self.l2_flash = config.get("l2_flash", True)
        
        log_info(f"[{name}] 威慑配置: L1(间隔{self.l1_interval}s) L2(间隔{self.l2_interval}s,闪灯={self.l2_flash})")
    
    def set_house_mode(self, mode: str):
        self.house_mode = mode
    
    async def start(self, pre_level: int):
        """启动威慑"""
        if self.active and self.level == pre_level:
            return
        
        if self.active:
            direction = "⬆️" if pre_level > self.level else "⬇️"
            log_info(f"[{self.name}] {direction} L{self.level} → L{pre_level}")
            await self._stop_task()
        
        self.active = True
        self.level = pre_level
        
        # DISARMED/HOME 模式只开灯
        if self.house_mode in ("disarmed", "home"):
            log_info(f"[{self.name}] {self.house_mode.upper()}: 仅 Spotlight 常亮")
            await self._spotlight_on()
            return
        
        if pre_level == 0:
            # PRE-L0: 静默记录
            log_info(f"[{self.name}] PRE-L0: 仅记录")
            await self._spotlight_off()
        
        elif pre_level == 1:
            # PRE-L1: 稳定灯光 + 间隔 beep
            flash_str = "闪灯" if self.l1_flash else "常亮"
            log_info(f"[{self.name}] PRE-L1: Spotlight {flash_str} + 每{self.l1_interval}秒 Beep")
            self._task = asyncio.create_task(self._level_loop(
                interval=self.l1_interval,
                flash=self.l1_flash,
                level_name="L1"
            ))
        
        elif pre_level >= 2:
            # PRE-L2: 增强灯光 + 1Hz beep
            flash_str = "闪灯" if self.l2_flash else "常亮"
            log_info(f"[{self.name}] PRE-L2: Spotlight {flash_str} + 每{self.l2_interval}秒 Beep")
            self._task = asyncio.create_task(self._level_loop(
                interval=self.l2_interval,
                flash=self.l2_flash,
                level_name="L2"
            ))
    
    async def _spotlight_on(self):
        for retry in range(3):
            try:
                await self.reolink.spotlight(True)
                return True
            except:
                await asyncio.sleep(0.5)
        return False
    
    async def _spotlight_off(self):
        for retry in range(3):
            try:
                await self.reolink.spotlight(False)
                return True
            except:
                await asyncio.sleep(0.5)
        return False
    
    async def _level_loop(self, interval: int, flash: bool, level_name: str):
        """威慑循环 (PRD §3: beep 不是 siren)"""
        beep_count = 0
        light_on = True
        
        await self._spotlight_on()
        
        try:
            while self.active:
                # 分段 sleep，更频繁检查 active 状态
                for _ in range(interval * 10):  # 每 0.1 秒检查一次
                    if not self.active:
                        log_info(f"[{self.name}] 威慑循环检测到停止信号")
                        return
                    await asyncio.sleep(0.1)
                
                if not self.active:
                    break
                
                beep_count += 1
                
                # 闪灯
                if flash:
                    light_on = not light_on
                    if light_on:
                        await self._spotlight_on()
                    else:
                        await self._spotlight_off()
                    log_info(f"[{self.name}] 🔊💡 {level_name} Beep #{beep_count} Light={'ON' if light_on else 'OFF'}")
                else:
                    log_info(f"[{self.name}] 🔊 {level_name} Beep #{beep_count}")
                
                # 短促 beep (不是持续 siren)
                if self.active:  # 再次检查
                    await self.reolink.siren(True)
                    await asyncio.sleep(0.1)
                    await self.reolink.siren(False)
        
        except asyncio.CancelledError:
            log_info(f"[{self.name}] 威慑循环被取消")
        finally:
            await self._spotlight_off()
            try:
                await self.reolink.siren(False)
            except:
                pass
            log_info(f"[{self.name}] 威慑循环已退出")
    
    async def _stop_task(self):
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
            self._task = None
        
        await self._spotlight_off()
        try:
            await self.reolink.siren(False)
        except:
            pass
    
    async def stop(self):
        """停止威慑"""
        if not self.active and self.level == 0:
            return
        
        self.active = False
        await self._stop_task()
        self.level = 0
        log_info(f"[{self.name}] 威慑已停止")


# ============================================================
# 摄像头检测器
# ============================================================

class CameraDetector:
    """单个摄像头的 YOLO 检测器"""
    
    CONFIRM_FRAMES = 2  # 确认帧数
    CLEAR_DELAY = 5.0   # 清除延迟
    
    def __init__(self, config: CameraDetectionConfig, model, house_mode: str = "away"):
        self.config = config
        self.model = model
        self.house_mode = house_mode
        
        self.capture: Optional[RTSPRealtimeCapture] = None
        self.reolink: Optional[ReolinkController] = None
        self.deterrent: Optional[DeterrentController] = None
        
        # 状态
        self.person_active = False
        self.current_zone = ""
        self.current_level = 0
        self.last_person_time = 0
        self.consecutive_detections = 0
        self.last_frame_count = 0
        
        # 回调
        self._on_pre_change: Optional[Callable] = None
    
    def set_on_pre_change(self, callback: Callable[[str, int, str], None]):
        """
        设置 PRE 级别变化回调
        
        callback(camera_name, pre_level, zone)
        """
        self._on_pre_change = callback
    
    def get_zone(self, bbox: List[int]) -> tuple:
        """根据 bbox 判断分区"""
        x1, y1, x2, y2 = bbox
        
        if self.config.zone_mode == "vertical":
            x_center = (x1 + x2) // 2
            width = self.capture.width if self.capture else 896
            
            door_x = int(width * self.config.zones["door_threshold"])
            yard_x = int(width * self.config.zones.get("yard_threshold", 1.0))
            
            if self.config.direction == "left_to_right":
                if x_center < door_x:
                    return "door", 2
                elif yard_x < 1.0 * width and x_center >= yard_x:
                    return "street", 0
                else:
                    return "yard", 1
            else:
                if x_center > width - door_x:
                    return "door", 2
                elif yard_x < 1.0 * width and x_center <= width - yard_x:
                    return "street", 0
                else:
                    return "yard", 1
        else:
            y_bottom = y2
            height = self.capture.height if self.capture else 576
            
            door_y = int(height * self.config.zones["door_threshold"])
            yard_y = int(height * self.config.zones["yard_threshold"])
            
            if y_bottom >= door_y:
                return "door", 2
            elif y_bottom >= yard_y:
                return "yard", 1
            else:
                return "street", 0
    
    async def start(self) -> bool:
        """启动检测"""
        name = self.config.name
        
        # RTSP
        rtsp_url = f"rtsp://{self.config.user}:{self.config.password}@{self.config.ip}:554/{self.config.stream_path}"
        self.capture = RTSPRealtimeCapture(rtsp_url, name)
        if not self.capture.start():
            return False
        
        # Reolink API
        self.reolink = ReolinkController(
            self.config.ip, self.config.user, self.config.password, name
        )
        await self.reolink.connect()
        
        # 威慑控制器
        self.deterrent = DeterrentController(self.reolink, name, self.config.deterrent)
        self.deterrent.set_house_mode(self.house_mode)
        
        return True
    
    async def stop(self):
        """停止检测"""
        if self.deterrent:
            await self.deterrent.stop()
        if self.reolink:
            await self.reolink.disconnect()
        if self.capture:
            self.capture.stop()
    
    def set_house_mode(self, mode: str):
        """设置房屋模式"""
        self.house_mode = mode
        if self.deterrent:
            self.deterrent.set_house_mode(mode)
    
    async def process_frame(self) -> bool:
        """处理一帧"""
        if not self.capture:
            return False
        
        frame, frame_time, frame_count = self.capture.get_frame()
        
        if frame is None or frame_count == self.last_frame_count:
            return False
        
        self.last_frame_count = frame_count
        now = time.time()
        name = self.config.name
        
        # YOLO 检测
        results = self.model(frame, verbose=False, conf=self.config.conf_threshold)
        
        persons = []
        for r in results:
            for box in r.boxes:
                cls_id = int(box.cls[0])
                if self.model.names[cls_id] == "person":
                    conf = float(box.conf[0])
                    bbox = [int(v) for v in box.xyxy[0].tolist()]
                    zone, pre_level = self.get_zone(bbox)
                    persons.append({
                        "conf": conf,
                        "bbox": bbox,
                        "zone": zone,
                        "pre_level": pre_level,
                    })
        
        # 状态机
        if persons:
            self.last_person_time = now
            self.consecutive_detections += 1
            
            best = max(persons, key=lambda x: x["pre_level"])
            
            log_debug(f"[{name}] 👤 PERSON conf={best['conf']:.2f} zone={best['zone']} PRE-L{best['pre_level']}")
            
            if not self.person_active:
                if self.consecutive_detections >= self.CONFIRM_FRAMES:
                    self.person_active = True
                    self.current_zone = best["zone"]
                    self.current_level = best["pre_level"]
                    
                    log_info(f"[{name}] ========== PERSON ENTER | {self.current_zone} L{self.current_level} ==========")
                    
                    if self.house_mode != "disarmed":
                        await self.deterrent.start(self.current_level)
                    
                    # 回调
                    if self._on_pre_change:
                        self._on_pre_change(name, self.current_level, self.current_zone)
            else:
                if best["pre_level"] != self.current_level:
                    old_level = self.current_level
                    self.current_zone = best["zone"]
                    self.current_level = best["pre_level"]
                    
                    direction = "⬆️" if self.current_level > old_level else "⬇️"
                    log_info(f"[{name}] {direction} L{old_level} → L{self.current_level} ({self.current_zone})")
                    
                    if self.house_mode != "disarmed":
                        await self.deterrent.start(self.current_level)
                    
                    # 回调
                    if self._on_pre_change:
                        self._on_pre_change(name, self.current_level, self.current_zone)
        else:
            if not self.person_active:
                self.consecutive_detections = 0
            else:
                if now - self.last_person_time > self.CLEAR_DELAY:
                    log_info(f"[{name}] ========== PERSON LEAVE ==========")
                    
                    await self.deterrent.stop()
                    self.person_active = False
                    self.current_zone = ""
                    self.current_level = 0
                    self.consecutive_detections = 0
                    
                    # 回调
                    if self._on_pre_change:
                        self._on_pre_change(name, 0, "")
        
        return True


# ============================================================
# 摄像头检测服务
# ============================================================

class CameraDetectionService:
    """
    摄像头检测服务
    
    作为 ng-edge 的一个后台服务运行，处理所有摄像头的 YOLO 检测和 PRE 威慑
    """
    
    def __init__(self, house_mode: str = "away"):
        self.house_mode = house_mode
        self.detectors: Dict[str, CameraDetector] = {}
        self.model = None
        self._running = False
        self._task = None
        self._on_pre_change: Optional[Callable] = None
    
    def set_on_pre_change(self, callback: Callable[[str, int, str], None]):
        """设置 PRE 级别变化回调"""
        self._on_pre_change = callback
    
    async def add_camera(self, config: CameraDetectionConfig) -> bool:
        """添加摄像头"""
        if config.name in self.detectors:
            log_warning(f"[CameraService] 摄像头 {config.name} 已存在")
            return False
        
        # 懒加载 YOLO 模型
        if self.model is None:
            try:
                from ultralytics import YOLO
                log_info("[CameraService] 加载 YOLO 模型...")
                self.model = YOLO("yolo11s.pt")
                log_info("[CameraService] ✅ YOLO 模型就绪")
            except Exception as e:
                log_error(f"[CameraService] ❌ YOLO 加载失败: {e}")
                return False
        
        detector = CameraDetector(config, self.model, self.house_mode)
        
        # 设置回调
        if self._on_pre_change:
            detector.set_on_pre_change(self._on_pre_change)
        
        if await detector.start():
            self.detectors[config.name] = detector
            log_info(f"[CameraService] ✅ 摄像头 {config.name} 已添加")
            return True
        else:
            log_error(f"[CameraService] ❌ 摄像头 {config.name} 启动失败")
            return False
    
    async def remove_camera(self, name: str):
        """移除摄像头"""
        if name in self.detectors:
            await self.detectors[name].stop()
            del self.detectors[name]
            log_info(f"[CameraService] 摄像头 {name} 已移除")
    
    def set_house_mode(self, mode: str):
        """设置房屋模式"""
        self.house_mode = mode
        for detector in self.detectors.values():
            detector.set_house_mode(mode)
        log_info(f"[CameraService] 房屋模式: {mode}")
    
    async def start(self):
        """启动服务"""
        if self._running:
            return
        
        self._running = True
        self._task = asyncio.create_task(self._detection_loop())
        log_info(f"[CameraService] ✅ 服务已启动，{len(self.detectors)} 个摄像头")
    
    async def stop(self):
        """停止服务"""
        self._running = False
        
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
            self._task = None
        
        for detector in self.detectors.values():
            await detector.stop()
        
        log_info("[CameraService] 服务已停止")
    
    async def _detection_loop(self):
        """检测循环"""
        last_heartbeat = time.time()
        
        try:
            while self._running:
                now = time.time()
                
                # 处理所有摄像头
                for detector in self.detectors.values():
                    try:
                        await detector.process_frame()
                    except Exception as e:
                        log_error(f"[CameraService] 检测错误: {e}")
                
                # 心跳
                if now - last_heartbeat > 30:
                    status = " | ".join([
                        f"{d.config.name}:{'👤' if d.person_active else '✓'}"
                        for d in self.detectors.values()
                    ])
                    log_info(f"[CameraService] ♥ 心跳 | {status}")
                    last_heartbeat = now
                
                await asyncio.sleep(0.1)
        
        except asyncio.CancelledError:
            pass
    
    def get_status(self) -> Dict:
        """获取状态"""
        return {
            "running": self._running,
            "house_mode": self.house_mode,
            "cameras": {
                name: {
                    "person_active": d.person_active,
                    "current_zone": d.current_zone,
                    "current_level": d.current_level,
                }
                for name, d in self.detectors.items()
            }
        }


# ============================================================
# 全局服务实例
# ============================================================

_camera_detection_service: Optional[CameraDetectionService] = None


def get_camera_detection_service() -> Optional[CameraDetectionService]:
    """获取全局摄像头检测服务"""
    return _camera_detection_service


async def init_camera_detection_service(house_mode: str = "away") -> CameraDetectionService:
    """初始化全局摄像头检测服务"""
    global _camera_detection_service
    
    if _camera_detection_service is None:
        _camera_detection_service = CameraDetectionService(house_mode)
    
    return _camera_detection_service


async def shutdown_camera_detection_service():
    """关闭全局摄像头检测服务"""
    global _camera_detection_service
    
    if _camera_detection_service:
        await _camera_detection_service.stop()
        _camera_detection_service = None
