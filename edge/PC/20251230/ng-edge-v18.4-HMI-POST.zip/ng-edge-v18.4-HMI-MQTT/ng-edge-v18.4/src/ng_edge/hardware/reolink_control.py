"""
Reolink Camera Control API

使用 reolink_aio 库控制 Reolink 摄像头
支持: Spotlight, Siren, 威慑模式

基于已验证工作的 yolo11_multi_camera.py
"""

import asyncio
import logging
from dataclasses import dataclass
from typing import Optional, Dict, Any
from datetime import datetime, timezone

logger = logging.getLogger(__name__)


@dataclass
class CameraConnection:
    """摄像头连接配置"""
    ip: str
    username: str = "admin"
    password: str = ""
    port: int = 80  # 兼容 camera_manager 传入
    channel: int = 0


class ReolinkCameraControl:
    """
    Reolink 摄像头控制器
    
    使用 reolink_aio 库
    """
    
    def __init__(self, connection: CameraConnection):
        self.conn = connection
        self._host = None
        self._connected = False
    
    async def connect(self) -> Dict[str, Any]:
        """连接到摄像头"""
        try:
            from reolink_aio.api import Host
            
            logger.info(f"[Reolink] 连接 {self.conn.ip}...")
            self._host = Host(self.conn.ip, self.conn.username, self.conn.password)
            await self._host.get_host_data()
            
            model = self._host.camera_model(self.conn.channel) if self._host else "Unknown"
            self._connected = True
            
            logger.info(f"[Reolink] ✅ 已连接: {model}")
            
            return {
                "success": True,
                "model": model,
                "ip": self.conn.ip,
            }
        except ImportError:
            logger.error("[Reolink] ❌ reolink_aio 未安装，运行: pip install reolink-aio")
            return {"success": False, "error": "reolink_aio not installed"}
        except Exception as e:
            logger.error(f"[Reolink] ❌ 连接失败: {e}")
            return {"success": False, "error": str(e)}
    
    async def disconnect(self):
        """断开连接"""
        if self._host:
            try:
                await self._host.logout()
            except:
                pass
            self._host = None
            self._connected = False
            logger.info(f"[Reolink] 已断开 {self.conn.ip}")
    
    async def close(self):
        """关闭连接（兼容旧接口）"""
        await self.disconnect()
    
    async def test_connection(self) -> Dict[str, Any]:
        """测试连接"""
        if not self._connected:
            result = await self.connect()
            if not result["success"]:
                return result
        
        try:
            model = self._host.camera_model(self.conn.channel) if self._host else "Unknown"
            
            # 检测能力
            capabilities = []
            has_siren = False
            has_spotlight = False
            
            # reolink_aio 自动检测能力
            if self._host:
                # 尝试检测 spotlight
                try:
                    if hasattr(self._host, 'whiteled_state'):
                        capabilities.append("spotlight")
                        has_spotlight = True
                except:
                    pass
                
                # 尝试检测 siren  
                try:
                    if hasattr(self._host, 'set_siren'):
                        capabilities.append("siren")
                        has_siren = True
                except:
                    pass
            
            return {
                "success": True,
                "device": {
                    "model": model,
                    "ip": self.conn.ip,
                },
                "capabilities": capabilities,
                "has_siren": has_siren,
                "has_spotlight": has_spotlight,
            }
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    # =========================================================================
    # Spotlight 控制
    # =========================================================================
    
    async def spotlight_on(self, brightness: int = 100) -> Dict[str, Any]:
        """开启 Spotlight"""
        if not self._host:
            return {"success": False, "error": "Not connected"}
        
        try:
            await self._host.set_whiteled(self.conn.channel, state=True)
            logger.info(f"[Reolink] 💡 Spotlight ON ({self.conn.ip})")
            return {"success": True}
        except Exception as e:
            logger.error(f"[Reolink] Spotlight ON 失败: {e}")
            return {"success": False, "error": str(e)}
    
    async def spotlight_off(self) -> Dict[str, Any]:
        """关闭 Spotlight"""
        if not self._host:
            return {"success": False, "error": "Not connected"}
        
        try:
            await self._host.set_whiteled(self.conn.channel, state=False)
            logger.info(f"[Reolink] 💡 Spotlight OFF ({self.conn.ip})")
            return {"success": True}
        except Exception as e:
            logger.error(f"[Reolink] Spotlight OFF 失败: {e}")
            return {"success": False, "error": str(e)}
    
    # =========================================================================
    # Siren 控制
    # =========================================================================
    
    async def siren_on(self, times: int = 2) -> Dict[str, Any]:
        """开启 Siren"""
        if not self._host:
            return {"success": False, "error": "Not connected"}
        
        try:
            await self._host.set_siren(self.conn.channel, True)
            logger.info(f"[Reolink] 🔔 Siren ON ({self.conn.ip})")
            return {"success": True}
        except Exception as e:
            logger.error(f"[Reolink] Siren ON 失败: {e}")
            return {"success": False, "error": str(e)}
    
    async def siren_off(self) -> Dict[str, Any]:
        """关闭 Siren"""
        if not self._host:
            return {"success": False, "error": "Not connected"}
        
        try:
            await self._host.set_siren(self.conn.channel, False)
            logger.info(f"[Reolink] 🔔 Siren OFF ({self.conn.ip})")
            return {"success": True}
        except Exception as e:
            logger.error(f"[Reolink] Siren OFF 失败: {e}")
            return {"success": False, "error": str(e)}
    
    async def siren_cycle(self, times: int = 3) -> Dict[str, Any]:
        """Siren 响几次"""
        return await self.siren_on(times)
    
    # =========================================================================
    # 威慑模式
    # =========================================================================
    
    async def deterrent_start(self, brightness: int = 100, siren_times: int = 3) -> Dict[str, Any]:
        """启动威慑模式 (声光齐发)"""
        results = {
            "spotlight": await self.spotlight_on(brightness),
            "siren": await self.siren_on(siren_times),
        }
        
        success = any(r.get("success", False) for r in results.values())
        logger.info(f"[Reolink] ⚡ Deterrent START ({self.conn.ip})")
        
        return {
            "success": success,
            "results": results,
            "message": "Deterrent started" if success else "Failed"
        }
    
    async def deterrent_stop(self) -> Dict[str, Any]:
        """停止威慑模式"""
        results = {
            "spotlight": await self.spotlight_off(),
            "siren": await self.siren_off(),
        }
        
        success = any(r.get("success", False) for r in results.values())
        logger.info(f"[Reolink] Deterrent STOP ({self.conn.ip})")
        
        return {
            "success": success,
            "results": results,
        }


# =============================================================================
# 快速测试
# =============================================================================

async def quick_test(ip: str, username: str = "admin", password: str = "") -> Dict[str, Any]:
    """快速测试摄像头"""
    conn = CameraConnection(ip=ip, username=username, password=password)
    ctrl = ReolinkCameraControl(conn)
    
    try:
        result = await ctrl.test_connection()
        return result
    finally:
        await ctrl.close()


if __name__ == "__main__":
    import sys
    
    async def main():
        if len(sys.argv) < 4:
            print("Usage: python reolink_control.py <ip> <username> <password> [command]")
            print("Commands: test, light_on, light_off, siren_on, siren_off, deterrent")
            return
        
        ip, username, password = sys.argv[1:4]
        command = sys.argv[4] if len(sys.argv) > 4 else "test"
        
        conn = CameraConnection(ip=ip, username=username, password=password)
        ctrl = ReolinkCameraControl(conn)
        
        try:
            # 先连接
            result = await ctrl.connect()
            if not result["success"]:
                print(f"连接失败: {result}")
                return
            
            if command == "test":
                result = await ctrl.test_connection()
                print(f"Test: {result}")
            
            elif command == "light_on":
                result = await ctrl.spotlight_on()
                print(f"Spotlight ON: {result}")
            
            elif command == "light_off":
                result = await ctrl.spotlight_off()
                print(f"Spotlight OFF: {result}")
            
            elif command == "siren_on":
                result = await ctrl.siren_on()
                print(f"Siren ON: {result}")
            
            elif command == "siren_off":
                result = await ctrl.siren_off()
                print(f"Siren OFF: {result}")
            
            elif command == "deterrent":
                print("Starting deterrent...")
                result = await ctrl.deterrent_start()
                print(f"Deterrent: {result}")
                
                await asyncio.sleep(3)
                
                print("Stopping...")
                result = await ctrl.deterrent_stop()
                print(f"Stopped: {result}")
            
            else:
                print(f"Unknown command: {command}")
        
        finally:
            await ctrl.close()
    
    asyncio.run(main())
