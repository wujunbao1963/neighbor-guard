"""
Effect Runtime - 威慑效果执行引擎（简化版）

核心思想：
1. 聚合多摄像头的检测结果，取最高级别
2. 去抖 + 最短持续时间
3. 单线程执行设备动作
4. SecurityCoordinator 可以覆盖（PENDING/TRIGGERED 优先级更高）

使用方式：
    # 初始化
    effect_runtime = EffectRuntime(spotlight_on, spotlight_off, siren_trigger, siren_off)
    effect_runtime.start()
    
    # 摄像头检测报告（高频调用，内部去抖）
    effect_runtime.report_camera(cam_id="cam_back", level=2)
    
    # SecurityCoordinator 覆盖（立即生效，无去抖）
    effect_runtime.set_alarm_state("pending")  # 进入 Entry Delay
    effect_runtime.set_alarm_state("triggered")  # 警报触发
    effect_runtime.set_alarm_state("off")  # 撤防
"""

import asyncio
import time
import logging
from enum import Enum
from dataclasses import dataclass
from typing import Optional, Callable, Awaitable, Dict

logger = logging.getLogger(__name__)


class EffectMode(Enum):
    """效果模式（按优先级排序）"""
    OFF = 0
    PRE_L1 = 1      # 常亮 + 慢滴
    PRE_L2 = 2      # 闪灯 + 快滴
    PRE_L3 = 3      # 闪灯 + 更快滴
    PENDING = 10    # Entry Delay（静音）
    TRIGGERED = 20  # 全力警报


@dataclass
class EffectPattern:
    """效果模式的具体参数"""
    light_mode: str = "off"      # off / steady / flash
    light_flash_on: float = 5.0
    light_flash_off: float = 5.0
    siren_interval: float = 0    # 0 = 不响
    siren_duration: float = 1.0


# 模式 → 具体参数
PATTERNS: Dict[EffectMode, EffectPattern] = {
    EffectMode.OFF: EffectPattern(light_mode="off"),
    EffectMode.PRE_L1: EffectPattern(light_mode="steady", siren_interval=30, siren_duration=1),
    EffectMode.PRE_L2: EffectPattern(light_mode="flash", light_flash_on=5, light_flash_off=5, siren_interval=10, siren_duration=2),
    EffectMode.PRE_L3: EffectPattern(light_mode="flash", light_flash_on=3, light_flash_off=3, siren_interval=5, siren_duration=2),
    EffectMode.PENDING: EffectPattern(light_mode="off"),  # Entry Delay 不开灯
    EffectMode.TRIGGERED: EffectPattern(light_mode="flash", light_flash_on=1, light_flash_off=1, siren_interval=3, siren_duration=3),
}


class EffectRuntime:
    """
    效果运行时 - 单例模式
    
    特点：
    1. 聚合多摄像头检测，取最高级别
    2. PRE 级别变化有去抖，PENDING/TRIGGERED 立即生效
    3. 单线程执行设备动作
    """
    
    # 配置
    DEBOUNCE_UP = 0.5      # 升级去抖（L1→L2）
    DEBOUNCE_DOWN = 2.0    # 降级去抖（L2→L1, L1→OFF）
    MIN_HOLD_L2 = 5.0      # PRE_L2 最短持续
    MIN_HOLD_L1 = 3.0      # PRE_L1 最短持续
    CAMERA_TIMEOUT = 3.0   # 摄像头无报告视为离开
    
    def __init__(
        self,
        spotlight_on: Callable[[], Awaitable[None]],
        spotlight_off: Callable[[], Awaitable[None]],
        siren_trigger: Callable[[float], Awaitable[None]],
        siren_off: Callable[[], Awaitable[None]],
    ):
        self._spotlight_on = spotlight_on
        self._spotlight_off = spotlight_off
        self._siren_trigger = siren_trigger
        self._siren_off = siren_off
        
        # 摄像头报告：cam_id → (level, timestamp)
        self._camera_reports: Dict[str, tuple] = {}
        
        # 覆盖状态（来自 SecurityCoordinator）
        self._override_mode: Optional[EffectMode] = None
        
        # 当前状态
        self._current_mode: EffectMode = EffectMode.OFF
        self._mode_start_time: float = 0
        self._pending_mode: Optional[EffectMode] = None
        self._pending_time: float = 0
        
        # 设备状态
        self._light_on: bool = False
        self._last_siren_time: float = 0
        
        # 控制
        self._running: bool = False
        self._task: Optional[asyncio.Task] = None
        
        logger.info("[EffectRuntime] 初始化")
    
    def start(self):
        """启动"""
        if self._running:
            return
        self._running = True
        self._task = asyncio.create_task(self._run_loop())
        logger.info("[EffectRuntime] 启动")
    
    def stop(self):
        """停止"""
        self._running = False
        if self._task:
            self._task.cancel()
            self._task = None
        logger.info("[EffectRuntime] 停止")
    
    def report_camera(self, cam_id: str, level: int):
        """
        摄像头报告检测结果（高频调用）
        
        Args:
            cam_id: 摄像头ID
            level: 0=无人/street, 1=yard, 2=door, 3=critical
        """
        self._camera_reports[cam_id] = (level, time.time())
    
    def set_alarm_state(self, state: str):
        """
        SecurityCoordinator 设置警报状态（立即生效，无去抖）
        
        Args:
            state: "off" / "pending" / "triggered"
        """
        mode_map = {
            "off": None,  # 取消覆盖，恢复 PRE 控制
            "pending": EffectMode.PENDING,
            "triggered": EffectMode.TRIGGERED,
        }
        new_mode = mode_map.get(state)
        
        if new_mode != self._override_mode:
            old = self._override_mode.name if self._override_mode else "None"
            new = new_mode.name if new_mode else "None"
            logger.warning(f"[EffectRuntime] 覆盖状态: {old} → {new}")
            self._override_mode = new_mode
            
            # 立即切换（无去抖）
            if new_mode:
                self._switch_mode(new_mode, reason="override")
    
    def _get_aggregated_level(self) -> int:
        """聚合所有摄像头的报告，取最高级别"""
        now = time.time()
        max_level = 0
        
        for cam_id, (level, ts) in list(self._camera_reports.items()):
            if now - ts < self.CAMERA_TIMEOUT:
                max_level = max(max_level, level)
            else:
                # 超时，移除
                del self._camera_reports[cam_id]
        
        return max_level
    
    def _level_to_mode(self, level: int) -> EffectMode:
        """级别 → 模式"""
        mapping = {0: EffectMode.OFF, 1: EffectMode.PRE_L1, 2: EffectMode.PRE_L2, 3: EffectMode.PRE_L3}
        return mapping.get(level, EffectMode.OFF)
    
    def _switch_mode(self, new_mode: EffectMode, reason: str = ""):
        """切换模式"""
        if new_mode == self._current_mode:
            return
        
        old_mode = self._current_mode
        self._current_mode = new_mode
        self._mode_start_time = time.time()
        self._pending_mode = None
        self._last_siren_time = 0  # 重置警报计时
        
        logger.warning(f"[EffectRuntime] 模式切换: {old_mode.name} → {new_mode.name} ({reason})")
    
    async def _run_loop(self):
        """主循环"""
        logger.info("[EffectRuntime] 循环启动")
        
        # 启动时关闭所有设备（崩溃恢复）
        await self._shutdown_devices()
        
        try:
            while self._running:
                await self._tick()
                await asyncio.sleep(0.5)
        except asyncio.CancelledError:
            logger.info("[EffectRuntime] 循环取消")
        finally:
            await self._shutdown_devices()
    
    async def _tick(self):
        """每个 tick 的处理"""
        now = time.time()
        
        # 1. 如果有覆盖状态，使用覆盖
        if self._override_mode:
            if self._current_mode != self._override_mode:
                self._switch_mode(self._override_mode, reason="override_apply")
        else:
            # 2. 聚合摄像头报告
            level = self._get_aggregated_level()
            desired_mode = self._level_to_mode(level)
            
            # 3. 去抖处理
            self._process_debounce(desired_mode, now)
        
        # 4. 执行当前模式的效果
        await self._execute_effect(now)
    
    def _process_debounce(self, desired_mode: EffectMode, now: float):
        """去抖处理"""
        current = self._current_mode
        
        # 相同模式，取消待确认
        if desired_mode == current:
            if self._pending_mode:
                logger.debug(f"[EffectRuntime] 取消待确认 {self._pending_mode.name}")
                self._pending_mode = None
            return
        
        # 计算去抖时间
        if desired_mode.value > current.value:
            # 升级
            debounce = self.DEBOUNCE_UP
        else:
            # 降级
            elapsed = now - self._mode_start_time
            if current == EffectMode.PRE_L2 and elapsed < self.MIN_HOLD_L2:
                debounce = self.MIN_HOLD_L2 - elapsed
            elif current == EffectMode.PRE_L1 and elapsed < self.MIN_HOLD_L1:
                debounce = self.MIN_HOLD_L1 - elapsed
            else:
                debounce = self.DEBOUNCE_DOWN
        
        # 检查是否需要新的待确认
        if self._pending_mode != desired_mode:
            self._pending_mode = desired_mode
            self._pending_time = now
            logger.info(f"[EffectRuntime] 待确认: {current.name} → {desired_mode.name} (去抖 {debounce:.1f}s)")
        
        # 检查是否可以确认
        if self._pending_mode and now - self._pending_time >= debounce:
            self._switch_mode(self._pending_mode, reason="debounce_confirmed")
    
    async def _execute_effect(self, now: float):
        """执行当前模式的效果"""
        pattern = PATTERNS.get(self._current_mode, PATTERNS[EffectMode.OFF])
        elapsed = now - self._mode_start_time
        
        # 灯光
        await self._execute_light(pattern, elapsed)
        
        # 警报
        await self._execute_siren(pattern, elapsed)
    
    async def _execute_light(self, pattern: EffectPattern, elapsed: float):
        """执行灯光"""
        desired_on = False
        
        if pattern.light_mode == "steady":
            desired_on = True
        elif pattern.light_mode == "flash":
            cycle = pattern.light_flash_on + pattern.light_flash_off
            pos = elapsed % cycle
            desired_on = pos < pattern.light_flash_on
        
        if desired_on != self._light_on:
            self._light_on = desired_on
            try:
                if desired_on:
                    await self._spotlight_on()
                    logger.info("[EffectRuntime] 💡 ON")
                else:
                    await self._spotlight_off()
                    logger.info("[EffectRuntime] 💡 OFF")
            except Exception as e:
                logger.error(f"[EffectRuntime] 灯光失败: {e}")
    
    async def _execute_siren(self, pattern: EffectPattern, elapsed: float):
        """执行警报"""
        if pattern.siren_interval <= 0:
            return
        
        elapsed_int = int(elapsed)
        interval_int = int(pattern.siren_interval)
        
        # 首次进入触发一次
        if elapsed < 1.0 and self._last_siren_time == 0:
            self._last_siren_time = -1  # 标记已触发首次
            try:
                await self._siren_trigger(pattern.siren_duration)
                logger.info(f"[EffectRuntime] 🔔 警报 {pattern.siren_duration}s (首次)")
            except Exception as e:
                logger.error(f"[EffectRuntime] 警报失败: {e}")
            return
        
        # 周期触发
        if elapsed_int > 0 and elapsed_int % interval_int == 0 and elapsed_int != self._last_siren_time:
            self._last_siren_time = elapsed_int
            try:
                await self._siren_trigger(pattern.siren_duration)
                logger.info(f"[EffectRuntime] 🔔 警报 {pattern.siren_duration}s")
            except Exception as e:
                logger.error(f"[EffectRuntime] 警报失败: {e}")
    
    async def _shutdown_devices(self):
        """关闭所有设备"""
        logger.info("[EffectRuntime] 关闭设备")
        try:
            await self._spotlight_off()
            await self._siren_off()
        except Exception as e:
            logger.error(f"[EffectRuntime] 关闭失败: {e}")
        self._light_on = False
    
    def get_status(self) -> dict:
        """状态"""
        return {
            "running": self._running,
            "current_mode": self._current_mode.name,
            "pending_mode": self._pending_mode.name if self._pending_mode else None,
            "override_mode": self._override_mode.name if self._override_mode else None,
            "camera_count": len(self._camera_reports),
            "light_on": self._light_on,
        }
