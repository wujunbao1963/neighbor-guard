"""
Zigbee Signal Adapter

将 ZigbeeSignalRouter 的输出转换为 SignalEnvelope 格式。

这是一个适配层，不修改原有 ZigbeeSignalRouter 的逻辑，
只是在其输出端添加格式转换。
"""

from typing import Dict, Any, Optional, Callable
from datetime import datetime, timezone

from ng_edge.core.signal import SignalEnvelope, Hardness


# 信号类型映射：旧格式 → 新格式
SIGNAL_KIND_MAP = {
    "DOOR_OPEN": "door_open",
    "DOOR_CLOSE": "door_close",
    "MOTION_ACTIVE": "motion_pir",
    "GLASS_BREAK": "glass_break",
}


def convert_zigbee_signal(
    sensor_info: Dict[str, Any],
    signal_type: str,
    signal_data: Dict[str, Any],
) -> Optional[SignalEnvelope]:
    """
    将 ZigbeeSignalRouter 的回调数据转换为 SignalEnvelope
    
    Args:
        sensor_info: 传感器信息 (sensor_id, ieee_address, friendly_name, etc.)
        signal_type: 旧格式信号类型 (DOOR_OPEN, MOTION_ACTIVE, etc.)
        signal_data: 信号数据 (contact, battery, etc.)
    
    Returns:
        SignalEnvelope 或 None (如果无法转换)
    """
    # 映射信号类型
    signal_kind = SIGNAL_KIND_MAP.get(signal_type)
    if not signal_kind:
        return None
    
    # 提取传感器信息
    device_id = sensor_info.get("ieee_address", sensor_info.get("sensor_id", ""))
    friendly_name = sensor_info.get("friendly_name", "")
    entry_point_id = sensor_info.get("entry_point_id")
    zone_type = sensor_info.get("zone_type", "exterior")
    
    # 创建 SignalEnvelope
    return SignalEnvelope.from_zigbee(
        device_id=device_id,
        friendly_name=friendly_name,
        signal_kind=signal_kind,
        zone_id=zone_type,
        entrypoint_id=entry_point_id,
        raw_payload=signal_data,
        # 额外属性
        battery=signal_data.get("battery"),
        linkquality=signal_data.get("linkquality"),
        sensor_id=sensor_info.get("sensor_id"),
        sensor_type=sensor_info.get("sensor_type"),
    )


class ZigbeeSignalAdapter:
    """
    Zigbee 信号适配器
    
    包装 ZigbeeSignalRouter，将其输出转换为 SignalEnvelope。
    
    使用方式:
        router = ZigbeeSignalRouter()
        adapter = ZigbeeSignalAdapter(router)
        adapter.on_signal_envelope = my_handler  # 接收 SignalEnvelope
        router.start()
    """
    
    def __init__(self, router):
        """
        初始化适配器
        
        Args:
            router: ZigbeeSignalRouter 实例
        """
        self.router = router
        self.on_signal_envelope: Optional[Callable[[SignalEnvelope], None]] = None
        
        # 保存原有回调
        self._original_callback = router.on_signal_callback
        
        # 设置新回调
        router.on_signal_callback = self._on_router_signal
        
        # 统计
        self.stats = {
            "signals_received": 0,
            "signals_converted": 0,
            "conversion_errors": 0,
        }
    
    def _on_router_signal(
        self,
        sensor_info: Dict[str, Any],
        signal_type: str,
        signal_data: Dict[str, Any],
    ):
        """
        处理来自 Router 的信号
        """
        self.stats["signals_received"] += 1
        
        # 调用原有回调（如果有）
        if self._original_callback:
            self._original_callback(sensor_info, signal_type, signal_data)
        
        # 转换为 SignalEnvelope
        try:
            envelope = convert_zigbee_signal(sensor_info, signal_type, signal_data)
            
            if envelope:
                self.stats["signals_converted"] += 1
                
                # 调用新回调
                if self.on_signal_envelope:
                    self.on_signal_envelope(envelope)
            
        except Exception as e:
            self.stats["conversion_errors"] += 1
            print(f"[ZigbeeAdapter] ❌ 转换错误: {e}")
    
    def get_stats(self) -> Dict[str, int]:
        """获取统计信息"""
        return {
            **self.stats,
            "router_stats": self.router.get_stats(),
        }


def create_envelope_handler(
    callback: Callable[[SignalEnvelope], None]
) -> Callable[[Dict, str, Dict], None]:
    """
    创建一个回调函数，将旧格式转换为 SignalEnvelope 后调用
    
    这是一个简化的工厂函数，用于不想使用完整 Adapter 的场景。
    
    Args:
        callback: 接收 SignalEnvelope 的回调函数
    
    Returns:
        可以设置为 router.on_signal_callback 的函数
    """
    def handler(sensor_info: Dict, signal_type: str, signal_data: Dict):
        envelope = convert_zigbee_signal(sensor_info, signal_type, signal_data)
        if envelope:
            callback(envelope)
    
    return handler
