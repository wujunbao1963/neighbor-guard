"""
Context Gate Manager

管理上下文门控信号的 TTL (v2.2 §1.3)

Context Gate 是由摄像头检测产生的"预确认"信号：
- yard_confirmed: 院子里确认有人，TTL 120s
- porch_confirmed: 门廊确认有人，TTL 60s

当 Context Gate 有效时，可以加速 PRE 升级的 dwell 时间。
"""

from dataclasses import dataclass, field
from datetime import datetime, timezone, timedelta
from typing import Dict, Optional, List, Callable
from enum import Enum


class ContextGateType(str, Enum):
    """上下文门控类型"""
    YARD_CONFIRMED = "yard_confirmed"
    PORCH_CONFIRMED = "porch_confirmed"


# 默认 TTL 配置 (秒)
DEFAULT_GATE_TTL = {
    ContextGateType.YARD_CONFIRMED: 120,
    ContextGateType.PORCH_CONFIRMED: 60,
}


@dataclass
class ContextGate:
    """单个上下文门控"""
    gate_id: str
    gate_type: ContextGateType
    zone_id: str
    source_device: str
    
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    expires_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    ttl_sec: int = 120
    
    # 关联的信号
    source_signal_id: str = ""
    
    def is_valid(self, now: datetime = None) -> bool:
        """检查门控是否有效"""
        now = now or datetime.now(timezone.utc)
        return now < self.expires_at
    
    def remaining_sec(self, now: datetime = None) -> float:
        """剩余有效时间（秒）"""
        now = now or datetime.now(timezone.utc)
        delta = (self.expires_at - now).total_seconds()
        return max(0, delta)


@dataclass
class ContextGateConfig:
    """Context Gate 配置"""
    yard_confirmed_ttl_sec: int = 120
    porch_confirmed_ttl_sec: int = 60
    
    # Soft Gate 加速配置
    yard_accelerated_dwell_sec: int = 30   # 有 yard_confirmed 时的 dwell
    default_dwell_sec: int = 90            # 无门控时的 dwell


class ContextGateManager:
    """
    Context Gate 管理器
    
    使用方式:
        manager = ContextGateManager()
        
        # 激活门控（摄像头检测到人）
        manager.activate(
            gate_type=ContextGateType.YARD_CONFIRMED,
            zone_id="zone_front",
            source_device="cam_front",
        )
        
        # 检查门控
        if manager.is_active(ContextGateType.YARD_CONFIRMED, "zone_front"):
            # 使用加速 dwell
            dwell = config.yard_accelerated_dwell_sec
    """
    
    def __init__(self, config: Optional[ContextGateConfig] = None):
        self.config = config or ContextGateConfig()
        
        # 活跃的门控: (gate_type, zone_id) → ContextGate
        self._active_gates: Dict[tuple, ContextGate] = {}
        
        # 回调
        self.on_gate_activated: Optional[Callable[[ContextGate], None]] = None
        self.on_gate_expired: Optional[Callable[[ContextGate], None]] = None
        
        # 统计
        self.stats = {
            "gates_activated": 0,
            "gates_expired": 0,
            "gates_refreshed": 0,
        }
        
        # 门控 ID 计数器
        self._gate_counter = 0
    
    def get_ttl(self, gate_type: ContextGateType) -> int:
        """获取门控类型的 TTL"""
        if gate_type == ContextGateType.YARD_CONFIRMED:
            return self.config.yard_confirmed_ttl_sec
        elif gate_type == ContextGateType.PORCH_CONFIRMED:
            return self.config.porch_confirmed_ttl_sec
        return DEFAULT_GATE_TTL.get(gate_type, 60)
    
    def activate(
        self,
        gate_type: ContextGateType,
        zone_id: str,
        source_device: str,
        source_signal_id: str = "",
        ttl_sec: int = None,
    ) -> ContextGate:
        """
        激活上下文门控
        
        如果已存在相同类型和区域的门控，会刷新其过期时间。
        
        Args:
            gate_type: 门控类型
            zone_id: 区域 ID
            source_device: 来源设备
            source_signal_id: 来源信号 ID
            ttl_sec: 自定义 TTL（可选）
            
        Returns:
            ContextGate: 激活的门控
        """
        key = (gate_type, zone_id)
        ttl = ttl_sec if ttl_sec is not None else self.get_ttl(gate_type)
        now = datetime.now(timezone.utc)
        expires_at = now + timedelta(seconds=ttl)
        
        existing = self._active_gates.get(key)
        
        if existing and existing.is_valid(now):
            # 刷新现有门控
            existing.expires_at = expires_at
            existing.source_signal_id = source_signal_id or existing.source_signal_id
            self.stats["gates_refreshed"] += 1
            return existing
        
        # 创建新门控
        self._gate_counter += 1
        gate = ContextGate(
            gate_id=f"gate_{self._gate_counter:04d}",
            gate_type=gate_type,
            zone_id=zone_id,
            source_device=source_device,
            created_at=now,
            expires_at=expires_at,
            ttl_sec=ttl,
            source_signal_id=source_signal_id,
        )
        
        self._active_gates[key] = gate
        self.stats["gates_activated"] += 1
        
        if self.on_gate_activated:
            self.on_gate_activated(gate)
        
        return gate
    
    def is_active(self, gate_type: ContextGateType, zone_id: str, now: datetime = None) -> bool:
        """
        检查门控是否活跃
        
        Args:
            gate_type: 门控类型
            zone_id: 区域 ID
            now: 当前时间（用于测试）
            
        Returns:
            bool: 是否活跃
        """
        now = now or datetime.now(timezone.utc)
        key = (gate_type, zone_id)
        gate = self._active_gates.get(key)
        
        if gate and gate.is_valid(now):
            return True
        
        return False
    
    def get_gate(self, gate_type: ContextGateType, zone_id: str) -> Optional[ContextGate]:
        """获取门控（如果有效）"""
        key = (gate_type, zone_id)
        gate = self._active_gates.get(key)
        
        if gate and gate.is_valid():
            return gate
        
        return None
    
    def get_active_gates(self, zone_id: str = None) -> List[ContextGate]:
        """
        获取所有活跃的门控
        
        Args:
            zone_id: 可选，过滤特定区域
            
        Returns:
            List[ContextGate]: 活跃门控列表
        """
        now = datetime.now(timezone.utc)
        result = []
        
        for key, gate in self._active_gates.items():
            if gate.is_valid(now):
                if zone_id is None or gate.zone_id == zone_id:
                    result.append(gate)
        
        return result
    
    def invalidate(self, gate_type: ContextGateType, zone_id: str) -> bool:
        """
        手动使门控失效
        
        Returns:
            bool: 是否有门控被使失效
        """
        key = (gate_type, zone_id)
        if key in self._active_gates:
            gate = self._active_gates.pop(key)
            self.stats["gates_expired"] += 1
            
            if self.on_gate_expired:
                self.on_gate_expired(gate)
            
            return True
        
        return False
    
    def cleanup_expired(self) -> List[ContextGate]:
        """
        清理过期的门控
        
        应该定期调用（如每30秒）
        
        Returns:
            List[ContextGate]: 被清理的门控列表
        """
        now = datetime.now(timezone.utc)
        expired = []
        
        keys_to_remove = []
        for key, gate in self._active_gates.items():
            if not gate.is_valid(now):
                keys_to_remove.append(key)
                expired.append(gate)
        
        for key in keys_to_remove:
            gate = self._active_gates.pop(key)
            self.stats["gates_expired"] += 1
            
            if self.on_gate_expired:
                self.on_gate_expired(gate)
        
        return expired
    
    def get_accelerated_dwell(self, zone_id: str) -> int:
        """
        获取加速后的 dwell 时间
        
        根据活跃的 Context Gate 决定 dwell 时间。
        
        Args:
            zone_id: 区域 ID
            
        Returns:
            int: dwell 时间（秒）
        """
        # 检查是否有 yard_confirmed
        if self.is_active(ContextGateType.YARD_CONFIRMED, zone_id):
            return self.config.yard_accelerated_dwell_sec
        
        # 检查是否有 porch_confirmed（更短的 dwell）
        if self.is_active(ContextGateType.PORCH_CONFIRMED, zone_id):
            return self.config.yard_accelerated_dwell_sec // 2  # 15s
        
        # 无门控，使用默认 dwell
        return self.config.default_dwell_sec
    
    def get_stats(self) -> Dict:
        """获取统计信息"""
        now = datetime.now(timezone.utc)
        active_count = sum(1 for g in self._active_gates.values() if g.is_valid(now))
        
        return {
            **self.stats,
            "active_gates": active_count,
            "total_tracked": len(self._active_gates),
        }
