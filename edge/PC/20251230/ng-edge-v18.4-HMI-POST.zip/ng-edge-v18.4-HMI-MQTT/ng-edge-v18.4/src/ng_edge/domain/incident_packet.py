"""
Incident Packet Models - PRD v7.5.0 §5.5.3

Data models for Remote Verify View and Incident Packet generation.
"""

from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any, Literal
from datetime import datetime
from enum import Enum


# =============================================================================
# Remote Verify Configuration (PRD §5.5.2)
# =============================================================================

class RemoteVerifyMode(str, Enum):
    """Remote verification mode."""
    NONE = "none"
    SEGMENT_STREAM = "segment_stream"  # MVP: Rolling segments
    LIVE_STREAM = "live_stream"  # True live WebRTC/RTMP
    EXTERNAL_LINK = "external_link"  # External camera service


class CapabilityTier(str, Enum):
    """System capability tier (PRD §5.5.2)."""
    V = "V"  # Video available
    E = "E"  # Entry sensors only
    N = "N"  # No video


class RemoteVerifyConfig(BaseModel):
    """
    Remote Verify configuration.
    
    PRD §5.5.2 - Controls how remote verification is presented.
    """
    mode: RemoteVerifyMode = RemoteVerifyMode.NONE
    snapshots_min: int = Field(default=2, ge=0)  # Minimum snapshots to capture
    segment_cadence_sec_max: float = Field(default=10.0, ge=1.0)  # Max segment duration
    incident_packet_required: bool = True
    notes: Optional[str] = None


# =============================================================================
# Timeline Entry (PRD §5.5.3)
# =============================================================================

class TimelineEventType(str, Enum):
    """Timeline event types."""
    # State transitions
    STATE_TRANSITION = "state_transition"
    
    # Signal detections
    SIGNAL_DETECTED = "signal_detected"
    
    # Evidence captured
    EVIDENCE_CAPTURED = "evidence_captured"
    
    # User actions
    USER_ACTION = "user_action"
    
    # System actions
    SYSTEM_ACTION = "system_action"


class TimelineEntry(BaseModel):
    """
    Single entry in event timeline.
    
    PRD §5.5.3 - Audit trail item.
    """
    timestamp: datetime
    event_type: TimelineEventType
    actor: str  # "edge_system", "user:{userId}", "neighbor:{neighborId}"
    action: str  # Human-readable action
    details: Dict[str, Any] = Field(default_factory=dict)
    
    # State transition specific
    from_state: Optional[str] = None
    to_state: Optional[str] = None
    
    # Evidence specific
    evidence_id: Optional[str] = None
    media_ref: Optional[str] = None


# =============================================================================
# Media Manifest (PRD §5.5.3)
# =============================================================================

class EvidenceType(str, Enum):
    """Evidence media type."""
    SNAPSHOT = "snapshot"
    REMOTE_SEGMENT = "remote_segment"
    LIVE_STREAM = "live_stream"
    SENSOR_LOG = "sensor_log"
    NEIGHBOR_PHOTO = "neighbor_photo"
    NEIGHBOR_VIDEO = "neighbor_video"


class MediaItem(BaseModel):
    """
    Single media item in manifest.
    
    Represents a video clip, snapshot, or other evidence.
    """
    item_id: str
    evidence_type: EvidenceType
    camera_id: Optional[str] = None
    zone_id: Optional[str] = None
    timestamp: datetime
    duration_sec: Optional[float] = None
    file_size_bytes: Optional[int] = None
    storage_url: Optional[str] = None  # S3/CDN URL
    thumbnail_url: Optional[str] = None
    
    # Context
    capture_context: Dict[str, Any] = Field(default_factory=dict)
    priority: int = 0  # Higher = more important
    
    # Segment-specific
    segment_no: Optional[int] = None
    is_rolling_segment: bool = False


class MediaManifest(BaseModel):
    """
    Complete media manifest for incident.
    
    PRD §5.5.3 - Lists all captured evidence.
    """
    manifest_id: str
    event_id: str
    created_at: datetime
    updated_at: datetime
    
    # Media items
    items: List[MediaItem] = Field(default_factory=list)
    
    # Statistics
    total_items: int = 0
    total_size_bytes: int = 0
    snapshots_count: int = 0
    segments_count: int = 0
    
    # Live stream info
    live_stream_session_id: Optional[str] = None
    live_stream_url: Optional[str] = None
    
    def add_item(self, item: MediaItem) -> None:
        """Add media item to manifest."""
        self.items.append(item)
        self.total_items = len(self.items)
        if item.file_size_bytes:
            self.total_size_bytes += item.file_size_bytes
        if item.evidence_type == EvidenceType.SNAPSHOT:
            self.snapshots_count += 1
        elif item.evidence_type == EvidenceType.REMOTE_SEGMENT:
            self.segments_count += 1
        self.updated_at = datetime.utcnow()


# =============================================================================
# Edge Snapshot (PRD §5.5.3)
# =============================================================================

class EdgeSnapshot(BaseModel):
    """
    Edge-generated snapshot of incident.
    
    PRD §5.5.3 - Contains only local evidence and state machine timeline.
    """
    snapshot_id: str
    event_id: str
    generated_at: datetime
    edge_device_id: str
    
    # Event context
    workflow_class: str
    house_mode: str
    alarm_state: str
    
    # Entry point and zones
    triggered_entry_point_id: Optional[str] = None
    zones_involved: List[str] = Field(default_factory=list)
    
    # Timeline
    timeline: List[TimelineEntry] = Field(default_factory=list)
    
    # Media
    media_manifest_ref: Optional[str] = None
    
    # Assessment
    edge_assessment: Optional[Dict[str, Any]] = None
    
    # Tracks
    user_alert_level: int = 0
    dispatch_readiness_local: int = 0


# =============================================================================
# Incident Packet (PRD §5.5.3)
# =============================================================================

class CollabAssessment(BaseModel):
    """
    Collaborative assessment from Cloud/DCV.
    
    PRD §5.5.3 - Neighbor verification results.
    """
    verification_result: Optional[str] = None  # CONFIRMED_TRUE, ON_SCENE_NO_SIGNS, etc.
    verifier_type: Optional[str] = None  # neighbor, keyholder, etc.
    verifier_id: Optional[str] = None
    verified_at: Optional[datetime] = None
    notes: Optional[str] = None
    
    # External evidence
    neighbor_photos: List[str] = Field(default_factory=list)
    neighbor_videos: List[str] = Field(default_factory=list)
    
    # Final readiness
    dispatch_readiness_collab: int = 0
    dispatch_readiness_effective: int = 0


class IncidentPacket(BaseModel):
    """
    Complete incident packet.
    
    PRD §5.5.3 - Combines Edge Snapshot + Cloud collaboration.
    Supports JSON (machine) and printable summary (PDF/HTML).
    """
    packet_id: str
    event_id: str
    created_at: datetime
    updated_at: datetime
    
    # Version control
    version: int = 1
    is_final: bool = False
    
    # Edge snapshot
    edge_snapshot: EdgeSnapshot
    
    # Collaboration (Cloud)
    collab_assessment: Optional[CollabAssessment] = None
    
    # Media
    media_manifest: Optional[MediaManifest] = None
    
    # Dispatch
    dispatch_recommendation: str = "none"
    dispatch_script_15s: Optional[str] = None
    
    # Audit trail (complete)
    audit_trail: List[TimelineEntry] = Field(default_factory=list)
    
    # Remote verify
    remote_verify_enabled: bool = False
    remote_verify_mode: RemoteVerifyMode = RemoteVerifyMode.NONE
    
    # Status
    event_disposition: Optional[str] = None
    
    def add_timeline_entry(self, entry: TimelineEntry) -> None:
        """Add entry to audit trail."""
        self.audit_trail.append(entry)
        self.updated_at = datetime.utcnow()
    
    def mark_final(self) -> None:
        """Mark packet as final."""
        self.is_final = True
        self.updated_at = datetime.utcnow()


# =============================================================================
# Remote Verify View Model
# =============================================================================

class RemoteVerifyView(BaseModel):
    """
    Remote Verify View data model.
    
    PRD §5.5.2 - What user sees in Remote Verify UI.
    """
    event_id: str
    workflow_class: str
    alarm_state: str
    
    # Video/Media
    capability_tier: CapabilityTier
    remote_verify_mode: RemoteVerifyMode
    live_stream_url: Optional[str] = None
    latest_snapshot_url: Optional[str] = None
    
    # Timeline (last N entries)
    timeline_preview: List[TimelineEntry] = Field(default_factory=list)
    
    # Entry delay (if PENDING)
    entry_delay_remaining_sec: Optional[int] = None
    
    # Explanation
    explain_summary: Optional[Dict[str, str]] = None
    
    # Actions available
    can_disarm: bool = True
    can_request_neighbor: bool = True
    can_view_full_packet: bool = False
    
    # Context
    triggered_at: Optional[datetime] = None
    zones_involved: List[str] = Field(default_factory=list)


# =============================================================================
# Capture Scheduler (PRD §5.5.2)
# =============================================================================

class CaptureScheduleMode(str, Enum):
    """Capture schedule mode based on alarm state."""
    IDLE = "idle"  # No capture
    PRE_SNAPSHOT = "pre_snapshot"  # 1-2 snapshots
    PENDING_ROLLING = "pending_rolling"  # Rolling segments
    TRIGGERED_PRIORITY = "triggered_priority"  # Priority upload


class CaptureSchedule(BaseModel):
    """
    Media capture schedule.
    
    PRD §5.5.2 §5.5.2 - Defines what to capture when.
    """
    mode: CaptureScheduleMode
    event_id: str
    started_at: datetime
    
    # Snapshot config
    snapshots_requested: int = 2
    snapshots_captured: int = 0
    
    # Segment config
    segment_duration_sec: float = 10.0
    segment_interval_sec: float = 3.0
    max_duration_min: float = 5.0
    
    # Priority cameras
    priority_camera_ids: List[str] = Field(default_factory=list)
    
    # Status
    is_active: bool = True
    stopped_at: Optional[datetime] = None
