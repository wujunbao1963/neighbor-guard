"""
Action Gate - 动作权限矩阵 (v2.2 §5)

控制什么状态下允许执行什么动作。

设计原则：
1. 分离"能不能做"(Gate) 和"怎么做"(Executor)
2. 基于 ThreatState + WorkflowState 决定权限
3. 支持 Override (如紧急情况)
"""

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Dict, Set, Optional, List, Callable
from enum import Enum

from ng_edge.state.states import ThreatState, WorkflowState, WorkflowSubPhase


class ActionType(str, Enum):
    """动作类型"""
    # 威慑动作
    LIGHT_FLASH = "light_flash"           # 灯光闪烁
    CHIME = "chime"                        # 提示音
    VOICE_WARNING = "voice_warning"        # 语音警告
    SIREN_ACTIVATE = "siren_activate"      # 警报器激活
    SIREN_DEACTIVATE = "siren_deactivate"  # 警报器停止
    
    # 通知动作
    PUSH_NOTIFICATION = "push_notification"  # 推送通知
    SMS_ALERT = "sms_alert"                  # 短信警报
    PHONE_CALL = "phone_call"                # 电话
    
    # 证据动作
    START_RECORDING = "start_recording"      # 开始录制
    SNAPSHOT = "snapshot"                    # 抓拍
    UPLOAD_EVIDENCE = "upload_evidence"      # 上传证据
    
    # 调度动作
    REQUEST_DISPATCH = "request_dispatch"    # 请求派遣
    CANCEL_DISPATCH = "cancel_dispatch"      # 取消派遣
    
    # 系统动作
    ARM_SYSTEM = "arm_system"                # 布防
    DISARM_SYSTEM = "disarm_system"          # 撤防


class GateDecision(str, Enum):
    """权限决策"""
    ALLOW = "allow"           # 允许执行
    DENY = "deny"             # 拒绝执行
    DEFER = "defer"           # 延迟（需要确认）
    ALLOW_SILENT = "silent"   # 允许但静默（不通知用户）


@dataclass
class GateResult:
    """权限检查结果"""
    action: ActionType
    decision: GateDecision
    reason: str = ""
    
    # 条件
    requires_confirmation: bool = False
    delay_sec: int = 0
    
    # 上下文
    threat_state: Optional[ThreatState] = None
    workflow_state: Optional[WorkflowState] = None


@dataclass
class ActionGateConfig:
    """Action Gate 配置"""
    # PRE 阶段允许的动作
    pre_l1_actions: Set[ActionType] = field(default_factory=lambda: {
        ActionType.LIGHT_FLASH,
        ActionType.START_RECORDING,
        ActionType.SNAPSHOT,
    })
    
    pre_l2_actions: Set[ActionType] = field(default_factory=lambda: {
        ActionType.LIGHT_FLASH,
        ActionType.CHIME,
        ActionType.START_RECORDING,
        ActionType.SNAPSHOT,
        ActionType.PUSH_NOTIFICATION,
    })
    
    pre_l3_actions: Set[ActionType] = field(default_factory=lambda: {
        ActionType.LIGHT_FLASH,
        ActionType.CHIME,
        ActionType.VOICE_WARNING,
        ActionType.START_RECORDING,
        ActionType.SNAPSHOT,
        ActionType.PUSH_NOTIFICATION,
    })
    
    # PENDING 阶段允许的动作
    pending_actions: Set[ActionType] = field(default_factory=lambda: {
        ActionType.LIGHT_FLASH,
        ActionType.CHIME,
        ActionType.VOICE_WARNING,
        ActionType.START_RECORDING,
        ActionType.SNAPSHOT,
        ActionType.PUSH_NOTIFICATION,
    })
    
    # TRIGGERED 阶段允许的动作
    triggered_actions: Set[ActionType] = field(default_factory=lambda: {
        ActionType.LIGHT_FLASH,
        ActionType.CHIME,
        ActionType.VOICE_WARNING,
        ActionType.SIREN_ACTIVATE,
        ActionType.SIREN_DEACTIVATE,
        ActionType.START_RECORDING,
        ActionType.SNAPSHOT,
        ActionType.UPLOAD_EVIDENCE,
        ActionType.PUSH_NOTIFICATION,
        ActionType.SMS_ALERT,
        ActionType.PHONE_CALL,
        ActionType.REQUEST_DISPATCH,
        ActionType.CANCEL_DISPATCH,
    })
    
    # 始终允许的动作
    always_allowed: Set[ActionType] = field(default_factory=lambda: {
        ActionType.DISARM_SYSTEM,
        ActionType.SIREN_DEACTIVATE,
    })
    
    # 需要确认的动作
    requires_confirmation: Set[ActionType] = field(default_factory=lambda: {
        ActionType.REQUEST_DISPATCH,
        ActionType.PHONE_CALL,
    })


class ActionGate:
    """
    Action Gate - 动作权限控制器
    
    使用方式:
        gate = ActionGate()
        
        result = gate.check(
            action=ActionType.SIREN_ACTIVATE,
            threat_state=ThreatState.TRIGGERED,
            workflow_state=WorkflowState.ESCALATED,
        )
        
        if result.decision == GateDecision.ALLOW:
            executor.execute(action)
    """
    
    def __init__(self, config: Optional[ActionGateConfig] = None):
        self.config = config or ActionGateConfig()
        
        # 构建权限矩阵
        self._matrix = self._build_matrix()
        
        # 统计
        self.stats = {
            "checks": 0,
            "allowed": 0,
            "denied": 0,
            "deferred": 0,
        }
        
        # 回调
        self.on_decision: Optional[Callable[[GateResult], None]] = None
    
    def check(
        self,
        action: ActionType,
        threat_state: ThreatState,
        workflow_state: WorkflowState = WorkflowState.IDLE,
        sub_phase: Optional[WorkflowSubPhase] = None,
        override: bool = False,
    ) -> GateResult:
        """
        检查动作权限
        
        Args:
            action: 要执行的动作
            threat_state: 当前威胁状态
            workflow_state: 当前工作流状态
            sub_phase: 工作流子阶段（可选）
            override: 是否强制覆盖（紧急情况）
            
        Returns:
            GateResult: 权限检查结果
        """
        self.stats["checks"] += 1
        
        # 始终允许的动作
        if action in self.config.always_allowed:
            result = GateResult(
                action=action,
                decision=GateDecision.ALLOW,
                reason="always_allowed",
                threat_state=threat_state,
                workflow_state=workflow_state,
            )
            self.stats["allowed"] += 1
            self._notify(result)
            return result
        
        # 强制覆盖
        if override:
            result = GateResult(
                action=action,
                decision=GateDecision.ALLOW,
                reason="override",
                threat_state=threat_state,
                workflow_state=workflow_state,
            )
            self.stats["allowed"] += 1
            self._notify(result)
            return result
        
        # 查询权限矩阵
        allowed_actions = self._matrix.get(threat_state, set())
        
        if action in allowed_actions:
            decision = GateDecision.ALLOW
            reason = f"allowed_in_{threat_state.value}"
            
            # 检查是否需要确认
            requires_confirm = action in self.config.requires_confirmation
            
            result = GateResult(
                action=action,
                decision=decision,
                reason=reason,
                requires_confirmation=requires_confirm,
                threat_state=threat_state,
                workflow_state=workflow_state,
            )
            self.stats["allowed"] += 1
        else:
            result = GateResult(
                action=action,
                decision=GateDecision.DENY,
                reason=f"not_allowed_in_{threat_state.value}",
                threat_state=threat_state,
                workflow_state=workflow_state,
            )
            self.stats["denied"] += 1
        
        self._notify(result)
        return result
    
    def check_batch(
        self,
        actions: List[ActionType],
        threat_state: ThreatState,
        workflow_state: WorkflowState = WorkflowState.IDLE,
    ) -> Dict[ActionType, GateResult]:
        """
        批量检查动作权限
        
        Returns:
            Dict[ActionType, GateResult]: 每个动作的权限结果
        """
        return {
            action: self.check(action, threat_state, workflow_state)
            for action in actions
        }
    
    def get_allowed_actions(
        self,
        threat_state: ThreatState,
        workflow_state: WorkflowState = WorkflowState.IDLE,
    ) -> Set[ActionType]:
        """
        获取当前状态允许的所有动作
        
        Returns:
            Set[ActionType]: 允许的动作集合
        """
        allowed = self._matrix.get(threat_state, set()).copy()
        allowed.update(self.config.always_allowed)
        return allowed
    
    def get_stats(self) -> Dict:
        """获取统计信息"""
        return self.stats.copy()
    
    def _build_matrix(self) -> Dict[ThreatState, Set[ActionType]]:
        """构建权限矩阵"""
        return {
            ThreatState.NONE: set(),  # NONE 状态不允许警报动作
            ThreatState.PRE_L1: self.config.pre_l1_actions,
            ThreatState.PRE_L2: self.config.pre_l2_actions,
            ThreatState.PRE_L3: self.config.pre_l3_actions,
            ThreatState.PENDING: self.config.pending_actions,
            ThreatState.TRIGGERED: self.config.triggered_actions,
        }
    
    def _notify(self, result: GateResult):
        """通知回调"""
        if self.on_decision:
            self.on_decision(result)


# =============================================================================
# Siren Policy (v2.2 §6.1)
# =============================================================================

@dataclass
class SirenPolicyConfig:
    """警报策略配置"""
    # 警报延迟（verification-first）
    siren_delay_sec: int = 30            # TRIGGERED 后延迟激活警报
    
    # 警报持续时间
    siren_duration_sec: int = 180        # 警报持续 3 分钟
    siren_max_duration_sec: int = 600    # 最大持续 10 分钟
    
    # 间歇模式
    intermittent_on_sec: int = 30        # 响 30 秒
    intermittent_off_sec: int = 10       # 停 10 秒
    
    # 自动停止
    auto_stop_on_resolve: bool = True    # 解除时自动停止


class SirenState(str, Enum):
    """警报器状态"""
    OFF = "off"
    PENDING = "pending"      # 等待延迟
    ACTIVE = "active"        # 激活中
    INTERMITTENT = "intermittent"  # 间歇模式
    COOLDOWN = "cooldown"    # 冷却中


@dataclass
class SirenStatus:
    """警报器状态"""
    state: SirenState = SirenState.OFF
    activated_at: Optional[datetime] = None
    deactivate_at: Optional[datetime] = None
    reason: str = ""


class SirenPolicy:
    """
    警报策略控制器
    
    实现 verification-first 模式：
    1. TRIGGERED 后延迟 siren_delay_sec 秒
    2. 在延迟期间用户可以取消
    3. 延迟结束后激活警报
    """
    
    def __init__(self, config: Optional[SirenPolicyConfig] = None):
        self.config = config or SirenPolicyConfig()
        self._status = SirenStatus()
        
        # 回调
        self.on_state_change: Optional[Callable[[SirenState, SirenState], None]] = None
    
    @property
    def status(self) -> SirenStatus:
        return self._status
    
    @property
    def is_active(self) -> bool:
        return self._status.state in {SirenState.ACTIVE, SirenState.INTERMITTENT}
    
    def request_activation(self, reason: str = "") -> SirenStatus:
        """
        请求激活警报（进入延迟等待）
        
        Returns:
            SirenStatus: 新状态
        """
        if self._status.state != SirenState.OFF:
            return self._status
        
        old_state = self._status.state
        now = datetime.now(timezone.utc)
        
        self._status = SirenStatus(
            state=SirenState.PENDING,
            activated_at=now,
            reason=reason,
        )
        
        self._notify(old_state, SirenState.PENDING)
        return self._status
    
    def activate(self, reason: str = "") -> SirenStatus:
        """
        立即激活警报（跳过延迟）
        
        Returns:
            SirenStatus: 新状态
        """
        old_state = self._status.state
        now = datetime.now(timezone.utc)
        
        from datetime import timedelta
        deactivate_at = now + timedelta(seconds=self.config.siren_duration_sec)
        
        self._status = SirenStatus(
            state=SirenState.ACTIVE,
            activated_at=now,
            deactivate_at=deactivate_at,
            reason=reason or self._status.reason,
        )
        
        self._notify(old_state, SirenState.ACTIVE)
        return self._status
    
    def deactivate(self, reason: str = "") -> SirenStatus:
        """
        停止警报
        
        Returns:
            SirenStatus: 新状态
        """
        old_state = self._status.state
        
        self._status = SirenStatus(
            state=SirenState.OFF,
            reason=reason,
        )
        
        if old_state != SirenState.OFF:
            self._notify(old_state, SirenState.OFF)
        
        return self._status
    
    def check_pending_expired(self) -> bool:
        """
        检查延迟是否已过期
        
        Returns:
            bool: 是否应该激活
        """
        if self._status.state != SirenState.PENDING:
            return False
        
        if not self._status.activated_at:
            return False
        
        now = datetime.now(timezone.utc)
        elapsed = (now - self._status.activated_at).total_seconds()
        
        return elapsed >= self.config.siren_delay_sec
    
    def check_duration_expired(self) -> bool:
        """
        检查警报持续时间是否已过期
        
        Returns:
            bool: 是否应该停止
        """
        if self._status.state not in {SirenState.ACTIVE, SirenState.INTERMITTENT}:
            return False
        
        if not self._status.deactivate_at:
            return False
        
        now = datetime.now(timezone.utc)
        return now >= self._status.deactivate_at
    
    def get_remaining_delay(self) -> float:
        """获取剩余延迟时间（秒）"""
        if self._status.state != SirenState.PENDING:
            return 0
        
        if not self._status.activated_at:
            return 0
        
        now = datetime.now(timezone.utc)
        elapsed = (now - self._status.activated_at).total_seconds()
        remaining = self.config.siren_delay_sec - elapsed
        
        return max(0, remaining)
    
    def _notify(self, old_state: SirenState, new_state: SirenState):
        """通知状态变化"""
        if self.on_state_change:
            self.on_state_change(old_state, new_state)
