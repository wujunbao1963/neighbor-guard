"""
Camera Output Channel - 在报警状态变化时控制摄像头威慑

基于 yolo11_multi_camera.py 已验证的 reolink_aio 方式

使用方式:
    channel = CameraOutputChannel()
    await channel.start()
    
    # 在状态变化时调用
    await channel.on_state_change(entry_point_id, from_state, to_state)
"""

import asyncio
import logging
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any
from datetime import datetime, timezone
from enum import Enum

logger = logging.getLogger(__name__)


class DeterrentLevel(Enum):
    """威慑级别"""
    OFF = 0         # 关闭
    L0 = 1          # PRE L0: 无威慑 (仅记录)
    L1 = 2          # PRE L1: 灯光警告 (柔和)
    L2 = 3          # PRE L2: 灯光警告 (强烈)
    TRIGGERED = 4   # TRIGGERED: 声光齐发


@dataclass
class CameraConfig:
    """摄像头配置"""
    camera_id: str
    ip: str
    username: str = "admin"
    password: str = ""
    name: str = ""
    entry_point_id: Optional[str] = None
    zone_id: Optional[str] = None
    
    # 威慑参数
    spotlight_brightness: int = 100
    siren_times: int = 3


@dataclass
class CameraState:
    """摄像头状态"""
    camera_id: str
    connected: bool = False
    deterrent_level: DeterrentLevel = DeterrentLevel.OFF
    last_action: Optional[str] = None
    last_action_time: Optional[datetime] = None
    host: Any = None  # reolink_aio.Host


class CameraOutputChannel:
    """
    Camera Output Channel - 摄像头威慑输出通道
    
    特性:
    - 使用 reolink_aio 控制摄像头 (已验证可靠)
    - 支持多摄像头
    - 根据 AlarmState 自动控制威慑级别
    - 支持按 entry_point 过滤目标摄像头
    """
    
    def __init__(self, cameras: Optional[List[CameraConfig]] = None):
        self.cameras: Dict[str, CameraConfig] = {}
        self.states: Dict[str, CameraState] = {}
        self._lock = asyncio.Lock()
        self._started = False
        
        # 添加初始摄像头
        if cameras:
            for cam in cameras:
                self.add_camera(cam)
    
    def add_camera(self, config: CameraConfig):
        """添加摄像头"""
        self.cameras[config.camera_id] = config
        self.states[config.camera_id] = CameraState(camera_id=config.camera_id)
        logger.info(f"[CameraOutput] 添加摄像头: {config.camera_id} ({config.ip})")
    
    def remove_camera(self, camera_id: str):
        """移除摄像头"""
        if camera_id in self.cameras:
            del self.cameras[camera_id]
            del self.states[camera_id]
    
    async def start(self):
        """启动通道，连接所有摄像头"""
        if self._started:
            return
        
        logger.info("[CameraOutput] 启动...")
        
        for camera_id, config in self.cameras.items():
            await self._connect_camera(camera_id)
        
        self._started = True
        
        connected = sum(1 for s in self.states.values() if s.connected)
        logger.info(f"[CameraOutput] ✅ 已启动, {connected}/{len(self.cameras)} 摄像头在线")
    
    async def stop(self):
        """停止通道，断开所有摄像头"""
        logger.info("[CameraOutput] 停止...")
        
        # 先停止所有威慑
        for camera_id in self.cameras:
            await self._stop_deterrent(camera_id)
        
        # 断开连接
        for camera_id, state in self.states.items():
            if state.host:
                try:
                    await state.host.logout()
                except:
                    pass
                state.host = None
                state.connected = False
        
        self._started = False
        logger.info("[CameraOutput] 已停止")
    
    async def _connect_camera(self, camera_id: str) -> bool:
        """连接单个摄像头"""
        config = self.cameras.get(camera_id)
        state = self.states.get(camera_id)
        
        if not config or not state:
            return False
        
        try:
            from reolink_aio.api import Host
            
            logger.info(f"[CameraOutput] 连接 {config.name or camera_id} ({config.ip})...")
            
            host = Host(config.ip, config.username, config.password)
            await host.get_host_data()
            
            state.host = host
            state.connected = True
            
            model = host.camera_model(0) if host else "Unknown"
            logger.info(f"[CameraOutput] ✅ 已连接: {model}")
            
            return True
            
        except ImportError:
            logger.error("[CameraOutput] ❌ reolink_aio 未安装")
            return False
        except Exception as e:
            logger.error(f"[CameraOutput] ❌ 连接失败 {camera_id}: {e}")
            state.connected = False
            return False
    
    async def on_state_change(
        self,
        entry_point_id: str,
        from_state: str,
        to_state: str,
    ):
        """
        状态变化回调 - 核心方法
        
        根据状态变化控制威慑:
        - QUIET → PRE: 开灯光
        - QUIET/PRE → PENDING: 维持当前状态
        - PENDING → TRIGGERED: 声光齐发
        - * → QUIET: 停止威慑
        - * → DISARMED: 停止威慑
        """
        logger.info(f"[CameraOutput] 状态变化: {entry_point_id} | {from_state} → {to_state}")
        
        # 获取目标摄像头
        target_cameras = self._get_cameras_for_entry_point(entry_point_id)
        
        if not target_cameras:
            logger.warning(f"[CameraOutput] 无目标摄像头: {entry_point_id}")
            # 回退到所有摄像头
            target_cameras = list(self.cameras.keys())
        
        # 根据目标状态执行威慑
        to_state_lower = to_state.lower()
        
        if to_state_lower == "triggered":
            # TRIGGERED: 声光齐发
            logger.info(f"[CameraOutput] 🚨 TRIGGERED - 启动声光威慑!")
            for cam_id in target_cameras:
                await self._start_deterrent(cam_id, DeterrentLevel.TRIGGERED)
        
        elif to_state_lower == "pre":
            # PRE: 灯光警告
            logger.info(f"[CameraOutput] ⚡ PRE - 开启灯光警告")
            for cam_id in target_cameras:
                await self._start_deterrent(cam_id, DeterrentLevel.L2)
        
        elif to_state_lower in ("quiet", "disarmed"):
            # QUIET/DISARMED: 停止威慑
            logger.info(f"[CameraOutput] 停止威慑")
            for cam_id in target_cameras:
                await self._stop_deterrent(cam_id)
        
        elif to_state_lower == "pending":
            # PENDING: 保持当前状态（不改变威慑）
            logger.info(f"[CameraOutput] PENDING - 维持当前威慑状态")
    
    def _get_cameras_for_entry_point(self, entry_point_id: str) -> List[str]:
        """获取与入口点关联的摄像头"""
        result = []
        for cam_id, config in self.cameras.items():
            if config.entry_point_id == entry_point_id:
                result.append(cam_id)
        return result
    
    async def _start_deterrent(self, camera_id: str, level: DeterrentLevel):
        """启动威慑"""
        async with self._lock:
            config = self.cameras.get(camera_id)
            state = self.states.get(camera_id)
            
            if not config or not state:
                return
            
            if not state.connected or not state.host:
                # 尝试重连
                if not await self._connect_camera(camera_id):
                    return
            
            host = state.host
            if not host:
                return
            
            try:
                if level == DeterrentLevel.TRIGGERED:
                    # 声光齐发
                    await host.set_whiteled(0, state=True)
                    await host.set_siren(0, True)
                    logger.info(f"[CameraOutput] 🔴 {camera_id}: TRIGGERED (声+光)")
                
                elif level in (DeterrentLevel.L1, DeterrentLevel.L2):
                    # 仅灯光
                    await host.set_whiteled(0, state=True)
                    logger.info(f"[CameraOutput] 💡 {camera_id}: 灯光警告 (L{level.value-1})")
                
                state.deterrent_level = level
                state.last_action = f"deterrent_{level.name}"
                state.last_action_time = datetime.now(timezone.utc)
                
            except Exception as e:
                logger.error(f"[CameraOutput] 威慑启动失败 {camera_id}: {e}")
    
    async def _stop_deterrent(self, camera_id: str):
        """停止威慑"""
        async with self._lock:
            state = self.states.get(camera_id)
            
            if not state or not state.host:
                return
            
            host = state.host
            
            try:
                await host.set_whiteled(0, state=False)
                await host.set_siren(0, False)
                
                state.deterrent_level = DeterrentLevel.OFF
                state.last_action = "deterrent_off"
                state.last_action_time = datetime.now(timezone.utc)
                
                logger.info(f"[CameraOutput] ⬜ {camera_id}: 威慑已停止")
                
            except Exception as e:
                logger.error(f"[CameraOutput] 威慑停止失败 {camera_id}: {e}")
    
    # =========================================================================
    # 直接控制方法 (用于手动测试)
    # =========================================================================
    
    async def spotlight_on(self, camera_id: str) -> bool:
        """开启灯光"""
        state = self.states.get(camera_id)
        if not state or not state.host:
            return False
        
        try:
            await state.host.set_whiteled(0, state=True)
            logger.info(f"[CameraOutput] 💡 {camera_id}: Spotlight ON")
            return True
        except Exception as e:
            logger.error(f"[CameraOutput] Spotlight ON 失败 {camera_id}: {e}")
            return False
    
    async def spotlight_off(self, camera_id: str) -> bool:
        """关闭灯光"""
        state = self.states.get(camera_id)
        if not state or not state.host:
            return False
        
        try:
            await state.host.set_whiteled(0, state=False)
            logger.info(f"[CameraOutput] 💡 {camera_id}: Spotlight OFF")
            return True
        except Exception as e:
            logger.error(f"[CameraOutput] Spotlight OFF 失败 {camera_id}: {e}")
            return False
    
    async def siren_on(self, camera_id: str) -> bool:
        """开启警报"""
        state = self.states.get(camera_id)
        if not state or not state.host:
            return False
        
        try:
            await state.host.set_siren(0, True)
            logger.info(f"[CameraOutput] 🔔 {camera_id}: Siren ON")
            return True
        except Exception as e:
            logger.error(f"[CameraOutput] Siren ON 失败 {camera_id}: {e}")
            return False
    
    async def siren_off(self, camera_id: str) -> bool:
        """关闭警报"""
        state = self.states.get(camera_id)
        if not state or not state.host:
            return False
        
        try:
            await state.host.set_siren(0, False)
            logger.info(f"[CameraOutput] 🔔 {camera_id}: Siren OFF")
            return True
        except Exception as e:
            logger.error(f"[CameraOutput] Siren OFF 失败 {camera_id}: {e}")
            return False
    
    # =========================================================================
    # 状态查询
    # =========================================================================
    
    def get_status(self) -> Dict[str, Any]:
        """获取通道状态"""
        cameras_status = {}
        
        for cam_id, state in self.states.items():
            config = self.cameras.get(cam_id)
            cameras_status[cam_id] = {
                "name": config.name if config else cam_id,
                "ip": config.ip if config else "unknown",
                "connected": state.connected,
                "deterrent_level": state.deterrent_level.name,
                "last_action": state.last_action,
                "last_action_time": state.last_action_time.isoformat() if state.last_action_time else None,
                "entry_point_id": config.entry_point_id if config else None,
            }
        
        connected_count = sum(1 for s in self.states.values() if s.connected)
        
        return {
            "started": self._started,
            "total_cameras": len(self.cameras),
            "connected_cameras": connected_count,
            "cameras": cameras_status,
        }


# =============================================================================
# 快速测试
# =============================================================================

async def quick_test():
    """快速测试"""
    import sys
    
    if len(sys.argv) < 4:
        print("Usage: python camera_output_channel.py <ip> <user> <password> [state]")
        print("States: quiet, pre, pending, triggered")
        return
    
    ip, user, password = sys.argv[1:4]
    state = sys.argv[4] if len(sys.argv) > 4 else "triggered"
    
    # 创建配置
    config = CameraConfig(
        camera_id="test_cam",
        ip=ip,
        username=user,
        password=password,
        name="Test Camera",
        entry_point_id="test_entry",
    )
    
    # 创建通道
    channel = CameraOutputChannel([config])
    
    try:
        # 启动
        await channel.start()
        
        # 触发状态变化
        await channel.on_state_change("test_entry", "quiet", state)
        
        print(f"\n状态: {channel.get_status()}")
        
        # 等待 3 秒
        await asyncio.sleep(3)
        
        # 停止威慑
        await channel.on_state_change("test_entry", state, "quiet")
        
    finally:
        await channel.stop()


if __name__ == "__main__":
    asyncio.run(quick_test())
