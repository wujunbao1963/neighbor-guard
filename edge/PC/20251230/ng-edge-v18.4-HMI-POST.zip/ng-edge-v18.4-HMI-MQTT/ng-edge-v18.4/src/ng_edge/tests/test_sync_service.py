"""
Tests for Cloud Sync Service

Run with: pytest test_sync_service.py -v
"""

import pytest
import asyncio
import tempfile
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch
from datetime import datetime, timezone

import sys
sys.path.insert(0, str(Path(__file__).parent.parent))

from ng_edge.cloud.config import CloudConfig, DeviceCredentials
from ng_edge.cloud.sync_service import CloudSyncService, SyncStats


@pytest.fixture
def registered_config():
    """Config with device credentials."""
    with tempfile.TemporaryDirectory() as tmpdir:
        config = CloudConfig(
            server_url="http://test-server:3000",
            config_dir=tmpdir,
        )
        config.credentials = DeviceCredentials(
            device_id="dev-123",
            device_key="test-device-key",
            circle_id="circle-456",
            paired_at="2025-01-01T00:00:00Z",
        )
        yield config


class TestSyncStats:
    """Test SyncStats dataclass."""
    
    def test_default_values(self):
        stats = SyncStats()
        assert stats.heartbeat_success == 0
        assert stats.heartbeat_failure == 0
        assert stats.last_heartbeat is None
        assert stats.events_forwarded == 0


class TestCloudSyncService:
    """Test CloudSyncService."""
    
    def test_init(self, registered_config):
        sync = CloudSyncService(
            config=registered_config,
            heartbeat_interval_sec=10,
            topo_sync_interval_sec=60,
        )
        
        assert sync.heartbeat_interval == 10
        assert sync.topo_sync_interval == 60
        assert sync._running is False
    
    def test_get_status_not_running(self, registered_config):
        sync = CloudSyncService(registered_config)
        status = sync.get_status()
        
        assert status["running"] is False
        assert status["connected"] is False
        assert status["device_id"] == "dev-123"
    
    def test_is_connected(self, registered_config):
        sync = CloudSyncService(registered_config)
        
        assert sync.is_connected is False
        
        sync._was_connected = True
        assert sync.is_connected is True
    
    def test_set_topology_provider(self, registered_config):
        sync = CloudSyncService(registered_config)
        
        def my_topo():
            return {"version": 1, "zones": []}
        
        sync.set_topology_provider(my_topo)
        assert sync._topo_provider is not None


class TestSyncServiceAsync:
    """Async tests for CloudSyncService."""
    
    @pytest.mark.asyncio
    async def test_start_without_credentials(self):
        """Test start fails gracefully without credentials."""
        with tempfile.TemporaryDirectory() as tmpdir:
            config = CloudConfig(config_dir=tmpdir)
            sync = CloudSyncService(config)
            
            await sync.start()
            
            # Should not be running without credentials
            assert sync._running is False
    
    @pytest.mark.asyncio
    async def test_forward_event_not_registered(self):
        """Test event forwarding fails when not registered."""
        with tempfile.TemporaryDirectory() as tmpdir:
            config = CloudConfig(config_dir=tmpdir)
            sync = CloudSyncService(config)
            
            result = await sync.forward_event({"eventId": "123"})
            
            assert result is False
    
    @pytest.mark.asyncio
    async def test_forward_event_not_connected(self, registered_config):
        """Test event is queued when not connected."""
        sync = CloudSyncService(registered_config)
        sync._was_connected = False  # Simulate disconnected
        
        event = {"eventId": "test-event"}
        result = await sync.forward_event(event)
        
        assert result is False
        assert len(sync._event_queue) == 1
        assert sync.stats.events_queued == 1
    
    @pytest.mark.asyncio
    async def test_forward_event_success(self, registered_config):
        """Test successful event forwarding."""
        sync = CloudSyncService(registered_config)
        sync._was_connected = True
        
        # Mock the client's ingest_event
        with patch.object(sync.client, 'ingest_event', return_value=(True, {"eventId": "123", "deduped": False}, None)):
            event = {"eventId": "test-event"}
            result = await sync.forward_event(event)
        
        assert result is True
        assert sync.stats.events_forwarded == 1
    
    @pytest.mark.asyncio
    async def test_heartbeat_success(self, registered_config):
        """Test heartbeat success updates stats."""
        sync = CloudSyncService(registered_config)
        
        with patch.object(sync.client, 'health_check', return_value=(True, {"ok": True}, None)):
            await sync._do_heartbeat()
        
        assert sync.stats.heartbeat_success == 1
        assert sync.stats.last_heartbeat_ok is True
        assert sync._was_connected is True
    
    @pytest.mark.asyncio
    async def test_heartbeat_failure(self, registered_config):
        """Test heartbeat failure updates stats."""
        sync = CloudSyncService(registered_config)
        
        with patch.object(sync.client, 'health_check', return_value=(False, None, "Connection refused")):
            await sync._do_heartbeat()
        
        assert sync.stats.heartbeat_failure == 1
        assert sync.stats.last_heartbeat_ok is False
    
    @pytest.mark.asyncio
    async def test_connection_lost_after_3_failures(self, registered_config):
        """Test connection lost callback after 3 consecutive failures."""
        sync = CloudSyncService(registered_config)
        sync._was_connected = True
        
        lost_callback = MagicMock()
        sync.on_connection_lost(lost_callback)
        
        with patch.object(sync.client, 'health_check', return_value=(False, None, "Error")):
            # First 2 failures - should not trigger callback
            await sync._do_heartbeat()
            await sync._do_heartbeat()
            lost_callback.assert_not_called()
            
            # Third failure - should trigger callback
            await sync._do_heartbeat()
            lost_callback.assert_called_once()
    
    @pytest.mark.asyncio
    async def test_connection_restored(self, registered_config):
        """Test connection restored callback."""
        sync = CloudSyncService(registered_config)
        sync._was_connected = False
        
        restored_callback = MagicMock()
        sync.on_connection_restored(restored_callback)
        
        with patch.object(sync.client, 'health_check', return_value=(True, {"ok": True}, None)):
            await sync._do_heartbeat()
        
        restored_callback.assert_called_once()
        assert sync._was_connected is True
    
    @pytest.mark.asyncio
    async def test_event_queue_limit(self, registered_config):
        """Test event queue respects size limit."""
        sync = CloudSyncService(registered_config, event_queue_size=3)
        sync._was_connected = False
        
        # Queue 5 events (limit is 3)
        for i in range(5):
            await sync.forward_event({"eventId": f"event-{i}"})
        
        # Should only have last 3 events
        assert len(sync._event_queue) == 3
        assert sync._event_queue[0]["eventId"] == "event-2"
        assert sync._event_queue[2]["eventId"] == "event-4"
    
    @pytest.mark.asyncio
    async def test_retry_queued_events_on_reconnect(self, registered_config):
        """Test queued events are retried when connection is restored."""
        sync = CloudSyncService(registered_config)
        sync._was_connected = False
        
        # Queue an event
        await sync.forward_event({"eventId": "queued-event"})
        assert len(sync._event_queue) == 1
        
        # Simulate reconnect with successful ingest
        with patch.object(sync.client, 'health_check', return_value=(True, {"ok": True}, None)):
            with patch.object(sync.client, 'ingest_event', return_value=(True, {"eventId": "queued-event"}, None)):
                await sync._do_heartbeat()
        
        # Queue should be empty after retry
        assert len(sync._event_queue) == 0
        assert sync.stats.events_forwarded == 1


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
