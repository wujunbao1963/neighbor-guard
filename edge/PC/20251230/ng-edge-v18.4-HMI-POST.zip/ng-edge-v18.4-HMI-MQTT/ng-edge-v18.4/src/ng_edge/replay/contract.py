"""
NG-EDGE Replay Contract

Replay 合约定义，符合 Architecture Spec v2.2 §11

用途：
1. 复现生产问题
2. 规则变更回归测试
3. 压力测试
4. 合规审计

核心约束：
- 确定性：相同输入必须产生相同输出
- 无副作用：不触发真实通知/警报（除非 live 模式）
- 时间隔离：使用模拟时钟
- 配置冻结：重放期间规则和配置不变
"""

from dataclasses import dataclass, field
from datetime import datetime, timezone, timedelta
from enum import Enum
from typing import Dict, Any, Optional, List, Callable
import json

from ng_edge.core.signal import SignalEnvelope


# =============================================================================
# 枚举定义
# =============================================================================

class ReplayMode(str, Enum):
    """重放模式"""
    INSTANT = "instant"         # 立即执行，无时间模拟
    ACCELERATED = "accelerated" # 加速执行
    REALTIME = "realtime"       # 实时执行


class DiffSeverity(str, Enum):
    """差异严重程度"""
    NONE = "none"
    MINOR = "minor"       # 小差异（如时间戳微小偏差）
    MAJOR = "major"       # 主要差异（状态不同）
    CRITICAL = "critical" # 关键差异（安全相关）


# =============================================================================
# 状态快照
# =============================================================================

@dataclass
class ModeContext:
    """模式上下文"""
    arming_state: str = "disarmed"  # disarmed, armed_stay, armed_away
    house_mode: str = "home"        # home, away, night, vacation
    entry_delay_sec: int = 30
    exit_delay_sec: int = 60
    bypass_zones: List[str] = field(default_factory=list)


@dataclass
class DeviceState:
    """设备状态"""
    device_id: str
    device_type: str
    online: bool = True
    battery_level: Optional[int] = None
    last_seen: Optional[datetime] = None


@dataclass
class IncidentSnapshot:
    """事件快照"""
    incident_id: str
    threat_state: str
    workflow_state: str
    sub_phase: Optional[str] = None
    zone_id: str = ""
    entrypoint_id: Optional[str] = None
    signals: List[str] = field(default_factory=list)  # signal_ids


@dataclass
class ContextGateState:
    """上下文门控状态"""
    gate_type: str
    valid: bool
    expires_at: datetime


@dataclass
class InitialState:
    """初始状态"""
    mode_context: ModeContext = field(default_factory=ModeContext)
    active_incidents: List[IncidentSnapshot] = field(default_factory=list)
    device_states: List[DeviceState] = field(default_factory=list)
    judge_available: bool = True
    active_context_gates: List[ContextGateState] = field(default_factory=list)


# =============================================================================
# 配置
# =============================================================================

@dataclass
class ReplayConfig:
    """重放配置"""
    # Correlation
    pre_aggregation_window_sec: int = 60
    hard_association_window_sec: int = 30
    incident_active_window_sec: int = 300
    
    # Context Gate
    yard_confirmed_ttl_sec: int = 120
    porch_confirmed_ttl_sec: int = 60
    
    # State Machine
    entry_delay_sec: int = 30
    exit_delay_sec: int = 60
    quick_open_close_window_sec: int = 3
    
    # Decay
    pre_l3_silence_sec: int = 120
    pre_l2_silence_sec: int = 180
    pre_l1_silence_sec: int = 300
    
    # Soft Gate
    yard_accelerated_dwell_sec: int = 30
    default_dwell_sec: int = 90
    
    # Human Verify
    confirm_window_sec: int = 60
    decay_after_timeout_sec: int = 300
    
    # Judge
    offline_threshold_sec: int = 90


# =============================================================================
# 输入/输出
# =============================================================================

@dataclass
class ReplayInput:
    """
    重放输入 (v2.2 Spec §11.2)
    """
    replay_id: str
    description: str = ""
    
    # 信号序列（按 ingest_ts 排序）
    signals: List[SignalEnvelope] = field(default_factory=list)
    
    # 初始状态
    initial_state: InitialState = field(default_factory=InitialState)
    
    # 配置
    config: ReplayConfig = field(default_factory=ReplayConfig)
    
    # 时间控制
    time_mode: ReplayMode = ReplayMode.INSTANT
    acceleration_factor: float = 1.0
    
    def to_dict(self) -> Dict[str, Any]:
        """序列化"""
        return {
            "replay_id": self.replay_id,
            "description": self.description,
            "signals": [s.to_dict() for s in self.signals],
            "initial_state": {
                "mode_context": {
                    "arming_state": self.initial_state.mode_context.arming_state,
                    "house_mode": self.initial_state.mode_context.house_mode,
                    "entry_delay_sec": self.initial_state.mode_context.entry_delay_sec,
                    "exit_delay_sec": self.initial_state.mode_context.exit_delay_sec,
                    "bypass_zones": self.initial_state.mode_context.bypass_zones,
                },
                "judge_available": self.initial_state.judge_available,
            },
            "time_mode": self.time_mode.value,
            "acceleration_factor": self.acceleration_factor,
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ReplayInput":
        """反序列化"""
        signals = [SignalEnvelope.from_dict(s) for s in data.get("signals", [])]
        
        initial_state_data = data.get("initial_state", {})
        mode_context_data = initial_state_data.get("mode_context", {})
        
        return cls(
            replay_id=data.get("replay_id", ""),
            description=data.get("description", ""),
            signals=signals,
            initial_state=InitialState(
                mode_context=ModeContext(
                    arming_state=mode_context_data.get("arming_state", "disarmed"),
                    house_mode=mode_context_data.get("house_mode", "home"),
                    entry_delay_sec=mode_context_data.get("entry_delay_sec", 30),
                    exit_delay_sec=mode_context_data.get("exit_delay_sec", 60),
                    bypass_zones=mode_context_data.get("bypass_zones", []),
                ),
                judge_available=initial_state_data.get("judge_available", True),
            ),
            time_mode=ReplayMode(data.get("time_mode", "instant")),
            acceleration_factor=data.get("acceleration_factor", 1.0),
        )


@dataclass
class TransitionRecord:
    """状态转换记录"""
    record_id: str
    timestamp: datetime
    incident_id: str
    
    dimension: str  # "threat", "workflow", "sub_phase"
    from_state: str
    to_state: str
    
    rule_id: str = ""
    reason_code: str = ""
    
    trigger_signal_ids: List[str] = field(default_factory=list)
    
    context: Dict[str, Any] = field(default_factory=dict)


@dataclass
class AuthorizedAction:
    """授权的动作"""
    action_id: str
    action_type: str
    incident_id: str
    timestamp: datetime
    authorized: bool = True
    reason: str = ""


@dataclass
class ReplayOutput:
    """
    重放输出 (v2.2 Spec §11.3)
    """
    replay_id: str
    
    # 结果
    incidents: List[IncidentSnapshot] = field(default_factory=list)
    transitions: List[TransitionRecord] = field(default_factory=list)
    actions_authorized: List[AuthorizedAction] = field(default_factory=list)
    
    # 统计
    signals_processed: int = 0
    signals_deduplicated: int = 0
    incidents_created: int = 0
    incidents_merged: int = 0
    total_transitions: int = 0
    
    # 时间
    replay_started_at: Optional[datetime] = None
    replay_completed_at: Optional[datetime] = None
    simulated_duration_sec: float = 0.0
    wall_clock_duration_sec: float = 0.0
    
    # 错误
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    
    def to_dict(self) -> Dict[str, Any]:
        """序列化"""
        return {
            "replay_id": self.replay_id,
            "incidents": [
                {
                    "incident_id": i.incident_id,
                    "threat_state": i.threat_state,
                    "workflow_state": i.workflow_state,
                }
                for i in self.incidents
            ],
            "transitions": [
                {
                    "record_id": t.record_id,
                    "dimension": t.dimension,
                    "from_state": t.from_state,
                    "to_state": t.to_state,
                    "reason_code": t.reason_code,
                }
                for t in self.transitions
            ],
            "stats": {
                "signals_processed": self.signals_processed,
                "incidents_created": self.incidents_created,
                "total_transitions": self.total_transitions,
            },
            "errors": self.errors,
            "warnings": self.warnings,
        }


# =============================================================================
# Replay Diff (用于回归测试)
# =============================================================================

@dataclass
class TransitionDiff:
    """转换差异"""
    index: int
    diff_type: str  # "added", "removed", "changed"
    transition_a: Optional[TransitionRecord] = None
    transition_b: Optional[TransitionRecord] = None
    details: str = ""


@dataclass
class ReplayDiff:
    """
    重放差异 (v2.2 Spec §11.7)
    
    用于比较两次重放的结果，检测回归
    """
    replay_id_a: str
    replay_id_b: str
    
    # 差异
    incident_diffs: List[Dict[str, Any]] = field(default_factory=list)
    transition_diffs: List[TransitionDiff] = field(default_factory=list)
    action_diffs: List[Dict[str, Any]] = field(default_factory=list)
    
    # 汇总
    is_identical: bool = True
    diff_count: int = 0
    severity: DiffSeverity = DiffSeverity.NONE
    
    @classmethod
    def compare(cls, output_a: ReplayOutput, output_b: ReplayOutput) -> "ReplayDiff":
        """
        比较两个重放结果
        """
        diff = cls(
            replay_id_a=output_a.replay_id,
            replay_id_b=output_b.replay_id,
        )
        
        # 比较 incidents
        incidents_a = {i.incident_id: i for i in output_a.incidents}
        incidents_b = {i.incident_id: i for i in output_b.incidents}
        
        all_incident_ids = set(incidents_a.keys()) | set(incidents_b.keys())
        
        for inc_id in all_incident_ids:
            inc_a = incidents_a.get(inc_id)
            inc_b = incidents_b.get(inc_id)
            
            if inc_a and inc_b:
                if inc_a.threat_state != inc_b.threat_state:
                    diff.incident_diffs.append({
                        "incident_id": inc_id,
                        "field": "threat_state",
                        "value_a": inc_a.threat_state,
                        "value_b": inc_b.threat_state,
                    })
                    diff.is_identical = False
                    diff.diff_count += 1
                    diff.severity = DiffSeverity.CRITICAL
            elif inc_a:
                diff.incident_diffs.append({
                    "incident_id": inc_id,
                    "diff_type": "removed",
                    "value_a": inc_a.threat_state,
                })
                diff.is_identical = False
                diff.diff_count += 1
            else:
                diff.incident_diffs.append({
                    "incident_id": inc_id,
                    "diff_type": "added",
                    "value_b": inc_b.threat_state,
                })
                diff.is_identical = False
                diff.diff_count += 1
        
        # 比较 transitions 数量
        if len(output_a.transitions) != len(output_b.transitions):
            diff.is_identical = False
            diff.severity = max(diff.severity, DiffSeverity.MAJOR)
        
        # 简单比较转换序列
        max_len = max(len(output_a.transitions), len(output_b.transitions))
        for i in range(max_len):
            t_a = output_a.transitions[i] if i < len(output_a.transitions) else None
            t_b = output_b.transitions[i] if i < len(output_b.transitions) else None
            
            if t_a and t_b:
                if t_a.to_state != t_b.to_state or t_a.from_state != t_b.from_state:
                    diff.transition_diffs.append(TransitionDiff(
                        index=i,
                        diff_type="changed",
                        transition_a=t_a,
                        transition_b=t_b,
                        details=f"{t_a.from_state}->{t_a.to_state} vs {t_b.from_state}->{t_b.to_state}"
                    ))
                    diff.is_identical = False
                    diff.diff_count += 1
            elif t_a:
                diff.transition_diffs.append(TransitionDiff(
                    index=i,
                    diff_type="removed",
                    transition_a=t_a,
                ))
                diff.is_identical = False
                diff.diff_count += 1
            else:
                diff.transition_diffs.append(TransitionDiff(
                    index=i,
                    diff_type="added",
                    transition_b=t_b,
                ))
                diff.is_identical = False
                diff.diff_count += 1
        
        return diff


# =============================================================================
# Replay Engine Interface
# =============================================================================

class ReplayEngineInterface:
    """
    Replay Engine 接口
    
    具体实现将在 Phase 2 之后完成，
    当 Correlation Layer 和 State Machine 重构完成后
    """
    
    def run(self, input: ReplayInput) -> ReplayOutput:
        """
        运行重放
        
        Args:
            input: 重放输入
            
        Returns:
            ReplayOutput: 重放输出
        """
        raise NotImplementedError("ReplayEngine not yet implemented")
    
    def validate_determinism(self, input: ReplayInput, runs: int = 3) -> bool:
        """
        验证确定性
        
        运行多次重放，确保结果一致
        
        Args:
            input: 重放输入
            runs: 运行次数
            
        Returns:
            bool: 是否确定性
        """
        outputs = [self.run(input) for _ in range(runs)]
        
        for i in range(1, len(outputs)):
            diff = ReplayDiff.compare(outputs[0], outputs[i])
            if not diff.is_identical:
                return False
        
        return True


# =============================================================================
# 测试场景生成器
# =============================================================================

class TestScenarioBuilder:
    """
    测试场景构建器
    
    用于构建标准化的测试场景
    """
    
    def __init__(self, replay_id: str = ""):
        self.replay_id = replay_id or f"test_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        self.signals: List[SignalEnvelope] = []
        self.initial_state = InitialState()
        self.config = ReplayConfig()
        self.base_time = datetime.now(timezone.utc)
    
    def set_mode(self, arming_state: str, house_mode: str = "home") -> "TestScenarioBuilder":
        """设置模式"""
        self.initial_state.mode_context.arming_state = arming_state
        self.initial_state.mode_context.house_mode = house_mode
        return self
    
    def add_door_open(
        self,
        offset_sec: float,
        entrypoint_id: str,
        zone_id: str = "entry_exit",
        device_id: str = ""
    ) -> "TestScenarioBuilder":
        """添加门打开信号"""
        ts = self.base_time + timedelta(seconds=offset_sec)
        
        signal = SignalEnvelope.from_zigbee(
            device_id=device_id or f"contact_{entrypoint_id}",
            friendly_name=f"{entrypoint_id} Contact",
            signal_kind="door_open",
            zone_id=zone_id,
            entrypoint_id=entrypoint_id,
        )
        signal.timestamp = ts
        signal.ingest_ts = ts
        
        self.signals.append(signal)
        return self
    
    def add_door_close(
        self,
        offset_sec: float,
        entrypoint_id: str,
        zone_id: str = "entry_exit",
        device_id: str = ""
    ) -> "TestScenarioBuilder":
        """添加门关闭信号"""
        ts = self.base_time + timedelta(seconds=offset_sec)
        
        signal = SignalEnvelope.from_zigbee(
            device_id=device_id or f"contact_{entrypoint_id}",
            friendly_name=f"{entrypoint_id} Contact",
            signal_kind="door_close",
            zone_id=zone_id,
            entrypoint_id=entrypoint_id,
        )
        signal.timestamp = ts
        signal.ingest_ts = ts
        
        self.signals.append(signal)
        return self
    
    def add_person_detected(
        self,
        offset_sec: float,
        zone_id: str,
        camera_id: str,
        camera_role: CameraRole = CameraRole.JUDGE,
        confidence: float = 0.85,
        entrypoint_id: Optional[str] = None,
    ) -> "TestScenarioBuilder":
        """添加人员检测信号"""
        ts = self.base_time + timedelta(seconds=offset_sec)
        
        signal = SignalEnvelope.from_camera(
            device_id=camera_id,
            signal_kind="person_detected",
            zone_id=zone_id,
            camera_role=camera_role,
            confidence=confidence,
            entrypoint_id=entrypoint_id,
        )
        signal.timestamp = ts
        signal.ingest_ts = ts
        
        self.signals.append(signal)
        return self
    
    def add_timeout(self, offset_sec: float, timeout_type: str) -> "TestScenarioBuilder":
        """
        添加超时信号（用于模拟 entry delay expired 等）
        
        注意：这是一个特殊的"虚拟信号"，用于 Replay 中模拟时间流逝
        """
        ts = self.base_time + timedelta(seconds=offset_sec)
        
        signal = SignalEnvelope(
            source_type=SourceType.HEALTH,
            device_id="_system",
            zone_id="_global",
            signal_kind=f"_timeout_{timeout_type}",
            hardness=Hardness.HARD,  # 超时是硬信号
            timestamp=ts,
            ingest_ts=ts,
            attributes={
                "timeout_type": timeout_type,
            }
        )
        
        self.signals.append(signal)
        return self
    
    def build(self) -> ReplayInput:
        """构建重放输入"""
        # 按 ingest_ts 排序
        self.signals.sort(key=lambda s: s.ingest_ts)
        
        return ReplayInput(
            replay_id=self.replay_id,
            signals=self.signals,
            initial_state=self.initial_state,
            config=self.config,
        )


# =============================================================================
# 标准测试场景
# =============================================================================

def create_door_breach_scenario() -> ReplayInput:
    """
    标准场景：门违规 (AWAY 模式)
    
    T=0s: door_open (entry_exit zone)
    T=30s: entry_delay_expired (timeout)
    
    预期结果：
    - QUIET → PENDING (T=0s)
    - PENDING → TRIGGERED (T=30s)
    """
    return (
        TestScenarioBuilder("scenario_door_breach")
        .set_mode("armed_away", "away")
        .add_door_open(0, "ep_front_door", "entry_exit")
        .add_timeout(30, "entry_delay")
        .build()
    )


def create_quick_open_close_scenario() -> ReplayInput:
    """
    标准场景：快速开关门 (应取消 PENDING)
    
    T=0s: door_open
    T=2s: door_close (< 3s)
    
    预期结果：
    - QUIET → PENDING (T=0s)
    - PENDING → QUIET (T=2s, reason=QUICK_OPEN_CLOSE)
    """
    return (
        TestScenarioBuilder("scenario_quick_open_close")
        .set_mode("armed_away", "away")
        .add_door_open(0, "ep_front_door", "entry_exit")
        .add_door_close(2, "ep_front_door", "entry_exit")
        .build()
    )


def create_pre_escalation_scenario() -> ReplayInput:
    """
    标准场景：PRE 升级 (HOME 模式)
    
    T=0s: person_detected (exterior)
    T=10s: door_open (entry_exit)
    
    预期结果：
    - QUIET → PRE (T=0s)
    - PRE → PRE (T=10s, signal added)
    """
    return (
        TestScenarioBuilder("scenario_pre_escalation")
        .set_mode("armed_stay", "home")
        .add_person_detected(0, "exterior", "cam_front")
        .add_door_open(10, "ep_front_door", "entry_exit")
        .build()
    )
