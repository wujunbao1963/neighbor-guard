#!/usr/bin/env python3
"""
NG Edge - Server Integration Test Script

Tests device registration against a real server.

Usage:
    # First, get a user token from the server (dev login)
    curl -X POST http://YOUR_SERVER:3000/api/auth/dev/login \
        -H "Content-Type: application/json" \
        -d '{"email": "test@example.com", "displayName": "Test User"}'
    
    # Then create a circle
    curl -X POST http://YOUR_SERVER:3000/api/circles \
        -H "Authorization: Bearer YOUR_TOKEN" \
        -H "Content-Type: application/json" \
        -d '{"name": "My Home"}'
    
    # Then run this script
    python test_server_integration.py \
        --server http://YOUR_SERVER:3000 \
        --token YOUR_TOKEN \
        --circle YOUR_CIRCLE_ID
"""

import asyncio
import argparse
import sys
from pathlib import Path

# Add parent to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent))

from ng_edge.cloud import CloudConfig, CloudClient


async def test_health_check(client: CloudClient) -> bool:
    """Test 1: Health check."""
    print("\n" + "=" * 60)
    print("TEST 1: Health Check")
    print("=" * 60)
    
    healthy, data, error = await client.health_check()
    
    if healthy:
        print(f"✓ Server is healthy")
        print(f"  Response: {data}")
        return True
    else:
        print(f"✗ Server health check failed: {error}")
        return False


async def test_device_registration(client: CloudClient, circle_id: str) -> bool:
    """Test 2: Device registration."""
    print("\n" + "=" * 60)
    print("TEST 2: Device Registration")
    print("=" * 60)
    
    success, creds, error = await client.register_device(
        circle_id=circle_id,
        device_name="NG Edge Integration Test",
    )
    
    if success:
        print(f"✓ Device registered successfully!")
        print(f"  device_id: {creds.device_id}")
        print(f"  device_key: {creds.device_key[:20]}...")
        print(f"  circle_id: {creds.circle_id}")
        print(f"  paired_at: {creds.paired_at}")
        return True
    else:
        print(f"✗ Registration failed: {error}")
        return False


async def test_credentials_persistence(config: CloudConfig) -> bool:
    """Test 3: Credentials persistence."""
    print("\n" + "=" * 60)
    print("TEST 3: Credentials Persistence")
    print("=" * 60)
    
    if not config.is_registered:
        print("✗ No credentials to test (registration may have failed)")
        return False
    
    # Save credentials
    saved = config.save_credentials()
    if not saved:
        print("✗ Failed to save credentials")
        return False
    
    print(f"✓ Credentials saved to: {config.credentials_path}")
    
    # Load in new config
    config2 = CloudConfig(
        config_dir=config.config_dir,
        server_url=config.server_url,
    )
    
    loaded = config2.load_credentials()
    if not loaded:
        print("✗ Failed to load credentials")
        return False
    
    # Verify
    if config2.credentials.device_id == config.credentials.device_id:
        print(f"✓ Credentials loaded and verified")
        print(f"  device_id: {config2.credentials.device_id}")
        return True
    else:
        print("✗ Loaded credentials don't match")
        return False


async def main():
    parser = argparse.ArgumentParser(description="NG Edge Server Integration Test")
    parser.add_argument(
        "--server", "-s",
        required=True,
        help="Server URL (e.g., http://192.168.1.100:3000)",
    )
    parser.add_argument(
        "--token", "-t",
        required=True,
        help="User JWT token (from /api/auth/dev/login)",
    )
    parser.add_argument(
        "--circle", "-c",
        required=True,
        help="Circle ID to register device to",
    )
    parser.add_argument(
        "--config-dir",
        default="./test_config",
        help="Config directory for credentials storage",
    )
    
    args = parser.parse_args()
    
    print("=" * 60)
    print("NG Edge - Server Integration Test")
    print("=" * 60)
    print(f"Server URL: {args.server}")
    print(f"Circle ID:  {args.circle}")
    print(f"Config Dir: {args.config_dir}")
    
    # Setup
    config = CloudConfig(
        server_url=args.server,
        user_token=args.token,
        config_dir=args.config_dir,
    )
    
    client = CloudClient(config)
    
    results = []
    
    try:
        # Test 1: Health check
        results.append(("Health Check", await test_health_check(client)))
        
        # Test 2: Device registration
        results.append(("Device Registration", await test_device_registration(client, args.circle)))
        
        # Test 3: Credentials persistence
        results.append(("Credentials Persistence", await test_credentials_persistence(config)))
        
    finally:
        await client.close()
    
    # Summary
    print("\n" + "=" * 60)
    print("TEST SUMMARY")
    print("=" * 60)
    
    passed = 0
    failed = 0
    for name, success in results:
        status = "✓ PASS" if success else "✗ FAIL"
        print(f"  {status}: {name}")
        if success:
            passed += 1
        else:
            failed += 1
    
    print("-" * 60)
    print(f"  Total: {passed} passed, {failed} failed")
    
    if config.is_registered:
        print("\n" + "=" * 60)
        print("DEVICE CREDENTIALS (save these!)")
        print("=" * 60)
        print(f"  device_id:  {config.credentials.device_id}")
        print(f"  device_key: {config.credentials.device_key}")
        print(f"  circle_id:  {config.credentials.circle_id}")
        print(f"  Saved to:   {config.credentials_path}")
    
    return 0 if failed == 0 else 1


if __name__ == "__main__":
    exit_code = asyncio.run(main())
    sys.exit(exit_code)
