#!/usr/bin/env python3
"""
NG Edge - Device Registration Helper

Registers the edge device with the server using proper auth flow:
1. Request verification code
2. Login with code (587585 in test mode)
3. Get/create circle
4. Register device with deviceKey

Usage:
    python register_edge_device.py --server http://10.0.0.136:3000
"""

import asyncio
import argparse
import sys
from pathlib import Path

try:
    import aiohttp
except ImportError:
    print("ERROR: aiohttp required. Install with: pip install aiohttp")
    sys.exit(1)


async def request_code(session: aiohttp.ClientSession, server: str, email: str) -> bool:
    """Step 1: Request verification code."""
    url = f"{server}/api/auth/request-code"
    async with session.post(url, json={"email": email}) as resp:
        data = await resp.json()
        if resp.status == 200 and data.get("success"):
            print(f"  ✓ Code requested (test mode uses 587585)")
            return True
        else:
            print(f"  ✗ Failed: {data}")
            return False


async def login(session: aiohttp.ClientSession, server: str, email: str, code: str) -> str:
    """Step 2: Login with code, get access token."""
    url = f"{server}/api/auth/login"
    async with session.post(url, json={"email": email, "code": code}) as resp:
        data = await resp.json()
        if resp.status == 200:
            token = data.get("accessToken")
            if token:
                print(f"  ✓ Login successful")
                return token
        print(f"  ✗ Login failed: {data}")
        return None


async def get_circles(session: aiohttp.ClientSession, server: str, token: str) -> list:
    """Get user's circles."""
    url = f"{server}/api/circles"
    headers = {"Authorization": f"Bearer {token}"}
    async with session.get(url, headers=headers) as resp:
        data = await resp.json()
        if resp.status == 200:
            return data.get("circles", [])
        return []


async def create_circle(session: aiohttp.ClientSession, server: str, token: str, name: str) -> dict:
    """Create a new circle."""
    url = f"{server}/api/circles"
    headers = {"Authorization": f"Bearer {token}"}
    async with session.post(url, json={"name": name}, headers=headers) as resp:
        data = await resp.json()
        if resp.status in (200, 201):
            return data.get("circle") or data
        print(f"  ✗ Create circle failed: {data}")
        return None


async def register_device(
    session: aiohttp.ClientSession,
    server: str,
    token: str,
    circle_id: str,
    device_key: str,
    display_name: str,
) -> dict:
    """Register device with circle."""
    url = f"{server}/api/edge/devices"
    headers = {"Authorization": f"Bearer {token}"}
    payload = {
        "circleId": circle_id,
        "deviceKey": device_key,
        "displayName": display_name,
    }
    async with session.post(url, json=payload, headers=headers) as resp:
        data = await resp.json()
        if resp.status == 200 and data.get("success"):
            return data.get("data")
        print(f"  Response: {data}")
        return data


async def verify_heartbeat(session: aiohttp.ClientSession, server: str, device_key: str) -> bool:
    """Verify device can send heartbeat."""
    url = f"{server}/api/edge/devices/{device_key}/heartbeat"
    headers = {
        "Authorization": f"Device {device_key}",
        "Content-Type": "application/json",
    }
    async with session.post(url, json={"status": "ONLINE"}, headers=headers) as resp:
        data = await resp.json()
        if resp.status == 200 and data.get("success"):
            return True
        print(f"  Heartbeat response: {data}")
        return False


def load_device_key(path: str) -> str:
    """Load device key from file."""
    try:
        return Path(path).read_text().strip()
    except Exception as e:
        print(f"ERROR: Cannot read device key from {path}: {e}")
        return None


async def main():
    parser = argparse.ArgumentParser(description="Register Edge Device")
    parser.add_argument("--server", "-s", default="http://10.0.0.136:3000")
    parser.add_argument("--email", "-e", default="edge-admin@test.com")
    parser.add_argument("--code", "-c", default="587585", help="Verification code")
    parser.add_argument("--circle-name", default="My Home")
    parser.add_argument("--device-name", default="UP Xtreme Edge")
    parser.add_argument("--device-key-path", default="/var/lib/ng-edge/device_key")
    
    args = parser.parse_args()
    
    print("=" * 60)
    print("NG Edge - Device Registration")
    print("=" * 60)
    print(f"Server: {args.server}")
    print(f"Email:  {args.email}")
    print()
    
    # Load device key
    device_key = load_device_key(args.device_key_path)
    if not device_key:
        return 1
    print(f"Device Key: {device_key}")
    print()
    
    timeout = aiohttp.ClientTimeout(total=10)
    async with aiohttp.ClientSession(timeout=timeout) as session:
        
        # Step 1: Request code
        print("Step 1: Requesting verification code...")
        if not await request_code(session, args.server, args.email):
            return 1
        
        # Step 2: Login
        print("\nStep 2: Logging in with code...")
        token = await login(session, args.server, args.email, args.code)
        if not token:
            return 1
        print(f"  Token: {token[:40]}...")
        
        # Step 3: Get or create circle
        print("\nStep 3: Getting/creating circle...")
        circles = await get_circles(session, args.server, token)
        
        if circles:
            circle = circles[0]
            print(f"  ✓ Using existing circle: {circle.get('name')} (ID: {circle.get('id')})")
        else:
            circle = await create_circle(session, args.server, token, args.circle_name)
            if not circle:
                return 1
            print(f"  ✓ Created circle: {circle.get('name')} (ID: {circle.get('id')})")
        
        circle_id = circle.get("id")
        
        # Step 4: Register device
        print("\nStep 4: Registering edge device...")
        result = await register_device(
            session, args.server, token,
            circle_id, device_key, args.device_name
        )
        
        if result and result.get("id"):
            print(f"  ✓ Device registered!")
            print(f"    Device ID: {result.get('id')}")
            print(f"    Circle ID: {result.get('circleId')}")
            print(f"    Status: {result.get('effectiveStatus', 'UNKNOWN')}")
        else:
            print(f"  ⚠ Registration response: {result}")
        
        # Step 5: Verify heartbeat works
        print("\nStep 5: Testing heartbeat...")
        if await verify_heartbeat(session, args.server, device_key):
            print("  ✓ Heartbeat successful!")
        else:
            print("  ✗ Heartbeat failed")
            return 1
        
        # Summary
        print("\n" + "=" * 60)
        print("✓ REGISTRATION COMPLETE")
        print("=" * 60)
        print(f"Device Key: {device_key}")
        print(f"Circle ID:  {circle_id}")
        print()
        print("You can now run the sync service:")
        print(f"  python run_sync_v2.py --server {args.server}")
        
    return 0


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
