#!/usr/bin/env python3
"""
Step 2: 测试 CameraDetector 集成

独立测试 CameraDetector，验证 YOLO 检测 + 威慑是否联动

用法:
    python test_detector_step2.py 10.0.0.155 admin YOUR_PASSWORD
"""

import asyncio
import sys
import logging

# 设置日志级别
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s',
    datefmt='%H:%M:%S'
)

async def main():
    if len(sys.argv) < 4:
        print("用法: python test_detector_step2.py <ip> <user> <password> [mode]")
        print("  mode: away (默认), home, disarmed")
        return
    
    ip, user, password = sys.argv[1:4]
    house_mode = sys.argv[4] if len(sys.argv) > 4 else "away"
    
    print("=" * 60)
    print("Step 2: CameraDetector 集成测试")
    print("=" * 60)
    print(f"  IP: {ip}")
    print(f"  House Mode: {house_mode}")
    print("=" * 60)
    
    # 导入模块
    try:
        from ng_edge.hardware.camera_detection_service import (
            CameraDetector,
            CameraDetectionConfig,
            CAMERA_PRESETS,
        )
        print("[1] ✅ 模块导入成功")
    except ImportError as e:
        print(f"[1] ❌ 模块导入失败: {e}")
        return
    
    # 加载 YOLO
    try:
        from ultralytics import YOLO
        print("[2] 加载 YOLO 模型...")
        model = YOLO("yolo11s.pt")
        print("[2] ✅ YOLO 模型加载成功")
    except Exception as e:
        print(f"[2] ❌ YOLO 加载失败: {e}")
        return
    
    # 创建配置
    preset = CAMERA_PRESETS["backdoor"]
    config = CameraDetectionConfig(
        name="test_camera",
        ip=ip,
        user=user,
        password=password,
        stream_path=preset.get("stream_path", "h264Preview_01_sub"),
        zone_mode=preset.get("zone_mode", "horizontal"),
        direction=preset.get("direction", "bottom_to_top"),
        zones=preset.get("zones"),
        deterrent=preset.get("deterrent"),
    )
    print(f"[3] 配置: zone_mode={config.zone_mode}, zones={config.zones}")
    
    # 创建检测器
    detector = CameraDetector(config, model, house_mode)
    
    # 设置回调
    def on_pre_change(camera_name: str, pre_level: int, zone: str):
        print(f"[CALLBACK] PRE 变化: {camera_name} → L{pre_level} ({zone})")
    
    detector.set_on_pre_change(on_pre_change)
    
    # 启动
    print("[4] 启动检测器...")
    try:
        if await detector.start():
            print("[4] ✅ 检测器启动成功")
            
            # 检查组件状态
            print(f"  - capture: {'✅' if detector.capture else '❌'}")
            print(f"  - reolink: {'✅' if detector.reolink else '❌'}")
            print(f"  - deterrent: {'✅' if detector.deterrent else '❌'}")
            print(f"  - house_mode: {detector.house_mode}")
            
            if detector.deterrent:
                print(f"  - deterrent.house_mode: {detector.deterrent.house_mode}")
                print(f"  - deterrent.active: {detector.deterrent.active}")
        else:
            print("[4] ❌ 检测器启动失败")
            return
    except Exception as e:
        print(f"[4] ❌ 启动异常: {e}")
        import traceback
        traceback.print_exc()
        return
    
    # 运行检测循环
    print("\n[5] 开始检测循环 (30秒)...")
    print("    请在摄像头前走动测试...")
    print("-" * 60)
    
    try:
        for i in range(300):  # 30秒 * 10fps
            await detector.process_frame()
            await asyncio.sleep(0.1)
            
            # 每 5 秒打印状态
            if i > 0 and i % 50 == 0:
                print(f"  [{i//10}s] person_active={detector.person_active}, "
                      f"level={detector.current_level}, zone={detector.current_zone}")
    
    except KeyboardInterrupt:
        print("\n用户中断")
    
    finally:
        print("-" * 60)
        print("[6] 停止检测器...")
        await detector.stop()
        print("[6] ✅ 已停止")
    
    print("\n" + "=" * 60)
    print("测试完成")
    print("=" * 60)


if __name__ == "__main__":
    asyncio.run(main())
