#!/usr/bin/env python3
"""
Zigbee信号路由器

职责：
1. 监听所有Zigbee设备的MQTT消息
2. 通过IEEE地址找到对应的Sensor
3. 将MQTT消息转换为Signal对象
4. 路由给SecurityCoordinator处理
"""

import json
import time
import threading
from typing import Dict, Callable, Optional, Any
from datetime import datetime, timezone


class ZigbeeSignalRouter:
    """
    Zigbee信号路由器
    
    使用方法:
        router = ZigbeeSignalRouter(security_coordinator)
        router.register_sensor("sensor_contact_back_door", "0xb40e060fffe290c7")
        router.start()
    """
    
    def __init__(self, security_coordinator=None):
        """
        初始化路由器
        
        Args:
            security_coordinator: SecurityCoordinator实例（可选，测试时可为None）
        """
        self.security_coordinator = security_coordinator
        
        # IEEE地址 → Sensor信息的映射
        # Key: IEEE地址 (例如 "0xb40e060fffe290c7")
        # Value: {"sensor_id": "xxx", "sensor_type": "contact", "entry_point_id": "ep_back_door", ...}
        self.ieee_to_sensor: Dict[str, Dict[str, Any]] = {}
        
        # Friendly Name → Sensor信息的映射（用于MQTT路由）
        # Key: 设备友好名称 (例如 "Back Door Contact")
        # Value: 同上
        self.name_to_sensor: Dict[str, Dict[str, Any]] = {}
        
        # 统计信息
        self.stats = {
            "messages_received": 0,
            "signals_routed": 0,
            "unknown_devices": 0,
            "errors": 0
        }
        
        self.mqtt_client = None
        self.is_running = False
        
        # 回调函数（用于测试）
        self.on_signal_callback: Optional[Callable] = None
    
    def register_sensor(
        self,
        sensor_id: str,
        ieee_address: str,
        friendly_name: str,
        sensor_type: str,
        entry_point_id: str = "_global",
        zone_type: str = "exterior",
        **kwargs
    ):
        """
        注册sensor的IEEE地址映射
        
        Args:
            sensor_id: Sensor ID，例如 "sensor_contact_back_door"
            ieee_address: IEEE地址，例如 "0xb40e060fffe290c7"
            friendly_name: 设备友好名称，例如 "Back Door Contact"
            sensor_type: Sensor类型，例如 "contact", "motion"
            entry_point_id: Entry Point ID
            zone_type: Zone类型，例如 "exterior", "entry_exit", "interior"
        """
        # 清理IEEE地址格式
        ieee_clean = ieee_address.lower().strip()
        if not ieee_clean.startswith('0x'):
            ieee_clean = f"0x{ieee_clean}"
        
        sensor_info = {
            "sensor_id": sensor_id,
            "sensor_type": sensor_type,
            "friendly_name": friendly_name,
            "ieee_address": ieee_clean,
            "entry_point_id": entry_point_id,
            "zone_type": zone_type,
            **kwargs
        }
        
        # 同时注册两个映射
        self.ieee_to_sensor[ieee_clean] = sensor_info
        self.name_to_sensor[friendly_name] = sensor_info
        
        print(f"[Router] 📝 注册: {friendly_name} ({ieee_clean}) → {sensor_id} ({sensor_type})")
    
    def start(self, mqtt_host: str = "localhost", mqtt_port: int = 1883):
        """启动MQTT监听"""
        try:
            import paho.mqtt.client as mqtt
        except ImportError:
            print("[Router] ❌ paho-mqtt未安装，请运行: pip install paho-mqtt")
            return False
        
        def on_connect(client, userdata, flags, rc):
            if rc == 0:
                print(f"[Router] ✅ 已连接到MQTT {mqtt_host}:{mqtt_port}")
                # 订阅所有Zigbee设备消息
                client.subscribe("zigbee2mqtt/#")
                print(f"[Router] 📡 订阅: zigbee2mqtt/#")
                self.is_running = True
            else:
                print(f"[Router] ❌ MQTT连接失败: {rc}")
        
        def on_message(client, userdata, msg):
            try:
                # 跳过bridge消息
                if "bridge" in msg.topic:
                    return
                
                self.stats["messages_received"] += 1
                
                # 解析消息
                payload = json.loads(msg.payload)
                
                # 从payload中提取IEEE地址（如果有）
                # 注意：并非所有消息都包含ieee_address
                # 我们通过topic name来识别设备
                
                # 从topic提取设备名称
                # 例如: "zigbee2mqtt/Back Door Contact" → "Back Door Contact"
                parts = msg.topic.split('/')
                if len(parts) < 2:
                    return
                
                device_name = parts[1]
                
                # 查找对应的sensor（通过设备名称）
                sensor_info = self.name_to_sensor.get(device_name)
                
                if not sensor_info:
                    # 未注册的设备，跳过
                    self.stats["unknown_devices"] += 1
                    return
                
                # 处理消息并路由
                self._process_and_route(sensor_info, payload)
                
            except Exception as e:
                self.stats["errors"] += 1
                print(f"[Router] ❌ 消息处理错误: {e}")
        
        self.mqtt_client = mqtt.Client(
            client_id="ng_edge_signal_router",
            callback_api_version=mqtt.CallbackAPIVersion.VERSION1
        )
        self.mqtt_client.on_connect = on_connect
        self.mqtt_client.on_message = on_message
        
        try:
            print(f"[Router] 连接到 {mqtt_host}:{mqtt_port}...")
            self.mqtt_client.connect(mqtt_host, mqtt_port, 60)
            
            # 在后台线程运行
            def run_loop():
                self.mqtt_client.loop_forever()
            
            thread = threading.Thread(target=run_loop, daemon=True)
            thread.start()
            
            print("[Router] 🚀 信号路由器已启动")
            return True
            
        except Exception as e:
            print(f"[Router] ❌ 启动失败: {e}")
            return False
    
    def _process_and_route(self, sensor_info: Dict[str, Any], payload: Dict[str, Any]):
        """
        处理MQTT消息并路由信号
        
        Args:
            sensor_info: Sensor信息（包含sensor_id, sensor_type等）
            payload: MQTT消息payload
        """
        sensor_id = sensor_info["sensor_id"]
        sensor_type = sensor_info["sensor_type"]
        
        # 根据sensor类型解析payload并生成signal
        signal_type = None
        signal_data = {}
        
        if sensor_type == "contact":
            # Contact传感器
            # payload: {"contact": false, "battery": 100, "linkquality": 150}
            contact = payload.get('contact')
            
            if contact is False:  # 门/窗打开
                signal_type = "DOOR_OPEN"
                signal_data = {"contact": False}
            elif contact is True:  # 门/窗关闭
                signal_type = "DOOR_CLOSE"
                signal_data = {"contact": True}
        
        elif sensor_type == "motion":
            # Motion传感器
            # payload: {"occupancy": true, "battery": 100, "illuminance": 25}
            occupancy = payload.get('occupancy')
            
            if occupancy:
                signal_type = "MOTION_ACTIVE"
                signal_data = {
                    "occupancy": True,
                    "illuminance": payload.get('illuminance')
                }
        
        elif sensor_type == "glass_break":
            # Vibration传感器
            vibration = payload.get('vibration')
            
            if vibration:
                signal_type = "GLASS_BREAK"
                signal_data = {"vibration": True}
        
        if not signal_type:
            # 没有需要处理的信号（例如只是电池状态更新）
            return
        
        # 提取通用信息
        signal_data.update({
            "battery": payload.get('battery'),
            "linkquality": payload.get('linkquality'),
            "timestamp": datetime.now(timezone.utc).isoformat()
        })
        
        print(f"[Router] 📡 收到信号: {sensor_id} → {signal_type}")
        print(f"[Router]    数据: {signal_data}")
        
        self.stats["signals_routed"] += 1
        
        # 调用回调（用于测试）
        if self.on_signal_callback:
            self.on_signal_callback(sensor_info, signal_type, signal_data)
        
        # 路由给SecurityCoordinator（如果有）
        if self.security_coordinator:
            self._route_to_coordinator(sensor_info, signal_type, signal_data)
    
    def _route_to_coordinator(
        self,
        sensor_info: Dict[str, Any],
        signal_type: str,
        signal_data: Dict[str, Any]
    ):
        """
        将信号路由给SecurityCoordinator
        
        这里需要将signal_type转换为StateMachine的Signal对象
        """
        try:
            # 导入StateMachine的Signal类型
            # 注意：这个导入路径需要根据实际情况调整
            from ng_edge.services.state_machine_v5 import (
                Signal as SMSignal,
                SignalType as SMSignalType,
                ZoneType as SMZoneType
            )
            
            # 映射signal_type
            signal_type_map = {
                "DOOR_OPEN": SMSignalType.DOOR_OPEN,
                "DOOR_CLOSE": SMSignalType.DOOR_CLOSE,
                "MOTION_ACTIVE": SMSignalType.MOTION_ACTIVE,
                "GLASS_BREAK": SMSignalType.GLASS_BREAK,
            }
            
            sm_signal_type = signal_type_map.get(signal_type)
            if not sm_signal_type:
                print(f"[Router] ⚠️  未知的signal类型: {signal_type}")
                return
            
            # 映射zone_type
            zone_type_map = {
                "exterior": SMZoneType.EXTERIOR,
                "entry_exit": SMZoneType.ENTRY_EXIT,
                "interior": SMZoneType.INTERIOR,
                "perimeter": SMZoneType.PERIMETER,
            }
            
            sm_zone_type = zone_type_map.get(
                sensor_info.get("zone_type", "exterior"),
                SMZoneType.EXTERIOR
            )
            
            # 创建Signal对象
            signal = SMSignal(
                entry_point_id=sensor_info.get("entry_point_id", "_global"),
                zone_type=sm_zone_type,
                signal_type=sm_signal_type,
                from_inside=False  # TODO: 方向推断
            )
            
            # 发送给SecurityCoordinator
            result = self.security_coordinator.process(signal)
            
            if result:
                print(f"[Router] ✅ 状态转换: {result.from_state.value} → {result.to_state.value}")
                print(f"[Router]    原因: {result.reason}")
            else:
                print(f"[Router] ℹ️  无状态转换")
            
        except ImportError as e:
            print(f"[Router] ⚠️  无法导入StateMachine: {e}")
        except Exception as e:
            print(f"[Router] ❌ 路由错误: {e}")
    
    def stop(self):
        """停止MQTT监听"""
        if self.mqtt_client:
            self.mqtt_client.disconnect()
            self.is_running = False
            print("[Router] 🛑 信号路由器已停止")
    
    def get_stats(self) -> Dict[str, int]:
        """获取统计信息"""
        return self.stats.copy()


def test_router():
    """测试信号路由器"""
    print("=" * 70)
    print("  Zigbee信号路由器测试")
    print("=" * 70)
    
    # 创建路由器（不连接SecurityCoordinator，只测试接收）
    router = ZigbeeSignalRouter()
    
    # 注册测试设备
    print("\n注册测试设备...")
    
    router.register_sensor(
        sensor_id="sensor_contact_back_door",
        ieee_address="0xb40e060fffe290c7",
        friendly_name="Back Door Contact",
        sensor_type="contact",
        entry_point_id="ep_back_door",
        zone_type="entry_exit"
    )
    
    router.register_sensor(
        sensor_id="sensor_motion_back_door",
        ieee_address="0x54ef4410014105aa",
        friendly_name="Back Door Motion",
        sensor_type="motion",
        entry_point_id="ep_back_door",
        zone_type="interior"
    )
    
    # 设置回调查看收到的信号
    def on_signal(sensor_info, signal_type, signal_data):
        print("\n" + "=" * 70)
        print("🎯 信号回调被触发!")
        print(f"  Sensor: {sensor_info['sensor_id']}")
        print(f"  Signal: {signal_type}")
        print(f"  Data: {json.dumps(signal_data, indent=2, ensure_ascii=False)}")
        print("=" * 70)
    
    router.on_signal_callback = on_signal
    
    # 启动路由器
    print("\n启动路由器...")
    if router.start():
        print("\n✅ 路由器已启动，监听中...")
        print("\n请触发你的Zigbee设备（开关门、走过motion传感器）")
        print("观察是否能捕获信号\n")
        print("监听30秒...\n")
        
        try:
            time.sleep(30)
        except KeyboardInterrupt:
            print("\n\n中断")
        
        # 显示统计
        stats = router.get_stats()
        print("\n" + "=" * 70)
        print("统计信息:")
        print(f"  收到消息: {stats['messages_received']}")
        print(f"  路由信号: {stats['signals_routed']}")
        print(f"  未知设备: {stats['unknown_devices']}")
        print(f"  错误: {stats['errors']}")
        print("=" * 70)
        
        router.stop()
    else:
        print("\n❌ 路由器启动失败")


if __name__ == "__main__":
    test_router()
