"""NG Edge API - PRD v7.4.2"""

from .manager import app, AppState, state

__all__ = ['app', 'AppState', 'state']
