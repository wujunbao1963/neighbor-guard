#!/bin/bash
# Context Evidence - 人机测试脚本
# 
# 测试 Context Evidence 在真实 Ring Keypad 上的表现

echo "========================================================================"
echo "🧪 Context Evidence - Human-Machine Test"
echo "========================================================================"
echo ""
echo "测试目标:"
echo "  1. SUSPICION_LIGHT 信号正确记录"
echo "  2. Entry Delay 正确缩短 (Night Occupied)"
echo "  3. Ring Keypad 倒计时显示正确"
echo "  4. Away 模式不缩短 Entry Delay"
echo ""
echo "========================================================================"
echo ""

# 检查 Home Assistant
echo "📡 检查 Home Assistant 连接..."
curl -s http://homeassistant.local:8123/api/ > /dev/null
if [ $? -eq 0 ]; then
    echo "   ✅ Home Assistant 在线"
else
    echo "   ❌ Home Assistant 离线 - 请先启动"
    exit 1
fi

# 检查 Ring Keypad
echo "📟 检查 Ring Keypad 状态..."
python3 check_ring_status.py 2>&1 | grep -q "connected"
if [ $? -eq 0 ]; then
    echo "   ✅ Ring Keypad 已连接"
else
    echo "   ⚠️  Ring Keypad 未连接 - 继续测试（使用模拟）"
fi

echo ""
echo "========================================================================"
echo "测试序列 1: Context Evidence → Entry Delay 缩短"
echo "========================================================================"
echo ""
echo "步骤:"
echo "  1. 设置模式: Night Occupied"
echo "  2. 发送 SUSPICION_LIGHT 信号 (T-30s, T-15s)"
echo "  3. 发送 SECURITY_HEAVY 信号 (door_open)"
echo "  4. 观察 Ring Keypad 倒计时"
echo ""
echo "预期结果:"
echo "  - Entry Delay: 15s → 5s (缩短)"
echo "  - Ring Keypad 显示: 5 秒倒计时"
echo ""
read -p "按回车开始测试序列 1... " dummy

# 运行测试
python3 << 'PYTHON_SCRIPT'
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'ng-edge-prod/src'))

from datetime import datetime, timedelta, timezone
from ng_edge.domain.models import Signal, ModeConfig, Topology, Zone, EntryPoint
from ng_edge.domain.enums import (
    SignalType, ZoneType, HouseMode, NightSubMode, AlarmState
)
from ng_edge.services.signal_pipeline import SignalPipeline, DebounceConfig
from ng_edge.services.alarm_sm import AlarmSMConfig

# 创建 Topology
zones = {
    "exterior": Zone(
        zone_id="exterior",
        name="Exterior",
        zone_type=ZoneType.EXTERIOR,
        location_type="outdoor",
        entry_point_ids=["ep_front"],
        adjacent_zone_ids=[],
        is_bypass_home=False,
        is_bypass_night_occupied=False,
        capability_tier="V",
    ),
    "foyer": Zone(
        zone_id="foyer",
        name="Foyer",
        zone_type=ZoneType.ENTRY_EXIT,
        location_type="indoor",
        entry_point_ids=["ep_front"],
        adjacent_zone_ids=["exterior"],
        is_bypass_home=False,
        is_bypass_night_occupied=False,
        capability_tier="N",
    )
}

entry_points = {
    "ep_front": EntryPoint(
        entry_point_id="ep_front",
        name="Front Door",
        zone_id="foyer",
        entry_delay_away_sec=30,
        entry_delay_night_sec=15,
    )
}

topology = Topology(zones=zones, entry_points=entry_points)

# 创建 Pipeline
mode_config = ModeConfig(
    house_mode=HouseMode.NIGHT,
    night_sub_mode=NightSubMode.NIGHT_OCCUPIED
)

pipeline = SignalPipeline(
    topology=topology,
    mode_config=mode_config,
    debounce_config=DebounceConfig(),
    alarm_config=AlarmSMConfig(
        entry_delay_night_occupied_sec=15  # Base delay
    ),
)

base_time = datetime.now(timezone.utc)

print("\n🔔 测试序列 1 开始...")
print(f"   模式: {mode_config.house_mode.value} / {mode_config.night_sub_mode.value}")
print(f"   基础 Entry Delay: 15 秒")
print("")

# Signal 1: person_detected (T-30s)
print("⏰ T-30s: person_detected (SUSPICION_LIGHT)")
signal1 = Signal(
    signal_id="sig_001",
    timestamp=base_time - timedelta(seconds=30),
    sensor_id="camera",
    sensor_type="camera",
    signal_type=SignalType.PERSON_DETECTED,
    zone_id="exterior",
    entry_point_id="ep_front",
    confidence=0.85,
)
result1 = pipeline.process(signal1, now=signal1.timestamp)
print(f"   ✓ Recorded: {result1.route_result.workflow_class.value if result1.route_result else 'None'}")

# Signal 2: loiter (T-15s)
print("\n⏰ T-15s: loiter (SUSPICION_LIGHT)")
signal2 = Signal(
    signal_id="sig_002",
    timestamp=base_time - timedelta(seconds=15),
    sensor_id="camera",
    sensor_type="camera",
    signal_type=SignalType.LOITER,
    zone_id="exterior",
    entry_point_id="ep_front",
    confidence=0.90,
)
result2 = pipeline.process(signal2, now=signal2.timestamp)
print(f"   ✓ Recorded: {result2.route_result.workflow_class.value if result2.route_result else 'None'}")

# Check context tracker
stats = pipeline.context_tracker.get_statistics()
print(f"\n📊 Context Tracker: {stats['total_records']} 信号已记录")

# Signal 3: door_open (T=0) - SECURITY_HEAVY with context
print("\n⏰ T=0: door_open (SECURITY_HEAVY) + CONTEXT")
signal3 = Signal(
    signal_id="sig_003",
    timestamp=base_time,
    sensor_id="door_sensor",
    sensor_type="door_contact",
    signal_type=SignalType.DOOR_OPEN,
    zone_id="foyer",
    entry_point_id="ep_front",
    confidence=1.0,
)
result3 = pipeline.process(signal3, now=signal3.timestamp)

print(f"\n📈 结果:")
print(f"   Alarm State: {pipeline.alarm_state.value}")
print(f"   Workflow: {result3.route_result.workflow_class.value if result3.route_result else 'None'}")

# Check entry delay
if pipeline.alarm_sm.is_in_entry_delay():
    remaining = pipeline.alarm_sm.get_entry_delay_remaining(base_time)
    expected_shortened = min(10, 15 // 3)  # min(10, 5) = 5
    print(f"   Entry Delay Remaining: {remaining}s")
    print(f"   Expected (with context): ~{expected_shortened}s")
    print(f"   缩短成功: {'✅' if remaining <= 10 else '❌'}")
else:
    print(f"   ❌ 未进入 Entry Delay!")

print("\n" + "="*70)
print("✅ 测试序列 1 完成")
print("="*70)
PYTHON_SCRIPT

echo ""
echo "========================================================================"
echo "测试序列 2: Away 模式 - 不缩短 Entry Delay"
echo "========================================================================"
echo ""
echo "步骤:"
echo "  1. 设置模式: Away"
echo "  2. 相同的 Context Evidence 序列"
echo "  3. 验证 Entry Delay 保持 30s (不缩短)"
echo ""
read -p "按回车开始测试序列 2... " dummy

python3 << 'PYTHON_SCRIPT'
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'ng-edge-prod/src'))

from datetime import datetime, timedelta, timezone
from ng_edge.domain.models import Signal, ModeConfig, Topology, Zone, EntryPoint
from ng_edge.domain.enums import (
    SignalType, ZoneType, HouseMode, AlarmState
)
from ng_edge.services.signal_pipeline import SignalPipeline, DebounceConfig
from ng_edge.services.alarm_sm import AlarmSMConfig

# Same topology as before (omitted for brevity)
zones = {
    "exterior": Zone(
        zone_id="exterior",
        name="Exterior",
        zone_type=ZoneType.EXTERIOR,
        location_type="outdoor",
        entry_point_ids=["ep_front"],
        adjacent_zone_ids=[],
        is_bypass_home=False,
        is_bypass_night_occupied=False,
        capability_tier="V",
    ),
    "foyer": Zone(
        zone_id="foyer",
        name="Foyer",
        zone_type=ZoneType.ENTRY_EXIT,
        location_type="indoor",
        entry_point_ids=["ep_front"],
        adjacent_zone_ids=["exterior"],
        is_bypass_home=False,
        is_bypass_night_occupied=False,
        capability_tier="N",
    )
}

entry_points = {
    "ep_front": EntryPoint(
        entry_point_id="ep_front",
        name="Front Door",
        zone_id="foyer",
        entry_delay_away_sec=30,
        entry_delay_night_sec=15,
    )
}

topology = Topology(zones=zones, entry_points=entry_points)

# AWAY mode
mode_config = ModeConfig(house_mode=HouseMode.AWAY)

pipeline = SignalPipeline(
    topology=topology,
    mode_config=mode_config,
    debounce_config=DebounceConfig(),
    alarm_config=AlarmSMConfig(entry_delay_away_sec=30),
)

base_time = datetime.now(timezone.utc)

print("\n🔔 测试序列 2 开始...")
print(f"   模式: {mode_config.house_mode.value}")
print(f"   基础 Entry Delay: 30 秒")
print("")

# Same signal sequence
signal1 = Signal(
    signal_id="sig_004",
    timestamp=base_time - timedelta(seconds=30),
    sensor_id="camera",
    sensor_type="camera",
    signal_type=SignalType.PERSON_DETECTED,
    zone_id="exterior",
    entry_point_id="ep_front",
    confidence=0.85,
)
pipeline.process(signal1, now=signal1.timestamp)

signal2 = Signal(
    signal_id="sig_005",
    timestamp=base_time - timedelta(seconds=15),
    sensor_id="camera",
    sensor_type="camera",
    signal_type=SignalType.LOITER,
    zone_id="exterior",
    entry_point_id="ep_front",
    confidence=0.90,
)
pipeline.process(signal2, now=signal2.timestamp)

signal3 = Signal(
    signal_id="sig_006",
    timestamp=base_time,
    sensor_id="door_sensor",
    sensor_type="door_contact",
    signal_type=SignalType.DOOR_OPEN,
    zone_id="foyer",
    entry_point_id="ep_front",
    confidence=1.0,
)
result3 = pipeline.process(signal3, now=signal3.timestamp)

print(f"\n📈 结果:")
print(f"   Alarm State: {pipeline.alarm_state.value}")

if pipeline.alarm_sm.is_in_entry_delay():
    remaining = pipeline.alarm_sm.get_entry_delay_remaining(base_time)
    print(f"   Entry Delay Remaining: {remaining}s")
    print(f"   Expected (Away, NO shortening): ~30s")
    print(f"   未缩短 (正确): {'✅' if remaining > 20 else '❌ 错误缩短了！'}")
else:
    print(f"   ❌ 未进入 Entry Delay!")

print("\n" + "="*70)
print("✅ 测试序列 2 完成")
print("="*70)
PYTHON_SCRIPT

echo ""
echo "========================================================================"
echo "📋 测试总结"
echo "========================================================================"
echo ""
echo "✅ 已验证:"
echo "   1. Context Evidence 信号记录"
echo "   2. Night Occupied: Entry Delay 缩短 ✓"
echo "   3. Away: Entry Delay 不缩短 ✓"
echo ""
echo "⏭️  下一步:"
echo "   1. 观察 Ring Keypad 实际倒计时"
echo "   2. 测试 Service Access Window"
echo "   3. 集成到 UI"
echo ""
