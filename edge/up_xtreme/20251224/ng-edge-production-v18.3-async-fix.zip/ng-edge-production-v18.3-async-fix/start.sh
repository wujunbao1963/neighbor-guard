#!/bin/bash

# NG Edge Manager Enhanced - 启动脚本（含Zigbee自动启动）

cd "$(dirname "$0")/src"

echo "======================================================================"
echo "🛡️  NG Edge Manager Enhanced"
echo "======================================================================"
echo ""
echo "✅ 双模式输入支持:"
echo "   ✋ 手动模式 - 快速测试和演示"
echo "   📹 摄像头模式 - 实时 YOLO 检测"
echo "   📡 Zigbee模式 - 物理传感器集成"
echo ""
echo "🌐 访问 UI:       http://localhost:8000"
echo "📖 访问 API 文档: http://localhost:8000/docs"
echo ""
echo "按 Ctrl+C 停止服务器"
echo ""
echo "======================================================================"
echo ""

# 后台启动Zigbee自动启动脚本
(
    sleep 5  # 等待NG Edge完全启动
    
    echo ""
    echo "[Config] 正在加载标准配置..."
    curl -s -X POST http://localhost:8000/api/load-standard-config > /dev/null 2>&1
    
    echo "[Config] 正在设置AWAY模式..."
    curl -s -X POST http://localhost:8000/api/pipeline/mode \
      -H "Content-Type: application/json" \
      -d '{"mode": "away"}' > /dev/null 2>&1
    
    sleep 1  # 等待配置加载完成
    
    echo "[Zigbee] 正在启动Zigbee MQTT客户端..."
    
    curl -s -X POST http://localhost:8000/api/zigbee/start \
      -H "Content-Type: application/json" \
      -d '{
        "mqtt_host": "localhost",
        "mqtt_port": 1883,
        "devices": [
          {
            "friendly_name": "Back Door Contact",
            "sensor_id": "sensor_door_back",
            "sensor_type": "door_contact",
            "zone_id": "zone_back_door",
            "device_type": "contact"
          },
          {
            "friendly_name": "Family Room Motion",
            "sensor_id": "sensor_pir_living",
            "sensor_type": "motion_pir",
            "zone_id": "zone_living_room",
            "device_type": "motion"
          }
        ]
      }' > /tmp/zigbee_start.log 2>&1
    
    if grep -q "started" /tmp/zigbee_start.log; then
        echo "[Zigbee] ✅ Zigbee客户端启动成功"
    else
        echo "[Zigbee] ⚠️  Zigbee客户端启动失败，请检查MQTT服务"
        echo "[Zigbee] 日志: /tmp/zigbee_start.log"
    fi
) &

# 启动主服务器
uvicorn ng_edge.api.manager:app --reload --host 0.0.0.0 --port 8000
