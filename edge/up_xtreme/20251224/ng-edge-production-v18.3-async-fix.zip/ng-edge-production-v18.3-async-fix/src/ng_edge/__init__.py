"""NG Edge - NeighborGuard Edge Security System v7.4.2"""

__version__ = "7.4.2"
