"""
Tests for Cloud Client

Run with: pytest test_cloud_client.py -v
"""

import pytest
import asyncio
import json
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch
import tempfile
import os

# Import cloud modules
import sys
sys.path.insert(0, str(Path(__file__).parent.parent))

from ng_edge.cloud.config import CloudConfig, DeviceCredentials
from ng_edge.cloud.client import CloudClient, CloudResponse


class TestDeviceCredentials:
    """Test DeviceCredentials dataclass."""
    
    def test_to_dict(self):
        creds = DeviceCredentials(
            device_id="dev-123",
            device_key="secret-key",
            circle_id="circle-456",
            paired_at="2025-01-01T00:00:00Z",
            device_name="Test Device",
        )
        
        d = creds.to_dict()
        
        assert d["device_id"] == "dev-123"
        assert d["device_key"] == "secret-key"
        assert d["circle_id"] == "circle-456"
        assert d["paired_at"] == "2025-01-01T00:00:00Z"
        assert d["device_name"] == "Test Device"
    
    def test_from_dict(self):
        data = {
            "device_id": "dev-123",
            "device_key": "secret-key",
            "circle_id": "circle-456",
            "paired_at": "2025-01-01T00:00:00Z",
            "device_name": "Test Device",
        }
        
        creds = DeviceCredentials.from_dict(data)
        
        assert creds.device_id == "dev-123"
        assert creds.device_key == "secret-key"
        assert creds.circle_id == "circle-456"


class TestCloudConfig:
    """Test CloudConfig."""
    
    def test_default_values(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            config = CloudConfig(config_dir=tmpdir)
            
            assert config.server_url == "http://localhost:3000"
            assert config.timeout_sec == 10
            assert config.is_registered is False
    
    def test_auth_headers(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            config = CloudConfig(config_dir=tmpdir)
            
            # No token set
            assert config.user_auth_header is None
            assert config.device_auth_header is None
            
            # Set user token
            config.user_token = "my-jwt-token"
            assert config.user_auth_header == "Bearer my-jwt-token"
            
            # Set credentials
            config.credentials = DeviceCredentials(
                device_id="dev-1",
                device_key="device-secret",
                circle_id="circle-1",
                paired_at="2025-01-01T00:00:00Z",
            )
            assert config.device_auth_header == "Device device-secret"
            assert config.is_registered is True
    
    def test_save_and_load_credentials(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            config = CloudConfig(config_dir=tmpdir)
            
            # Save credentials
            config.credentials = DeviceCredentials(
                device_id="dev-123",
                device_key="secret-key",
                circle_id="circle-456",
                paired_at="2025-01-01T00:00:00Z",
                device_name="Test Device",
            )
            
            assert config.save_credentials() is True
            assert config.credentials_path.exists()
            
            # Load in new config instance
            config2 = CloudConfig(config_dir=tmpdir)
            assert config2.is_registered is False
            
            assert config2.load_credentials() is True
            assert config2.is_registered is True
            assert config2.credentials.device_id == "dev-123"
            assert config2.credentials.device_key == "secret-key"
    
    def test_clear_credentials(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            config = CloudConfig(config_dir=tmpdir)
            config.credentials = DeviceCredentials(
                device_id="dev-1",
                device_key="key",
                circle_id="circle-1",
                paired_at="2025-01-01T00:00:00Z",
            )
            config.save_credentials()
            
            assert config.credentials_path.exists()
            
            config.clear_credentials()
            
            assert config.credentials is None
            assert not config.credentials_path.exists()


class TestCloudResponse:
    """Test CloudResponse."""
    
    def test_success_response(self):
        resp = CloudResponse(
            success=True,
            status_code=201,
            data={"deviceId": "123"},
        )
        
        assert resp.success is True
        assert resp.is_retryable is False
    
    def test_retryable_errors(self):
        # 408 Timeout - retryable
        resp = CloudResponse(success=False, status_code=408, error_code="TIMEOUT")
        assert resp.is_retryable is True
        
        # 429 Rate limited - retryable
        resp = CloudResponse(success=False, status_code=429, error_code="RATE_LIMITED")
        assert resp.is_retryable is True
        
        # 503 Service unavailable - retryable
        resp = CloudResponse(success=False, status_code=503, error_code="SERVICE_UNAVAILABLE")
        assert resp.is_retryable is True
        
        # 401 Unauthorized - not retryable
        resp = CloudResponse(success=False, status_code=401, error_code="AUTH_INVALID")
        assert resp.is_retryable is False
        
        # 422 Validation error - not retryable
        resp = CloudResponse(success=False, status_code=422, error_code="VALIDATION_ERROR")
        assert resp.is_retryable is False


class TestCloudClient:
    """Test CloudClient."""
    
    @pytest.fixture
    def config(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            yield CloudConfig(
                server_url="http://test-server:3000",
                config_dir=tmpdir,
            )
    
    def test_build_url(self, config):
        client = CloudClient(config)
        
        assert client._build_url("/health") == "http://test-server:3000/health"
        assert client._build_url("/api/circles/123/events") == "http://test-server:3000/api/circles/123/events"
    
    def test_get_status_not_registered(self, config):
        client = CloudClient(config)
        
        status = client.get_status()
        
        assert status["server_url"] == "http://test-server:3000"
        assert status["is_registered"] is False
        assert status["device_id"] is None
    
    def test_get_status_registered(self, config):
        config.credentials = DeviceCredentials(
            device_id="dev-123",
            device_key="key",
            circle_id="circle-456",
            paired_at="2025-01-01T00:00:00Z",
        )
        client = CloudClient(config)
        
        status = client.get_status()
        
        assert status["is_registered"] is True
        assert status["device_id"] == "dev-123"
        assert status["circle_id"] == "circle-456"


class TestCloudClientAsync:
    """Async tests for CloudClient."""
    
    @pytest.fixture
    def config(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            yield CloudConfig(
                server_url="http://test-server:3000",
                config_dir=tmpdir,
                user_token="test-jwt-token",
            )
    
    @pytest.fixture
    def registered_config(self):
        """Config with device credentials already set."""
        with tempfile.TemporaryDirectory() as tmpdir:
            config = CloudConfig(
                server_url="http://test-server:3000",
                config_dir=tmpdir,
            )
            config.credentials = DeviceCredentials(
                device_id="dev-123",
                device_key="test-device-key",
                circle_id="circle-456",
                paired_at="2025-01-01T00:00:00Z",
            )
            yield config
    
    @pytest.mark.asyncio
    async def test_register_device_no_token(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            config = CloudConfig(config_dir=tmpdir)  # No user_token
            client = CloudClient(config)
            
            success, creds, error = await client.register_device(circle_id="circle-123")
            
            assert success is False
            assert creds is None
            assert "token" in error.lower()
            
            await client.close()
    
    @pytest.mark.asyncio
    async def test_register_device_success(self, config):
        client = CloudClient(config)
        
        # Mock the _request method
        mock_response = CloudResponse(
            success=True,
            status_code=201,
            data={
                "deviceId": "new-device-id",
                "deviceKey": "new-device-key",
                "pairedAt": "2025-01-15T10:00:00Z",
                "capabilities": {
                    "fusion": True,
                    "evidenceUpload": True,
                    "topomap": False,
                },
            },
        )
        
        with patch.object(client, '_request', return_value=mock_response):
            success, creds, error = await client.register_device(circle_id="circle-123")
        
        assert success is True
        assert error is None
        assert creds is not None
        assert creds.device_id == "new-device-id"
        assert creds.device_key == "new-device-key"
        assert creds.circle_id == "circle-123"
        
        # Check credentials saved to config
        assert config.is_registered is True
        assert config.credentials.device_id == "new-device-id"
        
        # Check credentials file exists
        assert config.credentials_path.exists()
        
        await client.close()
    
    @pytest.mark.asyncio
    async def test_register_device_failure(self, config):
        client = CloudClient(config)
        
        mock_response = CloudResponse(
            success=False,
            status_code=401,
            error_code="AUTH_INVALID",
            error_message="Invalid token",
        )
        
        with patch.object(client, '_request', return_value=mock_response):
            success, creds, error = await client.register_device(circle_id="circle-123")
        
        assert success is False
        assert creds is None
        assert "Invalid token" in error
        
        # Config should not have credentials
        assert config.is_registered is False
        
        await client.close()
    
    @pytest.mark.asyncio
    async def test_health_check(self, config):
        client = CloudClient(config)
        
        mock_response = CloudResponse(
            success=True,
            status_code=200,
            data={"ok": True, "db": "up"},
        )
        
        with patch.object(client, '_request', return_value=mock_response):
            healthy, data, error = await client.health_check()
        
        assert healthy is True
        assert data["ok"] is True
        assert error is None
        
        await client.close()
    
    @pytest.mark.asyncio
    async def test_ingest_event_not_registered(self, config):
        """Test ingest fails when device not registered."""
        client = CloudClient(config)
        
        event = {"eventId": "123", "eventType": "motion_detected"}
        success, data, error = await client.ingest_event(event)
        
        assert success is False
        assert "not registered" in error.lower()
        
        await client.close()
    
    @pytest.mark.asyncio
    async def test_ingest_event_success(self, registered_config):
        """Test successful event ingest."""
        client = CloudClient(registered_config)
        
        mock_response = CloudResponse(
            success=True,
            status_code=201,
            data={
                "accepted": True,
                "eventId": "event-789",
                "serverReceivedAt": "2025-01-15T12:00:00Z",
                "deduped": False,
            },
        )
        
        event = {
            "eventId": "event-789",
            "occurredAt": "2025-01-15T11:59:00Z",
            "eventType": "motion_detected",
            "severity": "LOW",
            "notificationLevel": "NORMAL",
            "status": "OPEN",
            "title": "Test event",
            "explainSummary": {
                "ruleId": "TEST",
                "keySignals": [{"code": "test"}],
                "mode": "HOME",
            },
        }
        
        with patch.object(client, '_request', return_value=mock_response) as mock_req:
            success, data, error = await client.ingest_event(event)
            
            # Verify _request was called with correct auth
            call_args = mock_req.call_args
            assert call_args.kwargs["auth_header"] == "Device test-device-key"
            assert "/events/ingest" in call_args.kwargs["path"]
        
        assert success is True
        assert data["accepted"] is True
        assert data["eventId"] == "event-789"
        assert error is None
        
        await client.close()
    
    @pytest.mark.asyncio
    async def test_ingest_event_deduped(self, registered_config):
        """Test deduped event response."""
        client = CloudClient(registered_config)
        
        mock_response = CloudResponse(
            success=True,
            status_code=200,
            data={
                "accepted": True,
                "eventId": "event-789",
                "serverReceivedAt": "2025-01-15T12:00:00Z",
                "deduped": True,
            },
        )
        
        event = {"eventId": "event-789", "eventType": "motion_detected"}
        
        with patch.object(client, '_request', return_value=mock_response):
            success, data, error = await client.ingest_event(event, idempotency_key="same-key")
        
        assert success is True
        assert data["deduped"] is True
        
        await client.close()
    
    @pytest.mark.asyncio
    async def test_ingest_event_validation_error(self, registered_config):
        """Test ingest with validation error."""
        client = CloudClient(registered_config)
        
        mock_response = CloudResponse(
            success=False,
            status_code=422,
            error_code="VALIDATION_ERROR",
            error_message="eventType is required",
            data={"validationErrors": [{"path": "/eventType"}]},
        )
        
        event = {"eventId": "123"}  # Missing required fields
        
        with patch.object(client, '_request', return_value=mock_response):
            success, data, error = await client.ingest_event(event)
        
        assert success is False
        assert "eventType" in error
        
        await client.close()


class TestEventTypeMapping:
    """Test event type mapping methods."""
    
    @pytest.fixture
    def client(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            config = CloudConfig(config_dir=tmpdir)
            yield CloudClient(config)
    
    def test_map_event_type(self, client):
        assert client._map_event_type("intrusion") == "break_in_attempt"
        assert client._map_event_type("break_in") == "break_in_attempt"
        assert client._map_event_type("motion") == "motion_detected"
        assert client._map_event_type("fire") == "fire_detected"
        assert client._map_event_type("unknown_type") == "motion_detected"
    
    def test_map_severity(self, client):
        assert client._map_severity(3) == "HIGH"
        assert client._map_severity(2) == "MEDIUM"
        assert client._map_severity(1) == "LOW"
        assert client._map_severity(0) == "LOW"
    
    def test_map_notification_level(self, client):
        assert client._map_notification_level(3) == "HIGH"
        assert client._map_notification_level(2) == "HIGH"
        assert client._map_notification_level(1) == "NORMAL"
        assert client._map_notification_level(0) == "NONE"


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
