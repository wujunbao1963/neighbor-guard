"""
NG Edge Cloud Integration

Handles communication with NeighborGuard Cloud Server:
- Device registration (pairing)
- Event ingest
- Evidence upload
- Background sync (heartbeat, topology)
"""

from .config import CloudConfig, DeviceCredentials
from .client import CloudClient
from .sync_service import CloudSyncService, SyncStats

__all__ = [
    "CloudConfig",
    "DeviceCredentials", 
    "CloudClient",
    "CloudSyncService",
    "SyncStats",
]
