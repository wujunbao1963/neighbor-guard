"""
Cloud Configuration and Credentials

Handles:
- Server connection settings
- Device credentials storage/loading
- Configuration persistence
"""

from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Optional
from datetime import datetime
import json
import os


@dataclass
class DeviceCredentials:
    """Device credentials returned from registration."""
    device_id: str
    device_key: str
    circle_id: str
    paired_at: str
    device_name: str = ""
    
    def to_dict(self) -> dict:
        return asdict(self)
    
    @classmethod
    def from_dict(cls, data: dict) -> "DeviceCredentials":
        return cls(
            device_id=data["device_id"],
            device_key=data["device_key"],
            circle_id=data["circle_id"],
            paired_at=data["paired_at"],
            device_name=data.get("device_name", ""),
        )


@dataclass
class CloudConfig:
    """Cloud server configuration."""
    
    # Server settings
    server_url: str = "http://localhost:3000"
    timeout_sec: int = 10
    max_retries: int = 3
    
    # Credentials (loaded from file or set after registration)
    credentials: Optional[DeviceCredentials] = None
    
    # User token for initial registration (temporary)
    user_token: Optional[str] = None
    
    # Home Assistant instance ID (for device registration)
    ha_instance_id: str = ""
    
    # Device info
    device_name: str = "NG Edge Device"
    software_version: str = "1.1.0"
    
    # Capabilities
    capabilities: dict = field(default_factory=lambda: {
        "fusion": True,
        "evidenceUpload": True,
        "topomap": False,
    })
    
    # Persistence paths
    config_dir: str = "./config"
    credentials_file: str = "device_credentials.json"
    
    # System device key path (UP Xtreme location)
    system_device_key_path: str = "/var/lib/ng-edge/device_key"
    
    def __post_init__(self):
        """Ensure config directory exists."""
        Path(self.config_dir).mkdir(parents=True, exist_ok=True)
    
    @property
    def credentials_path(self) -> Path:
        """Full path to credentials file."""
        return Path(self.config_dir) / self.credentials_file
    
    @property
    def is_registered(self) -> bool:
        """Check if device has valid credentials."""
        return self.credentials is not None
    
    @property
    def device_auth_header(self) -> Optional[str]:
        """Get Device auth header value for API calls."""
        if self.credentials:
            return f"Device {self.credentials.device_key}"
        return None
    
    @property
    def user_auth_header(self) -> Optional[str]:
        """Get Bearer auth header value for registration."""
        if self.user_token:
            return f"Bearer {self.user_token}"
        return None
    
    def save_credentials(self) -> bool:
        """Save credentials to file."""
        if not self.credentials:
            return False
        
        try:
            with open(self.credentials_path, 'w') as f:
                json.dump(self.credentials.to_dict(), f, indent=2)
            print(f"[CLOUD] Credentials saved to {self.credentials_path}")
            return True
        except Exception as e:
            print(f"[ERROR] Failed to save credentials: {e}")
            return False
    
    def load_credentials(self) -> bool:
        """Load credentials from file."""
        if not self.credentials_path.exists():
            print(f"[CLOUD] No credentials file found at {self.credentials_path}")
            return False
        
        try:
            with open(self.credentials_path, 'r') as f:
                data = json.load(f)
            self.credentials = DeviceCredentials.from_dict(data)
            print(f"[CLOUD] Credentials loaded: device_id={self.credentials.device_id}")
            return True
        except Exception as e:
            print(f"[ERROR] Failed to load credentials: {e}")
            return False
    
    def load_system_device_key(self) -> Optional[str]:
        """
        Load device key from system path (/var/lib/ng-edge/device_key).
        
        The file contains a device key in format: NGEDGE-<uuid>
        
        Returns:
            The device key string, or None if not found
        """
        key_path = Path(self.system_device_key_path)
        
        if not key_path.exists():
            print(f"[CLOUD] System device key not found at {key_path}")
            return None
        
        try:
            device_key = key_path.read_text().strip()
            print(f"[CLOUD] Loaded system device key: {device_key[:20]}...")
            return device_key
        except Exception as e:
            print(f"[ERROR] Failed to load system device key: {e}")
            return None
    
    def load_or_create_credentials(
        self,
        circle_id: str,
        device_id: Optional[str] = None,
    ) -> bool:
        """
        Load credentials from file, or create from system device key.
        
        This is useful when:
        - Credentials file exists: load it
        - No credentials file but system device key exists: create credentials
        
        Args:
            circle_id: The circle ID to use
            device_id: Optional device ID (will generate if not provided)
            
        Returns:
            True if credentials are now available
        """
        # Try loading from credentials file first
        if self.load_credentials():
            return True
        
        # Try loading from system device key
        device_key = self.load_system_device_key()
        if device_key:
            # Extract device_id from key if it's in NGEDGE-<uuid> format
            if device_key.startswith("NGEDGE-"):
                extracted_id = device_key.replace("NGEDGE-", "")
                device_id = device_id or extracted_id
            
            self.credentials = DeviceCredentials(
                device_id=device_id or device_key,
                device_key=device_key,
                circle_id=circle_id,
                paired_at=datetime.now().isoformat(),
                device_name=self.device_name,
            )
            
            # Save for next time
            self.save_credentials()
            
            print(f"[CLOUD] Created credentials from system device key")
            print(f"[CLOUD]   device_id: {self.credentials.device_id}")
            print(f"[CLOUD]   circle_id: {self.credentials.circle_id}")
            return True
        
        print(f"[CLOUD] No credentials available")
        return False
    
    def clear_credentials(self) -> bool:
        """Clear credentials (for re-registration)."""
        self.credentials = None
        if self.credentials_path.exists():
            try:
                self.credentials_path.unlink()
                print(f"[CLOUD] Credentials file removed")
                return True
            except Exception as e:
                print(f"[ERROR] Failed to remove credentials file: {e}")
                return False
        return True
    
    @classmethod
    def from_env(cls) -> "CloudConfig":
        """Create config from environment variables."""
        return cls(
            server_url=os.getenv("NG_SERVER_URL", "http://localhost:3000"),
            ha_instance_id=os.getenv("NG_HA_INSTANCE_ID", ""),
            device_name=os.getenv("NG_DEVICE_NAME", "NG Edge Device"),
            user_token=os.getenv("NG_USER_TOKEN"),
            config_dir=os.getenv("NG_CONFIG_DIR", "./config"),
            system_device_key_path=os.getenv("NG_DEVICE_KEY_PATH", "/var/lib/ng-edge/device_key"),
        )
