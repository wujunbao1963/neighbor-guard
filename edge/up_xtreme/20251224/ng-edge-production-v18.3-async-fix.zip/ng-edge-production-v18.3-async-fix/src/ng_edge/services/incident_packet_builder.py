"""
Incident Packet Builder - PRD v7.5.0 §5.5.3

Builds incident packets and remote verify views from SecurityEvent.
"""

from typing import List, Optional, Dict, Any
from datetime import datetime, timezone
import uuid

from ..domain.models import SecurityEvent, Evidence
from ..domain.enums import AlarmState, EventDisposition
from ..domain.incident_packet import (
    EdgeSnapshot,
    IncidentPacket,
    MediaManifest,
    MediaItem,
    TimelineEntry,
    TimelineEventType,
    RemoteVerifyView,
    RemoteVerifyMode,
    CapabilityTier,
    CollabAssessment,
    EvidenceType,
    CaptureSchedule,
    CaptureScheduleMode,
)


class IncidentPacketBuilder:
    """
    Builds incident packets and remote verify views.
    
    PRD §5.5.3 - Edge Snapshot generation.
    """
    
    def __init__(
        self,
        edge_device_id: str,
        capability_tier: CapabilityTier = CapabilityTier.V
    ):
        """
        Initialize builder.
        
        Args:
            edge_device_id: Edge device ID
            capability_tier: System capability (V/E/N)
        """
        self.edge_device_id = edge_device_id
        self.capability_tier = capability_tier
    
    # =========================================================================
    # Edge Snapshot
    # =========================================================================
    
    def build_edge_snapshot(
        self,
        event: SecurityEvent,
        timeline: List[TimelineEntry],
        media_manifest_ref: Optional[str] = None
    ) -> EdgeSnapshot:
        """
        Build Edge Snapshot from SecurityEvent.
        
        Args:
            event: Security event
            timeline: Timeline entries
            media_manifest_ref: Media manifest reference
        
        Returns:
            EdgeSnapshot
        """
        # Generate snapshot ID
        snapshot_id = f"snap_{event.event_id}_{int(datetime.now(timezone.utc).timestamp())}"
        
        # Collect zones involved
        zones_involved = []
        if event.primary_zone_id:
            zones_involved.append(event.primary_zone_id)
        # TODO: Add additional zones from evidence
        
        # Build edge assessment
        edge_assessment = None
        if hasattr(event, 'avs_result') and event.avs_result:
            edge_assessment = {
                "capability_tier": self.capability_tier.value,
                "presence_tier": getattr(event.avs_result, 'presence_tier', 0),
                "threat_tier": getattr(event.avs_result, 'threat_tier', 0),
                "avs": {
                    "avs_final_level": getattr(event.avs_result, 'avs_level', 0),
                    "avs_peak_level": getattr(event.avs_result, 'avs_level', 0),
                }
            }
        
        return EdgeSnapshot(
            snapshot_id=snapshot_id,
            event_id=event.event_id,
            generated_at=datetime.now(timezone.utc),
            edge_device_id=self.edge_device_id,
            workflow_class=event.workflow_class.value,
            house_mode=event.house_mode.value,
            alarm_state=event.alarm_state.value,
            triggered_entry_point_id=event.entry_point_id,  # Fixed field name
            zones_involved=zones_involved,
            timeline=timeline,
            media_manifest_ref=media_manifest_ref,
            edge_assessment=edge_assessment,
            user_alert_level=event.user_alert_level.value if hasattr(event.user_alert_level, 'value') else event.user_alert_level,
            dispatch_readiness_local=event.dispatch_readiness_local.value if hasattr(event.dispatch_readiness_local, 'value') else event.dispatch_readiness_local,
        )
    
    def build_incident_packet(
        self,
        edge_snapshot: EdgeSnapshot,
        media_manifest: Optional[MediaManifest] = None,
        collab_assessment: Optional[CollabAssessment] = None,
        remote_verify_mode: RemoteVerifyMode = RemoteVerifyMode.NONE
    ) -> IncidentPacket:
        """
        Build complete Incident Packet.
        
        Args:
            edge_snapshot: Edge snapshot
            media_manifest: Media manifest
            collab_assessment: Collaborative assessment
            remote_verify_mode: Remote verify mode
        
        Returns:
            IncidentPacket
        """
        packet_id = f"pkt_{edge_snapshot.event_id}_{int(datetime.now(timezone.utc).timestamp())}"
        
        # Build audit trail (combine edge timeline + additional entries)
        audit_trail = list(edge_snapshot.timeline)
        
        return IncidentPacket(
            packet_id=packet_id,
            event_id=edge_snapshot.event_id,
            created_at=datetime.now(timezone.utc),
            updated_at=datetime.now(timezone.utc),
            version=1,
            edge_snapshot=edge_snapshot,
            collab_assessment=collab_assessment,
            media_manifest=media_manifest,
            audit_trail=audit_trail,
            remote_verify_enabled=(remote_verify_mode != RemoteVerifyMode.NONE),
            remote_verify_mode=remote_verify_mode,
        )
    
    # =========================================================================
    # Timeline Building
    # =========================================================================
    
    def build_timeline(
        self,
        event: SecurityEvent,
        evidence_list: List[Evidence]
    ) -> List[TimelineEntry]:
        """
        Build timeline from event and evidence.
        
        Args:
            event: Security event
            evidence_list: List of evidence
        
        Returns:
            Timeline entries sorted by timestamp
        """
        entries = []
        
        # Event creation
        entries.append(TimelineEntry(
            timestamp=event.created_at,
            event_type=TimelineEventType.SYSTEM_ACTION,
            actor="edge_system",
            action="Event created",
            details={
                "event_id": event.event_id,
                "workflow_class": event.workflow_class.value,
                "mode": event.house_mode.value,
            }
        ))
        
        # State transitions
        if event.alarm_state != AlarmState.QUIET:
            # Triggered state
            if event.triggered_at:
                entries.append(TimelineEntry(
                    timestamp=event.triggered_at,
                    event_type=TimelineEventType.STATE_TRANSITION,
                    actor="edge_system",
                    action="Alarm state changed",
                    from_state="quiet",
                    to_state=event.alarm_state.value,
                    details={
                        "entry_point_id": event.entry_point_id,  # Fixed
                        "zone_id": event.primary_zone_id,
                    }
                ))
        
        # Evidence detections
        for evidence in evidence_list:
            entries.append(TimelineEntry(
                timestamp=evidence.timestamp,
                event_type=TimelineEventType.SIGNAL_DETECTED,
                actor="edge_system",
                action=f"Signal detected: {evidence.signal_type.value}",
                details={
                    "signal_type": evidence.signal_type.value,
                    "zone_type": evidence.zone_type.value,
                    "confidence": evidence.confidence,
                },
                evidence_id=evidence.evidence_id,
            ))
        
        # Disposition changes
        if event.event_disposition and event.event_disposition != EventDisposition.PENDING:
            entries.append(TimelineEntry(
                timestamp=event.updated_at,
                event_type=TimelineEventType.STATE_TRANSITION,
                actor="edge_system",
                action=f"Disposition: {event.event_disposition.value}",
                to_state=event.event_disposition.value,
                details={}
            ))
        
        # Sort by timestamp
        entries.sort(key=lambda e: e.timestamp)
        
        return entries
    
    # =========================================================================
    # Remote Verify View
    # =========================================================================
    
    def build_remote_verify_view(
        self,
        event: SecurityEvent,
        timeline: List[TimelineEntry],
        entry_delay_remaining_sec: Optional[int] = None,
        latest_snapshot_url: Optional[str] = None,
        live_stream_url: Optional[str] = None
    ) -> RemoteVerifyView:
        """
        Build Remote Verify View for UI.
        
        Args:
            event: Security event
            timeline: Timeline entries
            entry_delay_remaining_sec: Entry delay countdown
            latest_snapshot_url: Latest snapshot URL
            live_stream_url: Live stream URL
        
        Returns:
            RemoteVerifyView
        """
        # Determine remote verify mode
        remote_verify_mode = RemoteVerifyMode.NONE
        if live_stream_url:
            remote_verify_mode = RemoteVerifyMode.LIVE_STREAM
        elif latest_snapshot_url:
            remote_verify_mode = RemoteVerifyMode.SEGMENT_STREAM
        
        # Timeline preview (last 5 entries)
        timeline_preview = sorted(timeline, key=lambda e: e.timestamp, reverse=True)[:5]
        timeline_preview.reverse()  # Show chronologically
        
        # Explain summary
        explain_summary = {
            "what": event.event_type.value.replace("_", " ").title(),
            "where": event.primary_zone_id or "Unknown",
            "when": self._format_relative_time(event.triggered_at or event.created_at),
        }
        
        # Zones involved
        zones_involved = []
        if event.primary_zone_id:
            zones_involved.append(event.primary_zone_id)
        
        return RemoteVerifyView(
            event_id=event.event_id,
            workflow_class=event.workflow_class.value,
            alarm_state=event.alarm_state.value,
            capability_tier=self.capability_tier,
            remote_verify_mode=remote_verify_mode,
            live_stream_url=live_stream_url,
            latest_snapshot_url=latest_snapshot_url,
            timeline_preview=timeline_preview,
            entry_delay_remaining_sec=entry_delay_remaining_sec,
            explain_summary=explain_summary,
            can_disarm=True,
            can_request_neighbor=True,
            can_view_full_packet=False,
            triggered_at=event.triggered_at,
            zones_involved=zones_involved,
        )
    
    # =========================================================================
    # Media Manifest
    # =========================================================================
    
    def create_media_manifest(
        self,
        event_id: str
    ) -> MediaManifest:
        """
        Create empty media manifest.
        
        Args:
            event_id: Event ID
        
        Returns:
            MediaManifest
        """
        manifest_id = f"manifest_{event_id}_{int(datetime.now(timezone.utc).timestamp())}"
        
        return MediaManifest(
            manifest_id=manifest_id,
            event_id=event_id,
            created_at=datetime.now(timezone.utc),
            updated_at=datetime.now(timezone.utc),
        )
    
    def add_snapshot_to_manifest(
        self,
        manifest: MediaManifest,
        camera_id: str,
        zone_id: str,
        timestamp: datetime,
        storage_url: Optional[str] = None,
        priority: int = 1
    ) -> MediaItem:
        """
        Add snapshot to manifest.
        
        Args:
            manifest: Media manifest
            camera_id: Camera ID
            zone_id: Zone ID
            timestamp: Capture timestamp
            storage_url: Storage URL
            priority: Priority (higher = more important)
        
        Returns:
            Created MediaItem
        """
        item_id = f"snap_{camera_id}_{int(timestamp.timestamp())}"
        
        item = MediaItem(
            item_id=item_id,
            evidence_type=EvidenceType.SNAPSHOT,
            camera_id=camera_id,
            zone_id=zone_id,
            timestamp=timestamp,
            storage_url=storage_url,
            priority=priority,
            capture_context={
                "event_id": manifest.event_id,
                "camera_id": camera_id,
                "zone_id": zone_id,
            }
        )
        
        manifest.add_item(item)
        return item
    
    def add_segment_to_manifest(
        self,
        manifest: MediaManifest,
        camera_id: str,
        zone_id: str,
        timestamp: datetime,
        duration_sec: float,
        segment_no: int,
        storage_url: Optional[str] = None,
        priority: int = 0
    ) -> MediaItem:
        """
        Add video segment to manifest.
        
        Args:
            manifest: Media manifest
            camera_id: Camera ID
            zone_id: Zone ID
            timestamp: Segment start time
            duration_sec: Segment duration
            segment_no: Segment number
            storage_url: Storage URL
            priority: Priority
        
        Returns:
            Created MediaItem
        """
        item_id = f"seg_{camera_id}_{segment_no}_{int(timestamp.timestamp())}"
        
        item = MediaItem(
            item_id=item_id,
            evidence_type=EvidenceType.REMOTE_SEGMENT,
            camera_id=camera_id,
            zone_id=zone_id,
            timestamp=timestamp,
            duration_sec=duration_sec,
            storage_url=storage_url,
            priority=priority,
            segment_no=segment_no,
            is_rolling_segment=True,
            capture_context={
                "event_id": manifest.event_id,
                "camera_id": camera_id,
                "zone_id": zone_id,
                "segment_no": segment_no,
            }
        )
        
        manifest.add_item(item)
        return item
    
    # =========================================================================
    # Capture Schedule
    # =========================================================================
    
    def create_capture_schedule(
        self,
        event_id: str,
        alarm_state: AlarmState,
        priority_camera_ids: Optional[List[str]] = None
    ) -> CaptureSchedule:
        """
        Create capture schedule based on alarm state.
        
        PRD §5.5.2:
        - PRE: 1-2 snapshots + 1 short segment
        - PENDING: Rolling segments (2-5 min)
        - TRIGGERED: Priority rolling segments
        
        Args:
            event_id: Event ID
            alarm_state: Current alarm state
            priority_camera_ids: Priority camera IDs
        
        Returns:
            CaptureSchedule
        """
        # Determine mode from alarm state
        mode = CaptureScheduleMode.IDLE
        snapshots_requested = 0
        max_duration_min = 5.0
        
        if alarm_state == AlarmState.PRE:
            mode = CaptureScheduleMode.PRE_SNAPSHOT
            snapshots_requested = 2
        elif alarm_state == AlarmState.PENDING:
            mode = CaptureScheduleMode.PENDING_ROLLING
            snapshots_requested = 1
            max_duration_min = 5.0
        elif alarm_state == AlarmState.TRIGGERED:
            mode = CaptureScheduleMode.TRIGGERED_PRIORITY
            max_duration_min = 5.0
        
        return CaptureSchedule(
            mode=mode,
            event_id=event_id,
            started_at=datetime.now(timezone.utc),
            snapshots_requested=snapshots_requested,
            segment_duration_sec=10.0,  # 10-second segments
            segment_interval_sec=3.0,  # 3-second gap max
            max_duration_min=max_duration_min,
            priority_camera_ids=priority_camera_ids or [],
            is_active=True,
        )
    
    # =========================================================================
    # Utilities
    # =========================================================================
    
    def _format_relative_time(self, dt: datetime) -> str:
        """Format datetime as relative time."""
        now = datetime.now(timezone.utc)
        delta = now - dt
        
        if delta.total_seconds() < 60:
            return "Just now"
        elif delta.total_seconds() < 3600:
            mins = int(delta.total_seconds() / 60)
            return f"{mins} min ago"
        elif delta.total_seconds() < 86400:
            hours = int(delta.total_seconds() / 3600)
            return f"{hours} hour{'s' if hours > 1 else ''} ago"
        else:
            return dt.strftime("%Y-%m-%d %H:%M UTC")
