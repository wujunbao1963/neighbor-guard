"""
Zigbee Configuration - Zigbee传感器配置

为Zigbee2MQTT传感器提供标准配置。
"""

from ng_edge.domain import (
    Zone,
    EntryPoint,
    Topology,
    ZoneType,
    LocationType,
    CapabilityTier,
    SignalType,
)


def create_zigbee_topology() -> Topology:
    """创建Zigbee传感器拓扑配置.
    
    配置说明:
    - Back Door: ENTRY_EXIT zone with contact sensor
    - Family Room: INTERIOR zone with motion sensor
    
    Returns:
        完整的 Topology 对象
    """
    
    zones = {
        # 后门 - Entry/Exit zone
        "zone_back_door": Zone(
            zone_id="zone_back_door",
            name="Back Door",
            zone_type=ZoneType.ENTRY_EXIT,
            location_type=LocationType.INDOOR,
            entry_point_ids=["ep_back_door"],
            capability_tier=CapabilityTier.E,
        ),
        
        # 家庭室 - Interior zone (注意：是INTERIOR，不是PERIMETER)
        "zone_family_room": Zone(
            zone_id="zone_family_room",
            name="Family Room",
            zone_type=ZoneType.INTERIOR,  # 改为INTERIOR
            location_type=LocationType.INDOOR,
            is_bypass_home=True,
            is_bypass_night_occupied=True,
            capability_tier=CapabilityTier.E,
        ),
    }
    
    entry_points = {
        # 后门入口点
        "ep_back_door": EntryPoint(
            entry_point_id="ep_back_door",
            name="Back Door Entry",
            zone_id="zone_back_door",
            entry_delay_away_sec=30,
            entry_delay_night_sec=15,
            entry_delay_home_sec=30,
            sensor_ids=["zigbee_back_door_001"],
            is_primary_entry=False,
        ),
    }
    
    return Topology(zones=zones, entry_points=entry_points)


def get_zigbee_sensor_bindings() -> dict:
    """获取Zigbee传感器绑定配置.
    
    Returns:
        传感器ID -> 配置的映射
    """
    return {
        # Back Door Contact
        "zigbee_back_door_001": {
            "sensor_id": "zigbee_back_door_001",
            "sensor_type": "door_contact",
            "name": "Back Door Contact",
            "zone_id": "zone_back_door",
            "zone_type": ZoneType.ENTRY_EXIT,
            "location_type": "indoor",
            "entry_point_id": "ep_back_door",  # 关键：这里指定entry_point_id
            "supported_signals": [
                SignalType.DOOR_OPEN,
                SignalType.DOOR_CLOSE,
            ],
        },
        
        # Family Room Motion
        "zigbee_family_room_001": {
            "sensor_id": "zigbee_family_room_001",
            "sensor_type": "motion_pir",
            "name": "Family Room Motion",
            "zone_id": "zone_family_room",
            "zone_type": ZoneType.INTERIOR,
            "location_type": "indoor",
            "entry_point_id": "ep_back_door",  # Interior follower连接到back door
            "supported_signals": [
                SignalType.MOTION_ACTIVE,
            ],
        },
    }
