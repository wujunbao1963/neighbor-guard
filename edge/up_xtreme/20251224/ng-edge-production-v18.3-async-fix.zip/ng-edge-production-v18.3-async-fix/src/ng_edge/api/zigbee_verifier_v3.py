#!/usr/bin/env python3
"""
Zigbee设备验证器 v3 - 修复版

修复：
- 不再请求设备状态（devices don't respond to /get）
- 直接订阅设备topic，等待主动发送的消息
- 检查linkquality字段判断在线状态
"""

import json
import time
from typing import Dict, Any, List


def list_zigbee_devices(
    mqtt_host: str = "localhost",
    mqtt_port: int = 1883,
    timeout_sec: int = 3
) -> Dict[str, Any]:
    """列出所有Zigbee2MQTT设备"""
    try:
        import paho.mqtt.client as mqtt
    except ImportError:
        return {
            "success": False,
            "devices": [],
            "error": "paho-mqtt未安装，请运行: pip install paho-mqtt"
        }
    
    result = {
        "success": False,
        "devices": [],
        "error": None
    }
    
    devices_received = False
    
    def on_connect(client, userdata, flags, rc):
        if rc == 0:
            print(f"[Lister] ✅ 已连接到MQTT {mqtt_host}:{mqtt_port}")
            client.subscribe("zigbee2mqtt/bridge/devices")
            client.publish("zigbee2mqtt/bridge/request/devices", "")
        else:
            result["error"] = f"MQTT连接失败: {rc}"
    
    def on_message(client, userdata, msg):
        nonlocal devices_received
        
        try:
            if msg.topic == "zigbee2mqtt/bridge/devices":
                devices_data = json.loads(msg.payload)
                print(f"[Lister] 收到设备列表，共 {len(devices_data)} 个设备")
                
                for device in devices_data:
                    # 跳过协调器
                    if device.get('type') == 'Coordinator':
                        continue
                    
                    device_info = {
                        "ieee_address": device.get('ieee_address'),
                        "friendly_name": device.get('friendly_name'),
                        "model": device.get('model_id') or device.get('definition', {}).get('model', 'Unknown'),
                        "manufacturer": device.get('manufacturer', 'Unknown'),
                        "type": device.get('type', 'Unknown'),
                        "supported": device.get('supported', False),
                        "power_source": device.get('power_source', 'Unknown'),
                    }
                    
                    # 推断设备类型
                    model_lower = device_info['model'].lower()
                    friendly_lower = device_info['friendly_name'].lower()
                    
                    if 'contact' in model_lower or 'contact' in friendly_lower or 'door' in friendly_lower:
                        device_info['sensor_type'] = 'contact'
                    elif 'motion' in model_lower or 'motion' in friendly_lower or 'occupancy' in model_lower:
                        device_info['sensor_type'] = 'motion'
                    elif 'vibration' in model_lower or 'glass' in model_lower:
                        device_info['sensor_type'] = 'glass_break'
                    elif 'smoke' in model_lower:
                        device_info['sensor_type'] = 'smoke'
                    elif 'water' in model_lower or 'leak' in model_lower:
                        device_info['sensor_type'] = 'water'
                    else:
                        device_info['sensor_type'] = 'unknown'
                    
                    result["devices"].append(device_info)
                
                result["success"] = True
                devices_received = True
                
        except Exception as e:
            print(f"[Lister] 消息处理错误: {e}")
            result["error"] = str(e)
    
    client = mqtt.Client(client_id="ng_edge_lister", callback_api_version=mqtt.CallbackAPIVersion.VERSION1)
    client.on_connect = on_connect
    client.on_message = on_message
    
    try:
        print(f"[Lister] 连接到 {mqtt_host}:{mqtt_port}...")
        client.connect(mqtt_host, mqtt_port, 60)
        
        start_time = time.time()
        while time.time() - start_time < timeout_sec:
            client.loop(timeout=0.1)
            if devices_received:
                break
        
        if not devices_received:
            result["error"] = f"超时：未在{timeout_sec}秒内收到设备列表"
        
    except Exception as e:
        result["error"] = f"列出设备失败: {str(e)}"
    finally:
        client.disconnect()
    
    return result


def verify_zigbee_device(
    ieee_address: str,
    mqtt_host: str = "localhost",
    mqtt_port: int = 1883,
    timeout_sec: int = 8
) -> Dict[str, Any]:
    """
    验证Zigbee设备是否存在于Zigbee2MQTT
    
    修复逻辑：
    1. 获取设备列表，找到设备
    2. 订阅设备topic
    3. 等待设备主动发送的状态消息（不请求）
    4. 检查linkquality判断在线状态
    """
    try:
        import paho.mqtt.client as mqtt
    except ImportError:
        return {
            "success": False,
            "error": "paho-mqtt未安装，请运行: pip install paho-mqtt"
        }
    
    # 清理IEEE地址格式
    ieee_clean = ieee_address.lower().strip()
    if not ieee_clean.startswith('0x'):
        ieee_clean = f"0x{ieee_clean}"
    
    result = {
        "success": False,
        "device_found": False,
        "device_online": False,
        "friendly_name": None,
        "model": None,
        "mqtt_topic": None,
        "sensor_type": None,
        "linkquality": None,
        "last_seen": None,
        "error": None
    }
    
    device_topic = None
    status_received = False
    
    def on_connect(client, userdata, flags, rc):
        if rc == 0:
            print(f"[Verifier] ✅ 已连接到MQTT {mqtt_host}:{mqtt_port}")
            # 订阅设备列表
            client.subscribe("zigbee2mqtt/bridge/devices")
            # 请求设备列表
            client.publish("zigbee2mqtt/bridge/request/devices", "")
        else:
            result["error"] = f"MQTT连接失败: {rc}"
    
    def on_message(client, userdata, msg):
        nonlocal device_topic, status_received
        
        try:
            # 处理设备列表
            if msg.topic == "zigbee2mqtt/bridge/devices":
                devices = json.loads(msg.payload)
                print(f"[Verifier] 收到设备列表，共 {len(devices)} 个设备")
                
                # 查找目标设备
                for device in devices:
                    if device.get('ieee_address') == ieee_clean:
                        result["device_found"] = True
                        result["friendly_name"] = device.get('friendly_name')
                        result["model"] = device.get('model_id') or device.get('definition', {}).get('model')
                        result["mqtt_topic"] = f"zigbee2mqtt/{device.get('friendly_name')}"
                        device_topic = result["mqtt_topic"]
                        
                        # 推断sensor类型
                        model_lower = result["model"].lower() if result["model"] else ""
                        friendly_lower = result["friendly_name"].lower()
                        
                        if 'contact' in model_lower or 'contact' in friendly_lower:
                            result["sensor_type"] = 'contact'
                        elif 'motion' in model_lower or 'motion' in friendly_lower:
                            result["sensor_type"] = 'motion'
                        elif 'vibration' in model_lower or 'glass' in model_lower:
                            result["sensor_type"] = 'glass_break'
                        
                        print(f"[Verifier] ✅ 找到设备: {result['friendly_name']}")
                        print(f"[Verifier]    型号: {result['model']}")
                        print(f"[Verifier]    IEEE: {ieee_clean}")
                        print(f"[Verifier]    推断类型: {result['sensor_type']}")
                        
                        # 订阅设备topic等待状态消息
                        client.subscribe(device_topic)
                        print(f"[Verifier] 📡 订阅: {device_topic}")
                        print(f"[Verifier] ⏳ 等待设备发送状态消息...")
                        break
                
                if not result["device_found"]:
                    print(f"[Verifier] ❌ 未找到IEEE地址: {ieee_clean}")
                    result["error"] = f"设备不存在于Zigbee2MQTT"
            
            # 处理设备状态消息
            elif device_topic and msg.topic == device_topic:
                payload = json.loads(msg.payload)
                print(f"[Verifier] 📨 收到设备状态消息")
                
                # 检查linkquality判断在线
                linkquality = payload.get('linkquality')
                if linkquality is not None:
                    result["device_online"] = True
                    result["linkquality"] = linkquality
                    result["last_seen"] = "刚刚"  # Just now
                    status_received = True
                    
                    print(f"[Verifier] ✅ 设备在线")
                    print(f"[Verifier]    信号强度: {linkquality}")
                    print(f"[Verifier]    状态: {payload}")
                
        except Exception as e:
            print(f"[Verifier] 消息处理错误: {e}")
    
    client = mqtt.Client(client_id="ng_edge_verifier", callback_api_version=mqtt.CallbackAPIVersion.VERSION1)
    client.on_connect = on_connect
    client.on_message = on_message
    
    try:
        print(f"[Verifier] 连接到 {mqtt_host}:{mqtt_port}...")
        client.connect(mqtt_host, mqtt_port, 60)
        
        # 运行事件循环
        start_time = time.time()
        while time.time() - start_time < timeout_sec:
            client.loop(timeout=0.1)
            
            # 设备已找到且收到状态消息
            if result["device_found"] and status_received:
                result["success"] = True
                print(f"[Verifier] ✅ 验证成功")
                break
            
            # 设备已找到，等待足够时间后仍未收到消息
            if result["device_found"] and time.time() - start_time > 6 and not status_received:
                # 设备存在但离线（很久没发送状态）
                result["success"] = True
                result["device_online"] = False
                print(f"[Verifier] ⚠️  设备存在但可能离线（未收到状态消息）")
                break
        
        if not result["device_found"]:
            result["error"] = f"超时：未在{timeout_sec}秒内找到设备"
            print(f"[Verifier] ❌ {result['error']}")
        
    except Exception as e:
        result["error"] = f"验证失败: {str(e)}"
        print(f"[Verifier] ❌ {result['error']}")
    finally:
        client.disconnect()
    
    return result


def interactive_device_selection():
    """交互式设备选择"""
    print("\n" + "=" * 70)
    print("  Zigbee设备列表")
    print("=" * 70)
    
    print("\n正在获取设备列表...")
    result = list_zigbee_devices()
    
    if not result["success"]:
        print(f"\n❌ 获取设备列表失败: {result['error']}")
        return None
    
    devices = result["devices"]
    
    if not devices:
        print("\n⚠️  没有找到任何Zigbee设备")
        return None
    
    # 显示设备列表
    print(f"\n找到 {len(devices)} 个Zigbee设备:\n")
    
    for i, device in enumerate(devices, 1):
        print(f"{i}. {device['friendly_name']}")
        print(f"   IEEE地址: {device['ieee_address']}")
        print(f"   型号: {device['model']}")
        print(f"   制造商: {device['manufacturer']}")
        print(f"   推断类型: {device['sensor_type']}")
        print()
    
    # 用户选择
    print("请选择一个设备进行验证测试 (输入序号，0退出):")
    try:
        choice = int(input(">>> ").strip())
        
        if choice == 0:
            return None
        
        if choice < 1 or choice > len(devices):
            print("❌ 无效的选择")
            return None
        
        selected = devices[choice - 1]
        print(f"\n已选择: {selected['friendly_name']}")
        print(f"IEEE地址: {selected['ieee_address']}")
        
        return selected
        
    except ValueError:
        print("❌ 请输入数字")
        return None
    except KeyboardInterrupt:
        print("\n\n取消")
        return None


def test_with_device_selection():
    """使用设备选择的测试流程"""
    print("=" * 70)
    print("  Zigbee设备验证器 v3 - 修复版")
    print("=" * 70)
    
    # 选择设备
    selected = interactive_device_selection()
    
    if not selected:
        print("\n未选择设备，退出")
        return
    
    # 验证选中的设备
    print("\n" + "=" * 70)
    print(f"  验证设备: {selected['friendly_name']}")
    print("=" * 70)
    
    print(f"\n开始验证 {selected['ieee_address']}...\n")
    
    result = verify_zigbee_device(selected['ieee_address'], timeout_sec=10)
    
    # 显示结果
    print("\n" + "=" * 70)
    print("  验证结果")
    print("=" * 70)
    
    print(f"\n{json.dumps(result, indent=2, ensure_ascii=False)}\n")
    
    if result["success"]:
        print("✅ 验证成功！")
        print(f"  设备名称: {result['friendly_name']}")
        print(f"  设备型号: {result['model']}")
        print(f"  推断类型: {result['sensor_type']}")
        print(f"  MQTT Topic: {result['mqtt_topic']}")
        
        if result['device_online']:
            print(f"  在线状态: ✅ 在线")
            print(f"  信号强度: {result['linkquality']}")
        else:
            print(f"  在线状态: ⚠️  离线（未收到状态消息）")
    else:
        print(f"❌ 验证失败: {result['error']}")
    
    print("\n" + "=" * 70)


if __name__ == "__main__":
    test_with_device_selection()
