"""
Zigbee API - SecurityCoordinator集成版本
修改说明: 将Zigbee信号发送到SecurityCoordinator（与模拟信号相同的路径）

关键改动:
1. 保留所有现有功能（向后兼容）
2. 使用SecurityCoordinator替代Pipeline（与模拟信号路径一致）
3. 添加错误处理，避免SecurityCoordinator问题影响Zigbee功能
"""
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import List, Optional
from datetime import datetime, timezone

from ng_edge.hardware.zigbee_mqtt_client import ZigbeeMQTTClient, ZigbeeDevice
from ng_edge.domain.enums import SignalType

# Router
zigbee_router = APIRouter(prefix="/api/zigbee", tags=["zigbee"])

# Global state
zigbee_client: Optional[ZigbeeMQTTClient] = None
zigbee_active = False
recent_signals = []  # 最近的signals


class ZigbeeDeviceConfig(BaseModel):
    """Zigbee设备配置"""
    friendly_name: str
    sensor_id: str
    sensor_type: str
    zone_id: str
    device_type: str  # 'motion' 或 'contact'


class ZigbeeStartRequest(BaseModel):
    """启动Zigbee客户端请求"""
    mqtt_host: str = "localhost"
    mqtt_port: int = 1883
    devices: List[ZigbeeDeviceConfig]


class ZigbeeStatusResponse(BaseModel):
    """Zigbee状态响应"""
    active: bool
    connected: bool
    device_count: int
    recent_signals: List[dict]
    pipeline_enabled: bool  # SecurityCoordinator是否可用


@zigbee_router.post("/start")
async def start_zigbee(request: ZigbeeStartRequest):
    """启动Zigbee客户端"""
    global zigbee_client, zigbee_active
    
    if zigbee_active:
        raise HTTPException(status_code=400, detail="Zigbee already active")
    
    try:
        # 创建客户端
        zigbee_client = ZigbeeMQTTClient(
            mqtt_host=request.mqtt_host,
            mqtt_port=request.mqtt_port,
            base_topic="zigbee2mqtt",
            on_signal=on_zigbee_signal
        )
        
        # 添加设备
        for dev in request.devices:
            zigbee_client.add_device(ZigbeeDevice(
                friendly_name=dev.friendly_name,
                sensor_id=dev.sensor_id,
                sensor_type=dev.sensor_type,
                zone_id=dev.zone_id,
                device_type=dev.device_type
            ))
        
        # 连接
        if not zigbee_client.connect():
            raise HTTPException(status_code=500, detail="Failed to connect to MQTT")
        
        zigbee_active = True
        
        return {
            "status": "started",
            "device_count": len(request.devices),
            "mqtt_host": request.mqtt_host
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@zigbee_router.post("/stop")
async def stop_zigbee():
    """停止Zigbee客户端"""
    global zigbee_client, zigbee_active
    
    if not zigbee_active:
        raise HTTPException(status_code=400, detail="Zigbee not active")
    
    if zigbee_client:
        zigbee_client.disconnect()
        zigbee_client = None
    
    zigbee_active = False
    
    return {"status": "stopped"}


@zigbee_router.get("/status")
async def get_zigbee_status() -> ZigbeeStatusResponse:
    """获取Zigbee状态"""
    # 检查SecurityCoordinator是否可用
    pipeline_enabled = False
    try:
        from . import manager
        if manager.state and manager.state.security_coordinator:
            pipeline_enabled = True
    except Exception:
        pass
    
    if not zigbee_active or not zigbee_client:
        return ZigbeeStatusResponse(
            active=False,
            connected=False,
            device_count=0,
            recent_signals=[],
            pipeline_enabled=pipeline_enabled
        )
    
    return ZigbeeStatusResponse(
        active=True,
        connected=zigbee_client.is_connected,
        device_count=len(zigbee_client.devices),
        recent_signals=recent_signals[:20],  # 最近20条
        pipeline_enabled=pipeline_enabled
    )


def on_zigbee_signal(signal):
    """
    Signal回调 - 集成到SecurityCoordinator（与模拟信号相同的路径）
    
    处理流程:
    1. 保存到display (用于Web UI显示) - 保证向后兼容
    2. 发送到SecurityCoordinator进行安防处理 - 使用与模拟信号相同的代码路径
    3. 错误隔离: SecurityCoordinator失败不影响Zigbee功能
    """
    global recent_signals
    
    # ===== 步骤1: 保存display (现有功能，保持不变) =====
    signal_data = {
        'signal_type': signal.signal_type.value,
        'sensor_id': signal.sensor_id,
        'zone_id': signal.zone_id,
        'confidence': signal.confidence,
        'timestamp': signal.timestamp.isoformat(),
        'battery': signal.raw_payload.get('battery') if signal.raw_payload else None,
        'linkquality': signal.raw_payload.get('linkquality') if signal.raw_payload else None
    }
    
    recent_signals.insert(0, signal_data)
    
    # 保留最近100条
    if len(recent_signals) > 100:
        recent_signals = recent_signals[:100]
    
    print(f"[Zigbee API] Signal received: {signal.signal_type.value} from {signal.sensor_id}")
    
    # ===== 步骤2: 发送到SecurityCoordinator (与模拟信号相同) =====
    try:
        # 动态导入manager避免循环依赖
        from . import manager
        
        # 检查manager是否可用
        if not manager.state:
            print(f"[Zigbee API] Warning: manager.state not available")
            return
            
        if not manager.state.security_coordinator:
            print(f"[Zigbee API] Warning: SecurityCoordinator not initialized")
            return
        
        # 获取sensor binding
        binding = manager.state.sensors.get(signal.sensor_id)
        if not binding:
            print(f"[Zigbee API] Warning: Sensor {signal.sensor_id} not found in bindings")
            return
        
        # 导入SecurityCoordinator的枚举类型
        from ..services.state_machine_v5 import (
            Signal as SMSignal,
            ZoneType as SMZoneType,
            SignalType as SMSignalType,
        )
        
        # 映射zone_type到v5枚举
        sm_zone_map = {
            "exterior": SMZoneType.EXTERIOR,
            "entry_exit": SMZoneType.ENTRY_EXIT,
            "interior": SMZoneType.INTERIOR,
            "perimeter": SMZoneType.PERIMETER,
        }
        
        # 映射signal_type到v5枚举
        sm_signal_map = {
            SignalType.PERSON_DETECTED: SMSignalType.PERSON_DETECTED,
            SignalType.VEHICLE_DETECTED: SMSignalType.VEHICLE_DETECTED,
            SignalType.DOOR_OPEN: SMSignalType.DOOR_OPEN,
            SignalType.DOOR_CLOSE: SMSignalType.DOOR_CLOSE,
            SignalType.MOTION_ACTIVE: SMSignalType.MOTION_ACTIVE,
            SignalType.GLASS_BREAK: SMSignalType.GLASS_BREAK,
        }
        
        zone_type_str = binding.zone_type.value if binding.zone_type else "unknown"
        sm_zone = sm_zone_map.get(zone_type_str, SMZoneType.EXTERIOR)
        sm_signal = sm_signal_map.get(signal.signal_type)
        
        if not sm_signal:
            print(f"[Zigbee API] Unsupported signal type: {signal.signal_type}")
            return
        
        # 获取entry_point_id
        entry_point_id = binding.entry_point_id or "_global"
        
        # 确保entry point已注册（与trigger_sensor相同）
        if entry_point_id != "_global":
            ep_config = manager.state.entry_points.get(entry_point_id)
            if ep_config:
                manager.state.security_coordinator.register_entry_point(
                    entry_point_id,
                    ep_config.name,
                    entry_delay_sec=ep_config.entry_delay_away_sec
                )
            else:
                manager.state.security_coordinator.register_entry_point(entry_point_id, entry_point_id)
        
        # 创建v5 Signal对象
        sig = SMSignal(
            entry_point_id=entry_point_id,
            signal_type=sm_signal,
            zone_type=sm_zone,
            from_inside=False,
        )
        
        # 调用SecurityCoordinator处理信号（与模拟信号完全相同）
        print(f"[Zigbee API] Sending to SecurityCoordinator: {signal.signal_type.value}")
        result = manager.state.security_coordinator.process(sig)
        
        # 记录处理结果
        if result:
            print(f"[Zigbee API] Signal processed successfully")
            if hasattr(result, 'state_change') and result.state_change:
                print(f"[Zigbee API] State transition: {result.state_change}")
        else:
            print(f"[Zigbee API] Signal processed (no state change)")
    
    except ImportError as e:
        # Manager未导入 - 这是正常情况（如果单独测试Zigbee API）
        print(f"[Zigbee API] SecurityCoordinator not available (manager not imported): {e}")
    
    except Exception as e:
        # SecurityCoordinator处理出错 - 记录但不影响Zigbee功能
        print(f"[Zigbee API] ERROR processing signal in SecurityCoordinator: {e}")
        import traceback
        traceback.print_exc()
