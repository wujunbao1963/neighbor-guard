"""
Zigbee2MQTT自动发现监听器

监听Zigbee2MQTT的设备事件，自动将新设备添加到设备池

工作流程:
1. 订阅 zigbee2mqtt/bridge/devices topic
2. 监听新设备加入事件
3. 自动添加到设备池
4. 通知用户进行绑定
"""

import paho.mqtt.client as mqtt
import json
from typing import Optional, Callable
from datetime import datetime


class Zigbee2MQTTDiscoveryListener:
    """
    Zigbee2MQTT自动发现监听器
    
    监听Zigbee2MQTT broker的设备事件
    """
    
    def __init__(
        self,
        mqtt_host: str = "localhost",
        mqtt_port: int = 1883,
        base_topic: str = "zigbee2mqtt",
        on_device_discovered: Optional[Callable] = None
    ):
        self.mqtt_host = mqtt_host
        self.mqtt_port = mqtt_port
        self.base_topic = base_topic
        self.on_device_discovered = on_device_discovered
        
        self.client: Optional[mqtt.Client] = None
        self.is_connected = False
        
        # 已知设备列表（避免重复添加）
        self.known_devices = set()
    
    def connect(self) -> bool:
        """连接到MQTT broker"""
        try:
            self.client = mqtt.Client(client_id="ng_edge_discovery")
            self.client.on_connect = self._on_connect
            self.client.on_message = self._on_message
            
            print(f"[Zigbee Discovery] 连接到 MQTT {self.mqtt_host}:{self.mqtt_port}")
            self.client.connect(self.mqtt_host, self.mqtt_port, 60)
            self.client.loop_start()
            
            return True
            
        except Exception as e:
            print(f"[Zigbee Discovery] 连接失败: {e}")
            return False
    
    def disconnect(self):
        """断开连接"""
        if self.client:
            self.client.loop_stop()
            self.client.disconnect()
            self.is_connected = False
    
    def _on_connect(self, client, userdata, flags, rc):
        """连接回调"""
        if rc == 0:
            self.is_connected = True
            print("[Zigbee Discovery] ✅ 已连接到MQTT broker")
            
            # 订阅设备列表topic
            client.subscribe(f"{self.base_topic}/bridge/devices")
            print(f"[Zigbee Discovery] 订阅: {self.base_topic}/bridge/devices")
            
            # 订阅设备事件
            client.subscribe(f"{self.base_topic}/bridge/event")
            print(f"[Zigbee Discovery] 订阅: {self.base_topic}/bridge/event")
            
        else:
            print(f"[Zigbee Discovery] ❌ 连接失败, code: {rc}")
    
    def _on_message(self, client, userdata, msg):
        """消息回调"""
        try:
            topic = msg.topic
            payload = json.loads(msg.payload.decode())
            
            # 处理设备列表
            if topic == f"{self.base_topic}/bridge/devices":
                self._handle_device_list(payload)
            
            # 处理设备事件
            elif topic == f"{self.base_topic}/bridge/event":
                self._handle_device_event(payload)
                
        except Exception as e:
            print(f"[Zigbee Discovery] 消息处理错误: {e}")
    
    def _handle_device_list(self, devices):
        """处理设备列表"""
        print(f"[Zigbee Discovery] 收到设备列表: {len(devices)} 个设备")
        
        for device in devices:
            self._process_device(device)
    
    def _handle_device_event(self, event):
        """处理设备事件"""
        event_type = event.get('type')
        
        # 设备加入事件
        if event_type == 'device_joined':
            data = event.get('data', {})
            print(f"[Zigbee Discovery] 🆕 新设备加入: {data.get('friendly_name')}")
            self._process_device(data)
        
        # 设备重命名事件
        elif event_type == 'device_renamed':
            data = event.get('data', {})
            old_name = data.get('from')
            new_name = data.get('to')
            print(f"[Zigbee Discovery] 设备重命名: {old_name} → {new_name}")
            # TODO: 更新设备池中的friendly_name
    
    def _process_device(self, device):
        """处理单个设备"""
        # 跳过协调器
        if device.get('type') == 'Coordinator':
            return
        
        ieee_address = device.get('ieee_address')
        if not ieee_address:
            return
        
        # 检查是否已处理
        if ieee_address in self.known_devices:
            return
        
        friendly_name = device.get('friendly_name', ieee_address)
        model = device.get('model_id') or device.get('definition', {}).get('model', 'Unknown')
        manufacturer = device.get('manufacturer', 'Unknown')
        
        print(f"[Zigbee Discovery] 发现设备:")
        print(f"  名称: {friendly_name}")
        print(f"  IEEE: {ieee_address}")
        print(f"  型号: {model}")
        print(f"  制造商: {manufacturer}")
        
        # 标记为已知
        self.known_devices.add(ieee_address)
        
        # 推断设备类型
        device_type_hint = None
        definition = device.get('definition', {})
        exposes = definition.get('exposes', [])
        
        for expose in exposes:
            if expose.get('type') == 'binary':
                feature = expose.get('name', '')
                if feature in ['contact', 'door', 'window']:
                    device_type_hint = 'contact'
                    break
                elif feature in ['occupancy', 'presence', 'motion']:
                    device_type_hint = 'motion'
                    break
                elif feature == 'vibration':
                    device_type_hint = 'glass_break'
                    break
        
        # 回调通知
        if self.on_device_discovered:
            self.on_device_discovered({
                'friendly_name': friendly_name,
                'ieee_address': ieee_address,
                'model': model,
                'manufacturer': manufacturer,
                'device_type_hint': device_type_hint
            })


def test_discovery_listener():
    """测试自动发现监听器"""
    def on_discovered(device_info):
        print(f"\n🎉 新设备发现回调:")
        print(f"  {device_info}")
    
    listener = Zigbee2MQTTDiscoveryListener(
        mqtt_host="localhost",
        mqtt_port=1883,
        on_device_discovered=on_discovered
    )
    
    if listener.connect():
        print("\n监听中，按Ctrl+C停止...\n")
        try:
            import time
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            print("\n停止监听")
            listener.disconnect()


if __name__ == "__main__":
    test_discovery_listener()
