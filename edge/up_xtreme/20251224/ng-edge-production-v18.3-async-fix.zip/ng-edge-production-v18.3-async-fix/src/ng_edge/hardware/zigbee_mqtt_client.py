"""
Zigbee MQTT客户端 - 连接Zigbee2MQTT
修复: 添加entry_point_id查找逻辑
"""
import paho.mqtt.client as mqtt
import json
import uuid
from datetime import datetime, timezone
from typing import Optional, Callable, Dict
from dataclasses import dataclass

from ng_edge.domain.models import Signal
from ng_edge.domain.enums import SignalType


@dataclass
class ZigbeeDevice:
    """Zigbee设备配置"""
    friendly_name: str   # Zigbee2MQTT中的名称
    sensor_id: str       # NG Edge sensor ID
    sensor_type: str     # NG Edge sensor type
    zone_id: str         # 绑定的zone
    device_type: str     # 'motion' 或 'contact'


class ZigbeeMQTTClient:
    """Zigbee2MQTT客户端"""
    
    def __init__(
        self,
        mqtt_host: str = "localhost",
        mqtt_port: int = 1883,
        base_topic: str = "zigbee2mqtt",
        on_signal: Optional[Callable] = None
    ):
        self.mqtt_host = mqtt_host
        self.mqtt_port = mqtt_port
        self.base_topic = base_topic
        self.on_signal = on_signal  # Signal回调函数
        
        # 设备映射
        self.devices: Dict[str, ZigbeeDevice] = {}
        
        # MQTT客户端
        self.client = mqtt.Client()
        self.client.on_connect = self._on_connect
        self.client.on_message = self._on_message
        
        self.is_connected = False
        
    def add_device(self, device: ZigbeeDevice):
        """添加设备"""
        self.devices[device.friendly_name] = device
        print(f"[Zigbee] Added device: {device.friendly_name} -> {device.sensor_id} ({device.device_type})")
    
    def connect(self) -> bool:
        """连接MQTT"""
        try:
            print(f"[Zigbee] Connecting to MQTT {self.mqtt_host}:{self.mqtt_port}")
            self.client.connect(self.mqtt_host, self.mqtt_port, 60)
            self.client.loop_start()
            return True
        except Exception as e:
            print(f"[Zigbee] Connection failed: {e}")
            return False
    
    def disconnect(self):
        """断开连接"""
        self.client.loop_stop()
        self.client.disconnect()
        self.is_connected = False
    
    def _on_connect(self, client, userdata, flags, rc):
        """连接回调"""
        if rc == 0:
            self.is_connected = True
            print("[Zigbee] ✅ Connected to MQTT broker")
            
            # 订阅所有设备
            for friendly_name in self.devices.keys():
                topic = f"{self.base_topic}/{friendly_name}"
                client.subscribe(topic)
                print(f"[Zigbee] Subscribed: {topic}")
        else:
            print(f"[Zigbee] ❌ Connection failed, code: {rc}")
    
    def _on_message(self, client, userdata, msg):
        """消息回调"""
        try:
            # 解析topic: zigbee2mqtt/Family Room Motion
            topic_parts = msg.topic.split('/')
            if len(topic_parts) < 2:
                return
            
            friendly_name = '/'.join(topic_parts[1:])  # 支持名称中有/
            
            # 查找设备
            device = self.devices.get(friendly_name)
            if not device:
                return
            
            # 解析payload
            payload = json.loads(msg.payload.decode())
            
            # 生成Signal
            signal = self._create_signal(device, payload)
            if signal and self.on_signal:
                self.on_signal(signal)
                
        except Exception as e:
            print(f"[Zigbee] Message error: {e}")
    
    def _create_signal(self, device: ZigbeeDevice, payload: dict) -> Optional[Signal]:
        """创建Signal"""
        
        # Motion传感器
        if device.device_type == 'motion':
            occupancy = payload.get('occupancy')
            if occupancy is None:
                return None
            
            # 只处理motion_active，忽略motion_inactive
            if not occupancy:
                return None
            
            signal_type = SignalType.MOTION_ACTIVE
            confidence = 0.95
            
        # Contact传感器 (门/窗)
        elif device.device_type == 'contact':
            contact = payload.get('contact')
            if contact is None:
                return None
            
            # contact=true表示关闭，contact=false表示打开
            signal_type = SignalType.DOOR_CLOSE if contact else SignalType.DOOR_OPEN
            confidence = 0.99
            
        else:
            return None
        
        # ===== 关键修复: 查找entry_point_id =====
        entry_point_id = None
        try:
            from ng_edge.api import manager
            if manager.state and manager.state.sensors:
                binding = manager.state.sensors.get(device.sensor_id)
                if binding:
                    entry_point_id = binding.entry_point_id
        except Exception as e:
            # 静默失败，不影响Signal创建
            pass
        # ===== 修复结束 =====
        
        # 创建Signal对象
        signal = Signal(
            signal_id=f"zigbee_{uuid.uuid4().hex[:12]}",
            signal_type=signal_type,
            sensor_id=device.sensor_id,
            sensor_type=device.sensor_type,
            zone_id=device.zone_id,
            entry_point_id=entry_point_id,  # 添加这个字段！
            timestamp=datetime.now(timezone.utc),
            confidence=confidence,
            raw_payload={
                "mqtt_topic": f"zigbee2mqtt/{device.friendly_name}",
                "payload": payload,
                "battery": payload.get('battery'),
                "linkquality": payload.get('linkquality')
            }
        )
        
        print(f"[Zigbee] Signal: {signal.signal_type.value} from {device.friendly_name} (confidence: {confidence:.2f})")
        return signal
