"""
设备池管理器 (Device Pool Manager)

统一管理所有硬件设备（摄像头、Zigbee传感器、Z-Wave设备）
设备独立于拓扑结构，可以动态绑定到Entry Point或Zone

设计原则：
1. 设备发现：自动从适配器发现新设备
2. 设备管理：增删改查设备
3. 动态绑定：设备可以绑定/解绑到拓扑
4. 持久化：设备配置保存到JSON文件
"""

import json
import uuid
from datetime import datetime, timezone
from typing import Dict, List, Optional, Any
from enum import Enum
from dataclasses import dataclass, asdict
from pathlib import Path


class DeviceType(str, Enum):
    """设备类型"""
    CAMERA = "camera"
    CONTACT = "contact"           # 门磁
    MOTION = "motion"             # Motion传感器
    GLASS_BREAK = "glass_break"   # 玻璃破碎
    KEYPAD = "keypad"             # 键盘
    SMOKE = "smoke"               # 烟雾
    WATER = "water"               # 水浸
    UNKNOWN = "unknown"


class DeviceStatus(str, Enum):
    """设备状态"""
    ONLINE = "online"             # 在线
    OFFLINE = "offline"           # 离线
    UNBOUND = "unbound"           # 未绑定到拓扑
    BOUND = "bound"               # 已绑定到拓扑
    ERROR = "error"               # 错误


class AdapterType(str, Enum):
    """适配器类型"""
    ZIGBEE2MQTT = "zigbee2mqtt"
    ZWAVE_JS = "zwave_js"
    CAMERA_RTSP = "camera_rtsp"
    MANUAL = "manual"


@dataclass
class Device:
    """设备数据模型"""
    
    # 基本信息
    device_id: str                    # 唯一ID (生成或从硬件获取)
    friendly_name: str                # 友好名称
    device_type: DeviceType           # 设备类型
    adapter_type: AdapterType         # 适配器类型
    
    # 硬件标识
    ieee_address: Optional[str] = None        # Zigbee IEEE地址
    zwave_node_id: Optional[str] = None       # Z-Wave节点ID
    camera_ip: Optional[str] = None           # 摄像头IP
    
    # 适配器特定信息
    mqtt_topic: Optional[str] = None          # MQTT topic
    adapter_device_id: Optional[str] = None   # 适配器中的设备ID
    
    # 状态
    status: DeviceStatus = DeviceStatus.UNBOUND
    last_seen: Optional[datetime] = None
    
    # 拓扑绑定
    bound_to_entry_point: Optional[str] = None    # 绑定的Entry Point ID
    bound_to_zone: Optional[str] = None           # 绑定的Zone ID
    sensor_id: Optional[str] = None               # 绑定后的Sensor ID
    
    # 设备特定配置
    config: Dict[str, Any] = None
    
    # 元数据
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    
    def __post_init__(self):
        if self.config is None:
            self.config = {}
        if self.created_at is None:
            self.created_at = datetime.now(timezone.utc)
        if self.updated_at is None:
            self.updated_at = datetime.now(timezone.utc)
    
    def to_dict(self) -> dict:
        """转换为字典"""
        data = asdict(self)
        # 转换枚举为字符串
        data['device_type'] = self.device_type.value
        data['adapter_type'] = self.adapter_type.value
        data['status'] = self.status.value
        # 转换datetime为ISO字符串
        if self.last_seen:
            data['last_seen'] = self.last_seen.isoformat()
        if self.created_at:
            data['created_at'] = self.created_at.isoformat()
        if self.updated_at:
            data['updated_at'] = self.updated_at.isoformat()
        return data
    
    @classmethod
    def from_dict(cls, data: dict) -> 'Device':
        """从字典创建"""
        # 转换枚举
        if 'device_type' in data:
            data['device_type'] = DeviceType(data['device_type'])
        if 'adapter_type' in data:
            data['adapter_type'] = AdapterType(data['adapter_type'])
        if 'status' in data:
            data['status'] = DeviceStatus(data['status'])
        
        # 转换datetime
        if 'last_seen' in data and data['last_seen']:
            data['last_seen'] = datetime.fromisoformat(data['last_seen'])
        if 'created_at' in data and data['created_at']:
            data['created_at'] = datetime.fromisoformat(data['created_at'])
        if 'updated_at' in data and data['updated_at']:
            data['updated_at'] = datetime.fromisoformat(data['updated_at'])
        
        return cls(**data)


class DevicePoolManager:
    """
    设备池管理器
    
    负责：
    1. 设备的增删改查
    2. 设备发现和自动添加
    3. 设备绑定到拓扑
    4. 设备状态更新
    5. 持久化存储
    """
    
    def __init__(self, storage_path: str = "./data/device_pool.json"):
        self.storage_path = Path(storage_path)
        self.devices: Dict[str, Device] = {}
        
        # 确保目录存在
        self.storage_path.parent.mkdir(parents=True, exist_ok=True)
        
        # 加载已有设备
        self.load()
    
    def add_device(self, device: Device) -> Device:
        """添加设备到池中"""
        # 如果没有device_id，生成一个
        if not device.device_id:
            device.device_id = self._generate_device_id(device)
        
        device.updated_at = datetime.now(timezone.utc)
        self.devices[device.device_id] = device
        self.save()
        
        print(f"[DevicePool] 添加设备: {device.friendly_name} ({device.device_type.value})")
        return device
    
    def get_device(self, device_id: str) -> Optional[Device]:
        """获取设备"""
        return self.devices.get(device_id)
    
    def get_device_by_friendly_name(self, friendly_name: str) -> Optional[Device]:
        """通过友好名称获取设备"""
        for device in self.devices.values():
            if device.friendly_name == friendly_name:
                return device
        return None
    
    def get_device_by_ieee(self, ieee_address: str) -> Optional[Device]:
        """通过Zigbee IEEE地址获取设备"""
        for device in self.devices.values():
            if device.ieee_address == ieee_address:
                return device
        return None
    
    def list_devices(
        self,
        device_type: Optional[DeviceType] = None,
        status: Optional[DeviceStatus] = None,
        adapter_type: Optional[AdapterType] = None
    ) -> List[Device]:
        """列出设备（支持过滤）"""
        devices = list(self.devices.values())
        
        if device_type:
            devices = [d for d in devices if d.device_type == device_type]
        if status:
            devices = [d for d in devices if d.status == status]
        if adapter_type:
            devices = [d for d in devices if d.adapter_type == adapter_type]
        
        return devices
    
    def update_device(self, device_id: str, updates: dict) -> Optional[Device]:
        """更新设备信息"""
        device = self.get_device(device_id)
        if not device:
            return None
        
        # 更新字段
        for key, value in updates.items():
            if hasattr(device, key):
                setattr(device, key, value)
        
        device.updated_at = datetime.now(timezone.utc)
        self.save()
        
        return device
    
    def delete_device(self, device_id: str) -> bool:
        """删除设备"""
        if device_id in self.devices:
            device = self.devices[device_id]
            print(f"[DevicePool] 删除设备: {device.friendly_name}")
            del self.devices[device_id]
            self.save()
            return True
        return False
    
    def bind_to_topology(
        self,
        device_id: str,
        entry_point_id: Optional[str] = None,
        zone_id: Optional[str] = None,
        sensor_id: Optional[str] = None
    ) -> Optional[Device]:
        """绑定设备到拓扑"""
        device = self.get_device(device_id)
        if not device:
            return None
        
        device.bound_to_entry_point = entry_point_id
        device.bound_to_zone = zone_id
        device.sensor_id = sensor_id or f"sensor_{device.device_type.value}_{device_id[:8]}"
        device.status = DeviceStatus.BOUND
        device.updated_at = datetime.now(timezone.utc)
        
        self.save()
        
        print(f"[DevicePool] 绑定设备: {device.friendly_name} → "
              f"EP:{entry_point_id}, Zone:{zone_id}, Sensor:{device.sensor_id}")
        
        return device
    
    def unbind_from_topology(self, device_id: str) -> Optional[Device]:
        """解绑设备"""
        device = self.get_device(device_id)
        if not device:
            return None
        
        device.bound_to_entry_point = None
        device.bound_to_zone = None
        device.sensor_id = None
        device.status = DeviceStatus.UNBOUND
        device.updated_at = datetime.now(timezone.utc)
        
        self.save()
        
        print(f"[DevicePool] 解绑设备: {device.friendly_name}")
        return device
    
    def update_device_status(
        self,
        device_id: str,
        status: DeviceStatus,
        last_seen: Optional[datetime] = None
    ):
        """更新设备状态"""
        device = self.get_device(device_id)
        if device:
            device.status = status
            if last_seen:
                device.last_seen = last_seen
            else:
                device.last_seen = datetime.now(timezone.utc)
            device.updated_at = datetime.now(timezone.utc)
            self.save()
    
    def auto_discover_zigbee_device(
        self,
        friendly_name: str,
        ieee_address: str,
        model: str,
        device_type_hint: Optional[str] = None
    ) -> Device:
        """
        自动发现Zigbee设备
        
        从Zigbee2MQTT获取设备信息并自动添加到设备池
        """
        # 检查是否已存在
        existing = self.get_device_by_ieee(ieee_address)
        if existing:
            print(f"[DevicePool] Zigbee设备已存在: {friendly_name}")
            return existing
        
        # 推断设备类型
        device_type = self._infer_device_type(model, device_type_hint)
        
        # 创建设备
        device = Device(
            device_id=f"zigbee_{ieee_address.replace(':', '')}",
            friendly_name=friendly_name,
            device_type=device_type,
            adapter_type=AdapterType.ZIGBEE2MQTT,
            ieee_address=ieee_address,
            mqtt_topic=f"zigbee2mqtt/{friendly_name}",
            adapter_device_id=ieee_address,
            status=DeviceStatus.UNBOUND,
            config={"model": model}
        )
        
        return self.add_device(device)
    
    def auto_discover_camera(
        self,
        friendly_name: str,
        camera_ip: str,
        camera_config: dict
    ) -> Device:
        """自动发现摄像头"""
        # 检查是否已存在
        for device in self.devices.values():
            if device.camera_ip == camera_ip:
                print(f"[DevicePool] 摄像头已存在: {camera_ip}")
                return device
        
        # 创建设备
        device = Device(
            device_id=f"camera_{camera_ip.replace('.', '_')}",
            friendly_name=friendly_name,
            device_type=DeviceType.CAMERA,
            adapter_type=AdapterType.CAMERA_RTSP,
            camera_ip=camera_ip,
            status=DeviceStatus.UNBOUND,
            config=camera_config
        )
        
        return self.add_device(device)
    
    def _infer_device_type(self, model: str, hint: Optional[str] = None) -> DeviceType:
        """推断设备类型"""
        model_lower = model.lower()
        
        # 使用hint
        if hint:
            hint_lower = hint.lower()
            if "contact" in hint_lower or "door" in hint_lower:
                return DeviceType.CONTACT
            if "motion" in hint_lower or "pir" in hint_lower:
                return DeviceType.MOTION
            if "glass" in hint_lower or "vibration" in hint_lower:
                return DeviceType.GLASS_BREAK
        
        # 根据型号推断
        if "contact" in model_lower or "door" in model_lower or "window" in model_lower:
            return DeviceType.CONTACT
        if "motion" in model_lower or "pir" in model_lower or "occupancy" in model_lower:
            return DeviceType.MOTION
        if "glass" in model_lower or "vibration" in model_lower:
            return DeviceType.GLASS_BREAK
        if "smoke" in model_lower:
            return DeviceType.SMOKE
        if "water" in model_lower or "leak" in model_lower:
            return DeviceType.WATER
        
        return DeviceType.UNKNOWN
    
    def _generate_device_id(self, device: Device) -> str:
        """生成设备ID"""
        if device.ieee_address:
            return f"zigbee_{device.ieee_address.replace(':', '')}"
        if device.camera_ip:
            return f"camera_{device.camera_ip.replace('.', '_')}"
        if device.zwave_node_id:
            return f"zwave_{device.zwave_node_id}"
        
        # 使用UUID
        return f"device_{uuid.uuid4().hex[:12]}"
    
    def save(self):
        """保存到文件"""
        data = {
            "devices": {
                device_id: device.to_dict()
                for device_id, device in self.devices.items()
            },
            "saved_at": datetime.now(timezone.utc).isoformat()
        }
        
        with open(self.storage_path, 'w') as f:
            json.dump(data, f, indent=2)
    
    def load(self):
        """从文件加载"""
        if not self.storage_path.exists():
            print(f"[DevicePool] 初始化新的设备池")
            return
        
        try:
            with open(self.storage_path, 'r') as f:
                data = json.load(f)
            
            devices_data = data.get('devices', {})
            for device_id, device_dict in devices_data.items():
                self.devices[device_id] = Device.from_dict(device_dict)
            
            print(f"[DevicePool] 加载了 {len(self.devices)} 个设备")
            
        except Exception as e:
            print(f"[DevicePool] 加载失败: {e}")
    
    def get_stats(self) -> dict:
        """获取统计信息"""
        total = len(self.devices)
        by_type = {}
        by_status = {}
        
        for device in self.devices.values():
            # 按类型统计
            dt = device.device_type.value
            by_type[dt] = by_type.get(dt, 0) + 1
            
            # 按状态统计
            st = device.status.value
            by_status[st] = by_status.get(st, 0) + 1
        
        return {
            "total": total,
            "by_type": by_type,
            "by_status": by_status,
            "unbound_count": by_status.get(DeviceStatus.UNBOUND.value, 0),
            "bound_count": by_status.get(DeviceStatus.BOUND.value, 0),
        }
