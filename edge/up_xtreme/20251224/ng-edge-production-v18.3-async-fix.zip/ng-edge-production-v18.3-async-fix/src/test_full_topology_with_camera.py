#!/usr/bin/env python3
"""
完整拓扑测试 - 摄像头 + Zigbee传感器集成

完整的报警链路测试:
1. 摄像头检测到人 (EXTERIOR) → PRE状态
2. 门磁检测开门 (ENTRY_EXIT) → PENDING状态  
3. Motion检测室内人员 (INTERIOR) → TRIGGERED状态

拓扑结构:
┌─────────────────────────────────────────┐
│      Entry Point: ep_back_door          │
├─────────────────────────────────────────┤
│ [1] EXTERIOR (zone_backyard)            │
│     └─ 摄像头 → PERSON_DETECTED → PRE  │
│                                         │
│ [2] ENTRY_EXIT (zone_back_door)         │
│     └─ 门磁 → DOOR_OPEN → PENDING      │
│                                         │
│ [3] INTERIOR (zone_living_room)         │
│     └─ Motion → MOTION_ACTIVE → TRIGGER │
└─────────────────────────────────────────┘
"""

import subprocess
import time
import requests
import sys
import os

os.chdir(os.path.dirname(os.path.abspath(__file__)))

BASE_URL = "http://localhost:8000"

# 摄像头配置 - 修改为你的实际IP
CAMERA_IP = "10.0.0.155"  # Reolink RLC-810WA
CAMERA_USERNAME = "admin"
CAMERA_PASSWORD = "Zafac05@a"

def print_section(title):
    """打印分节标题"""
    print("\n" + "=" * 70)
    print(f"  {title}")
    print("=" * 70)

def start_server():
    """启动服务器"""
    print_section("步骤1: 启动NG Edge服务器")
    
    subprocess.run(["pkill", "-f", "uvicorn.*ng_edge"], stderr=subprocess.DEVNULL)
    time.sleep(1)
    
    server_process = subprocess.Popen(
        ["uvicorn", "ng_edge.api.manager:app", "--host", "0.0.0.0", "--port", "8000"],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True
    )
    
    print("\n等待服务器启动...")
    for i in range(15):
        try:
            resp = requests.get(f"{BASE_URL}/api/pipeline/status", timeout=1)
            if resp.status_code == 200:
                print(f"✅ 服务器已就绪")
                return server_process
        except:
            pass
        time.sleep(1)
    
    print("❌ 服务器启动超时")
    server_process.terminate()
    return None

def load_config():
    """加载标准配置"""
    print_section("步骤2: 加载标准配置")
    
    try:
        resp = requests.post(f"{BASE_URL}/api/load-standard-config")
        if resp.status_code == 200:
            print("✅ 标准配置加载成功")
            print("\n配置的传感器:")
            print("  - sensor_camera_backyard (EXTERIOR zone)")
            print("  - sensor_door_back (ENTRY_EXIT zone)")
            print("  - sensor_pir_living (INTERIOR zone)")
            return True
        else:
            print(f"❌ 配置加载失败: {resp.status_code}")
            return False
    except Exception as e:
        print(f"❌ 错误: {e}")
        return False

def start_camera():
    """启动摄像头"""
    print_section("步骤3: 启动摄像头")
    
    print(f"\n摄像头配置:")
    print(f"  IP: {CAMERA_IP}")
    print(f"  Sensor ID: sensor_camera_backyard")
    print(f"  Zone: zone_backyard (EXTERIOR)")
    print(f"  Detection FPS: 5.0")
    
    try:
        resp = requests.post(f"{BASE_URL}/api/camera/start",
            json={
                "sensor_id": "sensor_camera_backyard",
                "zone_id": "zone_backyard",
                "camera_ip": CAMERA_IP,
                "camera_username": CAMERA_USERNAME,
                "camera_password": CAMERA_PASSWORD,
                "detection_fps": 5.0,
                "confidence_threshold": 0.6
            }
        )
        
        if resp.status_code == 200:
            print("\n✅ 摄像头启动成功")
            return True
        else:
            result = resp.json()
            print(f"\n❌ 摄像头启动失败: {resp.status_code}")
            print(f"   错误: {result.get('detail', 'Unknown error')}")
            print("\n⚠️  可能的原因:")
            print(f"   - 摄像头IP不正确 (当前: {CAMERA_IP})")
            print("   - 用户名或密码错误")
            print("   - 网络连接问题")
            return False
            
    except Exception as e:
        print(f"\n❌ 错误: {e}")
        return False

def start_zigbee():
    """启动Zigbee MQTT客户端"""
    print_section("步骤4: 启动Zigbee MQTT客户端")
    
    print("\nZigbee设备配置:")
    print("  1. Back Door Contact → sensor_door_back")
    print("  2. Family Room Motion → sensor_pir_living")
    
    try:
        resp = requests.post(f"{BASE_URL}/api/zigbee/start",
            json={
                "mqtt_host": "localhost",
                "mqtt_port": 1883,
                "devices": [
                    {
                        "friendly_name": "Back Door Contact",
                        "sensor_id": "sensor_door_back",
                        "sensor_type": "door_contact",
                        "zone_id": "zone_back_door",
                        "device_type": "contact"
                    },
                    {
                        "friendly_name": "Family Room Motion",
                        "sensor_id": "sensor_pir_living",
                        "sensor_type": "motion_pir",
                        "zone_id": "zone_living_room",
                        "device_type": "motion"
                    }
                ]
            }
        )
        
        if resp.status_code == 200:
            print("\n✅ Zigbee客户端启动成功")
            return True
        else:
            result = resp.json()
            print(f"\n❌ Zigbee启动失败: {resp.status_code}")
            print(f"   错误: {result.get('detail', 'Unknown error')}")
            return False
            
    except Exception as e:
        print(f"\n❌ 错误: {e}")
        return False

def set_away_mode():
    """设置AWAY模式"""
    print_section("步骤5: 设置AWAY模式")
    
    try:
        resp = requests.post(f"{BASE_URL}/api/pipeline/mode", json={"mode": "away"})
        if resp.status_code == 200:
            print("✅ 已设置AWAY模式")
            return True
        else:
            print(f"❌ 设置模式失败: {resp.status_code}")
            return False
    except Exception as e:
        print(f"❌ 错误: {e}")
        return False

def monitor_system(duration=90):
    """监控系统状态"""
    print_section("步骤6: 监控完整拓扑")
    
    print("\n📋 完整测试场景:")
    print("  1️⃣  在摄像头前走动 → 触发PERSON_DETECTED → 预期: PRE")
    print("  2️⃣  打开物理后门 → 触发DOOR_OPEN → 预期: PENDING (30秒倒计时)")
    print("  3️⃣  在Family Room走动 → 触发MOTION → 预期: TRIGGERED")
    print()
    print(f"将监控 {duration} 秒...")
    print("按 Ctrl+C 提前停止")
    print()
    
    start_time = time.time()
    last_alarm_state = None
    last_ep_state = {}
    camera_signal_count = 0
    zigbee_signal_count = 0
    
    try:
        while time.time() - start_time < duration:
            current_time = time.strftime("%H:%M:%S")
            
            # 获取系统状态
            try:
                resp = requests.get(f"{BASE_URL}/api/pipeline/status", timeout=1)
                status = resp.json()
                
                mode = status.get('mode', 'unknown')
                alarm = status.get('alarm_state', 'unknown')
                
                # 检查Alarm状态变化
                if alarm != last_alarm_state:
                    print(f"[{current_time}] 🚨 Alarm状态: {last_alarm_state} → {alarm}")
                    last_alarm_state = alarm
                
                # 检查EntryPoint状态
                ep_states = status.get('entry_point_states', {})
                for ep_id, state in ep_states.items():
                    if state != last_ep_state.get(ep_id):
                        print(f"[{current_time}] 🚪 EntryPoint {ep_id}: {last_ep_state.get(ep_id, 'unknown')} → {state}")
                        last_ep_state[ep_id] = state
                
                # 检查摄像头信号
                camera_resp = requests.get(f"{BASE_URL}/api/camera/status", timeout=1)
                camera = camera_resp.json()
                if camera.get('active'):
                    camera_stats = camera.get('stats', {})
                    recent_camera = camera_stats.get('recent_signals', [])
                    if len(recent_camera) > camera_signal_count:
                        new_signals = recent_camera[camera_signal_count:len(recent_camera)]
                        for sig in reversed(new_signals):
                            print(f"[{current_time}] 📹 摄像头: {sig.get('signal_type')} (conf: {sig.get('confidence', 0):.2f})")
                        camera_signal_count = len(recent_camera)
                
                # 检查Zigbee信号
                zigbee_resp = requests.get(f"{BASE_URL}/api/zigbee/status", timeout=1)
                zigbee = zigbee_resp.json()
                recent_zigbee = zigbee.get('recent_signals', [])
                if len(recent_zigbee) > zigbee_signal_count:
                    new_signals = recent_zigbee[zigbee_signal_count:len(recent_zigbee)]
                    for sig in reversed(new_signals):
                        print(f"[{current_time}] 📡 Zigbee: {sig.get('signal_type')} from {sig.get('sensor_id')}")
                    zigbee_signal_count = len(recent_zigbee)
                
            except Exception as e:
                pass  # 静默失败，继续监控
            
            time.sleep(2)
        
        print(f"\n⏰ 监控时间结束 ({duration}秒)")
        
    except KeyboardInterrupt:
        print("\n\n⚠️  用户停止监控")

def show_final_status():
    """显示最终状态"""
    print_section("最终状态报告")
    
    try:
        # 系统状态
        resp = requests.get(f"{BASE_URL}/api/pipeline/status")
        status = resp.json()
        
        print("\n系统状态:")
        print(f"  Mode: {status.get('mode')}")
        print(f"  Alarm: {status.get('alarm_state')}")
        
        ep_states = status.get('entry_point_states', {})
        if ep_states:
            print("\nEntry Point状态:")
            for ep_id, state in ep_states.items():
                print(f"  {ep_id}: {state}")
        
        # 摄像头状态
        camera_resp = requests.get(f"{BASE_URL}/api/camera/status")
        camera = camera_resp.json()
        
        if camera.get('active'):
            print("\n摄像头状态:")
            print(f"  Active: {camera.get('active')}")
            stats = camera.get('stats', {})
            print(f"  Total signals: {stats.get('signals_generated', 0)}")
            
            recent_camera = stats.get('recent_signals', [])
            if recent_camera:
                print(f"\n  最近检测 (最多5条):")
                for i, sig in enumerate(recent_camera[:5], 1):
                    ts = sig.get('timestamp', '')[:19]
                    print(f"    {i}. {sig.get('signal_type')} (conf: {sig.get('confidence', 0):.2f}) at {ts}")
        
        # Zigbee状态
        zigbee_resp = requests.get(f"{BASE_URL}/api/zigbee/status")
        zigbee = zigbee_resp.json()
        recent_zigbee = zigbee.get('recent_signals', [])
        
        if recent_zigbee:
            print(f"\nZigbee信号历史 (最多5条):")
            for i, sig in enumerate(recent_zigbee[:5], 1):
                ts = sig.get('timestamp', '')[:19]
                print(f"  {i}. {sig.get('signal_type'):15s} from {sig.get('sensor_id'):20s} at {ts}")
        
    except Exception as e:
        print(f"❌ 获取状态失败: {e}")

def main():
    """主函数"""
    server_process = None
    
    try:
        print("\n" + "🎯" * 35)
        print("  完整拓扑测试 - 摄像头 + Zigbee集成")
        print("🎯" * 35)
        print("\n📐 测试拓扑:")
        print("  EXTERIOR (摄像头) → PRE")
        print("  ENTRY_EXIT (门磁) → PENDING")
        print("  INTERIOR (Motion) → TRIGGERED")
        
        # 1. 启动服务器
        server_process = start_server()
        if not server_process:
            return 1
        
        time.sleep(2)
        
        # 2. 加载配置
        if not load_config():
            return 1
        
        time.sleep(1)
        
        # 3. 启动摄像头
        camera_ok = start_camera()
        if not camera_ok:
            print("\n⚠️  摄像头启动失败，继续测试（只用Zigbee）")
        
        time.sleep(2)
        
        # 4. 启动Zigbee
        zigbee_ok = start_zigbee()
        if not zigbee_ok:
            print("\n⚠️  Zigbee启动失败，继续测试（只用摄像头）")
        
        time.sleep(2)
        
        # 5. 设置AWAY模式
        if not set_away_mode():
            return 1
        
        time.sleep(1)
        
        # 6. 监控系统
        monitor_system(duration=90)
        
        # 7. 显示最终状态
        show_final_status()
        
        # 总结
        print_section("测试完成")
        print("\n✅ 预期的完整链路:")
        print("   1. 摄像头看到人 → Alarm: quiet → PRE")
        print("   2. Door打开 → Alarm: PRE → PENDING (30秒倒计时)")
        print("   3. Motion检测 → Alarm: PENDING → TRIGGERED")
        
        print("\n服务器仍在运行...")
        print("Web UI: http://localhost:8000")
        print("按Ctrl+C停止")
        
        # 保持运行
        try:
            server_process.wait()
        except KeyboardInterrupt:
            print("\n\n停止服务器...")
        
        return 0
        
    except KeyboardInterrupt:
        print("\n\n测试中断")
        return 1
        
    finally:
        if server_process:
            server_process.terminate()
            try:
                server_process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                server_process.kill()

if __name__ == "__main__":
    sys.exit(main())
