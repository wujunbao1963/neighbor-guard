#!/usr/bin/env python3
"""
NG Edge - Event Ingest Test Script

Tests event ingest against a real server using saved device credentials.

Usage:
    # Make sure you've already registered the device
    python test_event_ingest.py --server http://YOUR_SERVER:3000
"""

import asyncio
import argparse
import sys
import uuid
from pathlib import Path
from datetime import datetime, timezone

# Add parent to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent))

from ng_edge.cloud import CloudConfig, CloudClient


def create_test_event() -> dict:
    """Create a minimal test event matching the contract schema."""
    event_id = str(uuid.uuid4())
    now = datetime.now(timezone.utc).isoformat()
    
    return {
        "eventId": event_id,
        "occurredAt": now,
        "eventType": "motion_detected",
        "severity": "LOW",
        "notificationLevel": "NORMAL",
        "status": "OPEN",
        "title": "Test motion detected (integration test)",
        "description": "This is a test event from the edge integration test",
        "explainSummary": {
            "ruleId": "TEST_RULE",
            "keySignals": [
                {
                    "code": "pir.motion",
                    "source": "pir",
                    "sourceRef": "test_sensor",
                    "value": "motion",
                }
            ],
            "mode": "HOME",
        },
    }


def create_break_in_event() -> dict:
    """Create a more complex break-in test event."""
    event_id = str(uuid.uuid4())
    zone_id = str(uuid.uuid4())
    entry_point_id = str(uuid.uuid4())
    now = datetime.now(timezone.utc).isoformat()
    
    return {
        "eventId": event_id,
        "occurredAt": now,
        "eventType": "break_in_attempt",
        "severity": "HIGH",
        "notificationLevel": "HIGH",
        "status": "OPEN",
        "title": "Possible break-in attempt (test)",
        "description": "Front door opened + indoor motion (AWAY mode) - TEST",
        "zoneId": zone_id,
        "entryPointId": entry_point_id,
        "explainSummary": {
            "ruleId": "R1_BREAKIN_DOOR_PIR",
            "keySignals": [
                {
                    "code": "door_contact.open",
                    "source": "door_contact",
                    "sourceRef": "front_door",
                    "value": "open",
                },
                {
                    "code": "pir.motion",
                    "source": "pir",
                    "sourceRef": "indoor_entry",
                    "value": "motion",
                }
            ],
            "mode": "AWAY",
        },
        "alarmState": "ALARMING",
        # Note: mode, userAlertLevel, dispatchReadinessLevel are v1.1+ fields
        # Server may not accept them if running v1.0 contracts
    }


async def test_simple_ingest(client: CloudClient) -> bool:
    """Test 1: Simple event ingest."""
    print("\n" + "=" * 60)
    print("TEST 1: Simple Event Ingest")
    print("=" * 60)
    
    event = create_test_event()
    print(f"Event ID: {event['eventId']}")
    print(f"Event Type: {event['eventType']}")
    
    success, data, error = await client.ingest_event(event)
    
    if success:
        print(f"✓ Event ingested!")
        print(f"  Server received at: {data.get('serverReceivedAt')}")
        print(f"  Deduped: {data.get('deduped', False)}")
        return True
    else:
        print(f"✗ Ingest failed: {error}")
        return False


async def test_idempotency(client: CloudClient) -> bool:
    """Test 2: Idempotency - same event twice should be deduped."""
    print("\n" + "=" * 60)
    print("TEST 2: Idempotency (same event twice)")
    print("=" * 60)
    
    event = create_test_event()
    idempotency_key = str(uuid.uuid4())
    
    print(f"Event ID: {event['eventId']}")
    print(f"Idempotency Key: {idempotency_key}")
    
    # First ingest
    print("\nFirst ingest...")
    success1, data1, error1 = await client.ingest_event(event, idempotency_key)
    
    if not success1:
        print(f"✗ First ingest failed: {error1}")
        return False
    
    print(f"  Deduped: {data1.get('deduped', False)}")
    
    # Second ingest (same event, same key)
    print("\nSecond ingest (same event)...")
    success2, data2, error2 = await client.ingest_event(event, idempotency_key)
    
    if not success2:
        print(f"✗ Second ingest failed: {error2}")
        return False
    
    deduped = data2.get("deduped", False)
    print(f"  Deduped: {deduped}")
    
    if deduped:
        print("✓ Idempotency works - second request was deduped")
        return True
    else:
        print("⚠ Warning: Second request was not deduped (may be expected)")
        return True  # Not a failure, server might not dedupe


async def test_break_in_event(client: CloudClient) -> bool:
    """Test 3: Complex break-in event."""
    print("\n" + "=" * 60)
    print("TEST 3: Break-in Event (complex)")
    print("=" * 60)
    
    event = create_break_in_event()
    print(f"Event ID: {event['eventId']}")
    print(f"Event Type: {event['eventType']}")
    print(f"Severity: {event['severity']}")
    print(f"Alarm State: {event.get('alarmState')}")
    
    success, data, error = await client.ingest_event(event)
    
    if success:
        print(f"✓ Break-in event ingested!")
        print(f"  Server received at: {data.get('serverReceivedAt')}")
        return True
    else:
        print(f"✗ Ingest failed: {error}")
        return False


async def main():
    parser = argparse.ArgumentParser(description="NG Edge Event Ingest Test")
    parser.add_argument(
        "--server", "-s",
        required=True,
        help="Server URL (e.g., http://192.168.1.100:3000)",
    )
    parser.add_argument(
        "--config-dir",
        default="./config",
        help="Config directory with device credentials",
    )
    
    args = parser.parse_args()
    
    print("=" * 60)
    print("NG Edge - Event Ingest Test")
    print("=" * 60)
    print(f"Server URL: {args.server}")
    print(f"Config Dir: {args.config_dir}")
    
    # Load config with saved credentials
    config = CloudConfig(
        server_url=args.server,
        config_dir=args.config_dir,
    )
    
    # Load credentials
    if not config.load_credentials():
        print("\n✗ ERROR: No device credentials found!")
        print("  Run register_device.sh first to register the device.")
        return 1
    
    print(f"\nDevice ID: {config.credentials.device_id}")
    print(f"Circle ID: {config.credentials.circle_id}")
    
    client = CloudClient(config)
    
    results = []
    
    try:
        # Test 1: Simple ingest
        results.append(("Simple Event Ingest", await test_simple_ingest(client)))
        
        # Test 2: Idempotency
        results.append(("Idempotency", await test_idempotency(client)))
        
        # Test 3: Complex event
        results.append(("Break-in Event", await test_break_in_event(client)))
        
    finally:
        await client.close()
    
    # Summary
    print("\n" + "=" * 60)
    print("TEST SUMMARY")
    print("=" * 60)
    
    passed = 0
    failed = 0
    for name, success in results:
        status = "✓ PASS" if success else "✗ FAIL"
        print(f"  {status}: {name}")
        if success:
            passed += 1
        else:
            failed += 1
    
    print("-" * 60)
    print(f"  Total: {passed} passed, {failed} failed")
    
    return 0 if failed == 0 else 1


if __name__ == "__main__":
    exit_code = asyncio.run(main())
    sys.exit(exit_code)
