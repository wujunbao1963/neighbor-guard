# NG Edge Manager Enhanced - v1.0

## 🎯 这是什么？

这是一个**完整增强版**的 NG Edge Manager，包含：

- ✋ **手动模式**: 手工输入信号（测试/演示）
- 📹 **摄像头模式**: 实时 YOLO 检测（生产环境）
- 🎨 **现代化 UI**: 深色主题、实时监控、事件日志
- 📊 **完整功能**: Pipeline、Alarm State、Event 管理

---

## 🚀 快速开始（三步）

### 1. 解压

```bash
unzip ng-edge-production-enhanced-v1.0.zip
cd ng-edge-production-v1.0/ng-edge-production
```

### 2. 启动

```bash
./start.sh
```

### 3. 访问

打开浏览器：**http://localhost:8000**

---

## 🎮 使用方法

### 手动模式（默认）

1. 打开 http://localhost:8000
2. 默认在 "Manual Input" 模式
3. 选择信号类型、Zone ID、置信度
4. 点击 "Send Signal"
5. 观察系统状态变化

### 摄像头模式

1. 点击 "Real Camera" 按钮
2. 配置参数：
   - Camera IP: 10.0.0.155
   - Detection FPS: 5.0
   - Threshold: 0.6
3. 点击 "Start Camera"
4. 观察实时检测结果

---

## 📦 新增功能

### UI 增强
- ✅ 双模式切换
- ✅ 实时状态监控
- ✅ 摄像头状态指示器
- ✅ 事件日志滚动
- ✅ 统计数据展示

### API 增强
- ✅ POST /api/camera/start
- ✅ POST /api/camera/stop
- ✅ GET /api/camera/status
- ✅ 所有原有 API 保持不变

### 功能增强
- ✅ 实时 YOLO 检测
- ✅ 自动 Signal 生成
- ✅ Debounce 过滤
- ✅ Event 自动管理

---

## 📁 文件结构

```
ng-edge-production/
├── start.sh                          ← 启动脚本
├── README_ENHANCED.md                ← 本文件
├── src/
│   └── ng_edge/
│       ├── api/
│       │   ├── manager.py            ← 已增强（添加 camera API）
│       │   ├── camera_api.py         ← 新增（摄像头 API）
│       │   └── edge_manager_enhanced.html  ← 新增（UI）
│       └── hardware/
│           └── camera_signal_source.py  ← 新增（Signal 生成）
```

---

## 🔧 系统要求

### Python 依赖

```bash
pip install fastapi uvicorn opencv-python ultralytics --break-system-packages
```

### 硬件（可选）

- Reolink 摄像头（用于实时检测模式）
- 任何支持 RTSP 的摄像头

---

## 🌐 访问地址

- **UI 界面**: http://localhost:8000
- **API 文档**: http://localhost:8000/docs
- **健康检查**: http://localhost:8000/api/pipeline/status

---

## 📊 测试场景

### 场景 1: 快速测试

```
1. 启动服务器
2. 使用手动模式
3. 发送 "person_detected" 信号
4. 观察 Alarm State: QUIET → PRE
5. 检查事件日志
```

### 场景 2: 实际部署

```
1. 切换到摄像头模式
2. 配置摄像头 IP
3. 启动实时检测
4. 在摄像头前走动
5. 观察自动检测和 Signal 生成
```

---

## 🐛 故障排除

### 问题 1: 启动失败

```bash
# 检查 Python 版本
python3 --version  # 需要 3.10+

# 安装依赖
pip install fastapi uvicorn --break-system-packages
```

### 问题 2: UI 无法访问

```bash
# 检查端口
netstat -tuln | grep 8000

# 检查服务器日志
# 应该看到 "Uvicorn running on http://0.0.0.0:8000"
```

### 问题 3: 摄像头无法连接

```bash
# 检查摄像头 IP
ping 10.0.0.155

# 检查 RTSP 端口
nc -zv 10.0.0.155 554

# 安装依赖
pip install opencv-python ultralytics --break-system-packages
```

---

## 📋 原有功能

所有原有功能完全保留：

- ✅ Zone 管理
- ✅ Entry Point 管理
- ✅ Sensor 模拟
- ✅ Pipeline 控制
- ✅ Drill 执行
- ✅ Ring Keypad 集成
- ✅ 所有原有 API 端点

---

## 🎯 版本信息

- **版本**: 1.0 Enhanced
- **PRD**: v7.4.2
- **新增**: 双模式输入、实时摄像头检测
- **兼容**: 完全向后兼容原有功能

---

## 📞 技术支持

如有问题：

1. 查看 API 文档: http://localhost:8000/docs
2. 检查服务器日志输出
3. 验证 Python 依赖已安装

---

**享受增强的 NG Edge Manager！** 🎉
